import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { app, ipcMain, shell, type BrowserWindow } from 'electron';
import {
  IPC_CHANNELS,
  CreateAcademicYearSchema,
  SwitchAcademicYearSchema,
  UpdateThemeSettingSchema,
  OpenWhatsAppInputSchema,
  type AppInfoDto,
  type GlobalSettingsDto,
  type SetupStateDto,
  type AcademicYearDto,
} from '@tibyan/contracts';
import type { AcademicYearRow, DatabaseType } from '@tibyan/db';
import { createRawDatabase, migrateAcademicDatabase } from '@tibyan/db';
import { requirePermission } from '@tibyan/core';
import type { Runtime } from '../runtime.js';
import { safeIpcCall } from './errors.js';
import { validateIpcSender, isAllowedWhatsAppUrl } from '../security.js';

let persistedTheme: 'light' | 'dark' | 'system' = 'system';

function toAcademicYearDto(year: AcademicYearRow): AcademicYearDto {
  return {
    id: year.id,
    name: year.name,
    dbFilename: year.dbFilename,
    isActive: year.isActive,
    isArchived: year.isArchived,
    createdAt: year.createdAt,
    updatedAt: year.updatedAt,
  };
}

export function registerSystemIpcHandlers(runtime: Runtime, mainWindow: BrowserWindow | null): void {
  // 1. Get Application Information
  ipcMain.handle(IPC_CHANNELS.SYSTEM_GET_INFO, async (event) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall((): AppInfoDto => {
      return {
        nameEn: 'Tibyan',
        nameAr: 'تِبيان',
        version: '1.0.0',
        isPackaged: app?.isPackaged ?? false,
        platform: process.platform,
        appDataDir: runtime.paths.appDataDir,
      };
    });
  });

  // 2. Get Global Settings
  ipcMain.handle(IPC_CHANNELS.SYSTEM_GET_SETTINGS, async (event) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall((): GlobalSettingsDto => {
      return {
        theme: persistedTheme,
        activeAcademicYearId: runtime.activeAcademicYear?.id ?? null,
        activeAcademicYearName: runtime.activeAcademicYear?.name ?? null,
      };
    });
  });

  // 3. Get Setup State (First-run detection derived authoritatively from DB)
  ipcMain.handle(IPC_CHANNELS.SYSTEM_GET_SETUP_STATE, async (event) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall((): SetupStateDto => {
      const allUsers = runtime.academicYearRepo ? runtime.authService.userRepo.listAll() : [];
      const hasOwner = allUsers.some((u) => u.role === 'OWNER');
      const hasActiveAcademicYear = runtime.activeAcademicYear !== null;
      return {
        isSetupComplete: hasOwner && hasActiveAcademicYear,
        hasOwner,
        hasActiveAcademicYear,
        activeAcademicYearName: runtime.activeAcademicYear?.name ?? null,
      };
    });
  });

  // 4. Update Theme Setting
  ipcMain.handle(IPC_CHANNELS.SYSTEM_UPDATE_THEME, async (event, payload) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall(() => {
      const validated = UpdateThemeSettingSchema.parse(payload);
      persistedTheme = validated.theme;
      return undefined;
    });
  });

  // 5. List Academic Years
  ipcMain.handle(IPC_CHANNELS.SYSTEM_LIST_ACADEMIC_YEARS, async (event) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall(() => {
      const years = runtime.academicYearRepo.listAll();
      return years.map(toAcademicYearDto);
    });
  });

  // 6. Create Academic Year
  ipcMain.handle(IPC_CHANNELS.SYSTEM_CREATE_ACADEMIC_YEAR, async (event, payload) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall(() => {
      // If a MAIN session is active, verify SETTINGS_WRITE (Owner satisfies this)
      if (runtime.currentSession) {
        const actor = runtime.requireAuthenticatedActor();
        requirePermission(actor.role, actor.permissions ?? [], 'SETTINGS_WRITE');
      }

      const validated = CreateAcademicYearSchema.parse(payload);
      const existing = runtime.academicYearRepo.findByName(validated.name);
      if (existing) {
        throw new Error(`Academic year ${validated.name} already exists.`);
      }

      const yearId = crypto.randomUUID();
      const now = new Date().toISOString();
      const dbFilename = `tibyan-${validated.name}.sqlite`;

      // Check for filename collision in the registry
      const allYears = runtime.academicYearRepo.listAll();
      const existingFilename = allYears.find((y) => y.dbFilename === dbFilename);
      if (existingFilename) {
        throw new Error(`Academic year database ${dbFilename} is already registered.`);
      }

      // Security check: dbFilename traversal and boundary escape
      const normalized = path.normalize(dbFilename);
      if (path.isAbsolute(normalized) || normalized.includes('..') || path.basename(normalized) !== normalized) {
        throw new Error(`SECURITY_ERROR: Invalid academic year dbFilename traversal detected: ${dbFilename}`);
      }

      const resolvedCanonicalDir = path.resolve(runtime.paths.academicYearsDbDir);
      const targetFilePath = runtime.inMemory
        ? ':memory:'
        : path.resolve(resolvedCanonicalDir, normalized);

      if (!runtime.inMemory && !targetFilePath.startsWith(resolvedCanonicalDir)) {
        throw new Error(`SECURITY_ERROR: Academic year database path escaped canonical root: ${targetFilePath}`);
      }

      // Check for existing physical file collision on disk before mutating anything
      if (!runtime.inMemory && fs.existsSync(targetFilePath)) {
        throw new Error(`DATABASE_FILE_COLLISION: File already exists on disk: ${dbFilename}`);
      }

      let fileCreatedByThisOperation = false;

      // 1. Create and migrate the NEW academic SQLite database BEFORE committing registry row
      if (!runtime.inMemory) {
        let tempRaw: DatabaseType | null = null;
        try {
          tempRaw = createRawDatabase(targetFilePath);
          fileCreatedByThisOperation = true;
          migrateAcademicDatabase(tempRaw);
        } catch (dbErr) {
          if (tempRaw?.open) {
            tempRaw.close();
          }
          // Remove only the new/partial file created by this operation
          if (fileCreatedByThisOperation && fs.existsSync(targetFilePath)) {
            try {
              fs.unlinkSync(targetFilePath);
            } catch {}
          }
          throw dbErr;
        } finally {
          if (tempRaw?.open) {
            tempRaw.close();
          }
        }
      }

      const shouldActivate = allYears.length === 0;

      // 2. Commit the registry row in system database
      let created: AcademicYearRow;
      try {
        created = runtime.academicYearRepo.create({
          id: yearId,
          name: validated.name,
          dbFilename,
          isActive: shouldActivate,
          isArchived: false,
          createdAt: now,
          updatedAt: now,
        });
      } catch (registryErr) {
        // If database creation succeeded but registry insertion fails, delete only the newly created database file
        if (!runtime.inMemory && fileCreatedByThisOperation && fs.existsSync(targetFilePath)) {
          try {
            fs.unlinkSync(targetFilePath);
          } catch {}
        }
        throw registryErr;
      }

      // 3. Mount the year if shouldActivate
      if (shouldActivate) {
        try {
          runtime.mountAcademicYear(created);
        } catch (mountErr) {
          // If final runtime mount fails after both resources are valid,
          // preserve the registered year and valid database file so startup/recovery can retry.
          // Do not silently destroy them.
          throw mountErr;
        }
      }

      return toAcademicYearDto(created);
    });
  });

  // 7. Switch Active Academic Year (protected: requires SETTINGS_WRITE on MAIN actor)
  ipcMain.handle(IPC_CHANNELS.SYSTEM_SWITCH_ACADEMIC_YEAR, async (event, payload) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall(() => {
      const actor = runtime.requireAuthenticatedActor();
      requirePermission(actor.role, actor.permissions ?? [], 'SETTINGS_WRITE');

      const validated = SwitchAcademicYearSchema.parse(payload);
      const targetYear = runtime.academicYearRepo.findById(validated.academicYearId);
      if (!targetYear) {
        throw new Error('ACADEMIC_YEAR_NOT_FOUND: The requested academic year was not found.');
      }

      runtime.academicYearRepo.setActiveYear(targetYear.id);
      const refreshed = runtime.academicYearRepo.findById(targetYear.id)!;
      runtime.mountAcademicYear(refreshed);
      return undefined;
    });
  });

  // 8. Open WhatsApp External Link (Strictly Allowlisted)
  ipcMain.handle(IPC_CHANNELS.SYSTEM_OPEN_WHATSAPP, async (event, payload) => {
    if (!validateIpcSender(event, mainWindow)) {
      throw new Error('UNAUTHORIZED_IPC_SENDER');
    }
    return safeIpcCall(async () => {
      runtime.requireAuthenticatedActor();
      const validated = OpenWhatsAppInputSchema.parse(payload);
      const normalizedPhone = `20${validated.phone.slice(1)}`;
      const targetUrl = `https://wa.me/${normalizedPhone}?text=${encodeURIComponent(validated.message)}`;
      if (!isAllowedWhatsAppUrl(targetUrl)) {
        throw new Error('INVALID_WHATSAPP_URL: URL failed strict security validation.');
      }
      await shell.openExternal(targetUrl);
      return undefined;
    });
  });
}

export function unregisterSystemIpcHandlers(): void {
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_GET_INFO);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_GET_SETTINGS);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_GET_SETUP_STATE);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_UPDATE_THEME);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_LIST_ACADEMIC_YEARS);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_CREATE_ACADEMIC_YEAR);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_SWITCH_ACADEMIC_YEAR);
  ipcMain.removeHandler(IPC_CHANNELS.SYSTEM_OPEN_WHATSAPP);
}
