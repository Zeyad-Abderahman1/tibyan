var ju = Object.defineProperty;
var Xu = (r, e, t) => e in r ? ju(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var h = (r, e, t) => Xu(r, typeof e != "symbol" ? e + "" : e, t);
import x from "path";
import z from "fs";
import { fileURLToPath as Zu } from "url";
import { safeStorage as Yn, app as It, ipcMain as f, dialog as an, shell as Od, protocol as wd, Menu as Wu, BrowserWindow as vd } from "electron";
import Us from "better-sqlite3";
import b from "crypto";
import * as Ft from "node:fs";
import * as st from "node:path";
import * as ge from "node:crypto";
import { createRequire as ti } from "node:module";
import { fileURLToPath as el } from "node:url";
import tl from "net";
const sl = {
  contextIsolation: !0,
  nodeIntegration: !1,
  sandbox: !0,
  webSecurity: !0,
  allowRunningInsecureContent: !1,
  webviewTag: !1
};
function Cd(r, e) {
  try {
    const t = new URL(r);
    if (t.protocol === "file:")
      return !0;
    if (e) {
      const s = new URL(e);
      if (t.origin === s.origin)
        return !0;
    }
    return !1;
  } catch {
    return !1;
  }
}
function nl(r, e) {
  r.webContents.setWindowOpenHandler(() => ({ action: "deny" })), r.webContents.on("will-navigate", (t, s) => {
    Cd(s, e == null ? void 0 : e.allowedDevOrigin) || t.preventDefault();
  });
}
function rl(r) {
  try {
    const e = new URL(r);
    return e.protocol !== "https:" || e.hostname !== "wa.me" || e.username !== "" || e.password !== "" || e.port !== "" && e.port !== "443" ? !1 : /^\/201[0125]\d{8}$/.test(e.pathname);
  } catch {
    return !1;
  }
}
function il(r, e, t) {
  r.setPermissionRequestHandler((s, n, i, a) => {
    if (!e || typeof e.isDestroyed == "function" && e.isDestroyed()) {
      i(!1);
      return;
    }
    if (s && typeof s.id == "number" && s.id !== e.webContents.id) {
      i(!1);
      return;
    }
    if (a && typeof a.isMainFrame == "boolean" && !a.isMainFrame) {
      i(!1);
      return;
    }
    if (a != null && a.requestingUrl && !Cd(a.requestingUrl, t == null ? void 0 : t.allowedDevOrigin)) {
      i(!1);
      return;
    }
    if (n !== "media") {
      i(!1);
      return;
    }
    if (!a || !Array.isArray(a.mediaTypes) || a.mediaTypes.length === 0) {
      i(!1);
      return;
    }
    const o = a.mediaTypes.includes("audio"), d = a.mediaTypes.includes("video");
    if (o || !d) {
      i(!1);
      return;
    }
    i(!0);
  });
}
function A(r, e) {
  return !(!e || e.isDestroyed() || r.sender.id !== e.webContents.id || r.senderFrame && r.senderFrame.parent !== null);
}
const v = Symbol.for("drizzle:entityKind");
function C(r, e) {
  if (!r || typeof r != "object")
    return !1;
  if (r instanceof e)
    return !0;
  if (!Object.prototype.hasOwnProperty.call(e, v))
    throw new Error(
      `Class "${e.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`
    );
  let t = Object.getPrototypeOf(r).constructor;
  if (t)
    for (; t; ) {
      if (v in t && t[v] === e[v])
        return !0;
      t = Object.getPrototypeOf(t);
    }
  return !1;
}
var wi;
wi = v;
class we {
  constructor(e, t) {
    h(this, "name");
    h(this, "keyAsName");
    h(this, "primary");
    h(this, "notNull");
    h(this, "default");
    h(this, "defaultFn");
    h(this, "onUpdateFn");
    h(this, "hasDefault");
    h(this, "isUnique");
    h(this, "uniqueName");
    h(this, "uniqueType");
    h(this, "dataType");
    h(this, "columnType");
    h(this, "enumValues");
    h(this, "generated");
    h(this, "generatedIdentity");
    h(this, "config");
    this.table = e, this.config = t, this.name = t.name, this.keyAsName = t.keyAsName, this.notNull = t.notNull, this.default = t.default, this.defaultFn = t.defaultFn, this.onUpdateFn = t.onUpdateFn, this.hasDefault = t.hasDefault, this.primary = t.primaryKey, this.isUnique = t.isUnique, this.uniqueName = t.uniqueName, this.uniqueType = t.uniqueType, this.dataType = t.dataType, this.columnType = t.columnType, this.generated = t.generated, this.generatedIdentity = t.generatedIdentity;
  }
  mapFromDriverValue(e) {
    return e;
  }
  mapToDriverValue(e) {
    return e;
  }
  // ** @internal */
  shouldDisableInsert() {
    return this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
  }
}
h(we, wi, "Column");
var vi;
vi = v;
class Ud {
  constructor(e, t, s) {
    h(this, "config");
    /**
     * Alias for {@link $defaultFn}.
     */
    h(this, "$default", this.$defaultFn);
    /**
     * Alias for {@link $onUpdateFn}.
     */
    h(this, "$onUpdate", this.$onUpdateFn);
    this.config = {
      name: e,
      keyAsName: e === "",
      notNull: !1,
      default: void 0,
      hasDefault: !1,
      primaryKey: !1,
      isUnique: !1,
      uniqueName: void 0,
      uniqueType: void 0,
      dataType: t,
      columnType: s,
      generated: void 0
    };
  }
  /**
   * Changes the data type of the column. Commonly used with `json` columns. Also, useful for branded types.
   *
   * @example
   * ```ts
   * const users = pgTable('users', {
   * 	id: integer('id').$type<UserId>().primaryKey(),
   * 	details: json('details').$type<UserDetails>().notNull(),
   * });
   * ```
   */
  $type() {
    return this;
  }
  /**
   * Adds a `not null` clause to the column definition.
   *
   * Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
   */
  notNull() {
    return this.config.notNull = !0, this;
  }
  /**
   * Adds a `default <value>` clause to the column definition.
   *
   * Affects the `insert` model of the table - columns *with* `default` are optional on insert.
   *
   * If you need to set a dynamic default value, use {@link $defaultFn} instead.
   */
  default(e) {
    return this.config.default = e, this.config.hasDefault = !0, this;
  }
  /**
   * Adds a dynamic default value to the column.
   * The function will be called when the row is inserted, and the returned value will be used as the column value.
   *
   * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
   */
  $defaultFn(e) {
    return this.config.defaultFn = e, this.config.hasDefault = !0, this;
  }
  /**
   * Adds a dynamic update value to the column.
   * The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
   * If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
   *
   * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
   */
  $onUpdateFn(e) {
    return this.config.onUpdateFn = e, this.config.hasDefault = !0, this;
  }
  /**
   * Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
   *
   * In SQLite, `integer primary key` implicitly makes the column auto-incrementing.
   */
  primaryKey() {
    return this.config.primaryKey = !0, this.config.notNull = !0, this;
  }
  /** @internal Sets the name of the column to the key within the table definition if a name was not given. */
  setName(e) {
    this.config.name === "" && (this.config.name = e);
  }
}
h(Ud, vi, "ColumnBuilder");
const rs = Symbol.for("drizzle:Name"), si = Symbol.for("drizzle:isPgEnum");
function al(r) {
  return !!r && typeof r == "function" && si in r && r[si] === !0;
}
var Ci;
Ci = v;
class pt {
  constructor(e, t, s, n = !1) {
    this._ = {
      brand: "Subquery",
      sql: e,
      selectedFields: t,
      alias: s,
      isWith: n
    };
  }
  // getSQL(): SQL<unknown> {
  // 	return new SQL([this]);
  // }
}
h(pt, Ci, "Subquery");
var Ui, xi;
class Cr extends (xi = pt, Ui = v, xi) {
}
h(Cr, Ui, "WithSubquery");
const ol = {
  startActiveSpan(r, e) {
    return e();
  }
}, Ke = Symbol.for("drizzle:ViewBaseConfig"), tn = Symbol.for("drizzle:Schema"), nr = Symbol.for("drizzle:Columns"), ni = Symbol.for("drizzle:ExtraConfigColumns"), Jn = Symbol.for("drizzle:OriginalName"), Vn = Symbol.for("drizzle:BaseName"), on = Symbol.for("drizzle:IsAlias"), ri = Symbol.for("drizzle:ExtraConfigBuilder"), dl = Symbol.for("drizzle:IsDrizzleTable");
var bi, Li, Pi, ki, zi, Bi, Mi, Fi, $i, qi;
qi = v, $i = rs, Fi = Jn, Mi = tn, Bi = nr, zi = ni, ki = Vn, Pi = on, Li = dl, bi = ri;
class q {
  constructor(e, t, s) {
    /**
     * @internal
     * Can be changed if the table is aliased.
     */
    h(this, $i);
    /**
     * @internal
     * Used to store the original name of the table, before any aliasing.
     */
    h(this, Fi);
    /** @internal */
    h(this, Mi);
    /** @internal */
    h(this, Bi);
    /** @internal */
    h(this, zi);
    /**
     *  @internal
     * Used to store the table name before the transformation via the `tableCreator` functions.
     */
    h(this, ki);
    /** @internal */
    h(this, Pi, !1);
    /** @internal */
    h(this, Li, !0);
    /** @internal */
    h(this, bi);
    this[rs] = this[Jn] = e, this[tn] = t, this[Vn] = s;
  }
}
h(q, qi, "Table"), /** @internal */
h(q, "Symbol", {
  Name: rs,
  Schema: tn,
  OriginalName: Jn,
  Columns: nr,
  ExtraConfigColumns: ni,
  BaseName: Vn,
  IsAlias: on,
  ExtraConfigBuilder: ri
});
function As(r) {
  return r[rs];
}
function zs(r) {
  return `${r[tn] ?? "public"}.${r[rs]}`;
}
function xd(r) {
  return r != null && typeof r.getSQL == "function";
}
function cl(r) {
  var t;
  const e = { sql: "", params: [] };
  for (const s of r)
    e.sql += s.sql, e.params.push(...s.params), (t = s.typings) != null && t.length && (e.typings || (e.typings = []), e.typings.push(...s.typings));
  return e;
}
var Hi;
Hi = v;
class xe {
  constructor(e) {
    h(this, "value");
    this.value = Array.isArray(e) ? e : [e];
  }
  getSQL() {
    return new Y([this]);
  }
}
h(xe, Hi, "StringChunk");
var Gi;
Gi = v;
const cs = class cs {
  constructor(e) {
    /** @internal */
    h(this, "decoder", bd);
    h(this, "shouldInlineParams", !1);
    this.queryChunks = e;
  }
  append(e) {
    return this.queryChunks.push(...e.queryChunks), this;
  }
  toQuery(e) {
    return ol.startActiveSpan("drizzle.buildSQL", (t) => {
      const s = this.buildQueryFromSourceParams(this.queryChunks, e);
      return t == null || t.setAttributes({
        "drizzle.query.text": s.sql,
        "drizzle.query.params": JSON.stringify(s.params)
      }), s;
    });
  }
  buildQueryFromSourceParams(e, t) {
    const s = Object.assign({}, t, {
      inlineParams: t.inlineParams || this.shouldInlineParams,
      paramStartIndex: t.paramStartIndex || { value: 0 }
    }), {
      casing: n,
      escapeName: i,
      escapeParam: a,
      prepareTyping: o,
      inlineParams: d,
      paramStartIndex: u
    } = s;
    return cl(e.map((l) => {
      var p;
      if (C(l, xe))
        return { sql: l.value.join(""), params: [] };
      if (C(l, dn))
        return { sql: i(l.value), params: [] };
      if (l === void 0)
        return { sql: "", params: [] };
      if (Array.isArray(l)) {
        const S = [new xe("(")];
        for (const [N, y] of l.entries())
          S.push(y), N < l.length - 1 && S.push(new xe(", "));
        return S.push(new xe(")")), this.buildQueryFromSourceParams(S, s);
      }
      if (C(l, cs))
        return this.buildQueryFromSourceParams(l.queryChunks, {
          ...s,
          inlineParams: d || l.shouldInlineParams
        });
      if (C(l, q)) {
        const S = l[q.Symbol.Schema], N = l[q.Symbol.Name];
        return {
          sql: S === void 0 || l[on] ? i(N) : i(S) + "." + i(N),
          params: []
        };
      }
      if (C(l, we)) {
        const S = n.getColumnCasing(l);
        if (t.invokeSource === "indexes")
          return { sql: i(S), params: [] };
        const N = l.table[q.Symbol.Schema];
        return {
          sql: l.table[on] || N === void 0 ? i(l.table[q.Symbol.Name]) + "." + i(S) : i(N) + "." + i(l.table[q.Symbol.Name]) + "." + i(S),
          params: []
        };
      }
      if (C(l, _s)) {
        const S = l[Ke].schema, N = l[Ke].name;
        return {
          sql: S === void 0 || l[Ke].isAlias ? i(N) : i(S) + "." + i(N),
          params: []
        };
      }
      if (C(l, Yt)) {
        if (C(l.value, hs))
          return { sql: a(u.value++, l), params: [l], typings: ["none"] };
        const S = l.value === null ? null : l.encoder.mapToDriverValue(l.value);
        if (C(S, cs))
          return this.buildQueryFromSourceParams([S], s);
        if (d)
          return { sql: this.mapInlineParam(S, s), params: [] };
        let N = ["none"];
        return o && (N = [o(l.encoder)]), { sql: a(u.value++, S), params: [S], typings: N };
      }
      return C(l, hs) ? { sql: a(u.value++, l), params: [l], typings: ["none"] } : C(l, cs.Aliased) && l.fieldAlias !== void 0 ? { sql: i(l.fieldAlias), params: [] } : C(l, pt) ? l._.isWith ? { sql: i(l._.alias), params: [] } : this.buildQueryFromSourceParams([
        new xe("("),
        l._.sql,
        new xe(") "),
        new dn(l._.alias)
      ], s) : al(l) ? l.schema ? { sql: i(l.schema) + "." + i(l.enumName), params: [] } : { sql: i(l.enumName), params: [] } : xd(l) ? (p = l.shouldOmitSQLParens) != null && p.call(l) ? this.buildQueryFromSourceParams([l.getSQL()], s) : this.buildQueryFromSourceParams([
        new xe("("),
        l.getSQL(),
        new xe(")")
      ], s) : d ? { sql: this.mapInlineParam(l, s), params: [] } : { sql: a(u.value++, l), params: [l], typings: ["none"] };
    }));
  }
  mapInlineParam(e, { escapeString: t }) {
    if (e === null)
      return "null";
    if (typeof e == "number" || typeof e == "boolean")
      return e.toString();
    if (typeof e == "string")
      return t(e);
    if (typeof e == "object") {
      const s = e.toString();
      return t(s === "[object Object]" ? JSON.stringify(e) : s);
    }
    throw new Error("Unexpected param value: " + e);
  }
  getSQL() {
    return this;
  }
  as(e) {
    return e === void 0 ? this : new cs.Aliased(this, e);
  }
  mapWith(e) {
    return this.decoder = typeof e == "function" ? { mapFromDriverValue: e } : e, this;
  }
  inlineParams() {
    return this.shouldInlineParams = !0, this;
  }
  /**
   * This method is used to conditionally include a part of the query.
   *
   * @param condition - Condition to check
   * @returns itself if the condition is `true`, otherwise `undefined`
   */
  if(e) {
    return e ? this : void 0;
  }
};
h(cs, Gi, "SQL");
let Y = cs;
var Yi;
Yi = v;
class dn {
  constructor(e) {
    h(this, "brand");
    this.value = e;
  }
  getSQL() {
    return new Y([this]);
  }
}
h(dn, Yi, "Name");
function ul(r) {
  return typeof r == "object" && r !== null && "mapToDriverValue" in r && typeof r.mapToDriverValue == "function";
}
const bd = {
  mapFromDriverValue: (r) => r
}, Ld = {
  mapToDriverValue: (r) => r
};
({
  ...bd,
  ...Ld
});
var Ji;
Ji = v;
class Yt {
  /**
   * @param value - Parameter value
   * @param encoder - Encoder to convert the value to a driver parameter
   */
  constructor(e, t = Ld) {
    h(this, "brand");
    this.value = e, this.encoder = t;
  }
  getSQL() {
    return new Y([this]);
  }
}
h(Yt, Ji, "Param");
function _(r, ...e) {
  const t = [];
  (e.length > 0 || r.length > 0 && r[0] !== "") && t.push(new xe(r[0]));
  for (const [s, n] of e.entries())
    t.push(n, new xe(r[s + 1]));
  return new Y(t);
}
((r) => {
  function e() {
    return new Y([]);
  }
  r.empty = e;
  function t(d) {
    return new Y(d);
  }
  r.fromList = t;
  function s(d) {
    return new Y([new xe(d)]);
  }
  r.raw = s;
  function n(d, u) {
    const l = [];
    for (const [p, S] of d.entries())
      p > 0 && u !== void 0 && l.push(u), l.push(S);
    return new Y(l);
  }
  r.join = n;
  function i(d) {
    return new dn(d);
  }
  r.identifier = i;
  function a(d) {
    return new hs(d);
  }
  r.placeholder = a;
  function o(d, u) {
    return new Yt(d, u);
  }
  r.param = o;
})(_ || (_ = {}));
((r) => {
  var t;
  t = v;
  const s = class s {
    constructor(i, a) {
      /** @internal */
      h(this, "isSelectionField", !1);
      this.sql = i, this.fieldAlias = a;
    }
    getSQL() {
      return this.sql;
    }
    /** @internal */
    clone() {
      return new s(this.sql, this.fieldAlias);
    }
  };
  h(s, t, "SQL.Aliased");
  let e = s;
  r.Aliased = e;
})(Y || (Y = {}));
var Vi;
Vi = v;
class hs {
  constructor(e) {
    this.name = e;
  }
  getSQL() {
    return new Y([this]);
  }
}
h(hs, Vi, "Placeholder");
function Ks(r, e) {
  return r.map((t) => {
    if (C(t, hs)) {
      if (!(t.name in e))
        throw new Error(`No value for placeholder "${t.name}" was provided`);
      return e[t.name];
    }
    if (C(t, Yt) && C(t.value, hs)) {
      if (!(t.value.name in e))
        throw new Error(`No value for placeholder "${t.value.name}" was provided`);
      return t.encoder.mapToDriverValue(e[t.value.name]);
    }
    return t;
  });
}
const ll = Symbol.for("drizzle:IsDrizzleView");
var Qi, Ki, ji;
ji = v, Ki = Ke, Qi = ll;
class _s {
  constructor({ name: e, schema: t, selectedFields: s, query: n }) {
    /** @internal */
    h(this, Ki);
    /** @internal */
    h(this, Qi, !0);
    this[Ke] = {
      name: e,
      originalName: e,
      schema: t,
      selectedFields: s,
      query: n,
      isExisting: !n,
      isAlias: !1
    };
  }
  getSQL() {
    return new Y([this]);
  }
}
h(_s, ji, "View");
we.prototype.getSQL = function() {
  return new Y([this]);
};
q.prototype.getSQL = function() {
  return new Y([this]);
};
pt.prototype.getSQL = function() {
  return new Y([this]);
};
var Xi;
Xi = v;
class Bs {
  constructor(e) {
    this.table = e;
  }
  get(e, t) {
    return t === "table" ? this.table : e[t];
  }
}
h(Bs, Xi, "ColumnAliasProxyHandler");
var Zi;
Zi = v;
class Un {
  constructor(e, t) {
    this.alias = e, this.replaceOriginalName = t;
  }
  get(e, t) {
    if (t === q.Symbol.IsAlias)
      return !0;
    if (t === q.Symbol.Name)
      return this.alias;
    if (this.replaceOriginalName && t === q.Symbol.OriginalName)
      return this.alias;
    if (t === Ke)
      return {
        ...e[Ke],
        name: this.alias,
        isAlias: !0
      };
    if (t === q.Symbol.Columns) {
      const n = e[q.Symbol.Columns];
      if (!n)
        return n;
      const i = {};
      return Object.keys(n).map((a) => {
        i[a] = new Proxy(
          n[a],
          new Bs(new Proxy(e, this))
        );
      }), i;
    }
    const s = e[t];
    return C(s, we) ? new Proxy(s, new Bs(new Proxy(e, this))) : s;
  }
}
h(Un, Zi, "TableAliasProxyHandler");
function Qn(r, e) {
  return new Proxy(r, new Un(e, !1));
}
function Bt(r, e) {
  return new Proxy(
    r,
    new Bs(new Proxy(r.table, new Un(e, !1)))
  );
}
function Pd(r, e) {
  return new Y.Aliased(cn(r.sql, e), r.fieldAlias);
}
function cn(r, e) {
  return _.join(r.queryChunks.map((t) => C(t, we) ? Bt(t, e) : C(t, Y) ? cn(t, e) : C(t, Y.Aliased) ? Pd(t, e) : t));
}
var Wi;
Wi = v;
class kd {
  constructor(e, t) {
    h(this, "brand");
    this.name = e, this.value = t;
  }
  build(e) {
    return new zd(e, this);
  }
}
h(kd, Wi, "SQLiteCheckBuilder");
var ea;
ea = v;
class zd {
  constructor(e, t) {
    h(this, "name");
    h(this, "value");
    this.table = e, this.name = t.name, this.value = t.value;
  }
}
h(zd, ea, "SQLiteCheck");
function Re(r, e) {
  return new kd(r, e);
}
function ii(r, e, t) {
  const s = {}, n = r.reduce(
    (i, { path: a, field: o }, d) => {
      let u;
      C(o, we) ? u = o : C(o, Y) ? u = o.decoder : u = o.sql.decoder;
      let l = i;
      for (const [p, S] of a.entries())
        if (p < a.length - 1)
          S in l || (l[S] = {}), l = l[S];
        else {
          const N = e[d], y = l[S] = N === null ? null : u.mapFromDriverValue(N);
          if (t && C(o, we) && a.length === 2) {
            const I = a[0];
            I in s ? typeof s[I] == "string" && s[I] !== As(o.table) && (s[I] = !1) : s[I] = y === null ? As(o.table) : !1;
          }
        }
      return i;
    },
    {}
  );
  if (t && Object.keys(s).length > 0)
    for (const [i, a] of Object.entries(s))
      typeof a == "string" && !t[a] && (n[i] = null);
  return n;
}
function ms(r, e) {
  return Object.entries(r).reduce((t, [s, n]) => {
    if (typeof s != "string")
      return t;
    const i = e ? [...e, s] : [s];
    return C(n, we) || C(n, Y) || C(n, Y.Aliased) ? t.push({ path: i, field: n }) : C(n, q) ? t.push(...ms(n[q.Symbol.Columns], i)) : t.push(...ms(n, i)), t;
  }, []);
}
function Ur(r, e) {
  const t = Object.keys(r), s = Object.keys(e);
  if (t.length !== s.length)
    return !1;
  for (const [n, i] of t.entries())
    if (i !== s[n])
      return !1;
  return !0;
}
function Bd(r, e) {
  const t = Object.entries(e).filter(([, s]) => s !== void 0).map(([s, n]) => C(n, Y) || C(n, we) ? [s, n] : [s, new Yt(n, r[q.Symbol.Columns][s])]);
  if (t.length === 0)
    throw new Error("No values to set");
  return Object.fromEntries(t);
}
function hl(r, e) {
  for (const t of e)
    for (const s of Object.getOwnPropertyNames(t.prototype))
      s !== "constructor" && Object.defineProperty(
        r.prototype,
        s,
        Object.getOwnPropertyDescriptor(t.prototype, s) || /* @__PURE__ */ Object.create(null)
      );
}
function ml(r) {
  return r[q.Symbol.Columns];
}
function rr(r) {
  return C(r, pt) ? r._.alias : C(r, _s) ? r[Ke].name : C(r, Y) ? void 0 : r[q.Symbol.IsAlias] ? r[q.Symbol.Name] : r[q.Symbol.BaseName];
}
function xn(r, e) {
  return {
    name: typeof r == "string" && r.length > 0 ? r : "",
    config: typeof r == "object" ? r : e
  };
}
function pl(r) {
  if (typeof r != "object" || r === null || r.constructor.name !== "Object")
    return !1;
  if ("logger" in r) {
    const e = typeof r.logger;
    return !(e !== "boolean" && (e !== "object" || typeof r.logger.logQuery != "function") && e !== "undefined");
  }
  if ("schema" in r) {
    const e = typeof r.logger;
    return !(e !== "object" && e !== "undefined");
  }
  if ("casing" in r) {
    const e = typeof r.logger;
    return !(e !== "string" && e !== "undefined");
  }
  if ("mode" in r)
    return !(r.mode !== "default" || r.mode !== "planetscale" || r.mode !== void 0);
  if ("connection" in r) {
    const e = typeof r.connection;
    return !(e !== "string" && e !== "object" && e !== "undefined");
  }
  if ("client" in r) {
    const e = typeof r.client;
    return !(e !== "object" && e !== "function" && e !== "undefined");
  }
  return Object.keys(r).length === 0;
}
var ta;
ta = v;
class Md {
  constructor(e, t) {
    /** @internal */
    h(this, "reference");
    /** @internal */
    h(this, "_onUpdate");
    /** @internal */
    h(this, "_onDelete");
    this.reference = () => {
      const { name: s, columns: n, foreignColumns: i } = e();
      return { name: s, columns: n, foreignTable: i[0].table, foreignColumns: i };
    }, t && (this._onUpdate = t.onUpdate, this._onDelete = t.onDelete);
  }
  onUpdate(e) {
    return this._onUpdate = e, this;
  }
  onDelete(e) {
    return this._onDelete = e, this;
  }
  /** @internal */
  build(e) {
    return new Fd(e, this);
  }
}
h(Md, ta, "SQLiteForeignKeyBuilder");
var sa;
sa = v;
class Fd {
  constructor(e, t) {
    h(this, "reference");
    h(this, "onUpdate");
    h(this, "onDelete");
    this.table = e, this.reference = t.reference, this.onUpdate = t._onUpdate, this.onDelete = t._onDelete;
  }
  getName() {
    const { name: e, columns: t, foreignColumns: s } = this.reference(), n = t.map((o) => o.name), i = s.map((o) => o.name), a = [
      this.table[rs],
      ...n,
      s[0].table[rs],
      ...i
    ];
    return e ?? `${a.join("_")}_fk`;
  }
}
h(Fd, sa, "SQLiteForeignKey");
function fl(r, e) {
  return `${r[rs]}_${e.join("_")}_unique`;
}
var na, ra;
class Pt extends (ra = Ud, na = v, ra) {
  constructor() {
    super(...arguments);
    h(this, "foreignKeyConfigs", []);
  }
  references(t, s = {}) {
    return this.foreignKeyConfigs.push({ ref: t, actions: s }), this;
  }
  unique(t) {
    return this.config.isUnique = !0, this.config.uniqueName = t, this;
  }
  generatedAlwaysAs(t, s) {
    return this.config.generated = {
      as: t,
      type: "always",
      mode: (s == null ? void 0 : s.mode) ?? "virtual"
    }, this;
  }
  /** @internal */
  buildForeignKeys(t, s) {
    return this.foreignKeyConfigs.map(({ ref: n, actions: i }) => ((a, o) => {
      const d = new Md(() => {
        const u = a();
        return { columns: [t], foreignColumns: [u] };
      });
      return o.onUpdate && d.onUpdate(o.onUpdate), o.onDelete && d.onDelete(o.onDelete), d.build(s);
    })(n, i));
  }
}
h(Pt, na, "SQLiteColumnBuilder");
var ia, aa;
class at extends (aa = we, ia = v, aa) {
  constructor(e, t) {
    t.uniqueName || (t.uniqueName = fl(e, [t.name])), super(e, t), this.table = e;
  }
}
h(at, ia, "SQLiteColumn");
var oa, da;
class $d extends (da = Pt, oa = v, da) {
  constructor(e) {
    super(e, "bigint", "SQLiteBigInt");
  }
  /** @internal */
  build(e) {
    return new qd(e, this.config);
  }
}
h($d, oa, "SQLiteBigIntBuilder");
var ca, ua;
class qd extends (ua = at, ca = v, ua) {
  getSQLType() {
    return "blob";
  }
  mapFromDriverValue(e) {
    if (Buffer.isBuffer(e))
      return BigInt(e.toString());
    if (e instanceof ArrayBuffer) {
      const t = new TextDecoder();
      return BigInt(t.decode(e));
    }
    return BigInt(String.fromCodePoint(...e));
  }
  mapToDriverValue(e) {
    return Buffer.from(e.toString());
  }
}
h(qd, ca, "SQLiteBigInt");
var la, ha;
class Hd extends (ha = Pt, la = v, ha) {
  constructor(e) {
    super(e, "json", "SQLiteBlobJson");
  }
  /** @internal */
  build(e) {
    return new Gd(
      e,
      this.config
    );
  }
}
h(Hd, la, "SQLiteBlobJsonBuilder");
var ma, pa;
class Gd extends (pa = at, ma = v, pa) {
  getSQLType() {
    return "blob";
  }
  mapFromDriverValue(e) {
    if (Buffer.isBuffer(e))
      return JSON.parse(e.toString());
    if (e instanceof ArrayBuffer) {
      const t = new TextDecoder();
      return JSON.parse(t.decode(e));
    }
    return JSON.parse(String.fromCodePoint(...e));
  }
  mapToDriverValue(e) {
    return Buffer.from(JSON.stringify(e));
  }
}
h(Gd, ma, "SQLiteBlobJson");
var fa, Ea;
class Yd extends (Ea = Pt, fa = v, Ea) {
  constructor(e) {
    super(e, "buffer", "SQLiteBlobBuffer");
  }
  /** @internal */
  build(e) {
    return new Jd(e, this.config);
  }
}
h(Yd, fa, "SQLiteBlobBufferBuilder");
var Sa, ga;
class Jd extends (ga = at, Sa = v, ga) {
  getSQLType() {
    return "blob";
  }
}
h(Jd, Sa, "SQLiteBlobBuffer");
function El(r, e) {
  const { name: t, config: s } = xn(r, e);
  return (s == null ? void 0 : s.mode) === "json" ? new Hd(t) : (s == null ? void 0 : s.mode) === "bigint" ? new $d(t) : new Yd(t);
}
var _a, Na;
class Vd extends (Na = Pt, _a = v, Na) {
  constructor(e, t, s) {
    super(e, "custom", "SQLiteCustomColumn"), this.config.fieldConfig = t, this.config.customTypeParams = s;
  }
  /** @internal */
  build(e) {
    return new Qd(
      e,
      this.config
    );
  }
}
h(Vd, _a, "SQLiteCustomColumnBuilder");
var Ia, ya;
class Qd extends (ya = at, Ia = v, ya) {
  constructor(t, s) {
    super(t, s);
    h(this, "sqlName");
    h(this, "mapTo");
    h(this, "mapFrom");
    this.sqlName = s.customTypeParams.dataType(s.fieldConfig), this.mapTo = s.customTypeParams.toDriver, this.mapFrom = s.customTypeParams.fromDriver;
  }
  getSQLType() {
    return this.sqlName;
  }
  mapFromDriverValue(t) {
    return typeof this.mapFrom == "function" ? this.mapFrom(t) : t;
  }
  mapToDriverValue(t) {
    return typeof this.mapTo == "function" ? this.mapTo(t) : t;
  }
}
h(Qd, Ia, "SQLiteCustomColumn");
function Sl(r) {
  return (e, t) => {
    const { name: s, config: n } = xn(e, t);
    return new Vd(
      s,
      n,
      r
    );
  };
}
var Ta, Aa;
class bn extends (Aa = Pt, Ta = v, Aa) {
  constructor(e, t, s) {
    super(e, t, s), this.config.autoIncrement = !1;
  }
  primaryKey(e) {
    return e != null && e.autoIncrement && (this.config.autoIncrement = !0), this.config.hasDefault = !0, super.primaryKey();
  }
}
h(bn, Ta, "SQLiteBaseIntegerBuilder");
var Ra, Da;
class Ln extends (Da = at, Ra = v, Da) {
  constructor() {
    super(...arguments);
    h(this, "autoIncrement", this.config.autoIncrement);
  }
  getSQLType() {
    return "integer";
  }
}
h(Ln, Ra, "SQLiteBaseInteger");
var Oa, wa;
class Kd extends (wa = bn, Oa = v, wa) {
  constructor(e) {
    super(e, "number", "SQLiteInteger");
  }
  build(e) {
    return new jd(
      e,
      this.config
    );
  }
}
h(Kd, Oa, "SQLiteIntegerBuilder");
var va, Ca;
class jd extends (Ca = Ln, va = v, Ca) {
}
h(jd, va, "SQLiteInteger");
var Ua, xa;
class Xd extends (xa = bn, Ua = v, xa) {
  constructor(e, t) {
    super(e, "date", "SQLiteTimestamp"), this.config.mode = t;
  }
  /**
   * @deprecated Use `default()` with your own expression instead.
   *
   * Adds `DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer))` to the column, which is the current epoch timestamp in milliseconds.
   */
  defaultNow() {
    return this.default(_`(cast((julianday('now') - 2440587.5)*86400000 as integer))`);
  }
  build(e) {
    return new Zd(
      e,
      this.config
    );
  }
}
h(Xd, Ua, "SQLiteTimestampBuilder");
var ba, La;
class Zd extends (La = Ln, ba = v, La) {
  constructor() {
    super(...arguments);
    h(this, "mode", this.config.mode);
  }
  mapFromDriverValue(t) {
    return this.config.mode === "timestamp" ? new Date(t * 1e3) : new Date(t);
  }
  mapToDriverValue(t) {
    const s = t.getTime();
    return this.config.mode === "timestamp" ? Math.floor(s / 1e3) : s;
  }
}
h(Zd, ba, "SQLiteTimestamp");
var Pa, ka;
class Wd extends (ka = bn, Pa = v, ka) {
  constructor(e, t) {
    super(e, "boolean", "SQLiteBoolean"), this.config.mode = t;
  }
  build(e) {
    return new ec(
      e,
      this.config
    );
  }
}
h(Wd, Pa, "SQLiteBooleanBuilder");
var za, Ba;
class ec extends (Ba = Ln, za = v, Ba) {
  constructor() {
    super(...arguments);
    h(this, "mode", this.config.mode);
  }
  mapFromDriverValue(t) {
    return Number(t) === 1;
  }
  mapToDriverValue(t) {
    return t ? 1 : 0;
  }
}
h(ec, za, "SQLiteBoolean");
function he(r, e) {
  const { name: t, config: s } = xn(r, e);
  return (s == null ? void 0 : s.mode) === "timestamp" || (s == null ? void 0 : s.mode) === "timestamp_ms" ? new Xd(t, s.mode) : (s == null ? void 0 : s.mode) === "boolean" ? new Wd(t, s.mode) : new Kd(t);
}
var Ma, Fa;
class tc extends (Fa = Pt, Ma = v, Fa) {
  constructor(e) {
    super(e, "string", "SQLiteNumeric");
  }
  /** @internal */
  build(e) {
    return new sc(
      e,
      this.config
    );
  }
}
h(tc, Ma, "SQLiteNumericBuilder");
var $a, qa;
class sc extends (qa = at, $a = v, qa) {
  getSQLType() {
    return "numeric";
  }
}
h(sc, $a, "SQLiteNumeric");
function gl(r) {
  return new tc(r ?? "");
}
var Ha, Ga;
class nc extends (Ga = Pt, Ha = v, Ga) {
  constructor(e) {
    super(e, "number", "SQLiteReal");
  }
  /** @internal */
  build(e) {
    return new rc(e, this.config);
  }
}
h(nc, Ha, "SQLiteRealBuilder");
var Ya, Ja;
class rc extends (Ja = at, Ya = v, Ja) {
  getSQLType() {
    return "real";
  }
}
h(rc, Ya, "SQLiteReal");
function xr(r) {
  return new nc(r ?? "");
}
var Va, Qa;
class ic extends (Qa = Pt, Va = v, Qa) {
  constructor(e, t) {
    super(e, "string", "SQLiteText"), this.config.enumValues = t.enum, this.config.length = t.length;
  }
  /** @internal */
  build(e) {
    return new ac(
      e,
      this.config
    );
  }
}
h(ic, Va, "SQLiteTextBuilder");
var Ka, ja;
class ac extends (ja = at, Ka = v, ja) {
  constructor(t, s) {
    super(t, s);
    h(this, "enumValues", this.config.enumValues);
    h(this, "length", this.config.length);
  }
  getSQLType() {
    return `text${this.config.length ? `(${this.config.length})` : ""}`;
  }
}
h(ac, Ka, "SQLiteText");
var Xa, Za;
class oc extends (Za = Pt, Xa = v, Za) {
  constructor(e) {
    super(e, "json", "SQLiteTextJson");
  }
  /** @internal */
  build(e) {
    return new dc(
      e,
      this.config
    );
  }
}
h(oc, Xa, "SQLiteTextJsonBuilder");
var Wa, eo;
class dc extends (eo = at, Wa = v, eo) {
  getSQLType() {
    return "text";
  }
  mapFromDriverValue(e) {
    return JSON.parse(e);
  }
  mapToDriverValue(e) {
    return JSON.stringify(e);
  }
}
h(dc, Wa, "SQLiteTextJson");
function m(r, e = {}) {
  const { name: t, config: s } = xn(r, e);
  return s.mode === "json" ? new oc(t) : new ic(t, s);
}
var to;
to = v;
const On = class On {
  constructor(e) {
    h(this, "config");
    this.config = { ...e };
  }
  get(e, t) {
    if (t === "_")
      return {
        ...e._,
        selectedFields: new Proxy(
          e._.selectedFields,
          this
        )
      };
    if (t === Ke)
      return {
        ...e[Ke],
        selectedFields: new Proxy(
          e[Ke].selectedFields,
          this
        )
      };
    if (typeof t == "symbol")
      return e[t];
    const n = (C(e, pt) ? e._.selectedFields : C(e, _s) ? e[Ke].selectedFields : e)[t];
    if (C(n, Y.Aliased)) {
      if (this.config.sqlAliasedBehavior === "sql" && !n.isSelectionField)
        return n.sql;
      const i = n.clone();
      return i.isSelectionField = !0, i;
    }
    if (C(n, Y)) {
      if (this.config.sqlBehavior === "sql")
        return n;
      throw new Error(
        `You tried to reference "${t}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`
      );
    }
    return C(n, we) ? this.config.alias ? new Proxy(
      n,
      new Bs(
        new Proxy(
          n.table,
          new Un(this.config.alias, this.config.replaceOriginalName ?? !1)
        )
      )
    ) : n : typeof n != "object" || n === null ? n : new Proxy(n, new On(this.config));
  }
};
h(On, to, "SelectionProxyHandler");
let Ze = On;
var so, no;
no = v, so = Symbol.toStringTag;
class os {
  constructor() {
    h(this, so, "QueryPromise");
  }
  catch(e) {
    return this.then(void 0, e);
  }
  finally(e) {
    return this.then(
      (t) => (e == null || e(), t),
      (t) => {
        throw e == null || e(), t;
      }
    );
  }
  then(e, t) {
    return this.execute().then(e, t);
  }
}
h(os, no, "QueryPromise");
function _l() {
  return {
    blob: El,
    customType: Sl,
    integer: he,
    numeric: gl,
    real: xr,
    text: m
  };
}
const ir = Symbol.for("drizzle:SQLiteInlineForeignKeys");
var ro, io, ao, oo, co;
class nt extends (co = q, oo = v, ao = q.Symbol.Columns, io = ir, ro = q.Symbol.ExtraConfigBuilder, co) {
  constructor() {
    super(...arguments);
    /** @internal */
    h(this, ao);
    /** @internal */
    h(this, io, []);
    /** @internal */
    h(this, ro);
  }
}
h(nt, oo, "SQLiteTable"), /** @internal */
h(nt, "Symbol", Object.assign({}, q.Symbol, {
  InlineForeignKeys: ir
}));
function Nl(r, e, t, s, n = r) {
  const i = new nt(r, s, n), a = typeof e == "function" ? e(_l()) : e, o = Object.fromEntries(
    Object.entries(a).map(([u, l]) => {
      const p = l;
      p.setName(u);
      const S = p.build(i);
      return i[ir].push(...p.buildForeignKeys(S, i)), [u, S];
    })
  ), d = Object.assign(i, o);
  return d[q.Symbol.Columns] = o, d[q.Symbol.ExtraConfigColumns] = o, t && (d[nt.Symbol.ExtraConfigBuilder] = t), d;
}
const ie = (r, e, t) => Nl(r, e, t);
var uo, lo;
class ar extends (lo = os, uo = v, lo) {
  constructor(t, s, n, i) {
    super();
    /** @internal */
    h(this, "config");
    h(this, "run", (t) => this._prepare().run(t));
    h(this, "all", (t) => this._prepare().all(t));
    h(this, "get", (t) => this._prepare().get(t));
    h(this, "values", (t) => this._prepare().values(t));
    this.table = t, this.session = s, this.dialect = n, this.config = { table: t, withList: i };
  }
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will delete only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be deleted.
   *
   * ```ts
   * // Delete all cars with green color
   * db.delete(cars).where(eq(cars.color, 'green'));
   * // or
   * db.delete(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Delete all BMW cars with a green color
   * db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Delete all cars with the green or blue color
   * db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(t) {
    return this.config.where = t, this;
  }
  orderBy(...t) {
    if (typeof t[0] == "function") {
      const s = t[0](
        new Proxy(
          this.config.table[q.Symbol.Columns],
          new Ze({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      ), n = Array.isArray(s) ? s : [s];
      this.config.orderBy = n;
    } else {
      const s = t;
      this.config.orderBy = s;
    }
    return this;
  }
  limit(t) {
    return this.config.limit = t, this;
  }
  returning(t = this.table[nt.Symbol.Columns]) {
    return this.config.returning = ms(t), this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildDeleteQuery(this.config);
  }
  toSQL() {
    const { typings: t, ...s } = this.dialect.sqlToQuery(this.getSQL());
    return s;
  }
  /** @internal */
  _prepare(t = !0) {
    return this.session[t ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      !0
    );
  }
  prepare() {
    return this._prepare(!1);
  }
  async execute(t) {
    return this._prepare().execute(t);
  }
  $dynamic() {
    return this;
  }
}
h(ar, uo, "SQLiteDelete");
function Il(r) {
  return (r.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).map((t) => t.toLowerCase()).join("_");
}
function yl(r) {
  return (r.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).reduce((t, s, n) => {
    const i = n === 0 ? s.toLowerCase() : `${s[0].toUpperCase()}${s.slice(1)}`;
    return t + i;
  }, "");
}
function Tl(r) {
  return r;
}
var ho;
ho = v;
class cc {
  constructor(e) {
    /** @internal */
    h(this, "cache", {});
    h(this, "cachedTables", {});
    h(this, "convert");
    this.convert = e === "snake_case" ? Il : e === "camelCase" ? yl : Tl;
  }
  getColumnCasing(e) {
    if (!e.keyAsName)
      return e.name;
    const t = e.table[q.Symbol.Schema] ?? "public", s = e.table[q.Symbol.OriginalName], n = `${t}.${s}.${e.name}`;
    return this.cache[n] || this.cacheTable(e.table), this.cache[n];
  }
  cacheTable(e) {
    const t = e[q.Symbol.Schema] ?? "public", s = e[q.Symbol.OriginalName], n = `${t}.${s}`;
    if (!this.cachedTables[n]) {
      for (const i of Object.values(e[q.Symbol.Columns])) {
        const a = `${n}.${i.name}`;
        this.cache[a] = this.convert(i.name);
      }
      this.cachedTables[n] = !0;
    }
  }
  clearCache() {
    this.cache = {}, this.cachedTables = {};
  }
}
h(cc, ho, "CasingCache");
var mo, po;
class Pn extends (po = Error, mo = v, po) {
  constructor({ message: e, cause: t }) {
    super(e), this.name = "DrizzleError", this.cause = t;
  }
}
h(Pn, mo, "DrizzleError");
var fo, Eo;
class uc extends (Eo = Pn, fo = v, Eo) {
  constructor() {
    super({ message: "Rollback" });
  }
}
h(uc, fo, "TransactionRollbackError");
const ai = Symbol.for("drizzle:PgInlineForeignKeys"), oi = Symbol.for("drizzle:EnableRLS");
var So, go, _o, No, Io;
class or extends (Io = q, No = v, _o = ai, go = oi, So = q.Symbol.ExtraConfigBuilder, Io) {
  constructor() {
    super(...arguments);
    /**@internal */
    h(this, _o, []);
    /** @internal */
    h(this, go, !1);
    /** @internal */
    h(this, So);
  }
}
h(or, No, "PgTable"), /** @internal */
h(or, "Symbol", Object.assign({}, q.Symbol, {
  InlineForeignKeys: ai,
  EnableRLS: oi
}));
var yo, tr;
let Al = (yo = v, tr = class {
  constructor(e, t) {
    /** @internal */
    h(this, "columns");
    /** @internal */
    h(this, "name");
    this.columns = e, this.name = t;
  }
  /** @internal */
  build(e) {
    return new Rl(e, this.columns, this.name);
  }
}, h(tr, yo, "PgPrimaryKeyBuilder"), tr);
var To, sr;
let Rl = (To = v, sr = class {
  constructor(e, t, s) {
    h(this, "columns");
    h(this, "name");
    this.table = e, this.columns = t, this.name = s;
  }
  getName() {
    return this.name ?? `${this.table[or.Symbol.Name]}_${this.columns.map((e) => e.name).join("_")}_pk`;
  }
}, h(sr, To, "PgPrimaryKey"), sr);
function rt(r, e) {
  return ul(e) && !xd(r) && !C(r, Yt) && !C(r, hs) && !C(r, we) && !C(r, q) && !C(r, _s) ? new Yt(r, e) : r;
}
const g = (r, e) => _`${r} = ${rt(e, r)}`, Dl = (r, e) => _`${r} <> ${rt(e, r)}`;
function ae(...r) {
  const e = r.filter(
    (t) => t !== void 0
  );
  if (e.length !== 0)
    return e.length === 1 ? new Y(e) : new Y([
      new xe("("),
      _.join(e, new xe(" and ")),
      new xe(")")
    ]);
}
function kn(...r) {
  const e = r.filter(
    (t) => t !== void 0
  );
  if (e.length !== 0)
    return e.length === 1 ? new Y(e) : new Y([
      new xe("("),
      _.join(e, new xe(" or ")),
      new xe(")")
    ]);
}
function Ol(r) {
  return _`not ${r}`;
}
const dr = (r, e) => _`${r} > ${rt(e, r)}`, cr = (r, e) => _`${r} >= ${rt(e, r)}`, wl = (r, e) => _`${r} < ${rt(e, r)}`, lc = (r, e) => _`${r} <= ${rt(e, r)}`;
function is(r, e) {
  return Array.isArray(e) ? e.length === 0 ? _`false` : _`${r} in ${e.map((t) => rt(t, r))}` : _`${r} in ${rt(e, r)}`;
}
function vl(r, e) {
  return Array.isArray(e) ? e.length === 0 ? _`true` : _`${r} not in ${e.map((t) => rt(t, r))}` : _`${r} not in ${rt(e, r)}`;
}
function Ms(r) {
  return _`${r} is null`;
}
function Cl(r) {
  return _`${r} is not null`;
}
function Ul(r) {
  return _`exists ${r}`;
}
function xl(r) {
  return _`not exists ${r}`;
}
function bl(r, e, t) {
  return _`${r} between ${rt(e, r)} and ${rt(
    t,
    r
  )}`;
}
function Ll(r, e, t) {
  return _`${r} not between ${rt(
    e,
    r
  )} and ${rt(t, r)}`;
}
function Ht(r, e) {
  return _`${r} like ${e}`;
}
function Pl(r, e) {
  return _`${r} not like ${e}`;
}
function kl(r, e) {
  return _`${r} ilike ${e}`;
}
function zl(r, e) {
  return _`${r} not ilike ${e}`;
}
function Ae(r) {
  return _`${r} asc`;
}
function de(r) {
  return _`${r} desc`;
}
var Ao;
Ao = v;
class br {
  constructor(e, t, s) {
    h(this, "referencedTableName");
    h(this, "fieldName");
    this.sourceTable = e, this.referencedTable = t, this.relationName = s, this.referencedTableName = t[q.Symbol.Name];
  }
}
h(br, Ao, "Relation");
var Ro;
Ro = v;
class hc {
  constructor(e, t) {
    this.table = e, this.config = t;
  }
}
h(hc, Ro, "Relations");
var Do, Oo;
const wn = class wn extends (Oo = br, Do = v, Oo) {
  constructor(e, t, s, n) {
    super(e, t, s == null ? void 0 : s.relationName), this.config = s, this.isNullable = n;
  }
  withFieldName(e) {
    const t = new wn(
      this.sourceTable,
      this.referencedTable,
      this.config,
      this.isNullable
    );
    return t.fieldName = e, t;
  }
};
h(wn, Do, "One");
let ps = wn;
var wo, vo;
const vn = class vn extends (vo = br, wo = v, vo) {
  constructor(e, t, s) {
    super(e, t, s == null ? void 0 : s.relationName), this.config = s;
  }
  withFieldName(e) {
    const t = new vn(
      this.sourceTable,
      this.referencedTable,
      this.config
    );
    return t.fieldName = e, t;
  }
};
h(vn, wo, "Many");
let un = vn;
function Bl() {
  return {
    and: ae,
    between: bl,
    eq: g,
    exists: Ul,
    gt: dr,
    gte: cr,
    ilike: kl,
    inArray: is,
    isNull: Ms,
    isNotNull: Cl,
    like: Ht,
    lt: wl,
    lte: lc,
    ne: Dl,
    not: Ol,
    notBetween: Ll,
    notExists: xl,
    notLike: Pl,
    notIlike: zl,
    notInArray: vl,
    or: kn,
    sql: _
  };
}
function Ml() {
  return {
    sql: _,
    asc: Ae,
    desc: de
  };
}
function Fl(r, e) {
  var i;
  Object.keys(r).length === 1 && "default" in r && !C(r.default, q) && (r = r.default);
  const t = {}, s = {}, n = {};
  for (const [a, o] of Object.entries(r))
    if (C(o, q)) {
      const d = zs(o), u = s[d];
      t[d] = a, n[a] = {
        tsName: a,
        dbName: o[q.Symbol.Name],
        schema: o[q.Symbol.Schema],
        columns: o[q.Symbol.Columns],
        relations: (u == null ? void 0 : u.relations) ?? {},
        primaryKey: (u == null ? void 0 : u.primaryKey) ?? []
      };
      for (const p of Object.values(
        o[q.Symbol.Columns]
      ))
        p.primary && n[a].primaryKey.push(p);
      const l = (i = o[q.Symbol.ExtraConfigBuilder]) == null ? void 0 : i.call(o, o[q.Symbol.ExtraConfigColumns]);
      if (l)
        for (const p of Object.values(l))
          C(p, Al) && n[a].primaryKey.push(...p.columns);
    } else if (C(o, hc)) {
      const d = zs(o.table), u = t[d], l = o.config(
        e(o.table)
      );
      let p;
      for (const [S, N] of Object.entries(l))
        if (u) {
          const y = n[u];
          y.relations[S] = N;
        } else
          d in s || (s[d] = {
            relations: {},
            primaryKey: p
          }), s[d].relations[S] = N;
    }
  return { tables: n, tableNamesMap: t };
}
function $l(r) {
  return function(t, s) {
    return new ps(
      r,
      t,
      s,
      (s == null ? void 0 : s.fields.reduce((n, i) => n && i.notNull, !0)) ?? !1
    );
  };
}
function ql(r) {
  return function(t, s) {
    return new un(r, t, s);
  };
}
function Hl(r, e, t) {
  if (C(t, ps) && t.config)
    return {
      fields: t.config.fields,
      references: t.config.references
    };
  const s = e[zs(t.referencedTable)];
  if (!s)
    throw new Error(
      `Table "${t.referencedTable[q.Symbol.Name]}" not found in schema`
    );
  const n = r[s];
  if (!n)
    throw new Error(`Table "${s}" not found in schema`);
  const i = t.sourceTable, a = e[zs(i)];
  if (!a)
    throw new Error(
      `Table "${i[q.Symbol.Name]}" not found in schema`
    );
  const o = [];
  for (const d of Object.values(
    n.relations
  ))
    (t.relationName && t !== d && d.relationName === t.relationName || !t.relationName && d.referencedTable === t.sourceTable) && o.push(d);
  if (o.length > 1)
    throw t.relationName ? new Error(
      `There are multiple relations with name "${t.relationName}" in table "${s}"`
    ) : new Error(
      `There are multiple relations between "${s}" and "${t.sourceTable[q.Symbol.Name]}". Please specify relation name`
    );
  if (o[0] && C(o[0], ps) && o[0].config)
    return {
      fields: o[0].config.references,
      references: o[0].config.fields
    };
  throw new Error(
    `There is not enough information to infer relation "${a}.${t.fieldName}"`
  );
}
function Gl(r) {
  return {
    one: $l(r),
    many: ql(r)
  };
}
function ur(r, e, t, s, n = (i) => i) {
  const i = {};
  for (const [
    a,
    o
  ] of s.entries())
    if (o.isJson) {
      const d = e.relations[o.tsKey], u = t[a], l = typeof u == "string" ? JSON.parse(u) : u;
      i[o.tsKey] = C(d, ps) ? l && ur(
        r,
        r[o.relationTableTsKey],
        l,
        o.selection,
        n
      ) : l.map(
        (p) => ur(
          r,
          r[o.relationTableTsKey],
          p,
          o.selection,
          n
        )
      );
    } else {
      const d = n(t[a]), u = o.field;
      let l;
      C(u, we) ? l = u : C(u, Y) ? l = u.decoder : l = u.sql.decoder, i[o.tsKey] = d === null ? null : l.mapFromDriverValue(d);
    }
  return i;
}
var Co, Uo;
class zn extends (Uo = _s, Co = v, Uo) {
}
h(zn, Co, "SQLiteViewBase");
var xo;
xo = v;
class ln {
  constructor(e) {
    /** @internal */
    h(this, "casing");
    this.casing = new cc(e == null ? void 0 : e.casing);
  }
  escapeName(e) {
    return `"${e}"`;
  }
  escapeParam(e) {
    return "?";
  }
  escapeString(e) {
    return `'${e.replace(/'/g, "''")}'`;
  }
  buildWithCTE(e) {
    if (!(e != null && e.length))
      return;
    const t = [_`with `];
    for (const [s, n] of e.entries())
      t.push(_`${_.identifier(n._.alias)} as (${n._.sql})`), s < e.length - 1 && t.push(_`, `);
    return t.push(_` `), _.join(t);
  }
  buildDeleteQuery({ table: e, where: t, returning: s, withList: n, limit: i, orderBy: a }) {
    const o = this.buildWithCTE(n), d = s ? _` returning ${this.buildSelection(s, { isSingleTable: !0 })}` : void 0, u = t ? _` where ${t}` : void 0, l = this.buildOrderBy(a), p = this.buildLimit(i);
    return _`${o}delete from ${e}${u}${d}${l}${p}`;
  }
  buildUpdateSet(e, t) {
    const s = e[q.Symbol.Columns], n = Object.keys(s).filter(
      (a) => {
        var o;
        return t[a] !== void 0 || ((o = s[a]) == null ? void 0 : o.onUpdateFn) !== void 0;
      }
    ), i = n.length;
    return _.join(n.flatMap((a, o) => {
      const d = s[a], u = t[a] ?? _.param(d.onUpdateFn(), d), l = _`${_.identifier(this.casing.getColumnCasing(d))} = ${u}`;
      return o < i - 1 ? [l, _.raw(", ")] : [l];
    }));
  }
  buildUpdateQuery({ table: e, set: t, where: s, returning: n, withList: i, joins: a, from: o, limit: d, orderBy: u }) {
    const l = this.buildWithCTE(i), p = this.buildUpdateSet(e, t), S = o && _.join([_.raw(" from "), this.buildFromTable(o)]), N = this.buildJoins(a), y = n ? _` returning ${this.buildSelection(n, { isSingleTable: !0 })}` : void 0, I = s ? _` where ${s}` : void 0, L = this.buildOrderBy(u), w = this.buildLimit(d);
    return _`${l}update ${e} set ${p}${S}${N}${I}${y}${L}${w}`;
  }
  /**
   * Builds selection SQL with provided fields/expressions
   *
   * Examples:
   *
   * `select <selection> from`
   *
   * `insert ... returning <selection>`
   *
   * If `isSingleTable` is true, then columns won't be prefixed with table name
   */
  buildSelection(e, { isSingleTable: t = !1 } = {}) {
    const s = e.length, n = e.flatMap(({ field: i }, a) => {
      const o = [];
      if (C(i, Y.Aliased) && i.isSelectionField)
        o.push(_.identifier(i.fieldAlias));
      else if (C(i, Y.Aliased) || C(i, Y)) {
        const d = C(i, Y.Aliased) ? i.sql : i;
        t ? o.push(
          new Y(
            d.queryChunks.map((u) => C(u, we) ? _.identifier(this.casing.getColumnCasing(u)) : u)
          )
        ) : o.push(d), C(i, Y.Aliased) && o.push(_` as ${_.identifier(i.fieldAlias)}`);
      } else if (C(i, we)) {
        const d = i.table[q.Symbol.Name];
        t ? o.push(_.identifier(this.casing.getColumnCasing(i))) : o.push(_`${_.identifier(d)}.${_.identifier(this.casing.getColumnCasing(i))}`);
      }
      return a < s - 1 && o.push(_`, `), o;
    });
    return _.join(n);
  }
  buildJoins(e) {
    if (!e || e.length === 0)
      return;
    const t = [];
    if (e)
      for (const [s, n] of e.entries()) {
        s === 0 && t.push(_` `);
        const i = n.table;
        if (C(i, nt)) {
          const a = i[nt.Symbol.Name], o = i[nt.Symbol.Schema], d = i[nt.Symbol.OriginalName], u = a === d ? void 0 : n.alias;
          t.push(
            _`${_.raw(n.joinType)} join ${o ? _`${_.identifier(o)}.` : void 0}${_.identifier(d)}${u && _` ${_.identifier(u)}`} on ${n.on}`
          );
        } else
          t.push(
            _`${_.raw(n.joinType)} join ${i} on ${n.on}`
          );
        s < e.length - 1 && t.push(_` `);
      }
    return _.join(t);
  }
  buildLimit(e) {
    return typeof e == "object" || typeof e == "number" && e >= 0 ? _` limit ${e}` : void 0;
  }
  buildOrderBy(e) {
    const t = [];
    if (e)
      for (const [s, n] of e.entries())
        t.push(n), s < e.length - 1 && t.push(_`, `);
    return t.length > 0 ? _` order by ${_.join(t)}` : void 0;
  }
  buildFromTable(e) {
    return C(e, q) && e[q.Symbol.OriginalName] !== e[q.Symbol.Name] ? _`${_.identifier(e[q.Symbol.OriginalName])} ${_.identifier(e[q.Symbol.Name])}` : e;
  }
  buildSelectQuery({
    withList: e,
    fields: t,
    fieldsFlat: s,
    where: n,
    having: i,
    table: a,
    joins: o,
    orderBy: d,
    groupBy: u,
    limit: l,
    offset: p,
    distinct: S,
    setOperators: N
  }) {
    const y = s ?? ms(t);
    for (const be of y)
      if (C(be.field, we) && As(be.field.table) !== (C(a, pt) ? a._.alias : C(a, zn) ? a[Ke].name : C(a, Y) ? void 0 : As(a)) && !((dt) => o == null ? void 0 : o.some(
        ({ alias: Kt }) => Kt === (dt[q.Symbol.IsAlias] ? As(dt) : dt[q.Symbol.BaseName])
      ))(be.field.table)) {
        const dt = As(be.field.table);
        throw new Error(
          `Your "${be.path.join("->")}" field references a column "${dt}"."${be.field.name}", but the table "${dt}" is not part of the query! Did you forget to join it?`
        );
      }
    const I = !o || o.length === 0, L = this.buildWithCTE(e), w = S ? _` distinct` : void 0, P = this.buildSelection(y, { isSingleTable: I }), O = this.buildFromTable(a), k = this.buildJoins(o), B = n ? _` where ${n}` : void 0, ue = i ? _` having ${i}` : void 0, M = [];
    if (u)
      for (const [be, dt] of u.entries())
        M.push(dt), be < u.length - 1 && M.push(_`, `);
    const K = M.length > 0 ? _` group by ${_.join(M)}` : void 0, Se = this.buildOrderBy(d), Tt = this.buildLimit(l), qe = p ? _` offset ${p}` : void 0, He = _`${L}select${w} ${P} from ${O}${k}${B}${K}${ue}${Se}${Tt}${qe}`;
    return N.length > 0 ? this.buildSetOperations(He, N) : He;
  }
  buildSetOperations(e, t) {
    const [s, ...n] = t;
    if (!s)
      throw new Error("Cannot pass undefined values to any set operator");
    return n.length === 0 ? this.buildSetOperationQuery({ leftSelect: e, setOperator: s }) : this.buildSetOperations(
      this.buildSetOperationQuery({ leftSelect: e, setOperator: s }),
      n
    );
  }
  buildSetOperationQuery({
    leftSelect: e,
    setOperator: { type: t, isAll: s, rightSelect: n, limit: i, orderBy: a, offset: o }
  }) {
    const d = _`${e.getSQL()} `, u = _`${n.getSQL()}`;
    let l;
    if (a && a.length > 0) {
      const y = [];
      for (const I of a)
        if (C(I, at))
          y.push(_.identifier(I.name));
        else if (C(I, Y)) {
          for (let L = 0; L < I.queryChunks.length; L++) {
            const w = I.queryChunks[L];
            C(w, at) && (I.queryChunks[L] = _.identifier(this.casing.getColumnCasing(w)));
          }
          y.push(_`${I}`);
        } else
          y.push(_`${I}`);
      l = _` order by ${_.join(y, _`, `)}`;
    }
    const p = typeof i == "object" || typeof i == "number" && i >= 0 ? _` limit ${i}` : void 0, S = _.raw(`${t} ${s ? "all " : ""}`), N = o ? _` offset ${o}` : void 0;
    return _`${d}${S}${u}${l}${p}${N}`;
  }
  buildInsertQuery({ table: e, values: t, onConflict: s, returning: n, withList: i, select: a }) {
    const o = [], d = e[q.Symbol.Columns], u = Object.entries(d).filter(
      ([I, L]) => !L.shouldDisableInsert()
    ), l = u.map(([, I]) => _.identifier(this.casing.getColumnCasing(I)));
    if (a) {
      const I = t;
      C(I, Y) ? o.push(I) : o.push(I.getSQL());
    } else {
      const I = t;
      o.push(_.raw("values "));
      for (const [L, w] of I.entries()) {
        const P = [];
        for (const [O, k] of u) {
          const B = w[O];
          if (B === void 0 || C(B, Yt) && B.value === void 0) {
            let ue;
            if (k.default !== null && k.default !== void 0)
              ue = C(k.default, Y) ? k.default : _.param(k.default, k);
            else if (k.defaultFn !== void 0) {
              const M = k.defaultFn();
              ue = C(M, Y) ? M : _.param(M, k);
            } else if (!k.default && k.onUpdateFn !== void 0) {
              const M = k.onUpdateFn();
              ue = C(M, Y) ? M : _.param(M, k);
            } else
              ue = _`null`;
            P.push(ue);
          } else
            P.push(B);
        }
        o.push(P), L < I.length - 1 && o.push(_`, `);
      }
    }
    const p = this.buildWithCTE(i), S = _.join(o), N = n ? _` returning ${this.buildSelection(n, { isSingleTable: !0 })}` : void 0, y = s != null && s.length ? _.join(s) : void 0;
    return _`${p}insert into ${e} ${l} ${S}${y}${N}`;
  }
  sqlToQuery(e, t) {
    return e.toQuery({
      casing: this.casing,
      escapeName: this.escapeName,
      escapeParam: this.escapeParam,
      escapeString: this.escapeString,
      invokeSource: t
    });
  }
  buildRelationalQuery({
    fullSchema: e,
    schema: t,
    tableNamesMap: s,
    table: n,
    tableConfig: i,
    queryConfig: a,
    tableAlias: o,
    nestedQueryRelation: d,
    joinOn: u
  }) {
    let l = [], p, S, N = [], y;
    const I = [];
    if (a === !0)
      l = Object.entries(i.columns).map(([P, O]) => ({
        dbKey: O.name,
        tsKey: P,
        field: Bt(O, o),
        relationTableTsKey: void 0,
        isJson: !1,
        selection: []
      }));
    else {
      const w = Object.fromEntries(
        Object.entries(i.columns).map(([M, K]) => [M, Bt(K, o)])
      );
      if (a.where) {
        const M = typeof a.where == "function" ? a.where(w, Bl()) : a.where;
        y = M && cn(M, o);
      }
      const P = [];
      let O = [];
      if (a.columns) {
        let M = !1;
        for (const [K, Se] of Object.entries(a.columns))
          Se !== void 0 && K in i.columns && (!M && Se === !0 && (M = !0), O.push(K));
        O.length > 0 && (O = M ? O.filter((K) => {
          var Se;
          return ((Se = a.columns) == null ? void 0 : Se[K]) === !0;
        }) : Object.keys(i.columns).filter((K) => !O.includes(K)));
      } else
        O = Object.keys(i.columns);
      for (const M of O) {
        const K = i.columns[M];
        P.push({ tsKey: M, value: K });
      }
      let k = [];
      a.with && (k = Object.entries(a.with).filter((M) => !!M[1]).map(([M, K]) => ({ tsKey: M, queryConfig: K, relation: i.relations[M] })));
      let B;
      if (a.extras) {
        B = typeof a.extras == "function" ? a.extras(w, { sql: _ }) : a.extras;
        for (const [M, K] of Object.entries(B))
          P.push({
            tsKey: M,
            value: Pd(K, o)
          });
      }
      for (const { tsKey: M, value: K } of P)
        l.push({
          dbKey: C(K, Y.Aliased) ? K.fieldAlias : i.columns[M].name,
          tsKey: M,
          field: C(K, we) ? Bt(K, o) : K,
          relationTableTsKey: void 0,
          isJson: !1,
          selection: []
        });
      let ue = typeof a.orderBy == "function" ? a.orderBy(w, Ml()) : a.orderBy ?? [];
      Array.isArray(ue) || (ue = [ue]), N = ue.map((M) => C(M, we) ? Bt(M, o) : cn(M, o)), p = a.limit, S = a.offset;
      for (const {
        tsKey: M,
        queryConfig: K,
        relation: Se
      } of k) {
        const Tt = Hl(t, s, Se), qe = zs(Se.referencedTable), He = s[qe], be = `${o}_${M}`, dt = ae(
          ...Tt.fields.map(
            (Cs, ei) => g(
              Bt(Tt.references[ei], be),
              Bt(Cs, o)
            )
          )
        ), Kt = this.buildRelationalQuery({
          fullSchema: e,
          schema: t,
          tableNamesMap: s,
          table: e[He],
          tableConfig: t[He],
          queryConfig: C(Se, ps) ? K === !0 ? { limit: 1 } : { ...K, limit: 1 } : K,
          tableAlias: be,
          joinOn: dt,
          nestedQueryRelation: Se
        }), vs = _`(${Kt.sql})`.as(M);
        l.push({
          dbKey: M,
          tsKey: M,
          field: vs,
          relationTableTsKey: He,
          isJson: !0,
          selection: Kt.selection
        });
      }
    }
    if (l.length === 0)
      throw new Pn({
        message: `No fields selected for table "${i.tsName}" ("${o}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.`
      });
    let L;
    if (y = ae(u, y), d) {
      let w = _`json_array(${_.join(
        l.map(
          ({ field: k }) => C(k, at) ? _.identifier(this.casing.getColumnCasing(k)) : C(k, Y.Aliased) ? k.sql : k
        ),
        _`, `
      )})`;
      C(d, un) && (w = _`coalesce(json_group_array(${w}), json_array())`);
      const P = [{
        dbKey: "data",
        tsKey: "data",
        field: w.as("data"),
        isJson: !0,
        relationTableTsKey: i.tsName,
        selection: l
      }];
      p !== void 0 || S !== void 0 || N.length > 0 ? (L = this.buildSelectQuery({
        table: Qn(n, o),
        fields: {},
        fieldsFlat: [
          {
            path: [],
            field: _.raw("*")
          }
        ],
        where: y,
        limit: p,
        offset: S,
        orderBy: N,
        setOperators: []
      }), y = void 0, p = void 0, S = void 0, N = void 0) : L = Qn(n, o), L = this.buildSelectQuery({
        table: C(L, nt) ? L : new pt(L, {}, o),
        fields: {},
        fieldsFlat: P.map(({ field: k }) => ({
          path: [],
          field: C(k, we) ? Bt(k, o) : k
        })),
        joins: I,
        where: y,
        limit: p,
        offset: S,
        orderBy: N,
        setOperators: []
      });
    } else
      L = this.buildSelectQuery({
        table: Qn(n, o),
        fields: {},
        fieldsFlat: l.map(({ field: w }) => ({
          path: [],
          field: C(w, we) ? Bt(w, o) : w
        })),
        joins: I,
        where: y,
        limit: p,
        offset: S,
        orderBy: N,
        setOperators: []
      });
    return {
      tableTsKey: i.tsName,
      sql: L,
      selection: l
    };
  }
}
h(ln, xo, "SQLiteDialect");
var bo, Lo;
class Lr extends (Lo = ln, bo = v, Lo) {
  migrate(e, t, s) {
    const n = s === void 0 || typeof s == "string" ? "__drizzle_migrations" : s.migrationsTable ?? "__drizzle_migrations", i = _`
			CREATE TABLE IF NOT EXISTS ${_.identifier(n)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
    t.run(i);
    const o = t.values(
      _`SELECT id, hash, created_at FROM ${_.identifier(n)} ORDER BY created_at DESC LIMIT 1`
    )[0] ?? void 0;
    t.run(_`BEGIN`);
    try {
      for (const d of e)
        if (!o || Number(o[2]) < d.folderMillis) {
          for (const u of d.sql)
            t.run(_.raw(u));
          t.run(
            _`INSERT INTO ${_.identifier(n)} ("hash", "created_at") VALUES(${d.hash}, ${d.folderMillis})`
          );
        }
      t.run(_`COMMIT`);
    } catch (d) {
      throw t.run(_`ROLLBACK`), d;
    }
  }
}
h(Lr, bo, "SQLiteSyncDialect");
var Po;
Po = v;
class mc {
  /** @internal */
  getSelectedFields() {
    return this._.selectedFields;
  }
}
h(mc, Po, "TypedQueryBuilder");
var ko;
ko = v;
class $t {
  constructor(e) {
    h(this, "fields");
    h(this, "session");
    h(this, "dialect");
    h(this, "withList");
    h(this, "distinct");
    this.fields = e.fields, this.session = e.session, this.dialect = e.dialect, this.withList = e.withList, this.distinct = e.distinct;
  }
  from(e) {
    const t = !!this.fields;
    let s;
    return this.fields ? s = this.fields : C(e, pt) ? s = Object.fromEntries(
      Object.keys(e._.selectedFields).map((n) => [n, e[n]])
    ) : C(e, zn) ? s = e[Ke].selectedFields : C(e, Y) ? s = {} : s = ml(e), new Pr({
      table: e,
      fields: s,
      isPartialSelect: t,
      session: this.session,
      dialect: this.dialect,
      withList: this.withList,
      distinct: this.distinct
    });
  }
}
h($t, ko, "SQLiteSelectBuilder");
var zo, Bo;
class pc extends (Bo = mc, zo = v, Bo) {
  constructor({ table: t, fields: s, isPartialSelect: n, session: i, dialect: a, withList: o, distinct: d }) {
    super();
    h(this, "_");
    /** @internal */
    h(this, "config");
    h(this, "joinsNotNullableMap");
    h(this, "tableName");
    h(this, "isPartialSelect");
    h(this, "session");
    h(this, "dialect");
    /**
     * Executes a `left join` operation by adding another table to the current query.
     *
     * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
     *
     * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
     *
     * @param table the table to join.
     * @param on the `on` clause.
     *
     * @example
     *
     * ```ts
     * // Select all users and their pets
     * const usersWithPets: { user: User; pets: Pet | null }[] = await db.select()
     *   .from(users)
     *   .leftJoin(pets, eq(users.id, pets.ownerId))
     *
     * // Select userId and petId
     * const usersIdsAndPetIds: { userId: number; petId: number | null }[] = await db.select({
     *   userId: users.id,
     *   petId: pets.id,
     * })
     *   .from(users)
     *   .leftJoin(pets, eq(users.id, pets.ownerId))
     * ```
     */
    h(this, "leftJoin", this.createJoin("left"));
    /**
     * Executes a `right join` operation by adding another table to the current query.
     *
     * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
     *
     * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
     *
     * @param table the table to join.
     * @param on the `on` clause.
     *
     * @example
     *
     * ```ts
     * // Select all users and their pets
     * const usersWithPets: { user: User | null; pets: Pet }[] = await db.select()
     *   .from(users)
     *   .rightJoin(pets, eq(users.id, pets.ownerId))
     *
     * // Select userId and petId
     * const usersIdsAndPetIds: { userId: number | null; petId: number }[] = await db.select({
     *   userId: users.id,
     *   petId: pets.id,
     * })
     *   .from(users)
     *   .rightJoin(pets, eq(users.id, pets.ownerId))
     * ```
     */
    h(this, "rightJoin", this.createJoin("right"));
    /**
     * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
     *
     * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
     *
     * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
     *
     * @param table the table to join.
     * @param on the `on` clause.
     *
     * @example
     *
     * ```ts
     * // Select all users and their pets
     * const usersWithPets: { user: User; pets: Pet }[] = await db.select()
     *   .from(users)
     *   .innerJoin(pets, eq(users.id, pets.ownerId))
     *
     * // Select userId and petId
     * const usersIdsAndPetIds: { userId: number; petId: number }[] = await db.select({
     *   userId: users.id,
     *   petId: pets.id,
     * })
     *   .from(users)
     *   .innerJoin(pets, eq(users.id, pets.ownerId))
     * ```
     */
    h(this, "innerJoin", this.createJoin("inner"));
    /**
     * Executes a `full join` operation by combining rows from two tables into a new table.
     *
     * Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
     *
     * See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
     *
     * @param table the table to join.
     * @param on the `on` clause.
     *
     * @example
     *
     * ```ts
     * // Select all users and their pets
     * const usersWithPets: { user: User | null; pets: Pet | null }[] = await db.select()
     *   .from(users)
     *   .fullJoin(pets, eq(users.id, pets.ownerId))
     *
     * // Select userId and petId
     * const usersIdsAndPetIds: { userId: number | null; petId: number | null }[] = await db.select({
     *   userId: users.id,
     *   petId: pets.id,
     * })
     *   .from(users)
     *   .fullJoin(pets, eq(users.id, pets.ownerId))
     * ```
     */
    h(this, "fullJoin", this.createJoin("full"));
    /**
     * Adds `union` set operator to the query.
     *
     * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
     *
     * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
     *
     * @example
     *
     * ```ts
     * // Select all unique names from customers and users tables
     * await db.select({ name: users.name })
     *   .from(users)
     *   .union(
     *     db.select({ name: customers.name }).from(customers)
     *   );
     * // or
     * import { union } from 'drizzle-orm/sqlite-core'
     *
     * await union(
     *   db.select({ name: users.name }).from(users),
     *   db.select({ name: customers.name }).from(customers)
     * );
     * ```
     */
    h(this, "union", this.createSetOperator("union", !1));
    /**
     * Adds `union all` set operator to the query.
     *
     * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
     *
     * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
     *
     * @example
     *
     * ```ts
     * // Select all transaction ids from both online and in-store sales
     * await db.select({ transaction: onlineSales.transactionId })
     *   .from(onlineSales)
     *   .unionAll(
     *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
     *   );
     * // or
     * import { unionAll } from 'drizzle-orm/sqlite-core'
     *
     * await unionAll(
     *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
     *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
     * );
     * ```
     */
    h(this, "unionAll", this.createSetOperator("union", !0));
    /**
     * Adds `intersect` set operator to the query.
     *
     * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
     *
     * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
     *
     * @example
     *
     * ```ts
     * // Select course names that are offered in both departments A and B
     * await db.select({ courseName: depA.courseName })
     *   .from(depA)
     *   .intersect(
     *     db.select({ courseName: depB.courseName }).from(depB)
     *   );
     * // or
     * import { intersect } from 'drizzle-orm/sqlite-core'
     *
     * await intersect(
     *   db.select({ courseName: depA.courseName }).from(depA),
     *   db.select({ courseName: depB.courseName }).from(depB)
     * );
     * ```
     */
    h(this, "intersect", this.createSetOperator("intersect", !1));
    /**
     * Adds `except` set operator to the query.
     *
     * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
     *
     * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
     *
     * @example
     *
     * ```ts
     * // Select all courses offered in department A but not in department B
     * await db.select({ courseName: depA.courseName })
     *   .from(depA)
     *   .except(
     *     db.select({ courseName: depB.courseName }).from(depB)
     *   );
     * // or
     * import { except } from 'drizzle-orm/sqlite-core'
     *
     * await except(
     *   db.select({ courseName: depA.courseName }).from(depA),
     *   db.select({ courseName: depB.courseName }).from(depB)
     * );
     * ```
     */
    h(this, "except", this.createSetOperator("except", !1));
    this.config = {
      withList: o,
      table: t,
      fields: { ...s },
      distinct: d,
      setOperators: []
    }, this.isPartialSelect = n, this.session = i, this.dialect = a, this._ = {
      selectedFields: s
    }, this.tableName = rr(t), this.joinsNotNullableMap = typeof this.tableName == "string" ? { [this.tableName]: !0 } : {};
  }
  createJoin(t) {
    return (s, n) => {
      var o;
      const i = this.tableName, a = rr(s);
      if (typeof a == "string" && ((o = this.config.joins) != null && o.some((d) => d.alias === a)))
        throw new Error(`Alias "${a}" is already used in this query`);
      if (!this.isPartialSelect && (Object.keys(this.joinsNotNullableMap).length === 1 && typeof i == "string" && (this.config.fields = {
        [i]: this.config.fields
      }), typeof a == "string" && !C(s, Y))) {
        const d = C(s, pt) ? s._.selectedFields : C(s, _s) ? s[Ke].selectedFields : s[q.Symbol.Columns];
        this.config.fields[a] = d;
      }
      if (typeof n == "function" && (n = n(
        new Proxy(
          this.config.fields,
          new Ze({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
        )
      )), this.config.joins || (this.config.joins = []), this.config.joins.push({ on: n, table: s, joinType: t, alias: a }), typeof a == "string")
        switch (t) {
          case "left": {
            this.joinsNotNullableMap[a] = !1;
            break;
          }
          case "right": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([d]) => [d, !1])
            ), this.joinsNotNullableMap[a] = !0;
            break;
          }
          case "inner": {
            this.joinsNotNullableMap[a] = !0;
            break;
          }
          case "full": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([d]) => [d, !1])
            ), this.joinsNotNullableMap[a] = !1;
            break;
          }
        }
      return this;
    };
  }
  createSetOperator(t, s) {
    return (n) => {
      const i = typeof n == "function" ? n(Yl()) : n;
      if (!Ur(this.getSelectedFields(), i.getSelectedFields()))
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      return this.config.setOperators.push({ type: t, isAll: s, rightSelect: i }), this;
    };
  }
  /** @internal */
  addSetOperators(t) {
    return this.config.setOperators.push(...t), this;
  }
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be selected.
   *
   * ```ts
   * // Select all cars with green color
   * await db.select().from(cars).where(eq(cars.color, 'green'));
   * // or
   * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Select all BMW cars with a green color
   * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Select all cars with the green or blue color
   * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(t) {
    return typeof t == "function" && (t = t(
      new Proxy(
        this.config.fields,
        new Ze({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
      )
    )), this.config.where = t, this;
  }
  /**
   * Adds a `having` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
   *
   * @param having the `having` clause.
   *
   * @example
   *
   * ```ts
   * // Select all brands with more than one car
   * await db.select({
   * 	brand: cars.brand,
   * 	count: sql<number>`cast(count(${cars.id}) as int)`,
   * })
   *   .from(cars)
   *   .groupBy(cars.brand)
   *   .having(({ count }) => gt(count, 1));
   * ```
   */
  having(t) {
    return typeof t == "function" && (t = t(
      new Proxy(
        this.config.fields,
        new Ze({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
      )
    )), this.config.having = t, this;
  }
  groupBy(...t) {
    if (typeof t[0] == "function") {
      const s = t[0](
        new Proxy(
          this.config.fields,
          new Ze({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      this.config.groupBy = Array.isArray(s) ? s : [s];
    } else
      this.config.groupBy = t;
    return this;
  }
  orderBy(...t) {
    if (typeof t[0] == "function") {
      const s = t[0](
        new Proxy(
          this.config.fields,
          new Ze({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      ), n = Array.isArray(s) ? s : [s];
      this.config.setOperators.length > 0 ? this.config.setOperators.at(-1).orderBy = n : this.config.orderBy = n;
    } else {
      const s = t;
      this.config.setOperators.length > 0 ? this.config.setOperators.at(-1).orderBy = s : this.config.orderBy = s;
    }
    return this;
  }
  /**
   * Adds a `limit` clause to the query.
   *
   * Calling this method will set the maximum number of rows that will be returned by this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param limit the `limit` clause.
   *
   * @example
   *
   * ```ts
   * // Get the first 10 people from this query.
   * await db.select().from(people).limit(10);
   * ```
   */
  limit(t) {
    return this.config.setOperators.length > 0 ? this.config.setOperators.at(-1).limit = t : this.config.limit = t, this;
  }
  /**
   * Adds an `offset` clause to the query.
   *
   * Calling this method will skip a number of rows when returning results from this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param offset the `offset` clause.
   *
   * @example
   *
   * ```ts
   * // Get the 10th-20th people from this query.
   * await db.select().from(people).offset(10).limit(10);
   * ```
   */
  offset(t) {
    return this.config.setOperators.length > 0 ? this.config.setOperators.at(-1).offset = t : this.config.offset = t, this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildSelectQuery(this.config);
  }
  toSQL() {
    const { typings: t, ...s } = this.dialect.sqlToQuery(this.getSQL());
    return s;
  }
  as(t) {
    return new Proxy(
      new pt(this.getSQL(), this.config.fields, t),
      new Ze({ alias: t, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  /** @internal */
  getSelectedFields() {
    return new Proxy(
      this.config.fields,
      new Ze({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  $dynamic() {
    return this;
  }
}
h(pc, zo, "SQLiteSelectQueryBuilder");
var Mo, Fo;
class Pr extends (Fo = pc, Mo = v, Fo) {
  constructor() {
    super(...arguments);
    h(this, "run", (t) => this._prepare().run(t));
    h(this, "all", (t) => this._prepare().all(t));
    h(this, "get", (t) => this._prepare().get(t));
    h(this, "values", (t) => this._prepare().values(t));
  }
  /** @internal */
  _prepare(t = !0) {
    if (!this.session)
      throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
    const s = ms(this.config.fields), n = this.session[t ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      s,
      "all",
      !0
    );
    return n.joinsNotNullableMap = this.joinsNotNullableMap, n;
  }
  prepare() {
    return this._prepare(!1);
  }
  async execute() {
    return this.all();
  }
}
h(Pr, Mo, "SQLiteSelect");
hl(Pr, [os]);
function Bn(r, e) {
  return (t, s, ...n) => {
    const i = [s, ...n].map((a) => ({
      type: r,
      isAll: e,
      rightSelect: a
    }));
    for (const a of i)
      if (!Ur(t.getSelectedFields(), a.rightSelect.getSelectedFields()))
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
    return t.addSetOperators(i);
  };
}
const Yl = () => ({
  union: Jl,
  unionAll: Vl,
  intersect: Ql,
  except: Kl
}), Jl = Bn("union", !1), Vl = Bn("union", !0), Ql = Bn("intersect", !1), Kl = Bn("except", !1);
var $o;
$o = v;
class kr {
  constructor(e) {
    h(this, "dialect");
    h(this, "dialectConfig");
    h(this, "$with", (e, t) => {
      const s = this;
      return { as: (i) => (typeof i == "function" && (i = i(s)), new Proxy(
        new Cr(
          i.getSQL(),
          t ?? ("getSelectedFields" in i ? i.getSelectedFields() ?? {} : {}),
          e,
          !0
        ),
        new Ze({ alias: e, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      )) };
    });
    this.dialect = C(e, ln) ? e : void 0, this.dialectConfig = C(e, ln) ? void 0 : e;
  }
  with(...e) {
    const t = this;
    function s(i) {
      return new $t({
        fields: i ?? void 0,
        session: void 0,
        dialect: t.getDialect(),
        withList: e
      });
    }
    function n(i) {
      return new $t({
        fields: i ?? void 0,
        session: void 0,
        dialect: t.getDialect(),
        withList: e,
        distinct: !0
      });
    }
    return { select: s, selectDistinct: n };
  }
  select(e) {
    return new $t({ fields: e ?? void 0, session: void 0, dialect: this.getDialect() });
  }
  selectDistinct(e) {
    return new $t({
      fields: e ?? void 0,
      session: void 0,
      dialect: this.getDialect(),
      distinct: !0
    });
  }
  // Lazy load dialect to avoid circular dependency
  getDialect() {
    return this.dialect || (this.dialect = new Lr(this.dialectConfig)), this.dialect;
  }
}
h(kr, $o, "SQLiteQueryBuilder");
var qo;
qo = v;
class lr {
  constructor(e, t, s, n) {
    this.table = e, this.session = t, this.dialect = s, this.withList = n;
  }
  values(e) {
    if (e = Array.isArray(e) ? e : [e], e.length === 0)
      throw new Error("values() must be called with at least one value");
    const t = e.map((s) => {
      const n = {}, i = this.table[q.Symbol.Columns];
      for (const a of Object.keys(s)) {
        const o = s[a];
        n[a] = C(o, Y) ? o : new Yt(o, i[a]);
      }
      return n;
    });
    return new hr(this.table, t, this.session, this.dialect, this.withList);
  }
  select(e) {
    const t = typeof e == "function" ? e(new kr()) : e;
    if (!C(t, Y) && !Ur(this.table[nr], t._.selectedFields))
      throw new Error(
        "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
      );
    return new hr(this.table, t, this.session, this.dialect, this.withList, !0);
  }
}
h(lr, qo, "SQLiteInsertBuilder");
var Ho, Go;
class hr extends (Go = os, Ho = v, Go) {
  constructor(t, s, n, i, a, o) {
    super();
    /** @internal */
    h(this, "config");
    h(this, "run", (t) => this._prepare().run(t));
    h(this, "all", (t) => this._prepare().all(t));
    h(this, "get", (t) => this._prepare().get(t));
    h(this, "values", (t) => this._prepare().values(t));
    this.session = n, this.dialect = i, this.config = { table: t, values: s, withList: a, select: o };
  }
  returning(t = this.config.table[nt.Symbol.Columns]) {
    return this.config.returning = ms(t), this;
  }
  /**
   * Adds an `on conflict do nothing` clause to the query.
   *
   * Calling this method simply avoids inserting a row as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
   *
   * @param config The `target` and `where` clauses.
   *
   * @example
   * ```ts
   * // Insert one row and cancel the insert if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing();
   *
   * // Explicitly specify conflict target
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing({ target: cars.id });
   * ```
   */
  onConflictDoNothing(t = {}) {
    if (this.config.onConflict || (this.config.onConflict = []), t.target === void 0)
      this.config.onConflict.push(_` on conflict do nothing`);
    else {
      const s = Array.isArray(t.target) ? _`${t.target}` : _`${[t.target]}`, n = t.where ? _` where ${t.where}` : _``;
      this.config.onConflict.push(_` on conflict ${s} do nothing${n}`);
    }
    return this;
  }
  /**
   * Adds an `on conflict do update` clause to the query.
   *
   * Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
   *
   * @param config The `target`, `set` and `where` clauses.
   *
   * @example
   * ```ts
   * // Update the row if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'Porsche' }
   *   });
   *
   * // Upsert with 'where' clause
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'newBMW' },
   *     where: sql`${cars.createdAt} > '2023-01-01'::date`,
   *   });
   * ```
   */
  onConflictDoUpdate(t) {
    if (t.where && (t.targetWhere || t.setWhere))
      throw new Error(
        'You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.'
      );
    this.config.onConflict || (this.config.onConflict = []);
    const s = t.where ? _` where ${t.where}` : void 0, n = t.targetWhere ? _` where ${t.targetWhere}` : void 0, i = t.setWhere ? _` where ${t.setWhere}` : void 0, a = Array.isArray(t.target) ? _`${t.target}` : _`${[t.target]}`, o = this.dialect.buildUpdateSet(this.config.table, Bd(this.config.table, t.set));
    return this.config.onConflict.push(
      _` on conflict ${a}${n} do update set ${o}${s}${i}`
    ), this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildInsertQuery(this.config);
  }
  toSQL() {
    const { typings: t, ...s } = this.dialect.sqlToQuery(this.getSQL());
    return s;
  }
  /** @internal */
  _prepare(t = !0) {
    return this.session[t ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      !0
    );
  }
  prepare() {
    return this._prepare(!1);
  }
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
}
h(hr, Ho, "SQLiteInsert");
var Yo;
Yo = v;
class mr {
  constructor(e, t, s, n) {
    this.table = e, this.session = t, this.dialect = s, this.withList = n;
  }
  set(e) {
    return new fc(
      this.table,
      Bd(this.table, e),
      this.session,
      this.dialect,
      this.withList
    );
  }
}
h(mr, Yo, "SQLiteUpdateBuilder");
var Jo, Vo;
class fc extends (Vo = os, Jo = v, Vo) {
  constructor(t, s, n, i, a) {
    super();
    /** @internal */
    h(this, "config");
    h(this, "leftJoin", this.createJoin("left"));
    h(this, "rightJoin", this.createJoin("right"));
    h(this, "innerJoin", this.createJoin("inner"));
    h(this, "fullJoin", this.createJoin("full"));
    h(this, "run", (t) => this._prepare().run(t));
    h(this, "all", (t) => this._prepare().all(t));
    h(this, "get", (t) => this._prepare().get(t));
    h(this, "values", (t) => this._prepare().values(t));
    this.session = n, this.dialect = i, this.config = { set: s, table: t, withList: a, joins: [] };
  }
  from(t) {
    return this.config.from = t, this;
  }
  createJoin(t) {
    return (s, n) => {
      const i = rr(s);
      if (typeof i == "string" && this.config.joins.some((a) => a.alias === i))
        throw new Error(`Alias "${i}" is already used in this query`);
      if (typeof n == "function") {
        const a = this.config.from ? C(s, nt) ? s[q.Symbol.Columns] : C(s, pt) ? s._.selectedFields : C(s, zn) ? s[Ke].selectedFields : void 0 : void 0;
        n = n(
          new Proxy(
            this.config.table[q.Symbol.Columns],
            new Ze({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          ),
          a && new Proxy(
            a,
            new Ze({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          )
        );
      }
      return this.config.joins.push({ on: n, table: s, joinType: t, alias: i }), this;
    };
  }
  /**
   * Adds a 'where' clause to the query.
   *
   * Calling this method will update only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param where the 'where' clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be updated.
   *
   * ```ts
   * // Update all cars with green color
   * db.update(cars).set({ color: 'red' })
   *   .where(eq(cars.color, 'green'));
   * // or
   * db.update(cars).set({ color: 'red' })
   *   .where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Update all BMW cars with a green color
   * db.update(cars).set({ color: 'red' })
   *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Update all cars with the green or blue color
   * db.update(cars).set({ color: 'red' })
   *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(t) {
    return this.config.where = t, this;
  }
  orderBy(...t) {
    if (typeof t[0] == "function") {
      const s = t[0](
        new Proxy(
          this.config.table[q.Symbol.Columns],
          new Ze({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      ), n = Array.isArray(s) ? s : [s];
      this.config.orderBy = n;
    } else {
      const s = t;
      this.config.orderBy = s;
    }
    return this;
  }
  limit(t) {
    return this.config.limit = t, this;
  }
  returning(t = this.config.table[nt.Symbol.Columns]) {
    return this.config.returning = ms(t), this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildUpdateQuery(this.config);
  }
  toSQL() {
    const { typings: t, ...s } = this.dialect.sqlToQuery(this.getSQL());
    return s;
  }
  /** @internal */
  _prepare(t = !0) {
    return this.session[t ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      !0
    );
  }
  prepare() {
    return this._prepare(!1);
  }
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
}
h(fc, Jo, "SQLiteUpdate");
var Qo, Ko, jo;
const ks = class ks extends (jo = Y, Ko = v, Qo = Symbol.toStringTag, jo) {
  constructor(t) {
    super(ks.buildEmbeddedCount(t.source, t.filters).queryChunks);
    h(this, "sql");
    h(this, Qo, "SQLiteCountBuilderAsync");
    h(this, "session");
    this.params = t, this.session = t.session, this.sql = ks.buildCount(
      t.source,
      t.filters
    );
  }
  static buildEmbeddedCount(t, s) {
    return _`(select count(*) from ${t}${_.raw(" where ").if(s)}${s})`;
  }
  static buildCount(t, s) {
    return _`select count(*) from ${t}${_.raw(" where ").if(s)}${s}`;
  }
  then(t, s) {
    return Promise.resolve(this.session.count(this.sql)).then(
      t,
      s
    );
  }
  catch(t) {
    return this.then(void 0, t);
  }
  finally(t) {
    return this.then(
      (s) => (t == null || t(), s),
      (s) => {
        throw t == null || t(), s;
      }
    );
  }
};
h(ks, Ko, "SQLiteCountBuilderAsync");
let pr = ks;
var Xo;
Xo = v;
class Ec {
  constructor(e, t, s, n, i, a, o, d) {
    this.mode = e, this.fullSchema = t, this.schema = s, this.tableNamesMap = n, this.table = i, this.tableConfig = a, this.dialect = o, this.session = d;
  }
  findMany(e) {
    return this.mode === "sync" ? new fr(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      e || {},
      "many"
    ) : new hn(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      e || {},
      "many"
    );
  }
  findFirst(e) {
    return this.mode === "sync" ? new fr(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      e ? { ...e, limit: 1 } : { limit: 1 },
      "first"
    ) : new hn(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      e ? { ...e, limit: 1 } : { limit: 1 },
      "first"
    );
  }
}
h(Ec, Xo, "SQLiteAsyncRelationalQueryBuilder");
var Zo, Wo;
class hn extends (Wo = os, Zo = v, Wo) {
  constructor(t, s, n, i, a, o, d, u, l) {
    super();
    /** @internal */
    h(this, "mode");
    this.fullSchema = t, this.schema = s, this.tableNamesMap = n, this.table = i, this.tableConfig = a, this.dialect = o, this.session = d, this.config = u, this.mode = l;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    }).sql;
  }
  /** @internal */
  _prepare(t = !1) {
    const { query: s, builtQuery: n } = this._toSQL();
    return this.session[t ? "prepareOneTimeQuery" : "prepareQuery"](
      n,
      void 0,
      this.mode === "first" ? "get" : "all",
      !0,
      (i, a) => {
        const o = i.map(
          (d) => ur(this.schema, this.tableConfig, d, s.selection, a)
        );
        return this.mode === "first" ? o[0] : o;
      }
    );
  }
  prepare() {
    return this._prepare(!1);
  }
  _toSQL() {
    const t = this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    }), s = this.dialect.sqlToQuery(t.sql);
    return { query: t, builtQuery: s };
  }
  toSQL() {
    return this._toSQL().builtQuery;
  }
  /** @internal */
  executeRaw() {
    return this.mode === "first" ? this._prepare(!1).get() : this._prepare(!1).all();
  }
  async execute() {
    return this.executeRaw();
  }
}
h(hn, Zo, "SQLiteAsyncRelationalQuery");
var ed, td;
class fr extends (td = hn, ed = v, td) {
  sync() {
    return this.executeRaw();
  }
}
h(fr, ed, "SQLiteSyncRelationalQuery");
var sd, nd;
class xs extends (nd = os, sd = v, nd) {
  constructor(t, s, n, i, a) {
    super();
    /** @internal */
    h(this, "config");
    this.execute = t, this.getSQL = s, this.dialect = i, this.mapBatchResult = a, this.config = { action: n };
  }
  getQuery() {
    return { ...this.dialect.sqlToQuery(this.getSQL()), method: this.config.action };
  }
  mapResult(t, s) {
    return s ? this.mapBatchResult(t) : t;
  }
  _prepare() {
    return this;
  }
  /** @internal */
  isResponseInArrayMode() {
    return !1;
  }
}
h(xs, sd, "SQLiteRaw");
var rd;
rd = v;
class zr {
  constructor(e, t, s, n) {
    h(this, "query");
    /**
     * Creates a subquery that defines a temporary named result set as a CTE.
     *
     * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
     *
     * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
     *
     * @param alias The alias for the subquery.
     *
     * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
     *
     * @example
     *
     * ```ts
     * // Create a subquery with alias 'sq' and use it in the select query
     * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
     *
     * const result = await db.with(sq).select().from(sq);
     * ```
     *
     * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
     *
     * ```ts
     * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
     * const sq = db.$with('sq').as(db.select({
     *   name: sql<string>`upper(${users.name})`.as('name'),
     * })
     * .from(users));
     *
     * const result = await db.with(sq).select({ name: sq.name }).from(sq);
     * ```
     */
    h(this, "$with", (e, t) => {
      const s = this;
      return { as: (i) => (typeof i == "function" && (i = i(new kr(s.dialect))), new Proxy(
        new Cr(
          i.getSQL(),
          t ?? ("getSelectedFields" in i ? i.getSelectedFields() ?? {} : {}),
          e,
          !0
        ),
        new Ze({ alias: e, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      )) };
    });
    this.resultKind = e, this.dialect = t, this.session = s, this._ = n ? {
      schema: n.schema,
      fullSchema: n.fullSchema,
      tableNamesMap: n.tableNamesMap
    } : {
      schema: void 0,
      fullSchema: {},
      tableNamesMap: {}
    }, this.query = {};
    const i = this.query;
    if (this._.schema)
      for (const [a, o] of Object.entries(this._.schema))
        i[a] = new Ec(
          e,
          n.fullSchema,
          this._.schema,
          this._.tableNamesMap,
          n.fullSchema[a],
          o,
          t,
          s
        );
  }
  $count(e, t) {
    return new pr({ source: e, filters: t, session: this.session });
  }
  /**
   * Incorporates a previously defined CTE (using `$with`) into the main query.
   *
   * This method allows the main query to reference a temporary named result set.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
   *
   * @param queries The CTEs to incorporate into the main query.
   *
   * @example
   *
   * ```ts
   * // Define a subquery 'sq' as a CTE using $with
   * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
   *
   * // Incorporate the CTE 'sq' into the main query and select from it
   * const result = await db.with(sq).select().from(sq);
   * ```
   */
  with(...e) {
    const t = this;
    function s(d) {
      return new $t({
        fields: d ?? void 0,
        session: t.session,
        dialect: t.dialect,
        withList: e
      });
    }
    function n(d) {
      return new $t({
        fields: d ?? void 0,
        session: t.session,
        dialect: t.dialect,
        withList: e,
        distinct: !0
      });
    }
    function i(d) {
      return new mr(d, t.session, t.dialect, e);
    }
    function a(d) {
      return new lr(d, t.session, t.dialect, e);
    }
    function o(d) {
      return new ar(d, t.session, t.dialect, e);
    }
    return { select: s, selectDistinct: n, update: i, insert: a, delete: o };
  }
  select(e) {
    return new $t({ fields: e ?? void 0, session: this.session, dialect: this.dialect });
  }
  selectDistinct(e) {
    return new $t({
      fields: e ?? void 0,
      session: this.session,
      dialect: this.dialect,
      distinct: !0
    });
  }
  /**
   * Creates an update query.
   *
   * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
   *
   * Use `.set()` method to specify which values to update.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param table The table to update.
   *
   * @example
   *
   * ```ts
   * // Update all rows in the 'cars' table
   * await db.update(cars).set({ color: 'red' });
   *
   * // Update rows with filters and conditions
   * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
   *
   * // Update with returning clause
   * const updatedCar: Car[] = await db.update(cars)
   *   .set({ color: 'red' })
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  update(e) {
    return new mr(e, this.session, this.dialect);
  }
  /**
   * Creates an insert query.
   *
   * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert}
   *
   * @param table The table to insert into.
   *
   * @example
   *
   * ```ts
   * // Insert one row
   * await db.insert(cars).values({ brand: 'BMW' });
   *
   * // Insert multiple rows
   * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
   *
   * // Insert with returning clause
   * const insertedCar: Car[] = await db.insert(cars)
   *   .values({ brand: 'BMW' })
   *   .returning();
   * ```
   */
  insert(e) {
    return new lr(e, this.session, this.dialect);
  }
  /**
   * Creates a delete query.
   *
   * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param table The table to delete from.
   *
   * @example
   *
   * ```ts
   * // Delete all rows in the 'cars' table
   * await db.delete(cars);
   *
   * // Delete rows with filters and conditions
   * await db.delete(cars).where(eq(cars.color, 'green'));
   *
   * // Delete with returning clause
   * const deletedCar: Car[] = await db.delete(cars)
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  delete(e) {
    return new ar(e, this.session, this.dialect);
  }
  run(e) {
    const t = typeof e == "string" ? _.raw(e) : e.getSQL();
    return this.resultKind === "async" ? new xs(
      async () => this.session.run(t),
      () => t,
      "run",
      this.dialect,
      this.session.extractRawRunValueFromBatchResult.bind(this.session)
    ) : this.session.run(t);
  }
  all(e) {
    const t = typeof e == "string" ? _.raw(e) : e.getSQL();
    return this.resultKind === "async" ? new xs(
      async () => this.session.all(t),
      () => t,
      "all",
      this.dialect,
      this.session.extractRawAllValueFromBatchResult.bind(this.session)
    ) : this.session.all(t);
  }
  get(e) {
    const t = typeof e == "string" ? _.raw(e) : e.getSQL();
    return this.resultKind === "async" ? new xs(
      async () => this.session.get(t),
      () => t,
      "get",
      this.dialect,
      this.session.extractRawGetValueFromBatchResult.bind(this.session)
    ) : this.session.get(t);
  }
  values(e) {
    const t = typeof e == "string" ? _.raw(e) : e.getSQL();
    return this.resultKind === "async" ? new xs(
      async () => this.session.values(t),
      () => t,
      "values",
      this.dialect,
      this.session.extractRawValuesValueFromBatchResult.bind(this.session)
    ) : this.session.values(t);
  }
  transaction(e, t) {
    return this.session.transaction(e, t);
  }
}
h(zr, rd, "BaseSQLiteDatabase");
var id;
id = v;
class Br {
  constructor(e, t) {
    this.name = e, this.unique = t;
  }
  on(...e) {
    return new Sc(this.name, e, this.unique);
  }
}
h(Br, id, "SQLiteIndexBuilderOn");
var ad;
ad = v;
class Sc {
  constructor(e, t, s) {
    /** @internal */
    h(this, "config");
    this.config = {
      name: e,
      columns: t,
      unique: s,
      where: void 0
    };
  }
  /**
   * Condition for partial index.
   */
  where(e) {
    return this.config.where = e, this;
  }
  /** @internal */
  build(e) {
    return new gc(this.config, e);
  }
}
h(Sc, ad, "SQLiteIndexBuilder");
var od;
od = v;
class gc {
  constructor(e, t) {
    h(this, "config");
    this.config = { ...e, table: t };
  }
}
h(gc, od, "SQLiteIndex");
function W(r) {
  return new Br(r, !1);
}
function De(r) {
  return new Br(r, !0);
}
function jl(...r) {
  return r[0].columns ? new Er(r[0].columns, r[0].name) : new Er(r);
}
var dd;
dd = v;
class Er {
  constructor(e, t) {
    /** @internal */
    h(this, "columns");
    /** @internal */
    h(this, "name");
    this.columns = e, this.name = t;
  }
  /** @internal */
  build(e) {
    return new _c(e, this.columns, this.name);
  }
}
h(Er, dd, "SQLitePrimaryKeyBuilder");
var cd;
cd = v;
class _c {
  constructor(e, t, s) {
    h(this, "columns");
    h(this, "name");
    this.table = e, this.columns = t, this.name = s;
  }
  getName() {
    return this.name ?? `${this.table[nt.Symbol.Name]}_${this.columns.map((e) => e.name).join("_")}_pk`;
  }
}
h(_c, cd, "SQLitePrimaryKey");
var ud, ld;
class Nc extends (ld = os, ud = v, ld) {
  constructor(e) {
    super(), this.resultCb = e;
  }
  async execute() {
    return this.resultCb();
  }
  sync() {
    return this.resultCb();
  }
}
h(Nc, ud, "ExecuteResultSync");
var hd;
hd = v;
class Ic {
  constructor(e, t, s) {
    /** @internal */
    h(this, "joinsNotNullableMap");
    this.mode = e, this.executeMethod = t, this.query = s;
  }
  getQuery() {
    return this.query;
  }
  mapRunResult(e, t) {
    return e;
  }
  mapAllResult(e, t) {
    throw new Error("Not implemented");
  }
  mapGetResult(e, t) {
    throw new Error("Not implemented");
  }
  execute(e) {
    return this.mode === "async" ? this[this.executeMethod](e) : new Nc(() => this[this.executeMethod](e));
  }
  mapResult(e, t) {
    switch (this.executeMethod) {
      case "run":
        return this.mapRunResult(e, t);
      case "all":
        return this.mapAllResult(e, t);
      case "get":
        return this.mapGetResult(e, t);
    }
  }
}
h(Ic, hd, "PreparedQuery");
var md;
md = v;
class yc {
  constructor(e) {
    this.dialect = e;
  }
  prepareOneTimeQuery(e, t, s, n) {
    return this.prepareQuery(e, t, s, n);
  }
  run(e) {
    const t = this.dialect.sqlToQuery(e);
    try {
      return this.prepareOneTimeQuery(t, void 0, "run", !1).run();
    } catch (s) {
      throw new Pn({ cause: s, message: `Failed to run the query '${t.sql}'` });
    }
  }
  /** @internal */
  extractRawRunValueFromBatchResult(e) {
    return e;
  }
  all(e) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(e), void 0, "run", !1).all();
  }
  /** @internal */
  extractRawAllValueFromBatchResult(e) {
    throw new Error("Not implemented");
  }
  get(e) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(e), void 0, "run", !1).get();
  }
  /** @internal */
  extractRawGetValueFromBatchResult(e) {
    throw new Error("Not implemented");
  }
  values(e) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(e), void 0, "run", !1).values();
  }
  async count(e) {
    return (await this.values(e))[0][0];
  }
  /** @internal */
  extractRawValuesValueFromBatchResult(e) {
    throw new Error("Not implemented");
  }
}
h(yc, md, "SQLiteSession");
var pd, fd;
class Tc extends (fd = zr, pd = v, fd) {
  constructor(e, t, s, n, i = 0) {
    super(e, t, s, n), this.schema = n, this.nestedIndex = i;
  }
  rollback() {
    throw new uc();
  }
}
h(Tc, pd, "SQLiteTransaction");
var Ed;
Ed = v;
class Ac {
  write(e) {
    console.log(e);
  }
}
h(Ac, Ed, "ConsoleLogWriter");
var Sd;
Sd = v;
class Rc {
  constructor(e) {
    h(this, "writer");
    this.writer = (e == null ? void 0 : e.writer) ?? new Ac();
  }
  logQuery(e, t) {
    const s = t.map((i) => {
      try {
        return JSON.stringify(i);
      } catch {
        return String(i);
      }
    }), n = s.length ? ` -- params: [${s.join(", ")}]` : "";
    this.writer.write(`Query: ${e}${n}`);
  }
}
h(Rc, Sd, "DefaultLogger");
var gd;
gd = v;
class Dc {
  logQuery() {
  }
}
h(Dc, gd, "NoopLogger");
const vt = ie("users", {
  id: m("id").primaryKey(),
  fullName: m("full_name").notNull(),
  username: m("username").notNull().unique(),
  pinHash: m("pin_hash").notNull(),
  salt: m("salt").notNull(),
  role: m("role").$type().notNull(),
  status: m("status", { enum: ["ACTIVE", "INACTIVE"] }).notNull().default("ACTIVE"),
  failedAttempts: he("failed_attempts").notNull().default(0),
  lockedUntil: m("locked_until"),
  createdAt: m("created_at").notNull(),
  updatedAt: m("updated_at").notNull()
}), Mr = ie("permissions", {
  code: m("code").$type().primaryKey(),
  nameAr: m("name_ar").notNull(),
  descriptionAr: m("description_ar").notNull(),
  category: m("category").notNull()
}), Xt = ie("user_permissions", {
  userId: m("user_id").notNull().references(() => vt.id, { onDelete: "cascade" }),
  permissionCode: m("permission_code").notNull().references(() => Mr.code, { onDelete: "cascade" }),
  grantedAt: m("granted_at").notNull()
}, (r) => ({
  pk: jl({ columns: [r.userId, r.permissionCode] })
})), je = ie("academic_years", {
  id: m("id").primaryKey(),
  name: m("name").notNull().unique(),
  // e.g. "2026-2027"
  dbFilename: m("db_filename").notNull().unique(),
  // e.g. "tibyan-2026-2027.sqlite"
  isActive: he("is_active", { mode: "boolean" }).notNull().default(!1),
  isArchived: he("is_archived", { mode: "boolean" }).notNull().default(!1),
  createdAt: m("created_at").notNull(),
  updatedAt: m("updated_at").notNull()
}, (r) => ({
  // Database-level enforcement that only one academic year can be active at a time
  singleActiveYearIdx: De("idx_academic_years_single_active").on(r.isActive).where(_`is_active = 1`)
})), ds = ie("global_settings", {
  key: m("key").primaryKey(),
  valueJson: m("value_json").notNull(),
  updatedAt: m("updated_at").notNull()
}), Rt = ie("system_audit_log", {
  id: m("id").primaryKey(),
  actorType: m("actor_type").$type().notNull().default("USER"),
  actorUserId: m("actor_user_id"),
  actorNameSnapshot: m("actor_name_snapshot").notNull(),
  action: m("action").notNull(),
  entityType: m("entity_type").notNull(),
  entityId: m("entity_id").notNull(),
  beforeJson: m("before_json"),
  afterJson: m("after_json"),
  metadataJson: m("metadata_json"),
  createdAt: m("created_at").notNull()
}, (r) => ({
  actorInvariantCheck: Re(
    "chk_system_audit_actor_invariant",
    _`("actor_type" = 'USER' AND "actor_user_id" IS NOT NULL) OR ("actor_type" = 'SYSTEM' AND "actor_user_id" IS NULL)`
  ),
  idxSystemAuditCreated: De("idx_system_audit_created").on(r.createdAt, r.id)
})), Zt = ie("backup_records", {
  id: m("id").primaryKey(),
  backupPath: m("backup_path").notNull(),
  backupDate: m("backup_date").notNull(),
  status: m("status", { enum: ["SUCCESS", "FAILED"] }).notNull(),
  sizeBytes: he("size_bytes").notNull(),
  academicYearsIncludedJson: m("academic_years_included_json").notNull(),
  createdAt: m("created_at").notNull()
}), re = ie(
  "curriculum_catalogs",
  {
    id: m("id").primaryKey(),
    code: m("code").notNull(),
    title: m("title").notNull(),
    educationSystem: m("education_system").$type().notNull(),
    gradeLevel: m("grade_level").$type().notNull(),
    languageTrack: m("language_track").$type().notNull(),
    mathBranch: m("math_branch").$type(),
    version: he("version").notNull().default(1),
    status: m("status", { enum: ["DRAFT", "PUBLISHED", "ARCHIVED"] }).$type().notNull().default("DRAFT"),
    publishedAt: m("published_at"),
    description: m("description"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxCatalogScopeVersionBranch: De("idx_curriculum_catalog_scope_version_branch").on(r.educationSystem, r.gradeLevel, r.languageTrack, r.mathBranch, r.version).where(_`math_branch IS NOT NULL`),
    idxCatalogScopeVersionNoBranch: De("idx_curriculum_catalog_scope_version_nobranch").on(r.educationSystem, r.gradeLevel, r.languageTrack, r.version).where(_`math_branch IS NULL`),
    idxCatalogCodeVersion: De("idx_curriculum_catalog_code_version").on(r.code, r.version),
    idxCatalogStatus: W("idx_curriculum_catalog_status").on(r.status)
  })
), le = ie(
  "curriculum_nodes",
  {
    id: m("id").primaryKey(),
    catalogId: m("catalog_id").notNull().references(() => re.id, { onDelete: "cascade" }),
    parentId: m("parent_id"),
    tier: m("tier", { enum: ["UNIT", "LESSON", "CONCEPT", "SKILL"] }).$type().notNull(),
    titleAr: m("title_ar").notNull(),
    titleEn: m("title_en"),
    code: m("code").notNull(),
    orderIndex: he("order_index").notNull().default(0),
    description: m("description"),
    metadataJson: m("metadata_json"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxNodeCatalogParent: W("idx_curriculum_node_catalog_parent").on(r.catalogId, r.parentId),
    idxNodeCatalogOrder: W("idx_curriculum_node_catalog_order").on(r.catalogId, r.orderIndex),
    idxNodeCatalogTier: W("idx_curriculum_node_catalog_tier").on(r.catalogId, r.tier)
  })
), Ce = ie(
  "source_documents",
  {
    id: m("id").primaryKey(),
    title: m("title").notNull(),
    author: m("author"),
    publisher: m("publisher"),
    editionYear: m("edition_year"),
    curriculumCatalogId: m("curriculum_catalog_id").references(() => re.id, {
      onDelete: "set null"
    }),
    filePath: m("file_path").notNull(),
    fileName: m("file_name").notNull(),
    fileSizeBytes: he("file_size_bytes").notNull(),
    sha256Hash: m("sha256_hash").notNull(),
    pageCount: he("page_count").notNull(),
    status: m("status", { enum: ["INDEXED", "PROCESSING", "ERROR"] }).$type().notNull().default("INDEXED"),
    metadataJson: m("metadata_json"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxSourceDocumentHash: De("idx_source_document_hash").on(r.sha256Hash),
    idxSourceDocumentCatalog: W("idx_source_document_catalog").on(r.curriculumCatalogId)
  })
), ye = ie(
  "source_references",
  {
    id: m("id").primaryKey(),
    sourceDocumentId: m("source_document_id").notNull().references(() => Ce.id, { onDelete: "cascade" }),
    startPage: he("start_page").notNull(),
    endPage: he("end_page").notNull(),
    referenceLabel: m("reference_label").notNull(),
    notes: m("notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxSourceRefDocument: W("idx_source_ref_document").on(r.sourceDocumentId),
    idxSourceRefPages: W("idx_source_ref_pages").on(r.sourceDocumentId, r.startPage, r.endPage)
  })
), Ee = ie(
  "questions",
  {
    id: m("id").primaryKey(),
    code: m("code").notNull(),
    bodyJson: m("body_json").notNull(),
    modelAnswerJson: m("model_answer_json"),
    questionType: m("question_type", {
      enum: ["MULTIPLE_CHOICE", "ESSAY", "SHORT_ANSWER", "TRUE_FALSE"]
    }).$type().notNull().default("MULTIPLE_CHOICE"),
    difficulty: m("difficulty", {
      enum: ["EASY", "MEDIUM", "HARD", "ADVANCED"]
    }).$type().notNull().default("MEDIUM"),
    defaultMarks: he("default_marks").notNull().default(1),
    languageTrack: m("language_track").$type().notNull().default("ARABIC"),
    status: m("status", { enum: ["DRAFT", "ACTIVE", "ARCHIVED"] }).$type().notNull().default("ACTIVE"),
    contentFingerprint: m("content_fingerprint").notNull(),
    metadataJson: m("metadata_json"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxQuestionCode: De("idx_question_code").on(r.code),
    idxQuestionFingerprint: W("idx_question_fingerprint").on(r.contentFingerprint),
    idxQuestionTypeDiff: W("idx_question_type_diff").on(r.questionType, r.difficulty),
    idxQuestionStatus: W("idx_question_status").on(r.status)
  })
), it = ie(
  "question_curriculum_tags",
  {
    id: m("id").primaryKey(),
    questionId: m("question_id").notNull().references(() => Ee.id, { onDelete: "cascade" }),
    curriculumNodeId: m("curriculum_node_id").notNull().references(() => le.id, { onDelete: "cascade" }),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    idxQuestionNodeUnique: De("idx_question_node_unique").on(r.questionId, r.curriculumNodeId),
    idxQuestionTagNode: W("idx_question_tag_node").on(r.curriculumNodeId)
  })
), ve = ie(
  "question_source_references",
  {
    id: m("id").primaryKey(),
    questionId: m("question_id").notNull().references(() => Ee.id, { onDelete: "cascade" }),
    sourceReferenceId: m("source_reference_id").notNull().references(() => ye.id, { onDelete: "cascade" }),
    notes: m("notes"),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    idxQuestionSourceUnique: De("idx_question_source_unique").on(r.questionId, r.sourceReferenceId),
    idxQuestionSourceRef: W("idx_question_source_ref").on(r.sourceReferenceId)
  })
), Xl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  academicYears: je,
  backupRecords: Zt,
  curriculumCatalogs: re,
  curriculumNodes: le,
  globalSettings: ds,
  permissions: Mr,
  questionCurriculumTags: it,
  questionSourceReferences: ve,
  questions: Ee,
  sourceDocuments: Ce,
  sourceReferences: ye,
  systemAuditLog: Rt,
  userPermissions: Xt,
  users: vt
}, Symbol.toStringTag, { value: "Module" })), ee = ie(
  "students",
  {
    id: m("id").primaryKey(),
    studentCode: m("student_code").notNull().unique(),
    fullName: m("full_name").notNull(),
    photoPath: m("photo_path"),
    educationSystem: m("education_system").$type().notNull(),
    gradeLevel: m("grade_level").$type().notNull(),
    languageTrack: m("language_track").$type().notNull(),
    guardianPhone: m("guardian_phone").notNull(),
    status: m("status", { enum: ["ACTIVE", "INACTIVE"] }).$type().notNull().default("ACTIVE"),
    qrToken: m("qr_token").notNull().unique(),
    barcodeValue: m("barcode_value").notNull().unique(),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkStudentStatus: Re("chk_students_status", _`"status" IN ('ACTIVE', 'INACTIVE')`),
    idxStudentsStatus: W("idx_students_status").on(r.status),
    idxStudentsGrade: W("idx_students_grade").on(r.gradeLevel, r.educationSystem),
    idxStudentsTrack: W("idx_students_track").on(r.languageTrack)
  })
), ct = ie(
  "student_notes",
  {
    id: m("id").primaryKey(),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    authorUserId: m("author_user_id"),
    // Deliberately decoupled from system DB: NO FK
    authorNameSnapshot: m("author_name_snapshot").notNull(),
    noteText: m("note_text").notNull(),
    tag: m("tag").$type().notNull().default("GENERAL"),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    idxNotesStudent: W("idx_notes_student").on(r.studentId)
  })
), oe = ie(
  "groups",
  {
    id: m("id").primaryKey(),
    name: m("name").notNull(),
    educationSystem: m("education_system").$type().notNull(),
    gradeLevel: m("grade_level").$type().notNull(),
    languageTrack: m("language_track").$type().notNull(),
    focusMathBranch: m("focus_math_branch").$type(),
    defaultPaymentType: m("default_payment_type").$type().notNull(),
    defaultPaymentAmount: xr("default_payment_amount").notNull(),
    status: m("status", { enum: ["ACTIVE", "ARCHIVED"] }).notNull().default("ACTIVE"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkDefaultPaymentAmount: Re(
      "chk_groups_default_payment_amount",
      _`"default_payment_amount" >= 0`
    ),
    idxGroupsStatus: W("idx_groups_status").on(r.status),
    idxGroupsGrade: W("idx_groups_grade").on(r.gradeLevel, r.educationSystem)
  })
), se = ie(
  "group_enrollments",
  {
    id: m("id").primaryKey(),
    groupId: m("group_id").notNull().references(() => oe.id, { onDelete: "restrict" }),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    enrolledAt: m("enrolled_at").notNull(),
    leftAt: m("left_at"),
    status: m("status", { enum: ["ACTIVE", "ENDED"] }).notNull().default("ACTIVE"),
    paymentTypeOverride: m("payment_type_override").$type(),
    paymentAmountOverride: xr("payment_amount_override"),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    chkPaymentAmountOverride: Re(
      "chk_enrollment_payment_amount_override",
      _`"payment_amount_override" IS NULL OR "payment_amount_override" >= 0`
    ),
    // Partial unique index allows student departure and subsequent re-enrollment,
    // but prevents multiple simultaneous ACTIVE enrollments for the same student and group.
    idxGroupEnrollmentsActive: De("idx_group_enrollments_active").on(r.groupId, r.studentId).where(_`"status" = 'ACTIVE'`),
    idxEnrollmentsStudent: W("idx_enrollments_student").on(r.studentId),
    idxEnrollmentsGroup: W("idx_enrollments_group").on(r.groupId)
  })
), gt = ie(
  "group_schedules",
  {
    id: m("id").primaryKey(),
    groupId: m("group_id").notNull().references(() => oe.id, { onDelete: "restrict" }),
    weekday: he("weekday").$type().notNull(),
    startTime: m("start_time").notNull(),
    // 'HH:mm'
    durationMinutes: he("duration_minutes").notNull().default(120),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkWeekdayRange: Re("chk_schedule_weekday", _`"weekday" BETWEEN 0 AND 6`),
    chkDurationMinutes: Re("chk_schedule_duration", _`"duration_minutes" > 0`),
    idxSchedulesGroup: W("idx_schedules_group").on(r.groupId)
  })
), X = ie(
  "sessions",
  {
    id: m("id").primaryKey(),
    groupId: m("group_id").notNull().references(() => oe.id, { onDelete: "restrict" }),
    scheduleId: m("schedule_id").references(() => gt.id, { onDelete: "set null" }),
    // Immutable occurrence identity
    occurrenceKey: m("occurrence_key").notNull(),
    scheduledDate: m("scheduled_date").notNull(),
    // YYYY-MM-DD
    scheduledStartTime: m("scheduled_start_time").notNull(),
    // HH:mm
    // Mutable effective execution slot
    effectiveDate: m("effective_date").notNull(),
    // YYYY-MM-DD
    effectiveStartTime: m("effective_start_time").notNull(),
    // HH:mm
    durationMinutes: he("duration_minutes").notNull(),
    status: m("status").$type().notNull().default("SCHEDULED"),
    rescheduleReason: m("reschedule_reason"),
    rescheduledAt: m("rescheduled_at"),
    cancellationReason: m("cancellation_reason"),
    notes: m("notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkSessionDuration: Re("chk_session_duration", _`"duration_minutes" > 0`),
    idxSessionsOccurrence: De("idx_sessions_occurrence").on(r.occurrenceKey),
    idxSessionsEffectiveSlot: W("idx_sessions_effective_slot").on(
      r.groupId,
      r.effectiveDate,
      r.effectiveStartTime
    ),
    idxSessionsEffectiveDate: W("idx_sessions_effective_date").on(r.effectiveDate)
  })
), pe = ie(
  "attendance_records",
  {
    id: m("id").primaryKey(),
    sessionId: m("session_id").notNull().references(() => X.id, { onDelete: "restrict" }),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    status: m("status").$type().notNull(),
    arrivalTime: m("arrival_time"),
    // 'HH:mm'
    notes: m("notes"),
    recordedByUserId: m("recorded_by_user_id"),
    // Deliberately decoupled from system DB: NO FK
    recordedAt: m("recorded_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkAttendanceStatus: Re(
      "chk_attendance_status",
      _`"status" IN ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED')`
    ),
    chkAttendanceArrivalTime: Re(
      "chk_attendance_arrival_time",
      _`("status" = 'LATE' AND "arrival_time" IS NOT NULL AND ("arrival_time" GLOB '[0-1][0-9]:[0-5][0-9]' OR "arrival_time" GLOB '2[0-3]:[0-5][0-9]'))
        OR ("status" = 'PRESENT' AND ("arrival_time" IS NULL OR "arrival_time" GLOB '[0-1][0-9]:[0-5][0-9]' OR "arrival_time" GLOB '2[0-3]:[0-5][0-9]'))
        OR ("status" IN ('ABSENT', 'EXCUSED') AND "arrival_time" IS NULL)`
    ),
    idxAttendanceSessionStudent: De("idx_attendance_session_student").on(
      r.sessionId,
      r.studentId
    ),
    idxAttendanceSession: W("idx_attendance_session").on(r.sessionId),
    idxAttendanceStudent: W("idx_attendance_student").on(r.studentId)
  })
), Be = ie(
  "attendance_follow_ups",
  {
    id: m("id").primaryKey(),
    attendanceRecordId: m("attendance_record_id").notNull().references(() => pe.id, { onDelete: "restrict" }),
    contactStatus: m("contact_status").$type().notNull().default("UNCONTACTED"),
    note: m("note"),
    contactedAt: m("contacted_at"),
    // ISO datetime
    contactedByUserId: m("contacted_by_user_id"),
    // Deliberately decoupled from system DB: NO FK
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkContactStatus: Re(
      "chk_contact_status",
      _`"contact_status" IN ('UNCONTACTED', 'CONTACTED', 'UNREACHABLE')`
    ),
    idxAttendanceFollowUpRecord: De("idx_attendance_follow_up_record").on(r.attendanceRecordId),
    idxAttendanceFollowUpStatus: W("idx_attendance_follow_up_status").on(r.contactStatus)
  })
), Dt = ie(
  "academic_audit_log",
  {
    id: m("id").primaryKey(),
    actorType: m("actor_type").$type().notNull().default("USER"),
    actorUserId: m("actor_user_id"),
    // Deliberately decoupled from system DB: NO FK
    actorNameSnapshot: m("actor_name_snapshot").notNull(),
    action: m("action").notNull(),
    entityType: m("entity_type").notNull(),
    entityId: m("entity_id").notNull(),
    beforeJson: m("before_json"),
    afterJson: m("after_json"),
    metadataJson: m("metadata_json"),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    actorInvariantCheck: Re(
      "chk_academic_audit_actor_invariant",
      _`("actor_type" = 'USER' AND "actor_user_id" IS NOT NULL) OR ("actor_type" = 'SYSTEM' AND "actor_user_id" IS NULL)`
    ),
    idxAcademicAuditCreated: W("idx_academic_audit_created").on(r.createdAt),
    idxAcademicAuditEntity: W("idx_academic_audit_entity").on(r.entityType, r.entityId)
  })
), Xe = ie(
  "student_discounts",
  {
    id: m("id").primaryKey(),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    groupId: m("group_id").references(() => oe.id, { onDelete: "set null" }),
    discountType: m("discount_type").$type().notNull(),
    discountValue: he("discount_value").notNull(),
    reason: m("reason").notNull(),
    status: m("status", { enum: ["ACTIVE", "INACTIVE"] }).notNull().default("ACTIVE"),
    appliedByUserId: m("applied_by_user_id"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkDiscountValue: Re("chk_discounts_value", _`"discount_value" > 0`),
    idxDiscountsStudent: W("idx_discounts_student").on(r.studentId),
    idxDiscountsStatus: W("idx_discounts_status").on(r.status)
  })
), Ie = ie(
  "payments",
  {
    id: m("id").primaryKey(),
    receiptNumber: m("receipt_number").notNull().unique(),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    groupId: m("group_id").references(() => oe.id, { onDelete: "set null" }),
    amountCents: he("amount_cents").notNull(),
    paymentMethod: m("payment_method").$type().notNull().default("CASH"),
    paymentDate: m("payment_date").notNull(),
    // YYYY-MM-DD
    periodMonth: m("period_month"),
    // YYYY-MM
    notes: m("notes"),
    recordedByUserId: m("recorded_by_user_id").notNull(),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkPaymentAmount: Re("chk_payments_amount", _`"amount_cents" > 0`),
    idxPaymentsReceipt: De("idx_payments_receipt").on(r.receiptNumber),
    idxPaymentsStudent: W("idx_payments_student").on(r.studentId),
    idxPaymentsDate: W("idx_payments_date").on(r.paymentDate)
  })
), ze = ie(
  "invoices",
  {
    id: m("id").primaryKey(),
    invoiceNumber: m("invoice_number").notNull().unique(),
    studentId: m("student_id").notNull().references(() => ee.id, { onDelete: "restrict" }),
    groupId: m("group_id").references(() => oe.id, { onDelete: "set null" }),
    issueDate: m("issue_date").notNull(),
    dueDate: m("due_date"),
    periodMonth: m("period_month"),
    subtotalCents: he("subtotal_cents").notNull(),
    discountCents: he("discount_cents").notNull().default(0),
    totalCents: he("total_cents").notNull(),
    paidCents: he("paid_cents").notNull().default(0),
    remainingCents: he("remaining_cents").notNull().default(0),
    status: m("status").$type().notNull().default("UNPAID"),
    notes: m("notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    chkInvoiceSubtotal: Re("chk_invoices_subtotal", _`"subtotal_cents" >= 0`),
    chkInvoiceTotal: Re("chk_invoices_total", _`"total_cents" >= 0`),
    chkInvoicePaid: Re("chk_invoices_paid", _`"paid_cents" >= 0`),
    idxInvoicesNumber: De("idx_invoices_number").on(r.invoiceNumber),
    idxInvoicesStudent: W("idx_invoices_student").on(r.studentId),
    idxInvoicesStatus: W("idx_invoices_status").on(r.status)
  })
), Ot = ie(
  "invoice_items",
  {
    id: m("id").primaryKey(),
    invoiceId: m("invoice_id").notNull().references(() => ze.id, { onDelete: "cascade" }),
    description: m("description").notNull(),
    itemType: m("item_type").$type().notNull().default("CUSTOM"),
    quantity: he("quantity").notNull().default(1),
    unitPriceCents: he("unit_price_cents").notNull(),
    amountCents: he("amount_cents").notNull(),
    sessionId: m("session_id").references(() => X.id, { onDelete: "set null" })
  },
  (r) => ({
    chkItemQuantity: Re("chk_invoice_items_quantity", _`"quantity" > 0`),
    chkItemUnitPrice: Re("chk_invoice_items_unit_price", _`"unit_price_cents" >= 0`),
    chkItemAmount: Re("chk_invoice_items_amount", _`"amount_cents" >= 0`),
    idxInvoiceItemsInvoice: W("idx_invoice_items_invoice").on(r.invoiceId)
  })
), Wt = ie(
  "group_curriculum_assignments",
  {
    id: m("id").primaryKey(),
    groupId: m("group_id").notNull().references(() => oe.id, { onDelete: "cascade" }),
    catalogId: m("catalog_id").notNull(),
    // External ID to system DB
    catalogVersion: he("catalog_version").notNull(),
    assignedAt: m("assigned_at").notNull(),
    assignedByUserId: m("assigned_by_user_id"),
    assignedByNameSnapshot: m("assigned_name_snapshot").notNull(),
    notes: m("notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxGroupCurriculumAssignmentGroup: De("idx_group_curriculum_assignment_group").on(r.groupId),
    idxGroupCurriculumAssignmentCatalog: W("idx_group_curriculum_assignment_catalog").on(r.catalogId)
  })
), St = ie(
  "group_curriculum_progress",
  {
    id: m("id").primaryKey(),
    groupId: m("group_id").notNull().references(() => oe.id, { onDelete: "cascade" }),
    catalogId: m("catalog_id").notNull(),
    // External ID to system DB
    nodeId: m("node_id").notNull(),
    // External ID to system DB
    status: m("status", { enum: ["NOT_STARTED", "IN_PROGRESS", "COMPLETED"] }).$type().notNull().default("NOT_STARTED"),
    completedAt: m("completed_at"),
    updatedByUserId: m("updated_by_user_id"),
    updatedByNameSnapshot: m("updated_name_snapshot").notNull(),
    notes: m("notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxGroupCurriculumProgressGroupNode: De("idx_group_curriculum_progress_group_node").on(
      r.groupId,
      r.nodeId
    ),
    idxGroupCurriculumProgressGroupStatus: W("idx_group_curriculum_progress_group_status").on(
      r.groupId,
      r.status
    )
  })
), Le = ie(
  "lesson_plans",
  {
    id: m("id").primaryKey(),
    curriculumNodeId: m("curriculum_node_id").notNull(),
    title: m("title").notNull(),
    targetDurationMinutes: he("target_duration_minutes").notNull().default(60),
    status: m("status", { enum: ["DRAFT", "READY", "ARCHIVED"] }).$type().notNull().default("DRAFT"),
    version: he("version").notNull().default(1),
    sectionsJson: m("sections_json").notNull(),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxLessonPlansCurriculumNode: W("idx_lesson_plans_curriculum_node").on(r.curriculumNodeId),
    idxLessonPlansStatus: W("idx_lesson_plans_status").on(r.status)
  })
), Pe = ie(
  "session_reflections",
  {
    id: m("id").primaryKey(),
    sessionId: m("session_id").notNull().references(() => X.id, { onDelete: "restrict" }),
    lessonPlanId: m("lesson_plan_id"),
    lessonPlanSnapshotJson: m("lesson_plan_snapshot_json"),
    completionStatus: m("completion_status", {
      enum: ["COMPLETED", "PARTIALLY_COMPLETED", "POSTPONED"]
    }).$type().notNull(),
    uncompletedItems: m("uncompleted_items"),
    topicsNeedingReview: m("topics_needing_review"),
    quickNotes: m("quick_notes"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({
    idxSessionReflectionsSession: De("idx_session_reflections_session").on(r.sessionId),
    idxSessionReflectionsStatus: W("idx_session_reflections_status").on(r.completionStatus)
  })
), lt = ie(
  "exams",
  {
    id: m("id").primaryKey(),
    title: m("title").notNull(),
    blueprintJson: m("blueprint_json").notNull(),
    layoutJson: m("layout_json").notNull(),
    status: m("status", { enum: ["DRAFT", "CONFIRMED", "ARCHIVED"] }).notNull().default("DRAFT"),
    createdAt: m("created_at").notNull(),
    updatedAt: m("updated_at").notNull()
  },
  (r) => ({ idxExamsStatus: W("idx_exams_status").on(r.status) })
), Rs = ie(
  "exam_sections",
  {
    id: m("id").primaryKey(),
    examId: m("exam_id").notNull().references(() => lt.id, { onDelete: "cascade" }),
    title: m("title").notNull(),
    instructionsJson: m("instructions_json").notNull(),
    position: he("position").notNull(),
    createdAt: m("created_at").notNull()
  },
  (r) => ({ idxExamSectionsOrder: De("idx_exam_sections_order").on(r.examId, r.position) })
), sn = ie(
  "exam_questions",
  {
    id: m("id").primaryKey(),
    examSectionId: m("exam_section_id").notNull().references(() => Rs.id, { onDelete: "cascade" }),
    questionIdSnapshot: m("question_id_snapshot"),
    provenance: m("provenance").notNull(),
    contentJson: m("content_json").notNull(),
    answerJson: m("answer_json"),
    curriculumNodeIdsJson: m("curriculum_node_ids_json").notNull(),
    sourceReferenceIdsJson: m("source_reference_ids_json").notNull(),
    marks: he("marks").notNull(),
    answerSpaceLines: he("answer_space_lines").notNull().default(0),
    position: he("position").notNull(),
    createdAt: m("created_at").notNull()
  },
  (r) => ({
    chkExamQuestionMarks: Re("chk_exam_question_marks", _`${r.marks} > 0`),
    chkExamQuestionSpace: Re("chk_exam_question_space", _`${r.answerSpaceLines} >= 0`),
    idxExamQuestionsOrder: De("idx_exam_questions_order").on(r.examSectionId, r.position)
  })
), bs = ie(
  "exam_versions",
  {
    id: m("id").primaryKey(),
    examId: m("exam_id").notNull().references(() => lt.id, { onDelete: "cascade" }),
    label: m("label").notNull(),
    questionOrderJson: m("question_order_json").notNull(),
    answerKeyJson: m("answer_key_json").notNull(),
    createdAt: m("created_at").notNull()
  },
  (r) => ({ idxExamVersionsLabel: De("idx_exam_versions_label").on(r.examId, r.label) })
), Zl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  academicAuditLog: Dt,
  attendanceFollowUps: Be,
  attendanceRecords: pe,
  examQuestions: sn,
  examSections: Rs,
  examVersions: bs,
  exams: lt,
  groupCurriculumAssignments: Wt,
  groupCurriculumProgress: St,
  groupEnrollments: se,
  groupSchedules: gt,
  groups: oe,
  invoiceItems: Ot,
  invoices: ze,
  lessonPlans: Le,
  payments: Ie,
  sessionReflections: Pe,
  sessions: X,
  studentDiscounts: Xe,
  studentNotes: ct,
  students: ee
}, Symbol.toStringTag, { value: "Module" })), Wl = [
  {
    id: "0000_initial_schema",
    sql: '\n      CREATE TABLE IF NOT EXISTS `academic_years` (\n        `id` text PRIMARY KEY NOT NULL,\n        `name` text NOT NULL,\n        `db_filename` text NOT NULL,\n        `is_active` integer DEFAULT false NOT NULL,\n        `is_archived` integer DEFAULT false NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `academic_years_name_unique` ON `academic_years` (`name`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `academic_years_db_filename_unique` ON `academic_years` (`db_filename`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_academic_years_single_active` ON `academic_years` (`is_active`) WHERE is_active = 1;\n\n      CREATE TABLE IF NOT EXISTS `backup_records` (\n        `id` text PRIMARY KEY NOT NULL,\n        `backup_path` text NOT NULL,\n        `backup_date` text NOT NULL,\n        `status` text NOT NULL,\n        `size_bytes` integer NOT NULL,\n        `academic_years_included_json` text NOT NULL,\n        `created_at` text NOT NULL\n      );\n\n      CREATE TABLE IF NOT EXISTS `global_settings` (\n        `key` text PRIMARY KEY NOT NULL,\n        `value_json` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n\n      CREATE TABLE IF NOT EXISTS `permissions` (\n        `code` text PRIMARY KEY NOT NULL,\n        `name_ar` text NOT NULL,\n        `description_ar` text NOT NULL,\n        `category` text NOT NULL\n      );\n\n      CREATE TABLE IF NOT EXISTS `system_audit_log` (\n        `id` text PRIMARY KEY NOT NULL,\n        `actor_type` text DEFAULT \'USER\' NOT NULL,\n        `actor_user_id` text,\n        `actor_name_snapshot` text NOT NULL,\n        `action` text NOT NULL,\n        `entity_type` text NOT NULL,\n        `entity_id` text NOT NULL,\n        `before_json` text,\n        `after_json` text,\n        `metadata_json` text,\n        `created_at` text NOT NULL,\n        CONSTRAINT "chk_system_audit_actor_invariant" CHECK(("actor_type" = \'USER\' AND "actor_user_id" IS NOT NULL) OR ("actor_type" = \'SYSTEM\' AND "actor_user_id" IS NULL))\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_system_audit_created` ON `system_audit_log` (`created_at`,`id`);\n\n      CREATE TABLE IF NOT EXISTS `users` (\n        `id` text PRIMARY KEY NOT NULL,\n        `full_name` text NOT NULL,\n        `username` text NOT NULL,\n        `pin_hash` text NOT NULL,\n        `salt` text NOT NULL,\n        `role` text NOT NULL,\n        `status` text DEFAULT \'ACTIVE\' NOT NULL,\n        `failed_attempts` integer DEFAULT 0 NOT NULL,\n        `locked_until` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `users_username_unique` ON `users` (`username`);\n\n      CREATE TABLE IF NOT EXISTS `user_permissions` (\n        `user_id` text NOT NULL,\n        `permission_code` text NOT NULL,\n        `granted_at` text NOT NULL,\n        PRIMARY KEY(`user_id`, `permission_code`),\n        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,\n        FOREIGN KEY (`permission_code`) REFERENCES `permissions`(`code`) ON UPDATE no action ON DELETE cascade\n      );\n    '
  },
  {
    id: "0001_audit_triggers",
    sql: `
      -- Custom Migration: Immutability triggers for system_audit_log
      CREATE TRIGGER IF NOT EXISTS trg_prevent_system_audit_update
      BEFORE UPDATE ON system_audit_log
      BEGIN
        SELECT RAISE(ABORT, 'system_audit_log entries are immutable and cannot be updated');
      END;

      CREATE TRIGGER IF NOT EXISTS trg_prevent_system_audit_delete
      BEFORE DELETE ON system_audit_log
      BEGIN
        SELECT RAISE(ABORT, 'system_audit_log entries are immutable and cannot be deleted');
      END;
    `
  },
  {
    id: "0002_overrated_naoko",
    sql: "\n      CREATE TABLE IF NOT EXISTS `curriculum_catalogs` (\n        `id` text PRIMARY KEY NOT NULL,\n        `code` text NOT NULL,\n        `title` text NOT NULL,\n        `education_system` text NOT NULL,\n        `grade_level` text NOT NULL,\n        `language_track` text NOT NULL,\n        `math_branch` text,\n        `version` integer DEFAULT 1 NOT NULL,\n        `status` text DEFAULT 'DRAFT' NOT NULL,\n        `published_at` text,\n        `description` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_curriculum_catalog_scope_version` ON `curriculum_catalogs` (`education_system`,`grade_level`,`language_track`,`math_branch`,`version`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_curriculum_catalog_code_version` ON `curriculum_catalogs` (`code`,`version`);\n      CREATE INDEX IF NOT EXISTS `idx_curriculum_catalog_status` ON `curriculum_catalogs` (`status`);\n\n      CREATE TABLE IF NOT EXISTS `curriculum_nodes` (\n        `id` text PRIMARY KEY NOT NULL,\n        `catalog_id` text NOT NULL,\n        `parent_id` text,\n        `tier` text NOT NULL,\n        `title_ar` text NOT NULL,\n        `title_en` text,\n        `code` text NOT NULL,\n        `order_index` integer DEFAULT 0 NOT NULL,\n        `description` text,\n        `metadata_json` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`catalog_id`) REFERENCES `curriculum_catalogs`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE INDEX IF NOT EXISTS `idx_curriculum_node_catalog_parent` ON `curriculum_nodes` (`catalog_id`,`parent_id`);\n      CREATE INDEX IF NOT EXISTS `idx_curriculum_node_catalog_order` ON `curriculum_nodes` (`catalog_id`,`order_index`);\n      CREATE INDEX IF NOT EXISTS `idx_curriculum_node_catalog_tier` ON `curriculum_nodes` (`catalog_id`,`tier`);\n    "
  },
  {
    id: "0003_uneven_vengeance",
    sql: "\n      DROP INDEX IF EXISTS `idx_curriculum_catalog_scope_version`;\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_curriculum_catalog_scope_version_branch` ON `curriculum_catalogs` (`education_system`,`grade_level`,`language_track`,`math_branch`,`version`) WHERE math_branch IS NOT NULL;\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_curriculum_catalog_scope_version_nobranch` ON `curriculum_catalogs` (`education_system`,`grade_level`,`language_track`,`version`) WHERE math_branch IS NULL;\n    "
  },
  {
    id: "0004_certain_stellaris",
    sql: "\n      CREATE TABLE IF NOT EXISTS `source_documents` (\n        `id` text PRIMARY KEY NOT NULL,\n        `title` text NOT NULL,\n        `author` text,\n        `publisher` text,\n        `edition_year` text,\n        `curriculum_catalog_id` text,\n        `file_path` text NOT NULL,\n        `file_name` text NOT NULL,\n        `file_size_bytes` integer NOT NULL,\n        `sha256_hash` text NOT NULL,\n        `page_count` integer NOT NULL,\n        `status` text DEFAULT 'INDEXED' NOT NULL,\n        `metadata_json` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`curriculum_catalog_id`) REFERENCES `curriculum_catalogs`(`id`) ON UPDATE no action ON DELETE set null\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_source_document_hash` ON `source_documents` (`sha256_hash`);\n      CREATE INDEX IF NOT EXISTS `idx_source_document_catalog` ON `source_documents` (`curriculum_catalog_id`);\n\n      CREATE TABLE IF NOT EXISTS `source_references` (\n        `id` text PRIMARY KEY NOT NULL,\n        `source_document_id` text NOT NULL,\n        `start_page` integer NOT NULL,\n        `end_page` integer NOT NULL,\n        `reference_label` text NOT NULL,\n        `notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`source_document_id`) REFERENCES `source_documents`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE INDEX IF NOT EXISTS `idx_source_ref_document` ON `source_references` (`source_document_id`);\n      CREATE INDEX IF NOT EXISTS `idx_source_ref_pages` ON `source_references` (`source_document_id`,`start_page`,`end_page`);\n\n      CREATE TABLE IF NOT EXISTS `questions` (\n        `id` text PRIMARY KEY NOT NULL,\n        `code` text NOT NULL,\n        `body_json` text NOT NULL,\n        `model_answer_json` text,\n        `question_type` text DEFAULT 'MULTIPLE_CHOICE' NOT NULL,\n        `difficulty` text DEFAULT 'MEDIUM' NOT NULL,\n        `default_marks` integer DEFAULT 1 NOT NULL,\n        `language_track` text DEFAULT 'ARABIC' NOT NULL,\n        `status` text DEFAULT 'ACTIVE' NOT NULL,\n        `content_fingerprint` text NOT NULL,\n        `metadata_json` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_question_code` ON `questions` (`code`);\n      CREATE INDEX IF NOT EXISTS `idx_question_fingerprint` ON `questions` (`content_fingerprint`);\n      CREATE INDEX IF NOT EXISTS `idx_question_type_diff` ON `questions` (`question_type`,`difficulty`);\n      CREATE INDEX IF NOT EXISTS `idx_question_status` ON `questions` (`status`);\n\n      CREATE TABLE IF NOT EXISTS `question_curriculum_tags` (\n        `id` text PRIMARY KEY NOT NULL,\n        `question_id` text NOT NULL,\n        `curriculum_node_id` text NOT NULL,\n        `created_at` text NOT NULL,\n        FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON UPDATE no action ON DELETE cascade,\n        FOREIGN KEY (`curriculum_node_id`) REFERENCES `curriculum_nodes`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_question_node_unique` ON `question_curriculum_tags` (`question_id`,`curriculum_node_id`);\n      CREATE INDEX IF NOT EXISTS `idx_question_tag_node` ON `question_curriculum_tags` (`curriculum_node_id`);\n\n      CREATE TABLE IF NOT EXISTS `question_source_references` (\n        `id` text PRIMARY KEY NOT NULL,\n        `question_id` text NOT NULL,\n        `source_reference_id` text NOT NULL,\n        `notes` text,\n        `created_at` text NOT NULL,\n        FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON UPDATE no action ON DELETE cascade,\n        FOREIGN KEY (`source_reference_id`) REFERENCES `source_references`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_question_source_unique` ON `question_source_references` (`question_id`,`source_reference_id`);\n      CREATE INDEX IF NOT EXISTS `idx_question_source_ref` ON `question_source_references` (`source_reference_id`);\n    "
  }
], eh = [
  {
    id: "0000_initial_schema",
    sql: '\n      CREATE TABLE IF NOT EXISTS `students` (\n        `id` text PRIMARY KEY NOT NULL,\n        `student_code` text NOT NULL,\n        `full_name` text NOT NULL,\n        `photo_path` text,\n        `education_system` text NOT NULL,\n        `grade_level` text NOT NULL,\n        `language_track` text NOT NULL,\n        `guardian_phone` text NOT NULL,\n        `status` text DEFAULT \'ACTIVE\' NOT NULL,\n        `qr_token` text NOT NULL,\n        `barcode_value` text NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        CONSTRAINT "chk_students_status" CHECK("status" IN (\'ACTIVE\', \'INACTIVE\'))\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `students_student_code_unique` ON `students` (`student_code`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `students_qr_token_unique` ON `students` (`qr_token`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `students_barcode_value_unique` ON `students` (`barcode_value`);\n      CREATE INDEX IF NOT EXISTS `idx_students_status` ON `students` (`status`);\n      CREATE INDEX IF NOT EXISTS `idx_students_grade` ON `students` (`grade_level`,`education_system`);\n      CREATE INDEX IF NOT EXISTS `idx_students_track` ON `students` (`language_track`);\n\n      CREATE TABLE IF NOT EXISTS `student_notes` (\n        `id` text PRIMARY KEY NOT NULL,\n        `student_id` text NOT NULL,\n        `author_user_id` text,\n        `author_name_snapshot` text NOT NULL,\n        `note_text` text NOT NULL,\n        `tag` text DEFAULT \'GENERAL\' NOT NULL,\n        `created_at` text NOT NULL,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict\n      );\n      CREATE INDEX IF NOT EXISTS `idx_notes_student` ON `student_notes` (`student_id`);\n\n      CREATE TABLE IF NOT EXISTS `groups` (\n        `id` text PRIMARY KEY NOT NULL,\n        `name` text NOT NULL,\n        `education_system` text NOT NULL,\n        `grade_level` text NOT NULL,\n        `language_track` text NOT NULL,\n        `focus_math_branch` text,\n        `default_payment_type` text NOT NULL,\n        `default_payment_amount` real NOT NULL,\n        `status` text DEFAULT \'ACTIVE\' NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        CONSTRAINT "chk_groups_default_payment_amount" CHECK("default_payment_amount" >= 0)\n      );\n      CREATE INDEX IF NOT EXISTS `idx_groups_status` ON `groups` (`status`);\n      CREATE INDEX IF NOT EXISTS `idx_groups_grade` ON `groups` (`grade_level`,`education_system`);\n\n      CREATE TABLE IF NOT EXISTS `group_enrollments` (\n        `id` text PRIMARY KEY NOT NULL,\n        `group_id` text NOT NULL,\n        `student_id` text NOT NULL,\n        `enrolled_at` text NOT NULL,\n        `left_at` text,\n        `status` text DEFAULT \'ACTIVE\' NOT NULL,\n        `payment_type_override` text,\n        `payment_amount_override` real,\n        `created_at` text NOT NULL,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict,\n        CONSTRAINT "chk_enrollment_payment_amount_override" CHECK("payment_amount_override" IS NULL OR "payment_amount_override" >= 0)\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_group_enrollments_active` ON `group_enrollments` (`group_id`,`student_id`) WHERE "status" = \'ACTIVE\';\n      CREATE INDEX IF NOT EXISTS `idx_enrollments_student` ON `group_enrollments` (`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_enrollments_group` ON `group_enrollments` (`group_id`);\n\n      CREATE TABLE IF NOT EXISTS `group_schedules` (\n        `id` text PRIMARY KEY NOT NULL,\n        `group_id` text NOT NULL,\n        `weekday` integer NOT NULL,\n        `start_time` text NOT NULL,\n        `duration_minutes` integer DEFAULT 120 NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE restrict,\n        CONSTRAINT "chk_schedule_weekday" CHECK("weekday" BETWEEN 0 AND 6),\n        CONSTRAINT "chk_schedule_duration" CHECK("duration_minutes" > 0)\n      );\n      CREATE INDEX IF NOT EXISTS `idx_schedules_group` ON `group_schedules` (`group_id`);\n\n      CREATE TABLE IF NOT EXISTS `sessions` (\n        `id` text PRIMARY KEY NOT NULL,\n        `group_id` text NOT NULL,\n        `schedule_id` text,\n        `occurrence_key` text NOT NULL,\n        `scheduled_date` text NOT NULL,\n        `scheduled_start_time` text NOT NULL,\n        `effective_date` text NOT NULL,\n        `effective_start_time` text NOT NULL,\n        `duration_minutes` integer NOT NULL,\n        `status` text DEFAULT \'SCHEDULED\' NOT NULL,\n        `reschedule_reason` text,\n        `rescheduled_at` text,\n        `notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`schedule_id`) REFERENCES `group_schedules`(`id`) ON UPDATE no action ON DELETE set null,\n        CONSTRAINT "chk_session_duration" CHECK("duration_minutes" > 0)\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_sessions_occurrence` ON `sessions` (`occurrence_key`);\n      CREATE INDEX IF NOT EXISTS `idx_sessions_effective_slot` ON `sessions` (`group_id`,`effective_date`,`effective_start_time`);\n      CREATE INDEX IF NOT EXISTS `idx_sessions_effective_date` ON `sessions` (`effective_date`);\n\n      CREATE TABLE IF NOT EXISTS `academic_audit_log` (\n        `id` text PRIMARY KEY NOT NULL,\n        `actor_type` text DEFAULT \'USER\' NOT NULL,\n        `actor_user_id` text,\n        `actor_name_snapshot` text NOT NULL,\n        `action` text NOT NULL,\n        `entity_type` text NOT NULL,\n        `entity_id` text NOT NULL,\n        `before_json` text,\n        `after_json` text,\n        `metadata_json` text,\n        `created_at` text NOT NULL,\n        CONSTRAINT "chk_academic_audit_actor_invariant" CHECK(("actor_type" = \'USER\' AND "actor_user_id" IS NOT NULL) OR ("actor_type" = \'SYSTEM\' AND "actor_user_id" IS NULL))\n      );\n      CREATE INDEX IF NOT EXISTS `idx_academic_audit_created` ON `academic_audit_log` (`created_at`);\n      CREATE INDEX IF NOT EXISTS `idx_academic_audit_entity` ON `academic_audit_log` (`entity_type`,`entity_id`);\n    '
  },
  {
    id: "0001_audit_triggers",
    sql: `
      -- Custom Migration: Immutability triggers for academic_audit_log
      CREATE TRIGGER IF NOT EXISTS trg_prevent_academic_audit_update
      BEFORE UPDATE ON academic_audit_log
      BEGIN
        SELECT RAISE(ABORT, 'academic_audit_log entries are immutable and cannot be updated');
      END;

      CREATE TRIGGER IF NOT EXISTS trg_prevent_academic_audit_delete
      BEFORE DELETE ON academic_audit_log
      BEGIN
        SELECT RAISE(ABORT, 'academic_audit_log entries are immutable and cannot be deleted');
      END;
    `
  },
  {
    id: "0002_glamorous_sunspot",
    sql: "\n      ALTER TABLE `sessions` ADD `cancellation_reason` text;\n    "
  },
  {
    id: "0003_neat_krista_starr",
    sql: "\n      CREATE TABLE IF NOT EXISTS `attendance_records` (\n        `id` text PRIMARY KEY NOT NULL,\n        `session_id` text NOT NULL,\n        `student_id` text NOT NULL,\n        `status` text NOT NULL,\n        `arrival_time` text,\n        `notes` text,\n        `recorded_by_user_id` text,\n        `recorded_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_attendance_session_student` ON `attendance_records` (`session_id`,`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_attendance_session` ON `attendance_records` (`session_id`);\n      CREATE INDEX IF NOT EXISTS `idx_attendance_student` ON `attendance_records` (`student_id`);\n    "
  },
  {
    id: "0004_cold_bullseye",
    sql: '\n      PRAGMA foreign_keys=OFF;\n      CREATE TABLE `__new_attendance_records` (\n        `id` text PRIMARY KEY NOT NULL,\n        `session_id` text NOT NULL,\n        `student_id` text NOT NULL,\n        `status` text NOT NULL,\n        `arrival_time` text,\n        `notes` text,\n        `recorded_by_user_id` text,\n        `recorded_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict,\n        CONSTRAINT "chk_attendance_status" CHECK("status" IN (\'PRESENT\', \'ABSENT\', \'LATE\', \'EXCUSED\')),\n        CONSTRAINT "chk_attendance_arrival_time" CHECK(("status" = \'LATE\' AND "arrival_time" IS NOT NULL AND ("arrival_time" GLOB \'[0-1][0-9]:[0-5][0-9]\' OR "arrival_time" GLOB \'2[0-3]:[0-5][0-9]\'))\n          OR ("status" = \'PRESENT\' AND ("arrival_time" IS NULL OR "arrival_time" GLOB \'[0-1][0-9]:[0-5][0-9]\' OR "arrival_time" GLOB \'2[0-3]:[0-5][0-9]\'))\n          OR ("status" IN (\'ABSENT\', \'EXCUSED\') AND "arrival_time" IS NULL))\n      );\n      INSERT INTO `__new_attendance_records`("id", "session_id", "student_id", "status", "arrival_time", "notes", "recorded_by_user_id", "recorded_at", "updated_at")\n        SELECT "id", "session_id", "student_id", "status", "arrival_time", "notes", "recorded_by_user_id", "recorded_at", "updated_at" FROM `attendance_records`;\n      DROP TABLE `attendance_records`;\n      ALTER TABLE `__new_attendance_records` RENAME TO `attendance_records`;\n      PRAGMA foreign_keys=ON;\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_attendance_session_student` ON `attendance_records` (`session_id`,`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_attendance_session` ON `attendance_records` (`session_id`);\n      CREATE INDEX IF NOT EXISTS `idx_attendance_student` ON `attendance_records` (`student_id`);\n    '
  },
  {
    id: "0005_rainy_silvermane",
    sql: "\n      CREATE TABLE IF NOT EXISTS `attendance_follow_ups` (\n        `id` text PRIMARY KEY NOT NULL,\n        `attendance_record_id` text NOT NULL,\n        `contact_status` text DEFAULT 'UNCONTACTED' NOT NULL,\n        `note` text,\n        `contacted_at` text,\n        `contacted_by_user_id` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`attendance_record_id`) REFERENCES `attendance_records`(`id`) ON UPDATE no action ON DELETE restrict,\n        CONSTRAINT \"chk_contact_status\" CHECK(\"contact_status\" IN ('UNCONTACTED', 'CONTACTED', 'UNREACHABLE'))\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_attendance_follow_up_record` ON `attendance_follow_ups` (`attendance_record_id`);\n      CREATE INDEX IF NOT EXISTS `idx_attendance_follow_up_status` ON `attendance_follow_ups` (`contact_status`);\n    "
  },
  {
    id: "0006_parched_xavin",
    sql: '\n      CREATE TABLE IF NOT EXISTS `student_discounts` (\n        `id` text PRIMARY KEY NOT NULL,\n        `student_id` text NOT NULL,\n        `group_id` text,\n        `discount_type` text NOT NULL,\n        `discount_value` integer NOT NULL,\n        `reason` text NOT NULL,\n        `status` text DEFAULT \'ACTIVE\' NOT NULL,\n        `applied_by_user_id` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE set null,\n        CONSTRAINT "chk_discounts_value" CHECK("discount_value" > 0)\n      );\n      CREATE INDEX IF NOT EXISTS `idx_discounts_student` ON `student_discounts` (`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_discounts_status` ON `student_discounts` (`status`);\n\n      CREATE TABLE IF NOT EXISTS `payments` (\n        `id` text PRIMARY KEY NOT NULL,\n        `receipt_number` text NOT NULL,\n        `student_id` text NOT NULL,\n        `group_id` text,\n        `amount_cents` integer NOT NULL,\n        `payment_method` text DEFAULT \'CASH\' NOT NULL,\n        `payment_date` text NOT NULL,\n        `period_month` text,\n        `notes` text,\n        `recorded_by_user_id` text NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE set null,\n        CONSTRAINT "chk_payments_amount" CHECK("amount_cents" > 0)\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `payments_receipt_number_unique` ON `payments` (`receipt_number`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_payments_receipt` ON `payments` (`receipt_number`);\n      CREATE INDEX IF NOT EXISTS `idx_payments_student` ON `payments` (`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_payments_date` ON `payments` (`payment_date`);\n\n      CREATE TABLE IF NOT EXISTS `invoices` (\n        `id` text PRIMARY KEY NOT NULL,\n        `invoice_number` text NOT NULL,\n        `student_id` text NOT NULL,\n        `group_id` text,\n        `issue_date` text NOT NULL,\n        `due_date` text,\n        `period_month` text,\n        `subtotal_cents` integer NOT NULL,\n        `discount_cents` integer DEFAULT 0 NOT NULL,\n        `total_cents` integer NOT NULL,\n        `paid_cents` integer DEFAULT 0 NOT NULL,\n        `remaining_cents` integer DEFAULT 0 NOT NULL,\n        `status` text DEFAULT \'UNPAID\' NOT NULL,\n        `notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE restrict,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE set null,\n        CONSTRAINT "chk_invoices_subtotal" CHECK("subtotal_cents" >= 0),\n        CONSTRAINT "chk_invoices_total" CHECK("total_cents" >= 0),\n        CONSTRAINT "chk_invoices_paid" CHECK("paid_cents" >= 0)\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `invoices_invoice_number_unique` ON `invoices` (`invoice_number`);\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_invoices_number` ON `invoices` (`invoice_number`);\n      CREATE INDEX IF NOT EXISTS `idx_invoices_student` ON `invoices` (`student_id`);\n      CREATE INDEX IF NOT EXISTS `idx_invoices_status` ON `invoices` (`status`);\n\n      CREATE TABLE IF NOT EXISTS `invoice_items` (\n        `id` text PRIMARY KEY NOT NULL,\n        `invoice_id` text NOT NULL,\n        `description` text NOT NULL,\n        `item_type` text DEFAULT \'CUSTOM\' NOT NULL,\n        `quantity` integer DEFAULT 1 NOT NULL,\n        `unit_price_cents` integer NOT NULL,\n        `amount_cents` integer NOT NULL,\n        `session_id` text,\n        FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON UPDATE no action ON DELETE cascade,\n        FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE set null,\n        CONSTRAINT "chk_invoice_items_quantity" CHECK("quantity" > 0),\n        CONSTRAINT "chk_invoice_items_unit_price" CHECK("unit_price_cents" >= 0),\n        CONSTRAINT "chk_invoice_items_amount" CHECK("amount_cents" >= 0)\n      );\n      CREATE INDEX IF NOT EXISTS `idx_invoice_items_invoice` ON `invoice_items` (`invoice_id`);\n    '
  },
  {
    id: "0007_awesome_sunspot",
    sql: "\n      CREATE TABLE IF NOT EXISTS `group_curriculum_assignments` (\n        `id` text PRIMARY KEY NOT NULL,\n        `group_id` text NOT NULL,\n        `catalog_id` text NOT NULL,\n        `catalog_version` integer NOT NULL,\n        `assigned_at` text NOT NULL,\n        `assigned_by_user_id` text,\n        `assigned_name_snapshot` text NOT NULL,\n        `notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_group_curriculum_assignment_group` ON `group_curriculum_assignments` (`group_id`);\n      CREATE INDEX IF NOT EXISTS `idx_group_curriculum_assignment_catalog` ON `group_curriculum_assignments` (`catalog_id`);\n\n      CREATE TABLE IF NOT EXISTS `group_curriculum_progress` (\n        `id` text PRIMARY KEY NOT NULL,\n        `group_id` text NOT NULL,\n        `catalog_id` text NOT NULL,\n        `node_id` text NOT NULL,\n        `status` text DEFAULT 'NOT_STARTED' NOT NULL,\n        `completed_at` text,\n        `updated_by_user_id` text,\n        `updated_name_snapshot` text NOT NULL,\n        `notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`group_id`) REFERENCES `groups`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_group_curriculum_progress_group_node` ON `group_curriculum_progress` (`group_id`,`node_id`);\n      CREATE INDEX IF NOT EXISTS `idx_group_curriculum_progress_group_status` ON `group_curriculum_progress` (`group_id`,`status`);\n    "
  },
  {
    id: "0008_nifty_magus",
    sql: "\n      CREATE TABLE IF NOT EXISTS `lesson_plans` (\n        `id` text PRIMARY KEY NOT NULL,\n        `curriculum_node_id` text NOT NULL,\n        `title` text NOT NULL,\n        `target_duration_minutes` integer DEFAULT 60 NOT NULL,\n        `status` text DEFAULT 'DRAFT' NOT NULL,\n        `version` integer DEFAULT 1 NOT NULL,\n        `sections_json` text NOT NULL,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL\n      );\n      CREATE INDEX IF NOT EXISTS `idx_lesson_plans_curriculum_node` ON `lesson_plans` (`curriculum_node_id`);\n      CREATE INDEX IF NOT EXISTS `idx_lesson_plans_status` ON `lesson_plans` (`status`);\n\n      CREATE TABLE IF NOT EXISTS `session_reflections` (\n        `id` text PRIMARY KEY NOT NULL,\n        `session_id` text NOT NULL,\n        `lesson_plan_id` text,\n        `lesson_plan_snapshot_json` text,\n        `completion_status` text NOT NULL,\n        `uncompleted_items` text,\n        `topics_needing_review` text,\n        `quick_notes` text,\n        `created_at` text NOT NULL,\n        `updated_at` text NOT NULL,\n        FOREIGN KEY (`session_id`) REFERENCES `sessions`(`id`) ON UPDATE no action ON DELETE restrict\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_session_reflections_session` ON `session_reflections` (`session_id`);\n      CREATE INDEX IF NOT EXISTS `idx_session_reflections_status` ON `session_reflections` (`completion_status`);\n    "
  },
  {
    id: "0009_exotic_carmella_unuscione",
    sql: '\n      CREATE TABLE IF NOT EXISTS `exams` (\n        `id` text PRIMARY KEY NOT NULL, `title` text NOT NULL, `blueprint_json` text NOT NULL,\n        `layout_json` text NOT NULL, `status` text DEFAULT \'DRAFT\' NOT NULL,\n        `created_at` text NOT NULL, `updated_at` text NOT NULL\n      );\n      CREATE INDEX IF NOT EXISTS `idx_exams_status` ON `exams` (`status`);\n      CREATE TABLE IF NOT EXISTS `exam_sections` (\n        `id` text PRIMARY KEY NOT NULL, `exam_id` text NOT NULL, `title` text NOT NULL,\n        `instructions_json` text NOT NULL, `position` integer NOT NULL, `created_at` text NOT NULL,\n        FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_exam_sections_order` ON `exam_sections` (`exam_id`, `position`);\n      CREATE TABLE IF NOT EXISTS `exam_questions` (\n        `id` text PRIMARY KEY NOT NULL, `exam_section_id` text NOT NULL, `question_id_snapshot` text,\n        `provenance` text NOT NULL, `content_json` text NOT NULL, `answer_json` text,\n        `curriculum_node_ids_json` text NOT NULL, `source_reference_ids_json` text NOT NULL,\n        `marks` integer NOT NULL, `answer_space_lines` integer DEFAULT 0 NOT NULL,\n        `position` integer NOT NULL, `created_at` text NOT NULL,\n        FOREIGN KEY (`exam_section_id`) REFERENCES `exam_sections`(`id`) ON UPDATE no action ON DELETE cascade,\n        CONSTRAINT "chk_exam_question_marks" CHECK("marks" > 0),\n        CONSTRAINT "chk_exam_question_space" CHECK("answer_space_lines" >= 0)\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_exam_questions_order` ON `exam_questions` (`exam_section_id`, `position`);\n      CREATE TABLE IF NOT EXISTS `exam_versions` (\n        `id` text PRIMARY KEY NOT NULL, `exam_id` text NOT NULL, `label` text NOT NULL,\n        `question_order_json` text NOT NULL, `answer_key_json` text NOT NULL, `created_at` text NOT NULL,\n        FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON UPDATE no action ON DELETE cascade\n      );\n      CREATE UNIQUE INDEX IF NOT EXISTS `idx_exam_versions_label` ON `exam_versions` (`exam_id`, `label`);\n    '
  }
];
function Oc(r) {
  r.exec(`
    CREATE TABLE IF NOT EXISTS __tibyan_migrations (
      id TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
  `);
}
function th(r) {
  return Oc(r), r.prepare("SELECT id FROM __tibyan_migrations ORDER BY applied_at ASC").all().map((t) => t.id);
}
function wc(r, e) {
  Oc(r);
  const t = new Set(th(r)), s = [];
  for (const n of e)
    t.has(n.id) || (r.transaction(() => {
      r.exec(n.sql), r.prepare("INSERT INTO __tibyan_migrations (id, applied_at) VALUES (?, ?)").run(
        n.id,
        (/* @__PURE__ */ new Date()).toISOString()
      );
    })(), s.push(n.id));
  return s;
}
function sh(r) {
  return wc(r, Wl);
}
function vc(r) {
  return wc(r, eh);
}
var _d, Nd;
class Cc extends (Nd = yc, _d = v, Nd) {
  constructor(t, s, n, i = {}) {
    super(s);
    h(this, "logger");
    this.client = t, this.schema = n, this.logger = i.logger ?? new Dc();
  }
  prepareQuery(t, s, n, i, a) {
    const o = this.client.prepare(t.sql);
    return new Uc(
      o,
      t,
      this.logger,
      s,
      n,
      i,
      a
    );
  }
  transaction(t, s = {}) {
    const n = new Sr("sync", this.dialect, this, this.schema);
    return this.client.transaction(t)[s.behavior ?? "deferred"](n);
  }
}
h(Cc, _d, "BetterSQLiteSession");
var Id, yd;
const Cn = class Cn extends (yd = Tc, Id = v, yd) {
  transaction(e) {
    const t = `sp${this.nestedIndex}`, s = new Cn("sync", this.dialect, this.session, this.schema, this.nestedIndex + 1);
    this.session.run(_.raw(`savepoint ${t}`));
    try {
      const n = e(s);
      return this.session.run(_.raw(`release savepoint ${t}`)), n;
    } catch (n) {
      throw this.session.run(_.raw(`rollback to savepoint ${t}`)), n;
    }
  }
};
h(Cn, Id, "BetterSQLiteTransaction");
let Sr = Cn;
var Td, Ad;
class Uc extends (Ad = Ic, Td = v, Ad) {
  constructor(e, t, s, n, i, a, o) {
    super("sync", i, t), this.stmt = e, this.logger = s, this.fields = n, this._isResponseInArrayMode = a, this.customResultMapper = o;
  }
  run(e) {
    const t = Ks(this.query.params, e ?? {});
    return this.logger.logQuery(this.query.sql, t), this.stmt.run(...t);
  }
  all(e) {
    const { fields: t, joinsNotNullableMap: s, query: n, logger: i, stmt: a, customResultMapper: o } = this;
    if (!t && !o) {
      const u = Ks(n.params, e ?? {});
      return i.logQuery(n.sql, u), a.all(...u);
    }
    const d = this.values(e);
    return o ? o(d) : d.map((u) => ii(t, u, s));
  }
  get(e) {
    const t = Ks(this.query.params, e ?? {});
    this.logger.logQuery(this.query.sql, t);
    const { fields: s, stmt: n, joinsNotNullableMap: i, customResultMapper: a } = this;
    if (!s && !a)
      return n.get(...t);
    const o = n.raw().get(...t);
    if (o)
      return a ? a([o]) : ii(s, o, i);
  }
  values(e) {
    const t = Ks(this.query.params, e ?? {});
    return this.logger.logQuery(this.query.sql, t), this.stmt.raw().all(...t);
  }
  /** @internal */
  isResponseInArrayMode() {
    return this._isResponseInArrayMode;
  }
}
h(Uc, Td, "BetterSQLitePreparedQuery");
var Rd, Dd;
class xc extends (Dd = zr, Rd = v, Dd) {
}
h(xc, Rd, "BetterSQLite3Database");
function Is(r, e = {}) {
  const t = new Lr({ casing: e.casing });
  let s;
  e.logger === !0 ? s = new Rc() : e.logger !== !1 && (s = e.logger);
  let n;
  if (e.schema) {
    const o = Fl(
      e.schema,
      Gl
    );
    n = {
      fullSchema: e.schema,
      schema: o.tables,
      tableNamesMap: o.tableNamesMap
    };
  }
  const i = new Cc(r, t, n, { logger: s }), a = new xc("sync", t, i, n);
  return a.$client = r, a;
}
function mn(...r) {
  if (r[0] === void 0 || typeof r[0] == "string") {
    const e = r[0] === void 0 ? new Us() : new Us(r[0]);
    return Is(e, r[1]);
  }
  if (pl(r[0])) {
    const { connection: e, client: t, ...s } = r[0];
    if (t)
      return Is(t, s);
    if (typeof e == "object") {
      const { source: i, ...a } = e, o = new Us(i, a);
      return Is(o, s);
    }
    const n = new Us(e);
    return Is(n, s);
  }
  return Is(r[0], r[1]);
}
((r) => {
  function e(t) {
    return Is({}, t);
  }
  r.mock = e;
})(mn || (mn = {}));
let We = null, Ve = null;
function nh(r, e = !1) {
  r.pragma("foreign_keys = ON"), r.pragma("busy_timeout = 5000"), e || (r.pragma("journal_mode = WAL"), r.pragma("synchronous = NORMAL"));
}
function Ds(r) {
  const e = r === ":memory:" || r.startsWith("file::memory:"), t = new Us(r);
  return nh(t, e), t;
}
function rh(r = {}) {
  const e = r.filePath ?? ":memory:";
  if (We) {
    if (We.filePath === e && We.raw.open)
      return We;
    Fr();
  }
  const t = Ds(e), s = mn(t, { schema: Xl });
  return r.autoMigrate !== !1 && sh(t), We = {
    raw: t,
    db: s,
    filePath: e
  }, We;
}
function Jt() {
  if (!We || !We.raw.open)
    throw new Error("System database is not open. Call openSystemDatabase first.");
  return We;
}
function Fr() {
  We && (We.raw.open && We.raw.close(), We = null);
}
function di() {
  return We !== null && We.raw.open;
}
function ih(r, e = {}) {
  const t = e.filePath ?? ":memory:";
  if (Ve) {
    if (Ve.academicYearName === r && Ve.filePath === t && Ve.raw.open)
      return Ve;
    $r();
  }
  const s = Ds(t), n = mn(s, { schema: Zl });
  return e.autoMigrate !== !1 && vc(s), Ve = {
    raw: s,
    db: n,
    filePath: t,
    academicYearName: r
  }, Ve;
}
function Fe() {
  if (!Ve || !Ve.raw.open)
    throw new Error("Academic database is not open. Call openAcademicDatabase first.");
  return Ve;
}
function $r() {
  Ve && (Ve.raw.open && Ve.raw.close(), Ve = null);
}
function ah() {
  return Ve !== null && Ve.raw.open;
}
function oh() {
  $r(), Fr();
}
class kt {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Jt().db;
  }
  findById(e) {
    return this.client.select().from(vt).where(g(vt.id, e)).get() ?? null;
  }
  findByUsername(e) {
    return this.client.select().from(vt).where(g(vt.username, e)).get() ?? null;
  }
  create(e) {
    this.client.insert(vt).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create user with id: ${e.id}`);
    return t;
  }
  update(e, t) {
    return this.client.update(vt).set({ ...t, updatedAt: t.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString() }).where(g(vt.id, e)).run(), this.findById(e);
  }
  listAll() {
    return this.client.select().from(vt).all();
  }
  getUserPermissions(e) {
    return this.client.select({ code: Xt.permissionCode }).from(Xt).where(g(Xt.userId, e)).all().map((s) => s.code);
  }
  assignPermissions(e, t) {
    if (t.length === 0) return;
    const s = (/* @__PURE__ */ new Date()).toISOString(), n = t.map((i) => ({
      userId: e,
      permissionCode: i,
      grantedAt: s
    }));
    this.client.insert(Xt).values(n).onConflictDoNothing().run();
  }
  removePermissions(e, t) {
    t.length !== 0 && this.client.delete(Xt).where(
      ae(
        g(Xt.userId, e),
        is(Xt.permissionCode, t)
      )
    ).run();
  }
}
class bc {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Jt().db;
  }
  findById(e) {
    return this.client.select().from(je).where(g(je.id, e)).get() ?? null;
  }
  findByName(e) {
    return this.client.select().from(je).where(g(je.name, e)).get() ?? null;
  }
  findActive() {
    return this.client.select().from(je).where(g(je.isActive, !0)).get() ?? null;
  }
  create(e) {
    this.client.insert(je).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create academic year with id: ${e.id}`);
    return t;
  }
  setActiveYear(e) {
    const t = (/* @__PURE__ */ new Date()).toISOString();
    this.client.transaction((s) => {
      s.update(je).set({ isActive: !1, updatedAt: t }).where(g(je.isActive, !0)).run(), s.update(je).set({ isActive: !0, updatedAt: t }).where(g(je.id, e)).run();
    });
  }
  archiveYear(e) {
    const t = (/* @__PURE__ */ new Date()).toISOString();
    this.client.update(je).set({ isArchived: !0, isActive: !1, updatedAt: t }).where(g(je.id, e)).run();
  }
  listAll() {
    return this.client.select().from(je).all();
  }
}
class Te {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Jt().db;
  }
  insert(e) {
    this.client.insert(Rt).values(e).run();
    const t = this.client.select().from(Rt).where(g(Rt.id, e.id)).get();
    if (!t)
      throw new Error(`Failed to insert system audit entry with id: ${e.id}`);
    return t;
  }
  listRecent(e = 50) {
    return this.client.select().from(Rt).orderBy(de(Rt.createdAt)).limit(e).all();
  }
  findByEntity(e, t) {
    return this.client.select().from(Rt).where(
      ae(
        g(Rt.entityType, e),
        g(Rt.entityId, t)
      )
    ).orderBy(de(Rt.createdAt)).all();
  }
}
class dh {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Jt().db;
  }
  get(e) {
    const t = this.client.select({ valueJson: ds.valueJson }).from(ds).where(g(ds.key, e)).get();
    return t ? t.valueJson : null;
  }
  set(e, t) {
    const s = (/* @__PURE__ */ new Date()).toISOString();
    this.client.insert(ds).values({ key: e, valueJson: t, updatedAt: s }).onConflictDoUpdate({
      target: ds.key,
      set: { valueJson: t, updatedAt: s }
    }).run();
  }
  listAll() {
    return this.client.select().from(ds).all();
  }
}
class gr {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Jt().db;
  }
  create(e) {
    this.client.insert(Zt).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create backup record with id: ${e.id}`);
    return t;
  }
  findById(e) {
    return this.client.select().from(Zt).where(g(Zt.id, e)).get() ?? null;
  }
  findByPath(e) {
    return this.client.select().from(Zt).where(g(Zt.backupPath, e)).get() ?? null;
  }
  listRecent(e = 20) {
    return this.client.select().from(Zt).orderBy(de(Zt.createdAt)).limit(e).all();
  }
}
class ys {
  constructor(e) {
    this.db = e;
  }
  findById(e) {
    return this.db.select().from(re).where(g(re.id, e)).get() ?? null;
  }
  findByCode(e, t) {
    return t !== void 0 ? this.db.select().from(re).where(
      ae(
        g(re.code, e),
        g(re.version, t)
      )
    ).get() ?? null : this.db.select().from(re).where(g(re.code, e)).orderBy(de(re.version)).get() ?? null;
  }
  findByScope(e, t, s, n, i) {
    const a = [
      g(re.educationSystem, e),
      g(re.gradeLevel, t),
      g(re.languageTrack, s)
    ];
    return n != null ? a.push(g(re.mathBranch, n)) : a.push(Ms(re.mathBranch)), i !== void 0 && a.push(g(re.version, i)), this.db.select().from(re).where(ae(...a)).orderBy(de(re.version)).get() ?? null;
  }
  getLatestScopeVersion(e, t, s, n) {
    const i = this.findByScope(e, t, s, n);
    return i ? i.version : 0;
  }
  getNextVersion(e, t, s, n) {
    return this.getLatestScopeVersion(e, t, s, n) + 1;
  }
  list(e) {
    const t = [];
    if (e != null && e.educationSystem && t.push(g(re.educationSystem, e.educationSystem)), e != null && e.gradeLevel && t.push(g(re.gradeLevel, e.gradeLevel)), e != null && e.languageTrack && t.push(g(re.languageTrack, e.languageTrack)), (e == null ? void 0 : e.mathBranch) !== void 0 && (e.mathBranch === null ? t.push(Ms(re.mathBranch)) : t.push(g(re.mathBranch, e.mathBranch))), e != null && e.status && t.push(g(re.status, e.status)), e != null && e.search) {
      const s = `%${e.search}%`;
      t.push(
        kn(
          Ht(re.title, s),
          Ht(re.code, s),
          Ht(re.description, s)
        )
      );
    }
    return this.db.select().from(re).where(t.length > 0 ? ae(...t) : void 0).orderBy(
      re.gradeLevel,
      re.title,
      de(re.version)
    ).all();
  }
  create(e) {
    return this.db.insert(re).values(e).returning().get();
  }
  update(e, t) {
    const s = this.db.update(re).set({
      ...t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(re.id, e)).returning().get();
    if (!s)
      throw new Error(`Curriculum catalog with id '${e}' not found`);
    return s;
  }
}
class es {
  constructor(e) {
    this.db = e;
  }
  findById(e) {
    return this.db.select().from(le).where(g(le.id, e)).get() ?? null;
  }
  findByCatalogId(e) {
    return this.db.select().from(le).where(g(le.catalogId, e)).orderBy(Ae(le.orderIndex), Ae(le.createdAt)).all();
  }
  findByParentId(e, t) {
    const s = t ? ae(
      g(le.catalogId, e),
      g(le.parentId, t)
    ) : ae(
      g(le.catalogId, e),
      Ms(le.parentId)
    );
    return this.db.select().from(le).where(s).orderBy(Ae(le.orderIndex)).all();
  }
  getNextOrderIndex(e, t) {
    const s = this.findByParentId(e, t);
    return s.length === 0 ? 0 : Math.max(...s.map((n) => n.orderIndex)) + 1;
  }
  countByCatalogId(e) {
    return this.db.select({ id: le.id }).from(le).where(g(le.catalogId, e)).all().length;
  }
  countSkillsByCatalogId(e) {
    return this.db.select({ id: le.id }).from(le).where(
      ae(
        g(le.catalogId, e),
        g(le.tier, "SKILL")
      )
    ).all().length;
  }
  create(e) {
    return this.db.insert(le).values(e).returning().get();
  }
  createBatch(e) {
    return e.length === 0 ? [] : this.db.insert(le).values(e).returning().all();
  }
  update(e, t) {
    const s = this.db.update(le).set({
      ...t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(le.id, e)).returning().get();
    if (!s)
      throw new Error(`Curriculum node with id '${e}' not found`);
    return s;
  }
  delete(e) {
    return this.db.delete(le).where(g(le.id, e)).run().changes > 0;
  }
  deleteBatch(e) {
    if (e.length === 0) return 0;
    let t = 0;
    for (const s of e) {
      const n = this.db.delete(le).where(g(le.id, s)).run();
      t += n.changes;
    }
    return t;
  }
  reorder(e, t) {
    for (const s of t)
      this.db.update(le).set({
        orderIndex: s.orderIndex,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }).where(
        ae(
          g(le.id, s.id),
          g(le.catalogId, e)
        )
      ).run();
  }
}
class ch {
  constructor(e) {
    this.db = e;
  }
  findById(e) {
    return this.db.select().from(Ce).where(g(Ce.id, e)).get() ?? null;
  }
  findByHash(e) {
    return this.db.select().from(Ce).where(g(Ce.sha256Hash, e)).get() ?? null;
  }
  list(e) {
    return e ? this.db.select().from(Ce).where(g(Ce.curriculumCatalogId, e)).orderBy(de(Ce.createdAt)).all() : this.db.select().from(Ce).orderBy(de(Ce.createdAt)).all();
  }
  create(e) {
    return this.db.insert(Ce).values(e).returning().get();
  }
  update(e, t) {
    return this.db.update(Ce).set({ ...t, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(g(Ce.id, e)).returning().get();
  }
  delete(e) {
    this.db.delete(Ce).where(g(Ce.id, e)).run();
  }
}
class Lc {
  constructor(e) {
    this.db = e;
  }
  findById(e) {
    return this.db.select().from(ye).where(g(ye.id, e)).get() ?? null;
  }
  listBySourceDocument(e) {
    return this.db.select().from(ye).where(g(ye.sourceDocumentId, e)).orderBy(Ae(ye.startPage), Ae(ye.endPage)).all();
  }
  findAll() {
    return this.db.select().from(ye).orderBy(Ae(ye.startPage), Ae(ye.endPage)).all();
  }
  create(e) {
    return this.db.insert(ye).values(e).returning().get();
  }
  update(e, t) {
    return this.db.update(ye).set({ ...t, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(g(ye.id, e)).returning().get();
  }
  delete(e) {
    this.db.delete(ye).where(g(ye.id, e)).run();
  }
}
class Pc {
  constructor(e) {
    this.db = e;
  }
  findById(e) {
    return this.db.select().from(Ee).where(g(Ee.id, e)).get() ?? null;
  }
  findByCode(e) {
    return this.db.select().from(Ee).where(g(Ee.code, e)).get() ?? null;
  }
  findByFingerprint(e) {
    return this.db.select().from(Ee).where(g(Ee.contentFingerprint, e)).all();
  }
  getNextCode() {
    const e = this.db.select({ code: Ee.code }).from(Ee).orderBy(de(Ee.code)).limit(1).get();
    if (!e || !e.code.startsWith("Q-"))
      return "Q-000001";
    const t = parseInt(e.code.replace("Q-", ""), 10), s = isNaN(t) ? 1 : t + 1;
    return `Q-${String(s).padStart(6, "0")}`;
  }
  list(e) {
    const t = [];
    e != null && e.status && t.push(g(Ee.status, e.status)), e != null && e.questionType && t.push(g(Ee.questionType, e.questionType)), e != null && e.difficulty && t.push(g(Ee.difficulty, e.difficulty)), e != null && e.search && t.push(Ht(Ee.bodyJson, `%${e.search}%`));
    let s = this.db.select().from(Ee);
    t.length > 0 && (s = s.where(ae(...t)));
    const n = s.orderBy(de(Ee.createdAt)).all();
    if (e != null && e.curriculumNodeId) {
      const i = new Set(
        this.db.select({ questionId: it.questionId }).from(it).where(g(it.curriculumNodeId, e.curriculumNodeId)).all().map((a) => a.questionId)
      );
      return n.filter((a) => i.has(a.id));
    }
    return n;
  }
  getCurriculumTagIds(e) {
    return this.db.select({ nodeId: it.curriculumNodeId }).from(it).where(g(it.questionId, e)).all().map((t) => t.nodeId);
  }
  getSourceReferences(e) {
    return this.db.select({
      sourceReferenceId: ve.sourceReferenceId,
      notes: ve.notes,
      referenceLabel: ye.referenceLabel,
      startPage: ye.startPage,
      endPage: ye.endPage,
      sourceDocumentTitle: Ce.title
    }).from(ve).innerJoin(ye, g(ve.sourceReferenceId, ye.id)).innerJoin(Ce, g(ye.sourceDocumentId, Ce.id)).where(g(ve.questionId, e)).all().map((s) => ({
      sourceReferenceId: s.sourceReferenceId,
      referenceLabel: s.referenceLabel,
      sourceDocumentTitle: s.sourceDocumentTitle,
      startPage: s.startPage,
      endPage: s.endPage,
      notes: s.notes
    }));
  }
  create(e, t, s = []) {
    const n = (/* @__PURE__ */ new Date()).toISOString(), i = this.db.insert(Ee).values(e).returning().get();
    for (const a of t)
      this.db.insert(it).values({
        id: crypto.randomUUID(),
        questionId: i.id,
        curriculumNodeId: a,
        createdAt: n
      }).run();
    for (const a of s)
      this.db.insert(ve).values({
        id: crypto.randomUUID(),
        questionId: i.id,
        sourceReferenceId: a,
        createdAt: n
      }).run();
    return i;
  }
  update(e, t, s, n) {
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.db.update(Ee).set({ ...t, updatedAt: i }).where(g(Ee.id, e)).returning().get();
    if (s !== void 0) {
      this.db.delete(it).where(g(it.questionId, e)).run();
      for (const o of s)
        this.db.insert(it).values({
          id: crypto.randomUUID(),
          questionId: e,
          curriculumNodeId: o,
          createdAt: i
        }).run();
    }
    if (n !== void 0) {
      this.db.delete(ve).where(g(ve.questionId, e)).run();
      for (const o of n)
        this.db.insert(ve).values({
          id: crypto.randomUUID(),
          questionId: e,
          sourceReferenceId: o,
          createdAt: i
        }).run();
    }
    return a;
  }
  addSourceReference(e, t, s) {
    this.db.select().from(ve).where(
      ae(
        g(ve.questionId, e),
        g(ve.sourceReferenceId, t)
      )
    ).get() || this.db.insert(ve).values({
      id: crypto.randomUUID(),
      questionId: e,
      sourceReferenceId: t,
      notes: s ?? null,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    }).run();
  }
  archive(e) {
    this.db.update(Ee).set({ status: "ARCHIVED", updatedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(g(Ee.id, e)).run();
  }
  delete(e) {
    this.db.delete(it).where(g(it.questionId, e)).run(), this.db.delete(ve).where(g(ve.questionId, e)).run(), this.db.delete(Ee).where(g(Ee.id, e)).run();
  }
  linkSourceReference(e, t, s) {
    this.addSourceReference(e, t, s);
  }
  unlinkSourceReference(e, t) {
    this.db.delete(ve).where(
      ae(
        g(ve.questionId, e),
        g(ve.sourceReferenceId, t)
      )
    ).run();
  }
}
class Ct {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(ee).where(g(ee.id, e)).get() ?? null;
  }
  findByCode(e) {
    return this.client.select().from(ee).where(g(ee.studentCode, e)).get() ?? null;
  }
  findByQrToken(e) {
    return this.client.select().from(ee).where(g(ee.qrToken, e)).get() ?? null;
  }
  findByBarcode(e) {
    return this.client.select().from(ee).where(g(ee.barcodeValue, e)).get() ?? null;
  }
  create(e) {
    this.client.insert(ee).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create student with id: ${e.id}`);
    return t;
  }
  update(e, t) {
    const s = (/* @__PURE__ */ new Date()).toISOString();
    return this.client.update(ee).set({ ...t, updatedAt: t.updatedAt ?? s }).where(g(ee.id, e)).run(), this.findById(e);
  }
  list(e) {
    const t = [];
    if (e != null && e.searchQuery && e.searchQuery.trim().length > 0) {
      const s = `%${e.searchQuery.trim()}%`;
      t.push(
        kn(
          Ht(ee.fullName, s),
          Ht(ee.studentCode, s),
          Ht(ee.guardianPhone, s)
        )
      );
    }
    return e != null && e.status && t.push(g(ee.status, e.status)), e != null && e.gradeLevel && t.push(g(ee.gradeLevel, e.gradeLevel)), e != null && e.educationSystem && t.push(g(ee.educationSystem, e.educationSystem)), e != null && e.languageTrack && t.push(g(ee.languageTrack, e.languageTrack)), t.length > 0 ? this.client.select().from(ee).where(ae(...t)).all() : this.client.select().from(ee).all();
  }
  addNote(e) {
    this.client.insert(ct).values(e).run();
    const t = this.client.select().from(ct).where(g(ct.id, e.id)).get();
    if (!t)
      throw new Error(`Failed to create student note with id: ${e.id}`);
    return t;
  }
  getNotes(e) {
    return this.client.select().from(ct).where(g(ct.studentId, e)).orderBy(de(ct.createdAt)).all();
  }
  listFollowUpNotesWithActiveStudents() {
    return this.client.select({
      note: ct,
      student: ee
    }).from(ct).innerJoin(ee, g(ct.studentId, ee.id)).where(
      ae(
        g(ct.tag, "NEEDS_FOLLOW_UP"),
        g(ee.status, "ACTIVE")
      )
    ).orderBy(de(ct.createdAt), Ae(ee.fullName), Ae(ee.id)).all();
  }
}
class mt {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(oe).where(g(oe.id, e)).get() ?? null;
  }
  findByIds(e) {
    return e.length === 0 ? [] : this.client.select().from(oe).where(is(oe.id, e)).all();
  }
  countActive() {
    const e = this.client.select({ count: _`count(*)` }).from(oe).where(g(oe.status, "ACTIVE")).get();
    return (e == null ? void 0 : e.count) ?? 0;
  }
  create(e) {
    this.client.insert(oe).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create group with id: ${e.id}`);
    return t;
  }
  update(e, t) {
    const s = (/* @__PURE__ */ new Date()).toISOString();
    return this.client.update(oe).set({ ...t, updatedAt: t.updatedAt ?? s }).where(g(oe.id, e)).run(), this.findById(e);
  }
  list(e) {
    const t = [];
    return e != null && e.status && t.push(g(oe.status, e.status)), e != null && e.gradeLevel && t.push(g(oe.gradeLevel, e.gradeLevel)), e != null && e.educationSystem && t.push(g(oe.educationSystem, e.educationSystem)), e != null && e.languageTrack && t.push(g(oe.languageTrack, e.languageTrack)), t.length > 0 ? this.client.select().from(oe).where(ae(...t)).all() : this.client.select().from(oe).all();
  }
  addSchedule(e) {
    this.client.insert(gt).values(e).run();
    const t = this.client.select().from(gt).where(g(gt.id, e.id)).get();
    if (!t)
      throw new Error(`Failed to create schedule with id: ${e.id}`);
    return t;
  }
  getSchedules(e) {
    return this.client.select().from(gt).where(g(gt.groupId, e)).all();
  }
  deleteSchedule(e) {
    this.client.delete(gt).where(g(gt.id, e)).run();
  }
  deleteSchedulesByGroup(e) {
    this.client.delete(gt).where(g(gt.groupId, e)).run();
  }
}
class Ut {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(se).where(g(se.id, e)).get() ?? null;
  }
  findActiveEnrollment(e, t) {
    return this.client.select().from(se).where(
      ae(
        g(se.groupId, e),
        g(se.studentId, t),
        g(se.status, "ACTIVE")
      )
    ).get() ?? null;
  }
  create(e) {
    this.client.insert(se).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create enrollment with id: ${e.id}`);
    return t;
  }
  endEnrollment(e, t) {
    const s = t ?? (/* @__PURE__ */ new Date()).toISOString();
    this.client.update(se).set({ status: "ENDED", leftAt: s }).where(g(se.id, e)).run();
  }
  listByGroup(e, t = !1) {
    return t ? this.client.select().from(se).where(
      ae(
        g(se.groupId, e),
        g(se.status, "ACTIVE")
      )
    ).all() : this.client.select().from(se).where(g(se.groupId, e)).all();
  }
  listByStudent(e, t = !1) {
    return t ? this.client.select().from(se).where(
      ae(
        g(se.studentId, e),
        g(se.status, "ACTIVE")
      )
    ).all() : this.client.select().from(se).where(g(se.studentId, e)).all();
  }
  updatePaymentOverrides(e, t, s) {
    const n = {};
    return t !== void 0 && (n.paymentTypeOverride = t), s !== void 0 && (n.paymentAmountOverride = s), this.client.update(se).set(n).where(g(se.id, e)).run(), this.findById(e);
  }
  countActiveByGroupIds(e) {
    const t = /* @__PURE__ */ new Map();
    if (e.length === 0) return t;
    const s = this.client.select({
      groupId: se.groupId,
      count: _`count(*)`
    }).from(se).where(
      ae(
        is(se.groupId, e),
        g(se.status, "ACTIVE")
      )
    ).groupBy(se.groupId).all();
    for (const n of s)
      t.set(n.groupId, n.count);
    return t;
  }
  countDistinctActiveEnrolledStudents() {
    const e = this.client.select({
      count: _`count(distinct ${se.studentId})`
    }).from(se).innerJoin(ee, g(se.studentId, ee.id)).where(
      ae(
        g(se.status, "ACTIVE"),
        g(ee.status, "ACTIVE")
      )
    ).get();
    return (e == null ? void 0 : e.count) ?? 0;
  }
  getActiveGroupsForStudents(e) {
    const t = /* @__PURE__ */ new Map();
    if (e.length === 0) return t;
    const s = this.client.select({
      studentId: se.studentId,
      groupId: oe.id,
      groupName: oe.name
    }).from(se).innerJoin(oe, g(se.groupId, oe.id)).where(
      ae(
        is(se.studentId, e),
        g(se.status, "ACTIVE")
      )
    ).orderBy(Ae(oe.name), Ae(oe.id)).all();
    for (const n of s) {
      const i = t.get(n.studentId) ?? [];
      i.push({ groupId: n.groupId, groupName: n.groupName }), t.set(n.studentId, i);
    }
    return t;
  }
}
class ht {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(X).where(g(X.id, e)).get() ?? null;
  }
  findByOccurrenceKey(e) {
    return this.client.select().from(X).where(g(X.occurrenceKey, e)).get() ?? null;
  }
  create(e) {
    this.client.insert(X).values(e).run();
    const t = this.findById(e.id);
    if (!t)
      throw new Error(`Failed to create session with id: ${e.id}`);
    return t;
  }
  createMany(e) {
    if (e.length === 0) return [];
    this.client.insert(X).values(e).run();
    const t = e.map((s) => s.id);
    return this.client.select().from(X).where(is(X.id, t)).all();
  }
  update(e, t) {
    const s = (/* @__PURE__ */ new Date()).toISOString();
    return this.client.update(X).set({ ...t, updatedAt: t.updatedAt ?? s }).where(g(X.id, e)).run(), this.findById(e);
  }
  listByGroup(e) {
    return this.client.select().from(X).where(g(X.groupId, e)).orderBy(Ae(X.effectiveDate), Ae(X.effectiveStartTime)).all();
  }
  listByEffectiveDate(e) {
    return this.client.select().from(X).where(g(X.effectiveDate, e)).orderBy(Ae(X.effectiveStartTime)).all();
  }
  listByDateRange(e, t, s) {
    const n = [
      cr(X.effectiveDate, e),
      lc(X.effectiveDate, t)
    ];
    return s && n.push(g(X.groupId, s)), this.client.select().from(X).where(ae(...n)).orderBy(Ae(X.effectiveDate), Ae(X.effectiveStartTime)).all();
  }
  deleteUntouchedFutureScheduledSessions(e, t, s, n) {
    const i = s ? kn(
      dr(X.effectiveDate, t),
      ae(
        g(X.effectiveDate, t),
        dr(X.effectiveStartTime, s)
      )
    ) : cr(X.effectiveDate, t), a = [
      g(X.groupId, e),
      g(X.status, "SCHEDULED"),
      Ms(X.rescheduleReason),
      i
    ];
    return n && n.length > 0 && a.push(is(X.scheduleId, n)), this.client.delete(X).where(ae(...a)).run().changes;
  }
  updateStatus(e, t, s) {
    const n = {
      status: t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return s !== void 0 && (n.notes = s), this.update(e, n);
  }
}
class nn {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(pe).where(g(pe.id, e)).get() ?? null;
  }
  findBySessionAndStudent(e, t) {
    return this.client.select().from(pe).where(
      ae(
        g(pe.sessionId, e),
        g(pe.studentId, t)
      )
    ).get() ?? null;
  }
  listBySessionId(e) {
    return this.client.select().from(pe).where(g(pe.sessionId, e)).all();
  }
  upsert(e) {
    const t = e.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString();
    this.client.insert(pe).values({
      ...e,
      updatedAt: t
    }).onConflictDoUpdate({
      target: [pe.sessionId, pe.studentId],
      set: {
        status: e.status,
        arrivalTime: e.arrivalTime,
        notes: e.notes,
        recordedByUserId: e.recordedByUserId,
        updatedAt: t
      }
    }).run();
    const s = this.findBySessionAndStudent(e.sessionId, e.studentId);
    if (!s)
      throw new Error(
        `Failed to upsert attendance record for session ${e.sessionId} and student ${e.studentId}`
      );
    return s;
  }
  batchUpsert(e) {
    return e.length === 0 ? [] : e.map((t) => this.upsert(t));
  }
  listByDateWithDetails(e) {
    return this.client.select({
      id: pe.id,
      sessionId: pe.sessionId,
      studentId: pe.studentId,
      studentName: ee.fullName,
      guardianPhone: ee.guardianPhone,
      groupName: oe.name,
      status: pe.status,
      arrivalTime: pe.arrivalTime,
      notes: pe.notes,
      sessionDate: X.effectiveDate,
      sessionStartTime: X.effectiveStartTime,
      recordedByUserId: pe.recordedByUserId,
      recordedAt: pe.recordedAt,
      updatedAt: pe.updatedAt,
      contactStatus: _`COALESCE(${Be.contactStatus}, 'UNCONTACTED')`,
      contactNote: Be.note,
      contactedAt: Be.contactedAt,
      contactedByUserId: Be.contactedByUserId
    }).from(pe).innerJoin(X, g(pe.sessionId, X.id)).innerJoin(ee, g(pe.studentId, ee.id)).innerJoin(oe, g(X.groupId, oe.id)).leftJoin(Be, g(pe.id, Be.attendanceRecordId)).where(g(X.effectiveDate, e)).all();
  }
  countByStatusForSession(e) {
    const t = this.listBySessionId(e), s = {
      total: t.length,
      present: 0,
      absent: 0,
      late: 0,
      excused: 0
    };
    for (const n of t)
      n.status === "PRESENT" ? s.present++ : n.status === "ABSENT" ? s.absent++ : n.status === "LATE" ? s.late++ : n.status === "EXCUSED" && s.excused++;
    return s;
  }
}
class ci {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  findById(e) {
    return this.client.select().from(Be).where(g(Be.id, e)).get() ?? null;
  }
  findByAttendanceRecordId(e) {
    return this.client.select().from(Be).where(g(Be.attendanceRecordId, e)).get() ?? null;
  }
  listByAttendanceRecordIds(e) {
    return e.length === 0 ? [] : this.client.select().from(Be).where(is(Be.attendanceRecordId, e)).all();
  }
  upsert(e) {
    const t = e.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString();
    this.client.insert(Be).values({
      ...e,
      updatedAt: t
    }).onConflictDoUpdate({
      target: Be.attendanceRecordId,
      set: {
        contactStatus: e.contactStatus,
        note: e.note,
        contactedAt: e.contactedAt,
        contactedByUserId: e.contactedByUserId,
        updatedAt: t
      }
    }).run();
    const s = this.findByAttendanceRecordId(e.attendanceRecordId);
    if (!s)
      throw new Error(
        `Failed to upsert attendance follow up for record ${e.attendanceRecordId}`
      );
    return s;
  }
  deleteByAttendanceRecordId(e) {
    this.client.delete(Be).where(g(Be.attendanceRecordId, e)).run();
  }
}
class me {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  insert(e) {
    this.client.insert(Dt).values(e).run();
    const t = this.client.select().from(Dt).where(g(Dt.id, e.id)).get();
    if (!t)
      throw new Error(`Failed to insert academic audit entry with id: ${e.id}`);
    return t;
  }
  listRecent(e = 50) {
    return this.client.select().from(Dt).orderBy(de(Dt.createdAt)).limit(e).all();
  }
  findByEntity(e, t) {
    return this.client.select().from(Dt).where(
      ae(
        g(Dt.entityType, e),
        g(Dt.entityId, t)
      )
    ).orderBy(de(Dt.createdAt)).all();
  }
}
class kc {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  insert(e) {
    return this.client.insert(Ie).values(e).returning().get();
  }
  create(e) {
    return this.insert(e);
  }
  findById(e) {
    return this.client.select().from(Ie).where(g(Ie.id, e)).get() ?? null;
  }
  findByReceiptNumber(e) {
    return this.client.select().from(Ie).where(g(Ie.receiptNumber, e)).get() ?? null;
  }
  listByStudent(e) {
    return this.client.select().from(Ie).where(g(Ie.studentId, e)).orderBy(de(Ie.paymentDate), de(Ie.createdAt)).all();
  }
  listAll(e) {
    const t = [];
    e != null && e.studentId && t.push(g(Ie.studentId, e.studentId)), e != null && e.groupId && t.push(g(Ie.groupId, e.groupId));
    const s = this.client.select().from(Ie);
    return t.length > 0 ? s.where(ae(...t)).orderBy(de(Ie.paymentDate), de(Ie.createdAt)).all() : s.orderBy(de(Ie.paymentDate), de(Ie.createdAt)).all();
  }
  countAll() {
    const e = this.client.select({ count: _`count(*)` }).from(Ie).get();
    return (e == null ? void 0 : e.count) ?? 0;
  }
  totalPaidByStudent(e, t) {
    const s = [g(Ie.studentId, e)];
    t && s.push(g(Ie.groupId, t));
    const n = this.client.select({ total: _`COALESCE(SUM(amount_cents), 0)` }).from(Ie).where(ae(...s)).get();
    return (n == null ? void 0 : n.total) ?? 0;
  }
  totalCollected() {
    const e = this.client.select({ total: _`COALESCE(SUM(amount_cents), 0)` }).from(Ie).get();
    return (e == null ? void 0 : e.total) ?? 0;
  }
}
class uh {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  insert(e, t) {
    const s = this.client.insert(ze).values(e).returning().get(), n = [];
    for (const i of t) {
      const a = this.client.insert(Ot).values({
        ...i,
        invoiceId: s.id
      }).returning().get();
      n.push(a);
    }
    return { invoice: s, items: n };
  }
  create(e, t) {
    return this.insert(e, t);
  }
  findById(e) {
    const t = this.client.select().from(ze).where(g(ze.id, e)).get();
    if (!t) return null;
    const s = this.client.select().from(Ot).where(g(Ot.invoiceId, e)).all();
    return { invoice: t, items: s };
  }
  findByInvoiceNumber(e) {
    const t = this.client.select().from(ze).where(g(ze.invoiceNumber, e)).get();
    if (!t) return null;
    const s = this.client.select().from(Ot).where(g(Ot.invoiceId, t.id)).all();
    return { invoice: t, items: s };
  }
  listByStudent(e) {
    return this.client.select().from(ze).where(g(ze.studentId, e)).orderBy(de(ze.issueDate), de(ze.createdAt)).all().map((s) => {
      const n = this.client.select().from(Ot).where(g(Ot.invoiceId, s.id)).all();
      return { invoice: s, items: n };
    });
  }
  listAll() {
    return this.client.select().from(ze).orderBy(de(ze.issueDate), de(ze.createdAt)).all().map((t) => {
      const s = this.client.select().from(Ot).where(g(Ot.invoiceId, t.id)).all();
      return { invoice: t, items: s };
    });
  }
  updateStatus(e, t, s, n) {
    const i = {
      status: t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    s !== void 0 && (i.paidCents = s), n !== void 0 && (i.remainingCents = n), this.client.update(ze).set(i).where(g(ze.id, e)).run();
  }
  countAll() {
    const e = this.client.select({ count: _`count(*)` }).from(ze).get();
    return (e == null ? void 0 : e.count) ?? 0;
  }
}
class lh {
  constructor(e) {
    this.db = e;
  }
  get client() {
    return this.db ?? Fe().db;
  }
  insert(e) {
    return this.client.insert(Xe).values(e).returning().get();
  }
  create(e) {
    return this.insert(e);
  }
  findById(e) {
    return this.client.select().from(Xe).where(g(Xe.id, e)).get() ?? null;
  }
  listActiveByStudent(e, t) {
    const s = [
      g(Xe.studentId, e),
      g(Xe.status, "ACTIVE")
    ];
    return t && s.push(
      _`(${Xe.groupId} = ${t} OR ${Xe.groupId} IS NULL)`
    ), this.client.select().from(Xe).where(ae(...s)).orderBy(de(Xe.createdAt)).all();
  }
  listAllByStudent(e) {
    return this.client.select().from(Xe).where(g(Xe.studentId, e)).orderBy(de(Xe.createdAt)).all();
  }
  updateStatus(e, t) {
    this.client.update(Xe).set({ status: t, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(g(Xe.id, e)).run();
  }
}
class Kn {
  constructor(e) {
    this.db = e;
  }
  getAssignment(e) {
    return this.db.select().from(Wt).where(g(Wt.groupId, e)).get() ?? null;
  }
  assignCatalog(e) {
    const t = this.getAssignment(e.groupId);
    return t ? this.db.update(Wt).set({
      catalogId: e.catalogId,
      catalogVersion: e.catalogVersion,
      assignedAt: e.assignedAt,
      assignedByUserId: e.assignedByUserId,
      assignedByNameSnapshot: e.assignedByNameSnapshot,
      notes: e.notes,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(Wt.id, t.id)).returning().get() : this.db.insert(Wt).values(e).returning().get();
  }
  removeAssignment(e) {
    return this.db.delete(Wt).where(g(Wt.groupId, e)).run().changes > 0;
  }
  getProgressByGroup(e) {
    return this.db.select().from(St).where(g(St.groupId, e)).all();
  }
  getNodeProgress(e, t) {
    return this.db.select().from(St).where(
      ae(
        g(St.groupId, e),
        g(St.nodeId, t)
      )
    ).get() ?? null;
  }
  upsertProgress(e) {
    const t = this.getNodeProgress(e.groupId, e.nodeId);
    return t ? this.db.update(St).set({
      status: e.status,
      completedAt: e.status === "COMPLETED" ? e.completedAt ?? (/* @__PURE__ */ new Date()).toISOString() : null,
      updatedByUserId: e.updatedByUserId,
      updatedByNameSnapshot: e.updatedByNameSnapshot,
      notes: e.notes ?? t.notes,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(St.id, t.id)).returning().get() : this.db.insert(St).values({
      ...e,
      completedAt: e.status === "COMPLETED" ? e.completedAt ?? (/* @__PURE__ */ new Date()).toISOString() : null
    }).returning().get();
  }
  countProgressByStatus(e) {
    const t = this.getProgressByGroup(e);
    let s = 0, n = 0;
    for (const i of t)
      i.status === "COMPLETED" ? s++ : i.status === "IN_PROGRESS" && n++;
    return { completed: s, inProgress: n };
  }
  resetProgressForGroup(e) {
    this.db.delete(St).where(g(St.groupId, e)).run();
  }
  deleteByGroup(e) {
    this.resetProgressForGroup(e);
  }
  countByGroup(e) {
    return this.getProgressByGroup(e).length;
  }
}
class rn {
  constructor(e) {
    this.db = e;
  }
  create(e) {
    return this.db.insert(Le).values(e).returning().get();
  }
  update(e, t) {
    const s = this.db.update(Le).set({
      ...t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(Le.id, e)).returning().get();
    if (!s)
      throw new Error(`Lesson plan not found: ${e}`);
    return s;
  }
  findById(e) {
    return this.db.select().from(Le).where(g(Le.id, e)).get() ?? null;
  }
  findByCurriculumNodeId(e) {
    return this.db.select().from(Le).where(g(Le.curriculumNodeId, e)).orderBy(de(Le.createdAt)).all();
  }
  list(e) {
    const t = [];
    e != null && e.curriculumNodeId && t.push(g(Le.curriculumNodeId, e.curriculumNodeId)), e != null && e.status && t.push(g(Le.status, e.status)), e != null && e.search && t.push(Ht(Le.title, `%${e.search}%`));
    const s = this.db.select().from(Le);
    return t.length > 0 ? s.where(ae(...t)).orderBy(de(Le.createdAt)).all() : s.orderBy(de(Le.createdAt)).all();
  }
  delete(e) {
    return this.db.delete(Le).where(g(Le.id, e)).run().changes > 0;
  }
}
class jn {
  constructor(e) {
    this.db = e;
  }
  create(e) {
    return this.db.insert(Pe).values(e).returning().get();
  }
  update(e, t) {
    const s = this.db.update(Pe).set({
      ...t,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }).where(g(Pe.id, e)).returning().get();
    if (!s)
      throw new Error(`Session reflection not found: ${e}`);
    return s;
  }
  findById(e) {
    return this.db.select().from(Pe).where(g(Pe.id, e)).get() ?? null;
  }
  findBySessionId(e) {
    return this.db.select().from(Pe).where(g(Pe.sessionId, e)).get() ?? null;
  }
  findByLessonPlanId(e) {
    return this.db.select().from(Pe).where(g(Pe.lessonPlanId, e)).orderBy(de(Pe.createdAt)).all();
  }
  list(e) {
    const t = this.db.select().from(Pe);
    return e != null && e.completionStatus ? t.where(g(Pe.completionStatus, e.completionStatus)).orderBy(de(Pe.createdAt)).all() : t.orderBy(de(Pe.createdAt)).all();
  }
  delete(e) {
    return this.db.delete(Pe).where(g(Pe.id, e)).run().changes > 0;
  }
}
class hh {
  constructor(e) {
    this.db = e;
  }
  create(e) {
    this.db.transaction((t) => {
      t.insert(lt).values(e.exam).run(), e.sections.length && t.insert(Rs).values(e.sections).run(), e.questions.length && t.insert(sn).values(e.questions).run(), e.versions.length && t.insert(bs).values(e.versions).run();
    });
  }
  findSnapshot(e) {
    const t = this.db.select().from(lt).where(g(lt.id, e)).get();
    if (!t) return null;
    const s = this.db.select().from(Rs).where(g(Rs.examId, e)).orderBy(Ae(Rs.position)).all(), n = new Set(s.map((o) => o.id)), i = this.db.select().from(sn).orderBy(Ae(sn.position)).all().filter((o) => n.has(o.examSectionId)), a = this.db.select().from(bs).where(g(bs.examId, e)).orderBy(Ae(bs.label)).all();
    return { exam: t, sections: s, questions: i, versions: a };
  }
  list() {
    return this.db.select().from(lt).orderBy(Ae(lt.createdAt)).all();
  }
  delete(e) {
    this.db.transaction((t) => {
      t.delete(lt).where(g(lt.id, e)).run();
    });
  }
  updateStatus(e, t) {
    this.db.update(lt).set({ status: t, updatedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(g(lt.id, e)).run();
  }
}
class Mn {
  today() {
    const e = /* @__PURE__ */ new Date(), t = e.getFullYear(), s = String(e.getMonth() + 1).padStart(2, "0"), n = String(e.getDate()).padStart(2, "0");
    return `${t}-${s}-${n}`;
  }
  nowTime() {
    const e = /* @__PURE__ */ new Date(), t = String(e.getHours()).padStart(2, "0"), s = String(e.getMinutes()).padStart(2, "0");
    return `${t}:${s}`;
  }
  nowIso() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  nowDate() {
    return /* @__PURE__ */ new Date();
  }
}
var ce;
(function(r) {
  r.assertEqual = (n) => {
  };
  function e(n) {
  }
  r.assertIs = e;
  function t(n) {
    throw new Error();
  }
  r.assertNever = t, r.arrayToEnum = (n) => {
    const i = {};
    for (const a of n)
      i[a] = a;
    return i;
  }, r.getValidEnumValues = (n) => {
    const i = r.objectKeys(n).filter((o) => typeof n[n[o]] != "number"), a = {};
    for (const o of i)
      a[o] = n[o];
    return r.objectValues(a);
  }, r.objectValues = (n) => r.objectKeys(n).map(function(i) {
    return n[i];
  }), r.objectKeys = typeof Object.keys == "function" ? (n) => Object.keys(n) : (n) => {
    const i = [];
    for (const a in n)
      Object.prototype.hasOwnProperty.call(n, a) && i.push(a);
    return i;
  }, r.find = (n, i) => {
    for (const a of n)
      if (i(a))
        return a;
  }, r.isInteger = typeof Number.isInteger == "function" ? (n) => Number.isInteger(n) : (n) => typeof n == "number" && Number.isFinite(n) && Math.floor(n) === n;
  function s(n, i = " | ") {
    return n.map((a) => typeof a == "string" ? `'${a}'` : a).join(i);
  }
  r.joinValues = s, r.jsonStringifyReplacer = (n, i) => typeof i == "bigint" ? i.toString() : i;
})(ce || (ce = {}));
var ui;
(function(r) {
  r.mergeShapes = (e, t) => ({
    ...e,
    ...t
    // second overwrites first
  });
})(ui || (ui = {}));
const $ = ce.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]), ts = (r) => {
  switch (typeof r) {
    case "undefined":
      return $.undefined;
    case "string":
      return $.string;
    case "number":
      return Number.isNaN(r) ? $.nan : $.number;
    case "boolean":
      return $.boolean;
    case "function":
      return $.function;
    case "bigint":
      return $.bigint;
    case "symbol":
      return $.symbol;
    case "object":
      return Array.isArray(r) ? $.array : r === null ? $.null : r.then && typeof r.then == "function" && r.catch && typeof r.catch == "function" ? $.promise : typeof Map < "u" && r instanceof Map ? $.map : typeof Set < "u" && r instanceof Set ? $.set : typeof Date < "u" && r instanceof Date ? $.date : $.object;
    default:
      return $.unknown;
  }
}, U = ce.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
class bt extends Error {
  get errors() {
    return this.issues;
  }
  constructor(e) {
    super(), this.issues = [], this.addIssue = (s) => {
      this.issues = [...this.issues, s];
    }, this.addIssues = (s = []) => {
      this.issues = [...this.issues, ...s];
    };
    const t = new.target.prototype;
    Object.setPrototypeOf ? Object.setPrototypeOf(this, t) : this.__proto__ = t, this.name = "ZodError", this.issues = e;
  }
  format(e) {
    const t = e || function(i) {
      return i.message;
    }, s = { _errors: [] }, n = (i) => {
      for (const a of i.issues)
        if (a.code === "invalid_union")
          a.unionErrors.map(n);
        else if (a.code === "invalid_return_type")
          n(a.returnTypeError);
        else if (a.code === "invalid_arguments")
          n(a.argumentsError);
        else if (a.path.length === 0)
          s._errors.push(t(a));
        else {
          let o = s, d = 0;
          for (; d < a.path.length; ) {
            const u = a.path[d];
            d === a.path.length - 1 ? (o[u] = o[u] || { _errors: [] }, o[u]._errors.push(t(a))) : o[u] = o[u] || { _errors: [] }, o = o[u], d++;
          }
        }
    };
    return n(this), s;
  }
  static assert(e) {
    if (!(e instanceof bt))
      throw new Error(`Not a ZodError: ${e}`);
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, ce.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(e = (t) => t.message) {
    const t = {}, s = [];
    for (const n of this.issues)
      if (n.path.length > 0) {
        const i = n.path[0];
        t[i] = t[i] || [], t[i].push(e(n));
      } else
        s.push(e(n));
    return { formErrors: s, fieldErrors: t };
  }
  get formErrors() {
    return this.flatten();
  }
}
bt.create = (r) => new bt(r);
const _r = (r, e) => {
  let t;
  switch (r.code) {
    case U.invalid_type:
      r.received === $.undefined ? t = "Required" : t = `Expected ${r.expected}, received ${r.received}`;
      break;
    case U.invalid_literal:
      t = `Invalid literal value, expected ${JSON.stringify(r.expected, ce.jsonStringifyReplacer)}`;
      break;
    case U.unrecognized_keys:
      t = `Unrecognized key(s) in object: ${ce.joinValues(r.keys, ", ")}`;
      break;
    case U.invalid_union:
      t = "Invalid input";
      break;
    case U.invalid_union_discriminator:
      t = `Invalid discriminator value. Expected ${ce.joinValues(r.options)}`;
      break;
    case U.invalid_enum_value:
      t = `Invalid enum value. Expected ${ce.joinValues(r.options)}, received '${r.received}'`;
      break;
    case U.invalid_arguments:
      t = "Invalid function arguments";
      break;
    case U.invalid_return_type:
      t = "Invalid function return type";
      break;
    case U.invalid_date:
      t = "Invalid date";
      break;
    case U.invalid_string:
      typeof r.validation == "object" ? "includes" in r.validation ? (t = `Invalid input: must include "${r.validation.includes}"`, typeof r.validation.position == "number" && (t = `${t} at one or more positions greater than or equal to ${r.validation.position}`)) : "startsWith" in r.validation ? t = `Invalid input: must start with "${r.validation.startsWith}"` : "endsWith" in r.validation ? t = `Invalid input: must end with "${r.validation.endsWith}"` : ce.assertNever(r.validation) : r.validation !== "regex" ? t = `Invalid ${r.validation}` : t = "Invalid";
      break;
    case U.too_small:
      r.type === "array" ? t = `Array must contain ${r.exact ? "exactly" : r.inclusive ? "at least" : "more than"} ${r.minimum} element(s)` : r.type === "string" ? t = `String must contain ${r.exact ? "exactly" : r.inclusive ? "at least" : "over"} ${r.minimum} character(s)` : r.type === "number" ? t = `Number must be ${r.exact ? "exactly equal to " : r.inclusive ? "greater than or equal to " : "greater than "}${r.minimum}` : r.type === "bigint" ? t = `Number must be ${r.exact ? "exactly equal to " : r.inclusive ? "greater than or equal to " : "greater than "}${r.minimum}` : r.type === "date" ? t = `Date must be ${r.exact ? "exactly equal to " : r.inclusive ? "greater than or equal to " : "greater than "}${new Date(Number(r.minimum))}` : t = "Invalid input";
      break;
    case U.too_big:
      r.type === "array" ? t = `Array must contain ${r.exact ? "exactly" : r.inclusive ? "at most" : "less than"} ${r.maximum} element(s)` : r.type === "string" ? t = `String must contain ${r.exact ? "exactly" : r.inclusive ? "at most" : "under"} ${r.maximum} character(s)` : r.type === "number" ? t = `Number must be ${r.exact ? "exactly" : r.inclusive ? "less than or equal to" : "less than"} ${r.maximum}` : r.type === "bigint" ? t = `BigInt must be ${r.exact ? "exactly" : r.inclusive ? "less than or equal to" : "less than"} ${r.maximum}` : r.type === "date" ? t = `Date must be ${r.exact ? "exactly" : r.inclusive ? "smaller than or equal to" : "smaller than"} ${new Date(Number(r.maximum))}` : t = "Invalid input";
      break;
    case U.custom:
      t = "Invalid input";
      break;
    case U.invalid_intersection_types:
      t = "Intersection results could not be merged";
      break;
    case U.not_multiple_of:
      t = `Number must be a multiple of ${r.multipleOf}`;
      break;
    case U.not_finite:
      t = "Number must be finite";
      break;
    default:
      t = e.defaultError, ce.assertNever(r);
  }
  return { message: t };
};
let mh = _r;
function ph() {
  return mh;
}
const fh = (r) => {
  const { data: e, path: t, errorMaps: s, issueData: n } = r, i = [...t, ...n.path || []], a = {
    ...n,
    path: i
  };
  if (n.message !== void 0)
    return {
      ...n,
      path: i,
      message: n.message
    };
  let o = "";
  const d = s.filter((u) => !!u).slice().reverse();
  for (const u of d)
    o = u(a, { data: e, defaultError: o }).message;
  return {
    ...n,
    path: i,
    message: o
  };
};
function F(r, e) {
  const t = ph(), s = fh({
    issueData: e,
    data: r.data,
    path: r.path,
    errorMaps: [
      r.common.contextualErrorMap,
      // contextual error map is first priority
      r.schemaErrorMap,
      // then schema-bound map if available
      t,
      // then global override map
      t === _r ? void 0 : _r
      // then global default map
    ].filter((n) => !!n)
  });
  r.common.issues.push(s);
}
class et {
  constructor() {
    this.value = "valid";
  }
  dirty() {
    this.value === "valid" && (this.value = "dirty");
  }
  abort() {
    this.value !== "aborted" && (this.value = "aborted");
  }
  static mergeArray(e, t) {
    const s = [];
    for (const n of t) {
      if (n.status === "aborted")
        return V;
      n.status === "dirty" && e.dirty(), s.push(n.value);
    }
    return { status: e.value, value: s };
  }
  static async mergeObjectAsync(e, t) {
    const s = [];
    for (const n of t) {
      const i = await n.key, a = await n.value;
      s.push({
        key: i,
        value: a
      });
    }
    return et.mergeObjectSync(e, s);
  }
  static mergeObjectSync(e, t) {
    const s = {};
    for (const n of t) {
      const { key: i, value: a } = n;
      if (i.status === "aborted" || a.status === "aborted")
        return V;
      i.status === "dirty" && e.dirty(), a.status === "dirty" && e.dirty(), i.value !== "__proto__" && (typeof a.value < "u" || n.alwaysSet) && (s[i.value] = a.value);
    }
    return { status: e.value, value: s };
  }
}
const V = Object.freeze({
  status: "aborted"
}), Ls = (r) => ({ status: "dirty", value: r }), ft = (r) => ({ status: "valid", value: r }), li = (r) => r.status === "aborted", hi = (r) => r.status === "dirty", Os = (r) => r.status === "valid", pn = (r) => typeof Promise < "u" && r instanceof Promise;
var H;
(function(r) {
  r.errToObj = (e) => typeof e == "string" ? { message: e } : e || {}, r.toString = (e) => typeof e == "string" ? e : e == null ? void 0 : e.message;
})(H || (H = {}));
class Lt {
  constructor(e, t, s, n) {
    this._cachedPath = [], this.parent = e, this.data = t, this._path = s, this._key = n;
  }
  get path() {
    return this._cachedPath.length || (Array.isArray(this._key) ? this._cachedPath.push(...this._path, ...this._key) : this._cachedPath.push(...this._path, this._key)), this._cachedPath;
  }
}
const mi = (r, e) => {
  if (Os(e))
    return { success: !0, data: e.value };
  if (!r.common.issues.length)
    throw new Error("Validation failed but no issues detected.");
  return {
    success: !1,
    get error() {
      if (this._error)
        return this._error;
      const t = new bt(r.common.issues);
      return this._error = t, this._error;
    }
  };
};
function Z(r) {
  if (!r)
    return {};
  const { errorMap: e, invalid_type_error: t, required_error: s, description: n } = r;
  if (e && (t || s))
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  return e ? { errorMap: e, description: n } : { errorMap: (a, o) => {
    const { message: d } = r;
    return a.code === "invalid_enum_value" ? { message: d ?? o.defaultError } : typeof o.data > "u" ? { message: d ?? s ?? o.defaultError } : a.code !== "invalid_type" ? { message: o.defaultError } : { message: d ?? t ?? o.defaultError };
  }, description: n };
}
class ne {
  get description() {
    return this._def.description;
  }
  _getType(e) {
    return ts(e.data);
  }
  _getOrReturnCtx(e, t) {
    return t || {
      common: e.parent.common,
      data: e.data,
      parsedType: ts(e.data),
      schemaErrorMap: this._def.errorMap,
      path: e.path,
      parent: e.parent
    };
  }
  _processInputParams(e) {
    return {
      status: new et(),
      ctx: {
        common: e.parent.common,
        data: e.data,
        parsedType: ts(e.data),
        schemaErrorMap: this._def.errorMap,
        path: e.path,
        parent: e.parent
      }
    };
  }
  _parseSync(e) {
    const t = this._parse(e);
    if (pn(t))
      throw new Error("Synchronous parse encountered promise.");
    return t;
  }
  _parseAsync(e) {
    const t = this._parse(e);
    return Promise.resolve(t);
  }
  parse(e, t) {
    const s = this.safeParse(e, t);
    if (s.success)
      return s.data;
    throw s.error;
  }
  safeParse(e, t) {
    const s = {
      common: {
        issues: [],
        async: (t == null ? void 0 : t.async) ?? !1,
        contextualErrorMap: t == null ? void 0 : t.errorMap
      },
      path: (t == null ? void 0 : t.path) || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: ts(e)
    }, n = this._parseSync({ data: e, path: s.path, parent: s });
    return mi(s, n);
  }
  "~validate"(e) {
    var s, n;
    const t = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: ts(e)
    };
    if (!this["~standard"].async)
      try {
        const i = this._parseSync({ data: e, path: [], parent: t });
        return Os(i) ? {
          value: i.value
        } : {
          issues: t.common.issues
        };
      } catch (i) {
        (n = (s = i == null ? void 0 : i.message) == null ? void 0 : s.toLowerCase()) != null && n.includes("encountered") && (this["~standard"].async = !0), t.common = {
          issues: [],
          async: !0
        };
      }
    return this._parseAsync({ data: e, path: [], parent: t }).then((i) => Os(i) ? {
      value: i.value
    } : {
      issues: t.common.issues
    });
  }
  async parseAsync(e, t) {
    const s = await this.safeParseAsync(e, t);
    if (s.success)
      return s.data;
    throw s.error;
  }
  async safeParseAsync(e, t) {
    const s = {
      common: {
        issues: [],
        contextualErrorMap: t == null ? void 0 : t.errorMap,
        async: !0
      },
      path: (t == null ? void 0 : t.path) || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data: e,
      parsedType: ts(e)
    }, n = this._parse({ data: e, path: s.path, parent: s }), i = await (pn(n) ? n : Promise.resolve(n));
    return mi(s, i);
  }
  refine(e, t) {
    const s = (n) => typeof t == "string" || typeof t > "u" ? { message: t } : typeof t == "function" ? t(n) : t;
    return this._refinement((n, i) => {
      const a = e(n), o = () => i.addIssue({
        code: U.custom,
        ...s(n)
      });
      return typeof Promise < "u" && a instanceof Promise ? a.then((d) => d ? !0 : (o(), !1)) : a ? !0 : (o(), !1);
    });
  }
  refinement(e, t) {
    return this._refinement((s, n) => e(s) ? !0 : (n.addIssue(typeof t == "function" ? t(s, n) : t), !1));
  }
  _refinement(e) {
    return new Ss({
      schema: this,
      typeName: Q.ZodEffects,
      effect: { type: "refinement", refinement: e }
    });
  }
  superRefine(e) {
    return this._refinement(e);
  }
  constructor(e) {
    this.spa = this.safeParseAsync, this._def = e, this.parse = this.parse.bind(this), this.safeParse = this.safeParse.bind(this), this.parseAsync = this.parseAsync.bind(this), this.safeParseAsync = this.safeParseAsync.bind(this), this.spa = this.spa.bind(this), this.refine = this.refine.bind(this), this.refinement = this.refinement.bind(this), this.superRefine = this.superRefine.bind(this), this.optional = this.optional.bind(this), this.nullable = this.nullable.bind(this), this.nullish = this.nullish.bind(this), this.array = this.array.bind(this), this.promise = this.promise.bind(this), this.or = this.or.bind(this), this.and = this.and.bind(this), this.transform = this.transform.bind(this), this.brand = this.brand.bind(this), this.default = this.default.bind(this), this.catch = this.catch.bind(this), this.describe = this.describe.bind(this), this.pipe = this.pipe.bind(this), this.readonly = this.readonly.bind(this), this.isNullable = this.isNullable.bind(this), this.isOptional = this.isOptional.bind(this), this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: (t) => this["~validate"](t)
    };
  }
  optional() {
    return Gt.create(this, this._def);
  }
  nullable() {
    return gs.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return xt.create(this);
  }
  promise() {
    return yn.create(this, this._def);
  }
  or(e) {
    return Sn.create([this, e], this._def);
  }
  and(e) {
    return gn.create(this, e, this._def);
  }
  transform(e) {
    return new Ss({
      ...Z(this._def),
      schema: this,
      typeName: Q.ZodEffects,
      effect: { type: "transform", transform: e }
    });
  }
  default(e) {
    const t = typeof e == "function" ? e : () => e;
    return new Tn({
      ...Z(this._def),
      innerType: this,
      defaultValue: t,
      typeName: Q.ZodDefault
    });
  }
  brand() {
    return new Fc({
      typeName: Q.ZodBranded,
      type: this,
      ...Z(this._def)
    });
  }
  catch(e) {
    const t = typeof e == "function" ? e : () => e;
    return new An({
      ...Z(this._def),
      innerType: this,
      catchValue: t,
      typeName: Q.ZodCatch
    });
  }
  describe(e) {
    const t = this.constructor;
    return new t({
      ...this._def,
      description: e
    });
  }
  pipe(e) {
    return Hr.create(this, e);
  }
  readonly() {
    return Rn.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
}
const Eh = /^c[^\s-]{8,}$/i, Sh = /^[0-9a-z]+$/, gh = /^[0-9A-HJKMNP-TV-Z]{26}$/i, _h = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i, Nh = /^[a-z0-9_-]{21}$/i, Ih = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/, yh = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, Th = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i, Ah = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
let Xn;
const Rh = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Dh = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/, Oh = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/, wh = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, vh = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/, Ch = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/, zc = "((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))", Uh = new RegExp(`^${zc}$`);
function Bc(r) {
  let e = "[0-5]\\d";
  r.precision ? e = `${e}\\.\\d{${r.precision}}` : r.precision == null && (e = `${e}(\\.\\d+)?`);
  const t = r.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${e})${t}`;
}
function xh(r) {
  return new RegExp(`^${Bc(r)}$`);
}
function bh(r) {
  let e = `${zc}T${Bc(r)}`;
  const t = [];
  return t.push(r.local ? "Z?" : "Z"), r.offset && t.push("([+-]\\d{2}:?\\d{2})"), e = `${e}(${t.join("|")})`, new RegExp(`^${e}$`);
}
function Lh(r, e) {
  return !!((e === "v4" || !e) && Rh.test(r) || (e === "v6" || !e) && Oh.test(r));
}
function Ph(r, e) {
  if (!Ih.test(r))
    return !1;
  try {
    const [t] = r.split(".");
    if (!t)
      return !1;
    const s = t.replace(/-/g, "+").replace(/_/g, "/").padEnd(t.length + (4 - t.length % 4) % 4, "="), n = JSON.parse(atob(s));
    return !(typeof n != "object" || n === null || "typ" in n && (n == null ? void 0 : n.typ) !== "JWT" || !n.alg || e && n.alg !== e);
  } catch {
    return !1;
  }
}
function kh(r, e) {
  return !!((e === "v4" || !e) && Dh.test(r) || (e === "v6" || !e) && wh.test(r));
}
class qt extends ne {
  _parse(e) {
    if (this._def.coerce && (e.data = String(e.data)), this._getType(e) !== $.string) {
      const i = this._getOrReturnCtx(e);
      return F(i, {
        code: U.invalid_type,
        expected: $.string,
        received: i.parsedType
      }), V;
    }
    const s = new et();
    let n;
    for (const i of this._def.checks)
      if (i.kind === "min")
        e.data.length < i.value && (n = this._getOrReturnCtx(e, n), F(n, {
          code: U.too_small,
          minimum: i.value,
          type: "string",
          inclusive: !0,
          exact: !1,
          message: i.message
        }), s.dirty());
      else if (i.kind === "max")
        e.data.length > i.value && (n = this._getOrReturnCtx(e, n), F(n, {
          code: U.too_big,
          maximum: i.value,
          type: "string",
          inclusive: !0,
          exact: !1,
          message: i.message
        }), s.dirty());
      else if (i.kind === "length") {
        const a = e.data.length > i.value, o = e.data.length < i.value;
        (a || o) && (n = this._getOrReturnCtx(e, n), a ? F(n, {
          code: U.too_big,
          maximum: i.value,
          type: "string",
          inclusive: !0,
          exact: !0,
          message: i.message
        }) : o && F(n, {
          code: U.too_small,
          minimum: i.value,
          type: "string",
          inclusive: !0,
          exact: !0,
          message: i.message
        }), s.dirty());
      } else if (i.kind === "email")
        Th.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "email",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "emoji")
        Xn || (Xn = new RegExp(Ah, "u")), Xn.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "emoji",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "uuid")
        _h.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "uuid",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "nanoid")
        Nh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "nanoid",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "cuid")
        Eh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "cuid",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "cuid2")
        Sh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "cuid2",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "ulid")
        gh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
          validation: "ulid",
          code: U.invalid_string,
          message: i.message
        }), s.dirty());
      else if (i.kind === "url")
        try {
          new URL(e.data);
        } catch {
          n = this._getOrReturnCtx(e, n), F(n, {
            validation: "url",
            code: U.invalid_string,
            message: i.message
          }), s.dirty();
        }
      else i.kind === "regex" ? (i.regex.lastIndex = 0, i.regex.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "regex",
        code: U.invalid_string,
        message: i.message
      }), s.dirty())) : i.kind === "trim" ? e.data = e.data.trim() : i.kind === "includes" ? e.data.includes(i.value, i.position) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: { includes: i.value, position: i.position },
        message: i.message
      }), s.dirty()) : i.kind === "toLowerCase" ? e.data = e.data.toLowerCase() : i.kind === "toUpperCase" ? e.data = e.data.toUpperCase() : i.kind === "startsWith" ? e.data.startsWith(i.value) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: { startsWith: i.value },
        message: i.message
      }), s.dirty()) : i.kind === "endsWith" ? e.data.endsWith(i.value) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: { endsWith: i.value },
        message: i.message
      }), s.dirty()) : i.kind === "datetime" ? bh(i).test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: "datetime",
        message: i.message
      }), s.dirty()) : i.kind === "date" ? Uh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: "date",
        message: i.message
      }), s.dirty()) : i.kind === "time" ? xh(i).test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.invalid_string,
        validation: "time",
        message: i.message
      }), s.dirty()) : i.kind === "duration" ? yh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "duration",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : i.kind === "ip" ? Lh(e.data, i.version) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "ip",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : i.kind === "jwt" ? Ph(e.data, i.alg) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "jwt",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : i.kind === "cidr" ? kh(e.data, i.version) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "cidr",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : i.kind === "base64" ? vh.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "base64",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : i.kind === "base64url" ? Ch.test(e.data) || (n = this._getOrReturnCtx(e, n), F(n, {
        validation: "base64url",
        code: U.invalid_string,
        message: i.message
      }), s.dirty()) : ce.assertNever(i);
    return { status: s.value, value: e.data };
  }
  _regex(e, t, s) {
    return this.refinement((n) => e.test(n), {
      validation: t,
      code: U.invalid_string,
      ...H.errToObj(s)
    });
  }
  _addCheck(e) {
    return new qt({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  email(e) {
    return this._addCheck({ kind: "email", ...H.errToObj(e) });
  }
  url(e) {
    return this._addCheck({ kind: "url", ...H.errToObj(e) });
  }
  emoji(e) {
    return this._addCheck({ kind: "emoji", ...H.errToObj(e) });
  }
  uuid(e) {
    return this._addCheck({ kind: "uuid", ...H.errToObj(e) });
  }
  nanoid(e) {
    return this._addCheck({ kind: "nanoid", ...H.errToObj(e) });
  }
  cuid(e) {
    return this._addCheck({ kind: "cuid", ...H.errToObj(e) });
  }
  cuid2(e) {
    return this._addCheck({ kind: "cuid2", ...H.errToObj(e) });
  }
  ulid(e) {
    return this._addCheck({ kind: "ulid", ...H.errToObj(e) });
  }
  base64(e) {
    return this._addCheck({ kind: "base64", ...H.errToObj(e) });
  }
  base64url(e) {
    return this._addCheck({
      kind: "base64url",
      ...H.errToObj(e)
    });
  }
  jwt(e) {
    return this._addCheck({ kind: "jwt", ...H.errToObj(e) });
  }
  ip(e) {
    return this._addCheck({ kind: "ip", ...H.errToObj(e) });
  }
  cidr(e) {
    return this._addCheck({ kind: "cidr", ...H.errToObj(e) });
  }
  datetime(e) {
    return typeof e == "string" ? this._addCheck({
      kind: "datetime",
      precision: null,
      offset: !1,
      local: !1,
      message: e
    }) : this._addCheck({
      kind: "datetime",
      precision: typeof (e == null ? void 0 : e.precision) > "u" ? null : e == null ? void 0 : e.precision,
      offset: (e == null ? void 0 : e.offset) ?? !1,
      local: (e == null ? void 0 : e.local) ?? !1,
      ...H.errToObj(e == null ? void 0 : e.message)
    });
  }
  date(e) {
    return this._addCheck({ kind: "date", message: e });
  }
  time(e) {
    return typeof e == "string" ? this._addCheck({
      kind: "time",
      precision: null,
      message: e
    }) : this._addCheck({
      kind: "time",
      precision: typeof (e == null ? void 0 : e.precision) > "u" ? null : e == null ? void 0 : e.precision,
      ...H.errToObj(e == null ? void 0 : e.message)
    });
  }
  duration(e) {
    return this._addCheck({ kind: "duration", ...H.errToObj(e) });
  }
  regex(e, t) {
    return this._addCheck({
      kind: "regex",
      regex: e,
      ...H.errToObj(t)
    });
  }
  includes(e, t) {
    return this._addCheck({
      kind: "includes",
      value: e,
      position: t == null ? void 0 : t.position,
      ...H.errToObj(t == null ? void 0 : t.message)
    });
  }
  startsWith(e, t) {
    return this._addCheck({
      kind: "startsWith",
      value: e,
      ...H.errToObj(t)
    });
  }
  endsWith(e, t) {
    return this._addCheck({
      kind: "endsWith",
      value: e,
      ...H.errToObj(t)
    });
  }
  min(e, t) {
    return this._addCheck({
      kind: "min",
      value: e,
      ...H.errToObj(t)
    });
  }
  max(e, t) {
    return this._addCheck({
      kind: "max",
      value: e,
      ...H.errToObj(t)
    });
  }
  length(e, t) {
    return this._addCheck({
      kind: "length",
      value: e,
      ...H.errToObj(t)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(e) {
    return this.min(1, H.errToObj(e));
  }
  trim() {
    return new qt({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new qt({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new qt({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((e) => e.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((e) => e.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((e) => e.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((e) => e.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((e) => e.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((e) => e.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((e) => e.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((e) => e.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((e) => e.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((e) => e.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((e) => e.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((e) => e.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((e) => e.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((e) => e.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((e) => e.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((e) => e.kind === "base64url");
  }
  get minLength() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "min" && (e === null || t.value > e) && (e = t.value);
    return e;
  }
  get maxLength() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "max" && (e === null || t.value < e) && (e = t.value);
    return e;
  }
}
qt.create = (r) => new qt({
  checks: [],
  typeName: Q.ZodString,
  coerce: (r == null ? void 0 : r.coerce) ?? !1,
  ...Z(r)
});
function zh(r, e) {
  const t = (r.toString().split(".")[1] || "").length, s = (e.toString().split(".")[1] || "").length, n = t > s ? t : s, i = Number.parseInt(r.toFixed(n).replace(".", "")), a = Number.parseInt(e.toFixed(n).replace(".", ""));
  return i % a / 10 ** n;
}
class ws extends ne {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte, this.step = this.multipleOf;
  }
  _parse(e) {
    if (this._def.coerce && (e.data = Number(e.data)), this._getType(e) !== $.number) {
      const i = this._getOrReturnCtx(e);
      return F(i, {
        code: U.invalid_type,
        expected: $.number,
        received: i.parsedType
      }), V;
    }
    let s;
    const n = new et();
    for (const i of this._def.checks)
      i.kind === "int" ? ce.isInteger(e.data) || (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.invalid_type,
        expected: "integer",
        received: "float",
        message: i.message
      }), n.dirty()) : i.kind === "min" ? (i.inclusive ? e.data < i.value : e.data <= i.value) && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.too_small,
        minimum: i.value,
        type: "number",
        inclusive: i.inclusive,
        exact: !1,
        message: i.message
      }), n.dirty()) : i.kind === "max" ? (i.inclusive ? e.data > i.value : e.data >= i.value) && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.too_big,
        maximum: i.value,
        type: "number",
        inclusive: i.inclusive,
        exact: !1,
        message: i.message
      }), n.dirty()) : i.kind === "multipleOf" ? zh(e.data, i.value) !== 0 && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.not_multiple_of,
        multipleOf: i.value,
        message: i.message
      }), n.dirty()) : i.kind === "finite" ? Number.isFinite(e.data) || (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.not_finite,
        message: i.message
      }), n.dirty()) : ce.assertNever(i);
    return { status: n.value, value: e.data };
  }
  gte(e, t) {
    return this.setLimit("min", e, !0, H.toString(t));
  }
  gt(e, t) {
    return this.setLimit("min", e, !1, H.toString(t));
  }
  lte(e, t) {
    return this.setLimit("max", e, !0, H.toString(t));
  }
  lt(e, t) {
    return this.setLimit("max", e, !1, H.toString(t));
  }
  setLimit(e, t, s, n) {
    return new ws({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind: e,
          value: t,
          inclusive: s,
          message: H.toString(n)
        }
      ]
    });
  }
  _addCheck(e) {
    return new ws({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  int(e) {
    return this._addCheck({
      kind: "int",
      message: H.toString(e)
    });
  }
  positive(e) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: !1,
      message: H.toString(e)
    });
  }
  negative(e) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: !1,
      message: H.toString(e)
    });
  }
  nonpositive(e) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: !0,
      message: H.toString(e)
    });
  }
  nonnegative(e) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: !0,
      message: H.toString(e)
    });
  }
  multipleOf(e, t) {
    return this._addCheck({
      kind: "multipleOf",
      value: e,
      message: H.toString(t)
    });
  }
  finite(e) {
    return this._addCheck({
      kind: "finite",
      message: H.toString(e)
    });
  }
  safe(e) {
    return this._addCheck({
      kind: "min",
      inclusive: !0,
      value: Number.MIN_SAFE_INTEGER,
      message: H.toString(e)
    })._addCheck({
      kind: "max",
      inclusive: !0,
      value: Number.MAX_SAFE_INTEGER,
      message: H.toString(e)
    });
  }
  get minValue() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "min" && (e === null || t.value > e) && (e = t.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "max" && (e === null || t.value < e) && (e = t.value);
    return e;
  }
  get isInt() {
    return !!this._def.checks.find((e) => e.kind === "int" || e.kind === "multipleOf" && ce.isInteger(e.value));
  }
  get isFinite() {
    let e = null, t = null;
    for (const s of this._def.checks) {
      if (s.kind === "finite" || s.kind === "int" || s.kind === "multipleOf")
        return !0;
      s.kind === "min" ? (t === null || s.value > t) && (t = s.value) : s.kind === "max" && (e === null || s.value < e) && (e = s.value);
    }
    return Number.isFinite(t) && Number.isFinite(e);
  }
}
ws.create = (r) => new ws({
  checks: [],
  typeName: Q.ZodNumber,
  coerce: (r == null ? void 0 : r.coerce) || !1,
  ...Z(r)
});
class Fs extends ne {
  constructor() {
    super(...arguments), this.min = this.gte, this.max = this.lte;
  }
  _parse(e) {
    if (this._def.coerce)
      try {
        e.data = BigInt(e.data);
      } catch {
        return this._getInvalidInput(e);
      }
    if (this._getType(e) !== $.bigint)
      return this._getInvalidInput(e);
    let s;
    const n = new et();
    for (const i of this._def.checks)
      i.kind === "min" ? (i.inclusive ? e.data < i.value : e.data <= i.value) && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.too_small,
        type: "bigint",
        minimum: i.value,
        inclusive: i.inclusive,
        message: i.message
      }), n.dirty()) : i.kind === "max" ? (i.inclusive ? e.data > i.value : e.data >= i.value) && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.too_big,
        type: "bigint",
        maximum: i.value,
        inclusive: i.inclusive,
        message: i.message
      }), n.dirty()) : i.kind === "multipleOf" ? e.data % i.value !== BigInt(0) && (s = this._getOrReturnCtx(e, s), F(s, {
        code: U.not_multiple_of,
        multipleOf: i.value,
        message: i.message
      }), n.dirty()) : ce.assertNever(i);
    return { status: n.value, value: e.data };
  }
  _getInvalidInput(e) {
    const t = this._getOrReturnCtx(e);
    return F(t, {
      code: U.invalid_type,
      expected: $.bigint,
      received: t.parsedType
    }), V;
  }
  gte(e, t) {
    return this.setLimit("min", e, !0, H.toString(t));
  }
  gt(e, t) {
    return this.setLimit("min", e, !1, H.toString(t));
  }
  lte(e, t) {
    return this.setLimit("max", e, !0, H.toString(t));
  }
  lt(e, t) {
    return this.setLimit("max", e, !1, H.toString(t));
  }
  setLimit(e, t, s, n) {
    return new Fs({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind: e,
          value: t,
          inclusive: s,
          message: H.toString(n)
        }
      ]
    });
  }
  _addCheck(e) {
    return new Fs({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  positive(e) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: !1,
      message: H.toString(e)
    });
  }
  negative(e) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: !1,
      message: H.toString(e)
    });
  }
  nonpositive(e) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: !0,
      message: H.toString(e)
    });
  }
  nonnegative(e) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: !0,
      message: H.toString(e)
    });
  }
  multipleOf(e, t) {
    return this._addCheck({
      kind: "multipleOf",
      value: e,
      message: H.toString(t)
    });
  }
  get minValue() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "min" && (e === null || t.value > e) && (e = t.value);
    return e;
  }
  get maxValue() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "max" && (e === null || t.value < e) && (e = t.value);
    return e;
  }
}
Fs.create = (r) => new Fs({
  checks: [],
  typeName: Q.ZodBigInt,
  coerce: (r == null ? void 0 : r.coerce) ?? !1,
  ...Z(r)
});
class Nr extends ne {
  _parse(e) {
    if (this._def.coerce && (e.data = !!e.data), this._getType(e) !== $.boolean) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.boolean,
        received: s.parsedType
      }), V;
    }
    return ft(e.data);
  }
}
Nr.create = (r) => new Nr({
  typeName: Q.ZodBoolean,
  coerce: (r == null ? void 0 : r.coerce) || !1,
  ...Z(r)
});
class fn extends ne {
  _parse(e) {
    if (this._def.coerce && (e.data = new Date(e.data)), this._getType(e) !== $.date) {
      const i = this._getOrReturnCtx(e);
      return F(i, {
        code: U.invalid_type,
        expected: $.date,
        received: i.parsedType
      }), V;
    }
    if (Number.isNaN(e.data.getTime())) {
      const i = this._getOrReturnCtx(e);
      return F(i, {
        code: U.invalid_date
      }), V;
    }
    const s = new et();
    let n;
    for (const i of this._def.checks)
      i.kind === "min" ? e.data.getTime() < i.value && (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.too_small,
        message: i.message,
        inclusive: !0,
        exact: !1,
        minimum: i.value,
        type: "date"
      }), s.dirty()) : i.kind === "max" ? e.data.getTime() > i.value && (n = this._getOrReturnCtx(e, n), F(n, {
        code: U.too_big,
        message: i.message,
        inclusive: !0,
        exact: !1,
        maximum: i.value,
        type: "date"
      }), s.dirty()) : ce.assertNever(i);
    return {
      status: s.value,
      value: new Date(e.data.getTime())
    };
  }
  _addCheck(e) {
    return new fn({
      ...this._def,
      checks: [...this._def.checks, e]
    });
  }
  min(e, t) {
    return this._addCheck({
      kind: "min",
      value: e.getTime(),
      message: H.toString(t)
    });
  }
  max(e, t) {
    return this._addCheck({
      kind: "max",
      value: e.getTime(),
      message: H.toString(t)
    });
  }
  get minDate() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "min" && (e === null || t.value > e) && (e = t.value);
    return e != null ? new Date(e) : null;
  }
  get maxDate() {
    let e = null;
    for (const t of this._def.checks)
      t.kind === "max" && (e === null || t.value < e) && (e = t.value);
    return e != null ? new Date(e) : null;
  }
}
fn.create = (r) => new fn({
  checks: [],
  coerce: (r == null ? void 0 : r.coerce) || !1,
  typeName: Q.ZodDate,
  ...Z(r)
});
class pi extends ne {
  _parse(e) {
    if (this._getType(e) !== $.symbol) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.symbol,
        received: s.parsedType
      }), V;
    }
    return ft(e.data);
  }
}
pi.create = (r) => new pi({
  typeName: Q.ZodSymbol,
  ...Z(r)
});
class En extends ne {
  _parse(e) {
    if (this._getType(e) !== $.undefined) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.undefined,
        received: s.parsedType
      }), V;
    }
    return ft(e.data);
  }
}
En.create = (r) => new En({
  typeName: Q.ZodUndefined,
  ...Z(r)
});
class Ir extends ne {
  _parse(e) {
    if (this._getType(e) !== $.null) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.null,
        received: s.parsedType
      }), V;
    }
    return ft(e.data);
  }
}
Ir.create = (r) => new Ir({
  typeName: Q.ZodNull,
  ...Z(r)
});
class yr extends ne {
  constructor() {
    super(...arguments), this._any = !0;
  }
  _parse(e) {
    return ft(e.data);
  }
}
yr.create = (r) => new yr({
  typeName: Q.ZodAny,
  ...Z(r)
});
class Tr extends ne {
  constructor() {
    super(...arguments), this._unknown = !0;
  }
  _parse(e) {
    return ft(e.data);
  }
}
Tr.create = (r) => new Tr({
  typeName: Q.ZodUnknown,
  ...Z(r)
});
class as extends ne {
  _parse(e) {
    const t = this._getOrReturnCtx(e);
    return F(t, {
      code: U.invalid_type,
      expected: $.never,
      received: t.parsedType
    }), V;
  }
}
as.create = (r) => new as({
  typeName: Q.ZodNever,
  ...Z(r)
});
class Ar extends ne {
  _parse(e) {
    if (this._getType(e) !== $.undefined) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.void,
        received: s.parsedType
      }), V;
    }
    return ft(e.data);
  }
}
Ar.create = (r) => new Ar({
  typeName: Q.ZodVoid,
  ...Z(r)
});
class xt extends ne {
  _parse(e) {
    const { ctx: t, status: s } = this._processInputParams(e), n = this._def;
    if (t.parsedType !== $.array)
      return F(t, {
        code: U.invalid_type,
        expected: $.array,
        received: t.parsedType
      }), V;
    if (n.exactLength !== null) {
      const a = t.data.length > n.exactLength.value, o = t.data.length < n.exactLength.value;
      (a || o) && (F(t, {
        code: a ? U.too_big : U.too_small,
        minimum: o ? n.exactLength.value : void 0,
        maximum: a ? n.exactLength.value : void 0,
        type: "array",
        inclusive: !0,
        exact: !0,
        message: n.exactLength.message
      }), s.dirty());
    }
    if (n.minLength !== null && t.data.length < n.minLength.value && (F(t, {
      code: U.too_small,
      minimum: n.minLength.value,
      type: "array",
      inclusive: !0,
      exact: !1,
      message: n.minLength.message
    }), s.dirty()), n.maxLength !== null && t.data.length > n.maxLength.value && (F(t, {
      code: U.too_big,
      maximum: n.maxLength.value,
      type: "array",
      inclusive: !0,
      exact: !1,
      message: n.maxLength.message
    }), s.dirty()), t.common.async)
      return Promise.all([...t.data].map((a, o) => n.type._parseAsync(new Lt(t, a, t.path, o)))).then((a) => et.mergeArray(s, a));
    const i = [...t.data].map((a, o) => n.type._parseSync(new Lt(t, a, t.path, o)));
    return et.mergeArray(s, i);
  }
  get element() {
    return this._def.type;
  }
  min(e, t) {
    return new xt({
      ...this._def,
      minLength: { value: e, message: H.toString(t) }
    });
  }
  max(e, t) {
    return new xt({
      ...this._def,
      maxLength: { value: e, message: H.toString(t) }
    });
  }
  length(e, t) {
    return new xt({
      ...this._def,
      exactLength: { value: e, message: H.toString(t) }
    });
  }
  nonempty(e) {
    return this.min(1, e);
  }
}
xt.create = (r, e) => new xt({
  type: r,
  minLength: null,
  maxLength: null,
  exactLength: null,
  typeName: Q.ZodArray,
  ...Z(e)
});
function Ts(r) {
  if (r instanceof Oe) {
    const e = {};
    for (const t in r.shape) {
      const s = r.shape[t];
      e[t] = Gt.create(Ts(s));
    }
    return new Oe({
      ...r._def,
      shape: () => e
    });
  } else return r instanceof xt ? new xt({
    ...r._def,
    type: Ts(r.element)
  }) : r instanceof Gt ? Gt.create(Ts(r.unwrap())) : r instanceof gs ? gs.create(Ts(r.unwrap())) : r instanceof fs ? fs.create(r.items.map((e) => Ts(e))) : r;
}
class Oe extends ne {
  constructor() {
    super(...arguments), this._cached = null, this.nonstrict = this.passthrough, this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const e = this._def.shape(), t = ce.objectKeys(e);
    return this._cached = { shape: e, keys: t }, this._cached;
  }
  _parse(e) {
    if (this._getType(e) !== $.object) {
      const u = this._getOrReturnCtx(e);
      return F(u, {
        code: U.invalid_type,
        expected: $.object,
        received: u.parsedType
      }), V;
    }
    const { status: s, ctx: n } = this._processInputParams(e), { shape: i, keys: a } = this._getCached(), o = [];
    if (!(this._def.catchall instanceof as && this._def.unknownKeys === "strip"))
      for (const u in n.data)
        a.includes(u) || o.push(u);
    const d = [];
    for (const u of a) {
      const l = i[u], p = n.data[u];
      d.push({
        key: { status: "valid", value: u },
        value: l._parse(new Lt(n, p, n.path, u)),
        alwaysSet: u in n.data
      });
    }
    if (this._def.catchall instanceof as) {
      const u = this._def.unknownKeys;
      if (u === "passthrough")
        for (const l of o)
          d.push({
            key: { status: "valid", value: l },
            value: { status: "valid", value: n.data[l] }
          });
      else if (u === "strict")
        o.length > 0 && (F(n, {
          code: U.unrecognized_keys,
          keys: o
        }), s.dirty());
      else if (u !== "strip") throw new Error("Internal ZodObject error: invalid unknownKeys value.");
    } else {
      const u = this._def.catchall;
      for (const l of o) {
        const p = n.data[l];
        d.push({
          key: { status: "valid", value: l },
          value: u._parse(
            new Lt(n, p, n.path, l)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: l in n.data
        });
      }
    }
    return n.common.async ? Promise.resolve().then(async () => {
      const u = [];
      for (const l of d) {
        const p = await l.key, S = await l.value;
        u.push({
          key: p,
          value: S,
          alwaysSet: l.alwaysSet
        });
      }
      return u;
    }).then((u) => et.mergeObjectSync(s, u)) : et.mergeObjectSync(s, d);
  }
  get shape() {
    return this._def.shape();
  }
  strict(e) {
    return H.errToObj, new Oe({
      ...this._def,
      unknownKeys: "strict",
      ...e !== void 0 ? {
        errorMap: (t, s) => {
          var i, a;
          const n = ((a = (i = this._def).errorMap) == null ? void 0 : a.call(i, t, s).message) ?? s.defaultError;
          return t.code === "unrecognized_keys" ? {
            message: H.errToObj(e).message ?? n
          } : {
            message: n
          };
        }
      } : {}
    });
  }
  strip() {
    return new Oe({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new Oe({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(e) {
    return new Oe({
      ...this._def,
      shape: () => ({
        ...this._def.shape(),
        ...e
      })
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(e) {
    return new Oe({
      unknownKeys: e._def.unknownKeys,
      catchall: e._def.catchall,
      shape: () => ({
        ...this._def.shape(),
        ...e._def.shape()
      }),
      typeName: Q.ZodObject
    });
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(e, t) {
    return this.augment({ [e]: t });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(e) {
    return new Oe({
      ...this._def,
      catchall: e
    });
  }
  pick(e) {
    const t = {};
    for (const s of ce.objectKeys(e))
      e[s] && this.shape[s] && (t[s] = this.shape[s]);
    return new Oe({
      ...this._def,
      shape: () => t
    });
  }
  omit(e) {
    const t = {};
    for (const s of ce.objectKeys(this.shape))
      e[s] || (t[s] = this.shape[s]);
    return new Oe({
      ...this._def,
      shape: () => t
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return Ts(this);
  }
  partial(e) {
    const t = {};
    for (const s of ce.objectKeys(this.shape)) {
      const n = this.shape[s];
      e && !e[s] ? t[s] = n : t[s] = n.optional();
    }
    return new Oe({
      ...this._def,
      shape: () => t
    });
  }
  required(e) {
    const t = {};
    for (const s of ce.objectKeys(this.shape))
      if (e && !e[s])
        t[s] = this.shape[s];
      else {
        let i = this.shape[s];
        for (; i instanceof Gt; )
          i = i._def.innerType;
        t[s] = i;
      }
    return new Oe({
      ...this._def,
      shape: () => t
    });
  }
  keyof() {
    return Mc(ce.objectKeys(this.shape));
  }
}
Oe.create = (r, e) => new Oe({
  shape: () => r,
  unknownKeys: "strip",
  catchall: as.create(),
  typeName: Q.ZodObject,
  ...Z(e)
});
Oe.strictCreate = (r, e) => new Oe({
  shape: () => r,
  unknownKeys: "strict",
  catchall: as.create(),
  typeName: Q.ZodObject,
  ...Z(e)
});
Oe.lazycreate = (r, e) => new Oe({
  shape: r,
  unknownKeys: "strip",
  catchall: as.create(),
  typeName: Q.ZodObject,
  ...Z(e)
});
class Sn extends ne {
  _parse(e) {
    const { ctx: t } = this._processInputParams(e), s = this._def.options;
    function n(i) {
      for (const o of i)
        if (o.result.status === "valid")
          return o.result;
      for (const o of i)
        if (o.result.status === "dirty")
          return t.common.issues.push(...o.ctx.common.issues), o.result;
      const a = i.map((o) => new bt(o.ctx.common.issues));
      return F(t, {
        code: U.invalid_union,
        unionErrors: a
      }), V;
    }
    if (t.common.async)
      return Promise.all(s.map(async (i) => {
        const a = {
          ...t,
          common: {
            ...t.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await i._parseAsync({
            data: t.data,
            path: t.path,
            parent: a
          }),
          ctx: a
        };
      })).then(n);
    {
      let i;
      const a = [];
      for (const d of s) {
        const u = {
          ...t,
          common: {
            ...t.common,
            issues: []
          },
          parent: null
        }, l = d._parseSync({
          data: t.data,
          path: t.path,
          parent: u
        });
        if (l.status === "valid")
          return l;
        l.status === "dirty" && !i && (i = { result: l, ctx: u }), u.common.issues.length && a.push(u.common.issues);
      }
      if (i)
        return t.common.issues.push(...i.ctx.common.issues), i.result;
      const o = a.map((d) => new bt(d));
      return F(t, {
        code: U.invalid_union,
        unionErrors: o
      }), V;
    }
  }
  get options() {
    return this._def.options;
  }
}
Sn.create = (r, e) => new Sn({
  options: r,
  typeName: Q.ZodUnion,
  ...Z(e)
});
const Mt = (r) => r instanceof Nn ? Mt(r.schema) : r instanceof Ss ? Mt(r.innerType()) : r instanceof In ? [r.value] : r instanceof Es ? r.options : r instanceof Dr ? ce.objectValues(r.enum) : r instanceof Tn ? Mt(r._def.innerType) : r instanceof En ? [void 0] : r instanceof Ir ? [null] : r instanceof Gt ? [void 0, ...Mt(r.unwrap())] : r instanceof gs ? [null, ...Mt(r.unwrap())] : r instanceof Fc || r instanceof Rn ? Mt(r.unwrap()) : r instanceof An ? Mt(r._def.innerType) : [];
class qr extends ne {
  _parse(e) {
    const { ctx: t } = this._processInputParams(e);
    if (t.parsedType !== $.object)
      return F(t, {
        code: U.invalid_type,
        expected: $.object,
        received: t.parsedType
      }), V;
    const s = this.discriminator, n = t.data[s], i = this.optionsMap.get(n);
    return i ? t.common.async ? i._parseAsync({
      data: t.data,
      path: t.path,
      parent: t
    }) : i._parseSync({
      data: t.data,
      path: t.path,
      parent: t
    }) : (F(t, {
      code: U.invalid_union_discriminator,
      options: Array.from(this.optionsMap.keys()),
      path: [s]
    }), V);
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(e, t, s) {
    const n = /* @__PURE__ */ new Map();
    for (const i of t) {
      const a = Mt(i.shape[e]);
      if (!a.length)
        throw new Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);
      for (const o of a) {
        if (n.has(o))
          throw new Error(`Discriminator property ${String(e)} has duplicate value ${String(o)}`);
        n.set(o, i);
      }
    }
    return new qr({
      typeName: Q.ZodDiscriminatedUnion,
      discriminator: e,
      options: t,
      optionsMap: n,
      ...Z(s)
    });
  }
}
function Rr(r, e) {
  const t = ts(r), s = ts(e);
  if (r === e)
    return { valid: !0, data: r };
  if (t === $.object && s === $.object) {
    const n = ce.objectKeys(e), i = ce.objectKeys(r).filter((o) => n.indexOf(o) !== -1), a = { ...r, ...e };
    for (const o of i) {
      const d = Rr(r[o], e[o]);
      if (!d.valid)
        return { valid: !1 };
      a[o] = d.data;
    }
    return { valid: !0, data: a };
  } else if (t === $.array && s === $.array) {
    if (r.length !== e.length)
      return { valid: !1 };
    const n = [];
    for (let i = 0; i < r.length; i++) {
      const a = r[i], o = e[i], d = Rr(a, o);
      if (!d.valid)
        return { valid: !1 };
      n.push(d.data);
    }
    return { valid: !0, data: n };
  } else return t === $.date && s === $.date && +r == +e ? { valid: !0, data: r } : { valid: !1 };
}
class gn extends ne {
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e), n = (i, a) => {
      if (li(i) || li(a))
        return V;
      const o = Rr(i.value, a.value);
      return o.valid ? ((hi(i) || hi(a)) && t.dirty(), { status: t.value, value: o.data }) : (F(s, {
        code: U.invalid_intersection_types
      }), V);
    };
    return s.common.async ? Promise.all([
      this._def.left._parseAsync({
        data: s.data,
        path: s.path,
        parent: s
      }),
      this._def.right._parseAsync({
        data: s.data,
        path: s.path,
        parent: s
      })
    ]).then(([i, a]) => n(i, a)) : n(this._def.left._parseSync({
      data: s.data,
      path: s.path,
      parent: s
    }), this._def.right._parseSync({
      data: s.data,
      path: s.path,
      parent: s
    }));
  }
}
gn.create = (r, e, t) => new gn({
  left: r,
  right: e,
  typeName: Q.ZodIntersection,
  ...Z(t)
});
class fs extends ne {
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e);
    if (s.parsedType !== $.array)
      return F(s, {
        code: U.invalid_type,
        expected: $.array,
        received: s.parsedType
      }), V;
    if (s.data.length < this._def.items.length)
      return F(s, {
        code: U.too_small,
        minimum: this._def.items.length,
        inclusive: !0,
        exact: !1,
        type: "array"
      }), V;
    !this._def.rest && s.data.length > this._def.items.length && (F(s, {
      code: U.too_big,
      maximum: this._def.items.length,
      inclusive: !0,
      exact: !1,
      type: "array"
    }), t.dirty());
    const i = [...s.data].map((a, o) => {
      const d = this._def.items[o] || this._def.rest;
      return d ? d._parse(new Lt(s, a, s.path, o)) : null;
    }).filter((a) => !!a);
    return s.common.async ? Promise.all(i).then((a) => et.mergeArray(t, a)) : et.mergeArray(t, i);
  }
  get items() {
    return this._def.items;
  }
  rest(e) {
    return new fs({
      ...this._def,
      rest: e
    });
  }
}
fs.create = (r, e) => {
  if (!Array.isArray(r))
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  return new fs({
    items: r,
    typeName: Q.ZodTuple,
    rest: null,
    ...Z(e)
  });
};
class _n extends ne {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e);
    if (s.parsedType !== $.object)
      return F(s, {
        code: U.invalid_type,
        expected: $.object,
        received: s.parsedType
      }), V;
    const n = [], i = this._def.keyType, a = this._def.valueType;
    for (const o in s.data)
      n.push({
        key: i._parse(new Lt(s, o, s.path, o)),
        value: a._parse(new Lt(s, s.data[o], s.path, o)),
        alwaysSet: o in s.data
      });
    return s.common.async ? et.mergeObjectAsync(t, n) : et.mergeObjectSync(t, n);
  }
  get element() {
    return this._def.valueType;
  }
  static create(e, t, s) {
    return t instanceof ne ? new _n({
      keyType: e,
      valueType: t,
      typeName: Q.ZodRecord,
      ...Z(s)
    }) : new _n({
      keyType: qt.create(),
      valueType: e,
      typeName: Q.ZodRecord,
      ...Z(t)
    });
  }
}
class fi extends ne {
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e);
    if (s.parsedType !== $.map)
      return F(s, {
        code: U.invalid_type,
        expected: $.map,
        received: s.parsedType
      }), V;
    const n = this._def.keyType, i = this._def.valueType, a = [...s.data.entries()].map(([o, d], u) => ({
      key: n._parse(new Lt(s, o, s.path, [u, "key"])),
      value: i._parse(new Lt(s, d, s.path, [u, "value"]))
    }));
    if (s.common.async) {
      const o = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const d of a) {
          const u = await d.key, l = await d.value;
          if (u.status === "aborted" || l.status === "aborted")
            return V;
          (u.status === "dirty" || l.status === "dirty") && t.dirty(), o.set(u.value, l.value);
        }
        return { status: t.value, value: o };
      });
    } else {
      const o = /* @__PURE__ */ new Map();
      for (const d of a) {
        const u = d.key, l = d.value;
        if (u.status === "aborted" || l.status === "aborted")
          return V;
        (u.status === "dirty" || l.status === "dirty") && t.dirty(), o.set(u.value, l.value);
      }
      return { status: t.value, value: o };
    }
  }
}
fi.create = (r, e, t) => new fi({
  valueType: e,
  keyType: r,
  typeName: Q.ZodMap,
  ...Z(t)
});
class $s extends ne {
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e);
    if (s.parsedType !== $.set)
      return F(s, {
        code: U.invalid_type,
        expected: $.set,
        received: s.parsedType
      }), V;
    const n = this._def;
    n.minSize !== null && s.data.size < n.minSize.value && (F(s, {
      code: U.too_small,
      minimum: n.minSize.value,
      type: "set",
      inclusive: !0,
      exact: !1,
      message: n.minSize.message
    }), t.dirty()), n.maxSize !== null && s.data.size > n.maxSize.value && (F(s, {
      code: U.too_big,
      maximum: n.maxSize.value,
      type: "set",
      inclusive: !0,
      exact: !1,
      message: n.maxSize.message
    }), t.dirty());
    const i = this._def.valueType;
    function a(d) {
      const u = /* @__PURE__ */ new Set();
      for (const l of d) {
        if (l.status === "aborted")
          return V;
        l.status === "dirty" && t.dirty(), u.add(l.value);
      }
      return { status: t.value, value: u };
    }
    const o = [...s.data.values()].map((d, u) => i._parse(new Lt(s, d, s.path, u)));
    return s.common.async ? Promise.all(o).then((d) => a(d)) : a(o);
  }
  min(e, t) {
    return new $s({
      ...this._def,
      minSize: { value: e, message: H.toString(t) }
    });
  }
  max(e, t) {
    return new $s({
      ...this._def,
      maxSize: { value: e, message: H.toString(t) }
    });
  }
  size(e, t) {
    return this.min(e, t).max(e, t);
  }
  nonempty(e) {
    return this.min(1, e);
  }
}
$s.create = (r, e) => new $s({
  valueType: r,
  minSize: null,
  maxSize: null,
  typeName: Q.ZodSet,
  ...Z(e)
});
class Nn extends ne {
  get schema() {
    return this._def.getter();
  }
  _parse(e) {
    const { ctx: t } = this._processInputParams(e);
    return this._def.getter()._parse({ data: t.data, path: t.path, parent: t });
  }
}
Nn.create = (r, e) => new Nn({
  getter: r,
  typeName: Q.ZodLazy,
  ...Z(e)
});
class In extends ne {
  _parse(e) {
    if (e.data !== this._def.value) {
      const t = this._getOrReturnCtx(e);
      return F(t, {
        received: t.data,
        code: U.invalid_literal,
        expected: this._def.value
      }), V;
    }
    return { status: "valid", value: e.data };
  }
  get value() {
    return this._def.value;
  }
}
In.create = (r, e) => new In({
  value: r,
  typeName: Q.ZodLiteral,
  ...Z(e)
});
function Mc(r, e) {
  return new Es({
    values: r,
    typeName: Q.ZodEnum,
    ...Z(e)
  });
}
class Es extends ne {
  _parse(e) {
    if (typeof e.data != "string") {
      const t = this._getOrReturnCtx(e), s = this._def.values;
      return F(t, {
        expected: ce.joinValues(s),
        received: t.parsedType,
        code: U.invalid_type
      }), V;
    }
    if (this._cache || (this._cache = new Set(this._def.values)), !this._cache.has(e.data)) {
      const t = this._getOrReturnCtx(e), s = this._def.values;
      return F(t, {
        received: t.data,
        code: U.invalid_enum_value,
        options: s
      }), V;
    }
    return ft(e.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const e = {};
    for (const t of this._def.values)
      e[t] = t;
    return e;
  }
  get Values() {
    const e = {};
    for (const t of this._def.values)
      e[t] = t;
    return e;
  }
  get Enum() {
    const e = {};
    for (const t of this._def.values)
      e[t] = t;
    return e;
  }
  extract(e, t = this._def) {
    return Es.create(e, {
      ...this._def,
      ...t
    });
  }
  exclude(e, t = this._def) {
    return Es.create(this.options.filter((s) => !e.includes(s)), {
      ...this._def,
      ...t
    });
  }
}
Es.create = Mc;
class Dr extends ne {
  _parse(e) {
    const t = ce.getValidEnumValues(this._def.values), s = this._getOrReturnCtx(e);
    if (s.parsedType !== $.string && s.parsedType !== $.number) {
      const n = ce.objectValues(t);
      return F(s, {
        expected: ce.joinValues(n),
        received: s.parsedType,
        code: U.invalid_type
      }), V;
    }
    if (this._cache || (this._cache = new Set(ce.getValidEnumValues(this._def.values))), !this._cache.has(e.data)) {
      const n = ce.objectValues(t);
      return F(s, {
        received: s.data,
        code: U.invalid_enum_value,
        options: n
      }), V;
    }
    return ft(e.data);
  }
  get enum() {
    return this._def.values;
  }
}
Dr.create = (r, e) => new Dr({
  values: r,
  typeName: Q.ZodNativeEnum,
  ...Z(e)
});
class yn extends ne {
  unwrap() {
    return this._def.type;
  }
  _parse(e) {
    const { ctx: t } = this._processInputParams(e);
    if (t.parsedType !== $.promise && t.common.async === !1)
      return F(t, {
        code: U.invalid_type,
        expected: $.promise,
        received: t.parsedType
      }), V;
    const s = t.parsedType === $.promise ? t.data : Promise.resolve(t.data);
    return ft(s.then((n) => this._def.type.parseAsync(n, {
      path: t.path,
      errorMap: t.common.contextualErrorMap
    })));
  }
}
yn.create = (r, e) => new yn({
  type: r,
  typeName: Q.ZodPromise,
  ...Z(e)
});
class Ss extends ne {
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === Q.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e), n = this._def.effect || null, i = {
      addIssue: (a) => {
        F(s, a), a.fatal ? t.abort() : t.dirty();
      },
      get path() {
        return s.path;
      }
    };
    if (i.addIssue = i.addIssue.bind(i), n.type === "preprocess") {
      const a = n.transform(s.data, i);
      if (s.common.async)
        return Promise.resolve(a).then(async (o) => {
          if (t.value === "aborted")
            return V;
          const d = await this._def.schema._parseAsync({
            data: o,
            path: s.path,
            parent: s
          });
          return d.status === "aborted" ? V : d.status === "dirty" || t.value === "dirty" ? Ls(d.value) : d;
        });
      {
        if (t.value === "aborted")
          return V;
        const o = this._def.schema._parseSync({
          data: a,
          path: s.path,
          parent: s
        });
        return o.status === "aborted" ? V : o.status === "dirty" || t.value === "dirty" ? Ls(o.value) : o;
      }
    }
    if (n.type === "refinement") {
      const a = (o) => {
        const d = n.refinement(o, i);
        if (s.common.async)
          return Promise.resolve(d);
        if (d instanceof Promise)
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        return o;
      };
      if (s.common.async === !1) {
        const o = this._def.schema._parseSync({
          data: s.data,
          path: s.path,
          parent: s
        });
        return o.status === "aborted" ? V : (o.status === "dirty" && t.dirty(), a(o.value), { status: t.value, value: o.value });
      } else
        return this._def.schema._parseAsync({ data: s.data, path: s.path, parent: s }).then((o) => o.status === "aborted" ? V : (o.status === "dirty" && t.dirty(), a(o.value).then(() => ({ status: t.value, value: o.value }))));
    }
    if (n.type === "transform")
      if (s.common.async === !1) {
        const a = this._def.schema._parseSync({
          data: s.data,
          path: s.path,
          parent: s
        });
        if (!Os(a))
          return V;
        const o = n.transform(a.value, i);
        if (o instanceof Promise)
          throw new Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");
        return { status: t.value, value: o };
      } else
        return this._def.schema._parseAsync({ data: s.data, path: s.path, parent: s }).then((a) => Os(a) ? Promise.resolve(n.transform(a.value, i)).then((o) => ({
          status: t.value,
          value: o
        })) : V);
    ce.assertNever(n);
  }
}
Ss.create = (r, e, t) => new Ss({
  schema: r,
  typeName: Q.ZodEffects,
  effect: e,
  ...Z(t)
});
Ss.createWithPreprocess = (r, e, t) => new Ss({
  schema: e,
  effect: { type: "preprocess", transform: r },
  typeName: Q.ZodEffects,
  ...Z(t)
});
class Gt extends ne {
  _parse(e) {
    return this._getType(e) === $.undefined ? ft(void 0) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
}
Gt.create = (r, e) => new Gt({
  innerType: r,
  typeName: Q.ZodOptional,
  ...Z(e)
});
class gs extends ne {
  _parse(e) {
    return this._getType(e) === $.null ? ft(null) : this._def.innerType._parse(e);
  }
  unwrap() {
    return this._def.innerType;
  }
}
gs.create = (r, e) => new gs({
  innerType: r,
  typeName: Q.ZodNullable,
  ...Z(e)
});
class Tn extends ne {
  _parse(e) {
    const { ctx: t } = this._processInputParams(e);
    let s = t.data;
    return t.parsedType === $.undefined && (s = this._def.defaultValue()), this._def.innerType._parse({
      data: s,
      path: t.path,
      parent: t
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
}
Tn.create = (r, e) => new Tn({
  innerType: r,
  typeName: Q.ZodDefault,
  defaultValue: typeof e.default == "function" ? e.default : () => e.default,
  ...Z(e)
});
class An extends ne {
  _parse(e) {
    const { ctx: t } = this._processInputParams(e), s = {
      ...t,
      common: {
        ...t.common,
        issues: []
      }
    }, n = this._def.innerType._parse({
      data: s.data,
      path: s.path,
      parent: {
        ...s
      }
    });
    return pn(n) ? n.then((i) => ({
      status: "valid",
      value: i.status === "valid" ? i.value : this._def.catchValue({
        get error() {
          return new bt(s.common.issues);
        },
        input: s.data
      })
    })) : {
      status: "valid",
      value: n.status === "valid" ? n.value : this._def.catchValue({
        get error() {
          return new bt(s.common.issues);
        },
        input: s.data
      })
    };
  }
  removeCatch() {
    return this._def.innerType;
  }
}
An.create = (r, e) => new An({
  innerType: r,
  typeName: Q.ZodCatch,
  catchValue: typeof e.catch == "function" ? e.catch : () => e.catch,
  ...Z(e)
});
class Ei extends ne {
  _parse(e) {
    if (this._getType(e) !== $.nan) {
      const s = this._getOrReturnCtx(e);
      return F(s, {
        code: U.invalid_type,
        expected: $.nan,
        received: s.parsedType
      }), V;
    }
    return { status: "valid", value: e.data };
  }
}
Ei.create = (r) => new Ei({
  typeName: Q.ZodNaN,
  ...Z(r)
});
class Fc extends ne {
  _parse(e) {
    const { ctx: t } = this._processInputParams(e), s = t.data;
    return this._def.type._parse({
      data: s,
      path: t.path,
      parent: t
    });
  }
  unwrap() {
    return this._def.type;
  }
}
class Hr extends ne {
  _parse(e) {
    const { status: t, ctx: s } = this._processInputParams(e);
    if (s.common.async)
      return (async () => {
        const i = await this._def.in._parseAsync({
          data: s.data,
          path: s.path,
          parent: s
        });
        return i.status === "aborted" ? V : i.status === "dirty" ? (t.dirty(), Ls(i.value)) : this._def.out._parseAsync({
          data: i.value,
          path: s.path,
          parent: s
        });
      })();
    {
      const n = this._def.in._parseSync({
        data: s.data,
        path: s.path,
        parent: s
      });
      return n.status === "aborted" ? V : n.status === "dirty" ? (t.dirty(), {
        status: "dirty",
        value: n.value
      }) : this._def.out._parseSync({
        data: n.value,
        path: s.path,
        parent: s
      });
    }
  }
  static create(e, t) {
    return new Hr({
      in: e,
      out: t,
      typeName: Q.ZodPipeline
    });
  }
}
class Rn extends ne {
  _parse(e) {
    const t = this._def.innerType._parse(e), s = (n) => (Os(n) && (n.value = Object.freeze(n.value)), n);
    return pn(t) ? t.then((n) => s(n)) : s(t);
  }
  unwrap() {
    return this._def.innerType;
  }
}
Rn.create = (r, e) => new Rn({
  innerType: r,
  typeName: Q.ZodReadonly,
  ...Z(e)
});
var Q;
(function(r) {
  r.ZodString = "ZodString", r.ZodNumber = "ZodNumber", r.ZodNaN = "ZodNaN", r.ZodBigInt = "ZodBigInt", r.ZodBoolean = "ZodBoolean", r.ZodDate = "ZodDate", r.ZodSymbol = "ZodSymbol", r.ZodUndefined = "ZodUndefined", r.ZodNull = "ZodNull", r.ZodAny = "ZodAny", r.ZodUnknown = "ZodUnknown", r.ZodNever = "ZodNever", r.ZodVoid = "ZodVoid", r.ZodArray = "ZodArray", r.ZodObject = "ZodObject", r.ZodUnion = "ZodUnion", r.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", r.ZodIntersection = "ZodIntersection", r.ZodTuple = "ZodTuple", r.ZodRecord = "ZodRecord", r.ZodMap = "ZodMap", r.ZodSet = "ZodSet", r.ZodFunction = "ZodFunction", r.ZodLazy = "ZodLazy", r.ZodLiteral = "ZodLiteral", r.ZodEnum = "ZodEnum", r.ZodEffects = "ZodEffects", r.ZodNativeEnum = "ZodNativeEnum", r.ZodOptional = "ZodOptional", r.ZodNullable = "ZodNullable", r.ZodDefault = "ZodDefault", r.ZodCatch = "ZodCatch", r.ZodPromise = "ZodPromise", r.ZodBranded = "ZodBranded", r.ZodPipeline = "ZodPipeline", r.ZodReadonly = "ZodReadonly";
})(Q || (Q = {}));
const c = qt.create, D = ws.create, Nt = Nr.create, Bh = En.create, Mh = yr.create, Ys = Tr.create;
as.create;
const Fh = Ar.create, J = xt.create, T = Oe.create, $h = Sn.create, $c = qr.create;
gn.create;
fs.create;
const qs = _n.create, qh = Nn.create, Qe = In.create, j = Es.create;
yn.create;
Gt.create;
gs.create;
const yt = j(["GENERAL", "EGYPTIAN_BACCALAUREATE"]), ot = j([
  "PREP_1",
  "PREP_2",
  "PREP_3",
  "SEC_1",
  "SEC_2",
  "SEC_3"
]), $e = j(["ARABIC", "LANG_ENGLISH"]), Js = j([
  "GENERAL_MATH",
  "ALGEBRA",
  "GEOMETRY",
  "TRIGONOMETRY",
  "CALCULUS",
  "STATISTICS",
  "APPLIED_MATH"
]), Gr = j(["OWNER", "ASSISTANT"]), Hh = j(["USER", "SYSTEM"]), Yr = j([
  "STUDENTS_READ",
  "STUDENTS_WRITE",
  "GROUPS_READ",
  "GROUPS_WRITE",
  "SESSIONS_MANAGE",
  "ATTENDANCE_WRITE",
  "PAYMENTS_READ",
  "PAYMENTS_WRITE",
  "REPORTS_READ",
  "SETTINGS_WRITE",
  "USERS_MANAGE",
  "BACKUP_MANAGE"
]), Vs = j(["MONTHLY", "PER_SESSION"]), Jr = j([
  "CASH",
  "BANK_TRANSFER",
  "VODAFONE_CASH",
  "INSTAPAY",
  "OTHER"
]), qc = j(["FIXED_AMOUNT", "PERCENTAGE"]), Gh = j([
  "DRAFT",
  "UNPAID",
  "PARTIALLY_PAID",
  "PAID",
  "VOID"
]), Hc = j([
  "SESSION_FEE",
  "MONTHLY_SUBSCRIPTION",
  "MATERIAL_FEE",
  "CUSTOM"
]), Yh = j([
  "PAID",
  "PARTIALLY_PAID",
  "UNPAID",
  "OVERDUE"
]), Vr = j(["ACTIVE", "INACTIVE"]), Jh = j([
  "GENERAL",
  "ACADEMIC_WEAKNESS",
  "EXCELLENT",
  "BEHAVIOR",
  "NEEDS_FOLLOW_UP"
]), Vh = j([
  "SCHEDULED",
  "COMPLETED",
  "RESCHEDULED",
  "CANCELLED_BY_TEACHER"
]), Qh = $h([
  Qe(0),
  Qe(1),
  Qe(2),
  Qe(3),
  Qe(4),
  Qe(5),
  Qe(6)
]), Fn = j([
  "PRESENT",
  "ABSENT",
  "LATE",
  "EXCUSED"
]), Qr = j([
  "UNCONTACTED",
  "CONTACTED",
  "UNREACHABLE"
]), Gc = j(["DRAFT", "PUBLISHED", "ARCHIVED"]), Yc = j(["UNIT", "LESSON", "CONCEPT", "SKILL"]), Jc = j(["NOT_STARTED", "IN_PROGRESS", "COMPLETED"]), Kh = j([
  "INSUFFICIENT_DATA",
  "COMPLETED",
  "ON_TRACK",
  "UNREALISTIC_PACING"
]), $n = j(["DRAFT", "READY", "ARCHIVED"]), Kr = j([
  "COMPLETED",
  "PARTIALLY_COMPLETED",
  "POSTPONED"
]), jh = j(["INDEXED", "PROCESSING", "ERROR"]), Vt = j([
  "MULTIPLE_CHOICE",
  "ESSAY",
  "SHORT_ANSWER",
  "TRUE_FALSE"
]), Qt = j([
  "EASY",
  "MEDIUM",
  "HARD",
  "ADVANCED"
]), qn = j(["DRAFT", "ACTIVE", "ARCHIVED"]), Xh = /^\d{4}$/, jr = /^(?:\+20|0020)?0?1[0125]\d{8}$/, Qs = /^(?:[01]\d|2[0-3]):[0-5]\d$/, Zh = /^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$/;
function Vc(r) {
  if (!Zh.test(r))
    return !1;
  const e = r.split("-"), t = parseInt(e[0], 10), s = parseInt(e[1], 10), n = parseInt(e[2], 10), i = new Date(Date.UTC(t, s - 1, n));
  return i.getUTCFullYear() === t && i.getUTCMonth() === s - 1 && i.getUTCDate() === n;
}
const Hs = c().trim().refine(Vc, {
  message: "Invalid calendar date. Must be an existing calendar date in YYYY-MM-DD format (e.g. 2026-10-15)"
});
function Qc(r) {
  const e = r.trim().replace(/[\s-]/g, "");
  if (!e.match(jr))
    throw new Error(`Invalid Egyptian mobile number: ${r}`);
  const s = e.replace(/^(?:\+20|0020)/, "");
  return s.startsWith("0") ? s : `0${s}`;
}
function Wh(r) {
  return { success: !0, data: r };
}
function Ue(r, e, t) {
  return { success: !1, error: { code: r, message: e, details: t } };
}
const ss = c().trim().regex(Xh, "PIN must be exactly 4 numeric digits"), Kc = T({
  userId: c().uuid("Invalid user ID format"),
  pin: ss
}), em = T({
  fullName: c().trim().min(1, "Full name cannot be empty"),
  username: c().trim().min(3, "Username must be at least 3 characters").toLowerCase(),
  pin: ss
}), jc = T({
  fullName: c().trim().min(1, "Full name cannot be empty"),
  username: c().trim().min(3, "Username must be at least 3 characters").toLowerCase(),
  pin: ss,
  role: Gr,
  permissions: J(Yr).default([])
}), Xc = T({
  userId: c().uuid("Invalid user ID format"),
  permissions: J(Yr)
}), Zc = T({
  userId: c().uuid("Invalid user ID format"),
  status: j(["ACTIVE", "INACTIVE"])
}), Wc = T({
  userId: c().uuid("Invalid user ID format"),
  newPin: ss
});
T({
  id: c().uuid("Invalid user ID format"),
  fullName: c().min(1, "Full name cannot be empty"),
  username: c().min(3, "Username must be at least 3 characters"),
  role: Gr
});
T({
  id: c().uuid("Invalid user ID format"),
  fullName: c().min(1, "Full name cannot be empty"),
  username: c().min(3, "Username must be at least 3 characters"),
  role: Gr,
  status: j(["ACTIVE", "INACTIVE"]),
  permissions: J(Yr),
  createdAt: c(),
  updatedAt: c()
});
const Hn = c().trim().regex(
  jr,
  "Invalid Egyptian mobile number. Must be 11 digits starting with 010, 011, 012, or 015 (e.g. 01012345678 or +201012345678)"
).transform((r) => Qc(r)), tm = T({
  fullName: c().trim().min(1, "Full name cannot be empty"),
  educationSystem: yt,
  gradeLevel: ot,
  languageTrack: $e,
  guardianPhone: Hn,
  photoPath: c().trim().nullable().optional().default(null),
  initialNote: c().trim().optional()
}), sm = T({
  fullName: c().trim().min(1, "Full name cannot be empty"),
  educationSystem: yt,
  gradeLevel: ot,
  languageTrack: $e,
  guardianPhone: Hn,
  photoToken: c().trim().uuid("Invalid photo token format").nullable().optional(),
  initialNote: c().trim().optional()
}).passthrough().refine((r) => !("photoPath" in r), {
  message: "photoPath is not permitted in renderer requests. Use photoToken."
}), nm = T({
  studentId: c().uuid("Invalid student ID format"),
  fullName: c().trim().min(1, "Full name cannot be empty").optional(),
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  guardianPhone: Hn.optional(),
  photoPath: c().trim().nullable().optional(),
  status: Vr.optional()
}), rm = T({
  studentId: c().uuid("Invalid student ID format"),
  fullName: c().trim().min(1, "Full name cannot be empty").optional(),
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  guardianPhone: Hn.optional(),
  photoToken: c().trim().uuid("Invalid photo token format").nullable().optional(),
  status: Vr.optional()
}).passthrough().refine((r) => !("photoPath" in r), {
  message: "photoPath is not permitted in renderer requests. Use photoToken."
}), eu = T({
  studentId: c().uuid("Invalid student ID format"),
  noteText: c().trim().min(1, "Note text cannot be empty"),
  tag: Jh.default("GENERAL")
}), tu = T({
  searchQuery: c().trim().optional(),
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  status: Vr.optional(),
  groupId: c().uuid().optional()
}), su = T({
  id: c().uuid().optional(),
  weekday: Qh,
  startTime: c().trim().regex(Qs, "Start time must be in 24-hour format (HH:mm)"),
  durationMinutes: D().int("Duration must be an integer").positive("Duration must be greater than 0 minutes").default(120)
}), nu = T({
  name: c().trim().min(1, "Group name cannot be empty"),
  educationSystem: yt,
  gradeLevel: ot,
  languageTrack: $e,
  focusMathBranch: Js.nullable().optional().default(null),
  defaultPaymentType: Vs,
  defaultPaymentAmount: D().nonnegative("Default payment amount cannot be negative"),
  schedules: J(su).default([])
}), ru = T({
  groupId: c().uuid("Invalid group ID format"),
  name: c().trim().min(1, "Group name cannot be empty").optional(),
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  focusMathBranch: Js.nullable().optional(),
  defaultPaymentType: Vs.optional(),
  defaultPaymentAmount: D().nonnegative("Default payment amount cannot be negative").optional(),
  status: j(["ACTIVE", "ARCHIVED"]).optional()
}), iu = T({
  groupId: c().uuid("Invalid group ID format"),
  slots: J(su)
}), au = T({
  groupId: c().uuid("Invalid group ID format"),
  studentId: c().uuid("Invalid student ID format"),
  paymentTypeOverride: Vs.nullable().optional().default(null),
  paymentAmountOverride: D().nonnegative("Payment override amount cannot be negative").nullable().optional().default(null)
}), ou = T({
  enrollmentId: c().uuid("Invalid enrollment ID format"),
  paymentTypeOverride: Vs.nullable().optional(),
  paymentAmountOverride: D().nonnegative("Payment override amount cannot be negative").nullable().optional()
}), du = T({
  enrollmentId: c().uuid("Invalid enrollment ID format"),
  reason: c().trim().optional()
}), cu = T({
  sessionId: c().uuid("Invalid session ID format"),
  newEffectiveDate: Hs,
  newEffectiveStartTime: c().trim().regex(Qs, "Start time must be in 24-hour format (HH:mm)"),
  reason: c().trim().min(1, "Reschedule reason is required")
}), uu = T({
  sessionId: c().uuid("Invalid session ID format"),
  reason: c().trim().min(1, "Cancellation reason is required")
}), lu = T({
  startDate: Hs,
  endDate: Hs,
  groupId: c().uuid().optional()
}), im = T({
  id: c().uuid(),
  groupId: c().uuid(),
  groupName: c(),
  scheduleId: c().uuid().nullable().optional(),
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  // Immutable occurrence identity
  occurrenceKey: c(),
  scheduledDate: c(),
  // YYYY-MM-DD
  scheduledStartTime: c(),
  // HH:mm
  // Mutable effective execution slot (used for Today Dashboard & scheduling views)
  effectiveDate: c(),
  // YYYY-MM-DD
  effectiveStartTime: c(),
  // HH:mm
  durationMinutes: D(),
  status: Vh,
  rescheduleReason: c().nullable(),
  rescheduledAt: c().nullable().optional(),
  cancellationReason: c().nullable().optional(),
  notes: c().nullable(),
  studentCount: D().optional(),
  createdAt: c(),
  updatedAt: c()
}), hu = T({
  actorNameSnapshot: c().trim().min(1, "Actor name snapshot cannot be empty"),
  action: c().trim().min(1, "Action cannot be empty"),
  entityType: c().trim().min(1, "Entity type cannot be empty"),
  entityId: c().trim().min(1, "Entity ID cannot be empty"),
  beforeJson: c().nullable().optional().default(null),
  afterJson: c().nullable().optional().default(null),
  metadataJson: c().nullable().optional().default(null)
}), am = hu.extend({
  actorType: Qe("USER"),
  actorUserId: c().uuid("Invalid actor user ID for USER actor")
}), om = hu.extend({
  actorType: Qe("SYSTEM"),
  actorUserId: Qe(null).default(null)
});
$c("actorType", [
  am,
  om
]);
T({
  entityType: c().trim().optional(),
  entityId: c().trim().optional(),
  actorUserId: c().uuid().optional(),
  actorType: Hh.optional(),
  limit: D().int().positive().max(500).default(50),
  offset: D().int().nonnegative().default(0)
});
const dm = T({
  reason: c().trim().optional()
}), cm = T({
  name: c().trim().regex(/^\d{4}-\d{4}$/, "Academic year must be in format YYYY-YYYY (e.g. 2026-2027)")
}).refine(
  (r) => {
    const e = r.name.split("-"), t = parseInt(e[0], 10);
    return parseInt(e[1], 10) === t + 1;
  },
  {
    message: "Ending year must equal starting year + 1 (e.g. 2026-2027)",
    path: ["name"]
  }
), um = T({
  academicYearId: c().uuid("Invalid academic year ID format")
}), lm = T({
  theme: j(["light", "dark", "system"])
}), hm = T({
  phone: c().trim().regex(
    jr,
    "Invalid Egyptian mobile number. Must be 11 digits starting with 010, 011, 012, or 015 (e.g. 01012345678 or +201012345678)"
  ).transform((r) => Qc(r)),
  message: c().min(1, "Message cannot be empty").max(2e3, "Message too long")
}), mm = T({
  id: c().uuid(),
  sessionId: c().uuid(),
  studentId: c().uuid(),
  status: Fn,
  arrivalTime: c().regex(Qs, "Invalid arrival time format (HH:mm 00:00-23:59)").nullable(),
  notes: c().max(1e3).nullable(),
  recordedByUserId: c().nullable(),
  recordedAt: c().datetime(),
  updatedAt: c().datetime()
}), pm = T({
  studentId: c().uuid(),
  studentCode: c().min(1),
  studentName: c().min(1),
  photoUrl: c().nullable(),
  enrollmentId: c().uuid(),
  attendanceRecord: mm.nullable()
});
T({
  session: im,
  groupName: c().min(1),
  roster: J(pm),
  summary: T({
    totalStudents: D().int().nonnegative(),
    present: D().int().nonnegative(),
    absent: D().int().nonnegative(),
    late: D().int().nonnegative(),
    excused: D().int().nonnegative(),
    unmarked: D().int().nonnegative()
  })
});
const mu = T({
  sessionId: c().uuid(),
  studentId: c().uuid(),
  status: Fn,
  arrivalTime: c().regex(Qs, "Invalid arrival time format (HH:mm 00:00-23:59)").nullish(),
  notes: c().max(1e3).nullish()
}).refine((r) => r.status === "LATE" ? typeof r.arrivalTime == "string" && r.arrivalTime.trim().length > 0 : !0, {
  message: "Arrival time is required when status is LATE",
  path: ["arrivalTime"]
}).refine((r) => !((r.status === "ABSENT" || r.status === "EXCUSED") && r.arrivalTime != null), {
  message: "Arrival time must be null for ABSENT or EXCUSED status",
  path: ["arrivalTime"]
}), fm = T({
  studentId: c().uuid(),
  status: Fn,
  arrivalTime: c().regex(Qs, "Invalid arrival time format (HH:mm 00:00-23:59)").nullish(),
  notes: c().max(1e3).nullish()
}).refine((r) => r.status === "LATE" ? typeof r.arrivalTime == "string" && r.arrivalTime.trim().length > 0 : !0, {
  message: "Arrival time is required when status is LATE",
  path: ["arrivalTime"]
}).refine((r) => !((r.status === "ABSENT" || r.status === "EXCUSED") && r.arrivalTime != null), {
  message: "Arrival time must be null for ABSENT or EXCUSED status",
  path: ["arrivalTime"]
}), pu = T({
  sessionId: c().uuid(),
  records: J(fm).min(1, "At least one record is required")
}).refine((r) => {
  const e = r.records.map((t) => t.studentId);
  return new Set(e).size === e.length;
}, {
  message: "Duplicate studentId detected in batch attendance records",
  path: ["records"]
}), fu = T({
  sessionId: c().uuid(),
  notes: c().max(1e3).nullish()
}), Em = T({
  attendanceRecordId: c().uuid().optional(),
  studentId: c().uuid(),
  studentName: c().min(1),
  guardianPhone: c().min(1),
  sessionId: c().uuid(),
  groupName: c().min(1),
  status: Fn,
  sessionDate: c(),
  sessionStartTime: c(),
  whatsappMessage: c(),
  contactStatus: Qr.default("UNCONTACTED"),
  contactedAt: c().nullable().optional().default(null),
  contactedByUserId: c().nullable().optional().default(null),
  contactNote: c().nullable().optional().default(null)
});
T({
  date: c(),
  totalSessions: D().int().nonnegative(),
  totalAbsent: D().int().nonnegative(),
  totalLate: D().int().nonnegative(),
  followUps: J(Em)
});
T({
  id: c().uuid(),
  attendanceRecordId: c().uuid(),
  contactStatus: Qr,
  note: c().nullable(),
  contactedAt: c().nullable(),
  contactedByUserId: c().nullable(),
  createdAt: c(),
  updatedAt: c()
});
const Eu = T({
  attendanceRecordId: c().uuid(),
  contactStatus: Qr,
  note: c().max(1e3).nullish()
}), Sm = T({
  id: c().uuid(),
  receiptNumber: c(),
  studentId: c().uuid(),
  studentName: c().optional(),
  studentCode: c().optional(),
  groupId: c().uuid().nullable().optional(),
  groupName: c().optional(),
  amountCents: D().int().positive(),
  paymentMethod: Jr,
  paymentDate: c(),
  // YYYY-MM-DD
  periodMonth: c().nullable().optional(),
  // YYYY-MM
  notes: c().nullable().optional(),
  recordedByUserId: c(),
  createdAt: c(),
  updatedAt: c()
}), gm = T({
  studentId: c().uuid(),
  groupId: c().uuid().nullable().optional(),
  amountCents: D().int().positive({ message: "المبلغ يجب أن يكون أكبر من صفر" }),
  paymentMethod: Jr.default("CASH"),
  paymentDate: c().regex(/^\d{4}-\d{2}-\d{2}$/, { message: "صيغة التاريخ غير صالحة YYYY-MM-DD" }),
  periodMonth: c().regex(/^\d{4}-\d{2}$/, { message: "صيغة الشهر غير صالحة YYYY-MM" }).nullable().optional(),
  notes: c().max(500).optional()
});
T({
  id: c().uuid(),
  studentId: c().uuid(),
  groupId: c().uuid().nullable().optional(),
  groupName: c().optional(),
  discountType: qc,
  discountValue: D().int().positive(),
  reason: c(),
  status: j(["ACTIVE", "INACTIVE"]),
  appliedByUserId: c().nullable().optional(),
  createdAt: c(),
  updatedAt: c()
});
const _m = T({
  studentId: c().uuid(),
  groupId: c().uuid().nullable().optional(),
  discountType: qc,
  discountValue: D().int().positive({ message: "قيمة الخصم يجب أن تكون أكبر من صفر" }),
  reason: c().min(2, { message: "سبب الخصم مطلوب" }).max(200)
}).refine(
  (r) => r.discountType === "PERCENTAGE" ? r.discountValue >= 1 && r.discountValue <= 100 : !0,
  { message: "نسبة الخصم يجب أن تكون بين 1% و 100%", path: ["discountValue"] }
), Nm = T({
  id: c().uuid(),
  invoiceId: c().uuid(),
  description: c(),
  itemType: Hc,
  quantity: D().int().positive(),
  unitPriceCents: D().int().nonnegative(),
  amountCents: D().int().nonnegative(),
  sessionId: c().uuid().nullable().optional()
});
T({
  id: c().uuid(),
  invoiceNumber: c(),
  studentId: c().uuid(),
  studentName: c().optional(),
  studentCode: c().optional(),
  groupId: c().uuid().nullable().optional(),
  groupName: c().optional(),
  issueDate: c(),
  dueDate: c().nullable().optional(),
  periodMonth: c().nullable().optional(),
  subtotalCents: D().int().nonnegative(),
  discountCents: D().int().nonnegative(),
  totalCents: D().int().nonnegative(),
  paidCents: D().int().nonnegative(),
  remainingCents: D().int().nonnegative(),
  status: Gh,
  notes: c().nullable().optional(),
  items: J(Nm),
  createdAt: c(),
  updatedAt: c()
});
const Im = T({
  studentId: c().uuid(),
  groupId: c().uuid().nullable().optional(),
  issueDate: c().regex(/^\d{4}-\d{2}-\d{2}$/),
  dueDate: c().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  periodMonth: c().regex(/^\d{4}-\d{2}$/).nullable().optional(),
  notes: c().max(500).optional(),
  items: J(
    T({
      description: c().min(1),
      itemType: Hc.default("CUSTOM"),
      quantity: D().int().positive().default(1),
      unitPriceCents: D().int().nonnegative(),
      sessionId: c().uuid().nullable().optional()
    })
  ).min(1, { message: "يجب إضافة بند واحد على الأقل في الفاتورة" }),
  discountCents: D().int().nonnegative().default(0)
}), ym = T({
  groupId: c().uuid(),
  groupName: c(),
  paymentType: Vs,
  rateCents: D().int().nonnegative(),
  enrolledAt: c(),
  sessionsCount: D().int().nonnegative().optional(),
  monthsCount: D().int().nonnegative().optional(),
  totalChargeCents: D().int().nonnegative(),
  totalPaidCents: D().int().nonnegative(),
  balanceCents: D().int().nonnegative()
});
T({
  studentId: c().uuid(),
  studentName: c(),
  studentCode: c(),
  guardianPhone: c().optional(),
  gradeLevel: c().optional(),
  totalChargesCents: D().int().nonnegative(),
  totalDiscountsCents: D().int().nonnegative(),
  netPayableCents: D().int().nonnegative(),
  totalPaidCents: D().int().nonnegative(),
  remainingBalanceCents: D().int().nonnegative(),
  status: Yh,
  subscriptions: J(ym),
  recentPayments: J(Sm)
});
T({
  totalChargesCents: D().int().nonnegative(),
  totalCollectedCents: D().int().nonnegative(),
  totalOutstandingCents: D().int().nonnegative(),
  totalDiscountsCents: D().int().nonnegative(),
  activeStudentsCount: D().int().nonnegative(),
  paidStudentsCount: D().int().nonnegative(),
  unpaidStudentsCount: D().int().nonnegative()
});
const Xr = j(["80mm", "58mm"]), Tm = j(["SYSTEM_DRIVER", "ESCPOS_NETWORK", "ESCPOS_RAW"]);
T({
  name: c(),
  displayName: c(),
  description: c(),
  status: D(),
  isDefault: Nt()
});
const Su = T({
  printerName: c().optional(),
  paperWidth: Xr.default("80mm"),
  printMethod: Tm.default("SYSTEM_DRIVER"),
  networkHost: c().optional(),
  networkPort: D().int().positive().default(9100).optional(),
  autoCut: Nt().default(!0),
  copies: D().int().min(1).max(5).default(1)
}), Am = T({
  paymentId: c().uuid(),
  receiptNumber: c(),
  studentId: c().uuid(),
  studentName: c(),
  studentCode: c(),
  gradeLevel: c().optional(),
  gradeLevelNameAr: c().optional(),
  groupName: c().optional(),
  amountCents: D().int().positive(),
  amountFormatted: c(),
  paymentMethod: Jr,
  paymentMethodNameAr: c(),
  paymentDate: c(),
  periodMonth: c().nullable().optional(),
  remainingBalanceCents: D().int().nonnegative().optional(),
  remainingBalanceFormatted: c().optional(),
  teacherName: c(),
  operatorName: c(),
  notes: c().nullable().optional(),
  issuedAt: c(),
  isTestReceipt: Nt().optional()
}), Rm = T({
  paymentId: c().uuid(),
  settings: Su.optional()
}), Dm = T({
  settings: Su.optional(),
  paperWidth: Xr.default("80mm").optional()
}), Om = T({
  receipt: Am,
  paperWidth: Xr.default("80mm"),
  autoCut: Nt().default(!0)
}), wm = T({
  host: c().min(1, "Host address is required"),
  port: D().int().min(1).max(65535).default(9100),
  payloadBase64: c().min(1, "Payload is required")
}), vm = T({
  id: c().uuid(),
  code: c().min(1).max(64),
  title: c().min(1).max(255),
  educationSystem: yt,
  gradeLevel: ot,
  languageTrack: $e,
  mathBranch: Js.nullable(),
  version: D().int().min(1),
  status: Gc,
  publishedAt: c().nullable(),
  description: c().nullable(),
  createdAt: c(),
  updatedAt: c()
}), gu = T({
  code: c().min(1).max(64).regex(/^[a-zA-Z0-9_-]+$/, "Code must contain only alphanumeric characters, dashes, and underscores"),
  title: c().min(1).max(255),
  educationSystem: yt,
  gradeLevel: ot,
  languageTrack: $e,
  mathBranch: Js.optional().nullable(),
  description: c().max(1e3).optional().nullable()
}), _u = T({
  title: c().min(1).max(255).optional(),
  description: c().max(1e3).optional().nullable()
}), Cm = T({
  educationSystem: yt.optional(),
  gradeLevel: ot.optional(),
  languageTrack: $e.optional(),
  mathBranch: Js.optional().nullable(),
  status: Gc.optional(),
  search: c().optional()
}), Um = T({
  id: c().uuid(),
  catalogId: c().uuid(),
  parentId: c().uuid().nullable(),
  tier: Yc,
  titleAr: c().min(1).max(255),
  titleEn: c().max(255).nullable(),
  code: c().min(1).max(64),
  orderIndex: D().int().min(0),
  description: c().nullable(),
  metadataJson: c().nullable(),
  createdAt: c(),
  updatedAt: c()
}), Nu = T({
  catalogId: c().uuid(),
  parentId: c().uuid().optional().nullable(),
  tier: Yc,
  titleAr: c().min(1).max(255),
  titleEn: c().max(255).optional().nullable(),
  code: c().min(1).max(64),
  orderIndex: D().int().min(0).optional(),
  description: c().max(2e3).optional().nullable(),
  metadataJson: c().optional().nullable()
}), Iu = T({
  titleAr: c().min(1).max(255).optional(),
  titleEn: c().max(255).optional().nullable(),
  code: c().min(1).max(64).optional(),
  orderIndex: D().int().min(0).optional(),
  description: c().max(2e3).optional().nullable(),
  metadataJson: c().optional().nullable()
}), Or = T({
  catalogId: c().uuid(),
  items: J(
    T({
      id: c().uuid(),
      orderIndex: D().int().min(0)
    })
  ).min(1)
}), xm = Um.extend({
  children: qh(() => J(xm))
}), bm = T({
  id: c().uuid(),
  groupId: c().uuid(),
  catalogId: c().uuid(),
  catalogVersion: D().int().min(1),
  assignedAt: c(),
  assignedByUserId: c().nullable(),
  assignedByNameSnapshot: c(),
  notes: c().nullable(),
  createdAt: c(),
  updatedAt: c()
}), yu = T({
  groupId: c().uuid(),
  catalogId: c().uuid(),
  resetProgress: Nt().optional(),
  notes: c().max(1e3).optional().nullable()
});
T({
  id: c().uuid(),
  groupId: c().uuid(),
  catalogId: c().uuid(),
  nodeId: c().uuid(),
  status: Jc,
  completedAt: c().nullable(),
  updatedByUserId: c().nullable(),
  updatedByNameSnapshot: c(),
  notes: c().nullable(),
  createdAt: c(),
  updatedAt: c()
});
const Tu = T({
  groupId: c().uuid(),
  nodeId: c().uuid(),
  status: Jc,
  notes: c().max(1e3).optional().nullable()
}), Lm = T({
  status: Kh,
  messageAr: c(),
  completedSessionsCount: D().int().min(0),
  skillsPerWeekRate: D().nullable(),
  projectedCompletionDate: c().nullable()
});
T({
  assignment: bm.nullable(),
  catalog: vm.nullable(),
  totalSkills: D().int().min(0),
  completedSkills: D().int().min(0),
  inProgressSkills: D().int().min(0),
  remainingSkills: D().int().min(0),
  completionPercentage: D().min(0).max(100),
  projection: Lm
});
const Pm = T({
  bold: Nt().optional(),
  italic: Nt().optional(),
  underline: Nt().optional()
}), km = j(["rtl", "ltr", "auto"]), zm = j(["inline", "block"]), Bm = j([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/svg+xml"
]), Mm = T({
  id: c().min(1).max(64),
  type: Qe("text"),
  content: c().max(2e4, "Text content exceeds maximum length of 20000 characters"),
  direction: km.default("auto"),
  formatting: Pm.optional()
}), Fm = T({
  id: c().min(1).max(64),
  type: Qe("math"),
  latex: c().min(1, "LaTeX expression cannot be empty").max(1e4, "LaTeX expression exceeds maximum length of 10000 characters"),
  displayMode: zm.default("block"),
  altTextAr: c().max(500, "Arabic alt text cannot exceed 500 characters").optional().nullable()
}), $m = T({
  id: c().min(1).max(64),
  type: Qe("image"),
  mediaId: c().min(1, "Media ID cannot be empty").max(255).regex(
    /^[a-zA-Z0-9_\-.]+$/,
    "Media ID must contain only alphanumeric characters, dashes, underscores, and dots"
  ),
  caption: c().max(500).optional().nullable(),
  altText: c().max(500).optional().nullable(),
  width: D().int().positive().max(4e3).optional().nullable(),
  height: D().int().positive().max(4e3).optional().nullable(),
  mimeType: Bm.optional().nullable()
}), qm = T({
  id: c().min(1).max(64),
  type: Qe("geometry"),
  schemaVersion: Qe("v1"),
  title: c().max(255).optional().nullable(),
  width: D().int().positive().max(4e3).optional().nullable(),
  height: D().int().positive().max(4e3).optional().nullable(),
  svgPayload: c().max(5e4, "SVG payload exceeds maximum length of 50000 characters").optional().nullable(),
  metadata: qs(Ys()).optional()
}), Hm = $c("type", [
  Mm,
  Fm,
  $m,
  qm
]), _e = T({
  version: Qe(1),
  blocks: J(Hm).max(200, "A document cannot contain more than 200 blocks")
}), Gm = T({
  id: c().min(1).max(64),
  label: c().min(1).max(120),
  minutes: D().int().min(1).max(300)
}), Gn = T({
  objectives: J(c().min(1).max(500)).max(30).default([]),
  priorReview: _e,
  explanation: _e,
  examples: _e,
  inClassQuestions: _e,
  commonMistakes: _e,
  homework: _e,
  timingBreakdown: J(Gm).max(30).default([]),
  notes: c().max(3e3).optional().nullable()
});
T({
  id: c().uuid(),
  curriculumNodeId: c().min(1).max(64),
  title: c().min(1).max(255),
  targetDurationMinutes: D().int().min(1).max(480),
  status: $n,
  version: D().int().min(1),
  sections: Gn,
  createdAt: c(),
  updatedAt: c()
});
const Au = T({
  curriculumNodeId: c().min(1).max(64),
  title: c().min(1).max(255),
  targetDurationMinutes: D().int().min(1).max(480).default(60),
  status: $n.default("DRAFT"),
  sections: Gn
}), Ru = T({
  title: c().min(1).max(255).optional(),
  targetDurationMinutes: D().int().min(1).max(480).optional(),
  status: $n.optional(),
  sections: Gn.optional()
}), Ym = T({
  curriculumNodeId: c().optional(),
  status: $n.optional(),
  search: c().optional()
}), Jm = T({
  planId: c().uuid(),
  curriculumNodeId: c().min(1).max(64),
  title: c().min(1).max(255),
  targetDurationMinutes: D().int().min(1).max(480),
  version: D().int().min(1),
  sections: Gn,
  snapshottedAt: c()
});
T({
  id: c().uuid(),
  sessionId: c().min(1).max(64),
  lessonPlanId: c().uuid().optional().nullable(),
  lessonPlanSnapshot: Jm.optional().nullable(),
  completionStatus: Kr,
  uncompletedItems: c().max(3e3).optional().nullable(),
  topicsNeedingReview: c().max(3e3).optional().nullable(),
  quickNotes: c().max(4e3).optional().nullable(),
  createdAt: c(),
  updatedAt: c()
});
const Du = T({
  sessionId: c().min(1).max(64),
  lessonPlanId: c().uuid().optional().nullable(),
  completionStatus: Kr,
  uncompletedItems: c().max(3e3).optional().nullable(),
  topicsNeedingReview: c().max(3e3).optional().nullable(),
  quickNotes: c().max(4e3).optional().nullable()
}), Ou = T({
  completionStatus: Kr.optional(),
  uncompletedItems: c().max(3e3).optional().nullable(),
  topicsNeedingReview: c().max(3e3).optional().nullable(),
  quickNotes: c().max(4e3).optional().nullable()
});
T({
  id: c().uuid(),
  title: c().min(1).max(200),
  author: c().max(100).nullable().optional(),
  publisher: c().max(100).nullable().optional(),
  editionYear: c().max(20).nullable().optional(),
  curriculumCatalogId: c().uuid().nullable().optional(),
  filePath: c().min(1),
  fileName: c().min(1).max(255),
  fileSizeBytes: D().int().nonnegative(),
  sha256Hash: c().length(64),
  pageCount: D().int().positive(),
  status: jh.default("INDEXED"),
  metadata: qs(Ys()).optional(),
  createdAt: c(),
  updatedAt: c()
});
const wu = T({
  sourceFilePath: c().min(1),
  title: c().min(1).max(200),
  author: c().max(100).optional(),
  publisher: c().max(100).optional(),
  editionYear: c().max(20).optional(),
  curriculumCatalogId: c().uuid().optional()
}), vu = T({
  id: c().uuid(),
  title: c().min(1).max(200).optional(),
  author: c().max(100).nullable().optional(),
  publisher: c().max(100).nullable().optional(),
  editionYear: c().max(20).nullable().optional(),
  curriculumCatalogId: c().uuid().nullable().optional()
});
T({
  id: c().uuid(),
  sourceDocumentId: c().uuid(),
  startPage: D().int().positive(),
  endPage: D().int().positive(),
  referenceLabel: c().min(1).max(150),
  notes: c().max(1e3).nullable().optional(),
  createdAt: c(),
  updatedAt: c()
}).refine((r) => r.endPage >= r.startPage, {
  message: "رقم صفحة النهاية يجب أن يكون أكبر من أو يساوي رقم صفحة البداية",
  path: ["endPage"]
});
const Cu = T({
  sourceDocumentId: c().uuid(),
  startPage: D().int().positive(),
  endPage: D().int().positive(),
  referenceLabel: c().min(1).max(150),
  notes: c().max(1e3).optional()
}).refine((r) => r.endPage >= r.startPage, {
  message: "رقم صفحة النهاية يجب أن يكون أكبر من أو يساوي رقم صفحة البداية",
  path: ["endPage"]
}), Vm = T({
  id: c().uuid(),
  startPage: D().int().positive().optional(),
  endPage: D().int().positive().optional(),
  referenceLabel: c().min(1).max(150).optional(),
  notes: c().max(1e3).nullable().optional()
}), Qm = T({
  sourceReferenceId: c().uuid(),
  referenceLabel: c().optional(),
  sourceDocumentTitle: c().optional(),
  startPage: D().int().optional(),
  endPage: D().int().optional(),
  notes: c().nullable().optional()
});
T({
  id: c().uuid(),
  code: c().min(1).max(50),
  body: _e,
  modelAnswer: _e.nullable().optional(),
  questionType: Vt,
  difficulty: Qt,
  defaultMarks: D().int().positive().default(1),
  languageTrack: $e.default("ARABIC"),
  status: qn.default("ACTIVE"),
  contentFingerprint: c().min(1),
  curriculumTags: J(c().uuid()).default([]),
  sourceReferences: J(Qm).default([]),
  metadata: qs(Ys()).optional(),
  createdAt: c(),
  updatedAt: c()
});
const Uu = T({
  body: _e,
  modelAnswer: _e.optional(),
  questionType: Vt.default("MULTIPLE_CHOICE"),
  difficulty: Qt.default("MEDIUM"),
  defaultMarks: D().int().positive().default(1),
  languageTrack: $e.default("ARABIC"),
  status: qn.default("ACTIVE"),
  curriculumNodeIds: J(c().uuid()).min(1, "يجب ربط السؤال بمهارة أو درس واحد على الأقل"),
  sourceReferenceIds: J(c().uuid()).default([])
}), xu = T({
  id: c().uuid(),
  body: _e.optional(),
  modelAnswer: _e.nullable().optional(),
  questionType: Vt.optional(),
  difficulty: Qt.optional(),
  defaultMarks: D().int().positive().optional(),
  languageTrack: $e.optional(),
  status: qn.optional(),
  curriculumNodeIds: J(c().uuid()).optional(),
  sourceReferenceIds: J(c().uuid()).optional()
}), bu = T({
  curriculumNodeId: c().uuid().optional(),
  catalogId: c().uuid().optional(),
  questionType: Vt.optional(),
  difficulty: Qt.optional(),
  status: qn.optional(),
  search: c().optional()
}), Km = j(["EXACT", "CANDIDATE", "NONE"]), jm = T({
  isDuplicate: Nt(),
  matchLevel: Km,
  existingQuestionId: c().uuid().optional(),
  existingQuestionCode: c().optional(),
  reasonAr: c()
}), Zr = T({
  tempId: c().min(1),
  body: _e,
  modelAnswer: _e.optional(),
  questionType: Vt.default("MULTIPLE_CHOICE"),
  difficulty: Qt.default("MEDIUM"),
  defaultMarks: D().int().positive().default(1),
  languageTrack: $e.default("ARABIC"),
  curriculumNodeIds: J(c().uuid()).default([]),
  sourceReferenceIds: J(c().uuid()).default([])
}), Xm = j([
  "VALID",
  "WARNING",
  "DUPLICATE_EXACT",
  "DUPLICATE_CANDIDATE"
]);
T({
  tempId: c(),
  item: Zr,
  status: Xm,
  validationErrors: J(c()),
  duplicateMatch: jm.optional(),
  suggestedAction: j(["CREATE_NEW", "LINK_SOURCE", "DISMISS"])
});
const Zm = T({
  tempId: c(),
  action: j(["CREATE_NEW", "LINK_SOURCE", "DISMISS"]),
  targetQuestionId: c().uuid().optional(),
  item: Zr
}), Lu = T({
  actions: J(Zm)
}), Wm = j(["DRAFT", "CONFIRMED", "ARCHIVED"]), Pu = j(["QUESTION_BANK", "AI_CANDIDATE", "SOURCE_LINKED"]), Wr = T({
  title: c().trim().min(1).max(200),
  gradeLevel: ot,
  languageTrack: $e,
  curriculumNodeIds: J(c().uuid()).default([]),
  sourceReferenceIds: J(c().uuid()).default([]),
  totalQuestions: D().int().positive().max(100),
  totalMarks: D().int().positive().max(1e3),
  durationMinutes: D().int().positive().max(600),
  difficultyDistribution: qs(Qt, D().int().nonnegative()),
  questionTypeDistribution: qs(Vt, D().int().nonnegative()),
  variantCount: D().int().min(1).max(4).default(1)
}).superRefine((r, e) => {
  Object.values(r.difficultyDistribution).reduce((n, i) => n + i, 0) !== r.totalQuestions && e.addIssue({ code: U.custom, path: ["difficultyDistribution"], message: "يجب أن يساوي مجموع توزيع الصعوبة عدد الأسئلة" }), Object.values(r.questionTypeDistribution).reduce((n, i) => n + i, 0) !== r.totalQuestions && e.addIssue({ code: U.custom, path: ["questionTypeDistribution"], message: "يجب أن يساوي مجموع توزيع أنواع الأسئلة عدد الأسئلة" });
}), ep = T({
  body: _e,
  modelAnswer: _e.nullable(),
  questionType: Vt,
  difficulty: Qt,
  marks: D().int().positive().max(1e3)
}).strict(), tp = T({
  id: c().uuid(),
  examId: c().uuid(),
  title: c().min(1).max(200),
  instructionsJson: c().default("[]"),
  position: D().int().nonnegative(),
  createdAt: c()
}), sp = T({
  id: c().uuid(),
  examId: c().uuid(),
  label: j(["A", "B", "C", "D"]),
  questionOrder: J(c().uuid()),
  answerKey: J(T({
    placementId: c().uuid(),
    answer: Ys()
  })),
  createdAt: c()
}), np = T({
  id: c().uuid(),
  examSectionId: c().uuid().optional(),
  questionId: c().uuid().optional(),
  provenance: Pu,
  body: _e,
  modelAnswer: _e.nullable(),
  marks: D().int().positive(),
  answerSpaceLines: D().int().nonnegative().default(0),
  curriculumNodeIds: J(c().uuid()),
  sourceReferenceIds: J(c().uuid()),
  position: D().int().nonnegative()
});
T({
  id: c().uuid(),
  title: c().min(1).max(200),
  blueprint: Wr,
  status: Wm,
  sections: J(tp).default([]),
  placements: J(np),
  versions: J(sp).default([]),
  createdAt: c(),
  updatedAt: c()
});
T({
  valid: Nt(),
  conflicts: J(c()),
  selectedQuestions: J(T({
    questionId: c().uuid(),
    marks: D().int().positive(),
    curriculumNodeIds: J(c().uuid()),
    sourceReferenceIds: J(c().uuid()),
    questionType: Vt,
    difficulty: Qt,
    body: _e,
    modelAnswer: _e.nullable()
  })),
  totalSelectedMarks: D().int().nonnegative(),
  totalSelectedQuestions: D().int().nonnegative()
});
const rp = T({
  blueprint: Wr,
  placements: J(T({
    questionId: c().uuid().optional(),
    provenance: Pu,
    body: _e,
    modelAnswer: _e.nullable().default(null),
    marks: D().int().positive(),
    answerSpaceLines: D().int().nonnegative().default(0),
    curriculumNodeIds: J(c().uuid()),
    sourceReferenceIds: J(c().uuid()).default([]),
    position: D().int().nonnegative()
  })).min(1),
  sectionTitle: c().min(1).max(200).default("القسم الرئيسي")
}), ip = T({
  topicOrStandard: c().min(1).max(500),
  gradeLevel: ot,
  languageTrack: $e,
  questionType: Vt,
  difficulty: Qt,
  marks: D().int().positive().max(1e3).default(1),
  count: D().int().min(1).max(10).default(3),
  curriculumNodeIds: J(c().uuid()).default([]),
  sourceReferenceIds: J(c().uuid()).default([])
}), ap = T({
  apiKey: c().trim().min(1).max(1024)
}), op = T({
  configured: Nt()
}).strict(), E = {
  // Auth
  AUTH_LIST_USERS: "auth:listUsers",
  AUTH_LIST_MANAGEMENT_USERS: "auth:listManagementUsers",
  AUTH_LOGIN_PIN: "auth:loginPin",
  AUTH_LOGOUT: "auth:logout",
  AUTH_GET_SESSION: "auth:getSession",
  AUTH_BOOTSTRAP_OWNER: "auth:bootstrapOwner",
  AUTH_CREATE_USER: "auth:createUser",
  AUTH_UPDATE_PERMISSIONS: "auth:updatePermissions",
  AUTH_CHANGE_STATUS: "auth:changeStatus",
  AUTH_RESET_PIN: "auth:resetPin",
  // Students
  STUDENTS_LIST: "students:list",
  STUDENTS_GET_BY_ID: "students:getById",
  STUDENTS_CREATE: "students:create",
  STUDENTS_UPDATE: "students:update",
  STUDENTS_ADD_NOTE: "students:addNote",
  STUDENTS_LIST_NOTES: "students:listNotes",
  STUDENTS_CHOOSE_PHOTO_DIALOG: "students:choosePhotoDialog",
  STUDENTS_PRINT_CARDS: "students:printCards",
  STUDENTS_EXPORT_CARDS_PDF: "students:exportCardsPdf",
  // Groups
  GROUPS_LIST: "groups:list",
  GROUPS_GET_BY_ID: "groups:getById",
  GROUPS_CREATE: "groups:create",
  GROUPS_UPDATE: "groups:update",
  GROUPS_SET_SCHEDULE: "groups:setSchedule",
  // Enrollments
  ENROLLMENTS_LIST_BY_GROUP: "enrollments:listByGroup",
  ENROLLMENTS_ENROLL: "enrollments:enroll",
  ENROLLMENTS_UPDATE_PAYMENT: "enrollments:updatePayment",
  ENROLLMENTS_END: "enrollments:end",
  // Sessions & Rescheduling
  SESSIONS_MATERIALIZE: "sessions:materialize",
  SESSIONS_LIST_BY_RANGE: "sessions:listByRange",
  SESSIONS_RESCHEDULE: "sessions:reschedule",
  SESSIONS_CANCEL: "sessions:cancel",
  SESSIONS_COMPLETE: "sessions:complete",
  // Attendance
  ATTENDANCE_GET_ROSTER: "attendance:getRoster",
  ATTENDANCE_RECORD: "attendance:record",
  ATTENDANCE_BATCH_RECORD: "attendance:batchRecord",
  ATTENDANCE_GET_END_OF_DAY: "attendance:getEndOfDay",
  ATTENDANCE_UPDATE_FOLLOW_UP_STATUS: "attendance:updateFollowUpStatus",
  // Dashboard
  DASHBOARD_GET_TODAY: "dashboard:getToday",
  // Backup
  BACKUP_TRIGGER: "backup:trigger",
  BACKUP_GET_STATUS: "backup:getStatus",
  BACKUP_LIST_RECORDS: "backup:listRecords",
  // System & Academic Year
  SYSTEM_GET_INFO: "system:getInfo",
  SYSTEM_GET_SETTINGS: "system:getSettings",
  SYSTEM_GET_SETUP_STATE: "system:getSetupState",
  SYSTEM_UPDATE_THEME: "system:updateTheme",
  SYSTEM_LIST_ACADEMIC_YEARS: "system:listAcademicYears",
  SYSTEM_CREATE_ACADEMIC_YEAR: "system:createAcademicYear",
  SYSTEM_SWITCH_ACADEMIC_YEAR: "system:switchAcademicYear",
  SYSTEM_OPEN_WHATSAPP: "system:openWhatsApp",
  // Gemini configuration (credential material is accepted only by Main and never returned)
  GEMINI_GET_STATUS: "gemini:getStatus",
  GEMINI_SET_CREDENTIAL: "gemini:setCredential",
  GEMINI_DELETE_CREDENTIAL: "gemini:deleteCredential",
  // Finance
  FINANCE_RECORD_PAYMENT: "finance:recordPayment",
  FINANCE_LIST_STUDENT_PAYMENTS: "finance:listStudentPayments",
  FINANCE_GET_STUDENT_SUMMARY: "finance:getStudentSummary",
  FINANCE_LIST_ALL_SUMMARIES: "finance:listAllSummaries",
  FINANCE_GET_OVERALL_KPI: "finance:getOverallKpi",
  FINANCE_CREATE_INVOICE: "finance:createInvoice",
  FINANCE_GET_INVOICE: "finance:getInvoice",
  FINANCE_LIST_INVOICES: "finance:listInvoices",
  FINANCE_APPLY_DISCOUNT: "finance:applyDiscount",
  FINANCE_LIST_DISCOUNTS: "finance:listDiscounts",
  FINANCE_PRINT_INVOICE: "finance:printInvoice",
  FINANCE_EXPORT_INVOICE_PDF: "finance:exportInvoicePdf",
  // Thermal Printing
  THERMAL_LIST_PRINTERS: "thermal:listPrinters",
  THERMAL_GET_RECEIPT_DATA: "thermal:getReceiptData",
  THERMAL_PRINT_RECEIPT: "thermal:printReceipt",
  THERMAL_TEST_PRINT: "thermal:testPrint",
  THERMAL_GENERATE_ESCPOS: "thermal:generateEscpos",
  THERMAL_PRINT_ESCPOS_NETWORK: "thermal:printEscposNetwork",
  // Curriculum & Group Progress
  CURRICULUM_LIST_CATALOGS: "curriculum:listCatalogs",
  CURRICULUM_GET_CATALOG: "curriculum:getCatalog",
  CURRICULUM_CREATE_CATALOG: "curriculum:createCatalog",
  CURRICULUM_UPDATE_CATALOG: "curriculum:updateCatalog",
  CURRICULUM_PUBLISH_CATALOG: "curriculum:publishCatalog",
  CURRICULUM_REVISE_CATALOG: "curriculum:reviseCatalog",
  CURRICULUM_GET_TREE: "curriculum:getTree",
  CURRICULUM_CREATE_NODE: "curriculum:createNode",
  CURRICULUM_UPDATE_NODE: "curriculum:updateNode",
  CURRICULUM_DELETE_NODE: "curriculum:deleteNode",
  CURRICULUM_REORDER_NODES: "curriculum:reorderNodes",
  CURRICULUM_GET_GROUP_OVERVIEW: "curriculum:getGroupOverview",
  CURRICULUM_ASSIGN_GROUP_CATALOG: "curriculum:assignGroupCatalog",
  CURRICULUM_UPDATE_GROUP_PROGRESS: "curriculum:updateGroupProgress",
  CURRICULUM_GET_GROUP_PROGRESS_MAP: "curriculum:getGroupProgressMap",
  // Lesson Planner
  LESSON_PLAN_CREATE: "lessonPlanner:createPlan",
  LESSON_PLAN_UPDATE: "lessonPlanner:updatePlan",
  LESSON_PLAN_GET: "lessonPlanner:getPlan",
  LESSON_PLAN_LIST_BY_NODE: "lessonPlanner:listByNode",
  LESSON_PLAN_LIST: "lessonPlanner:list",
  LESSON_PLAN_ARCHIVE: "lessonPlanner:archivePlan",
  // Session Reflection
  SESSION_REFLECTION_CREATE: "sessionReflection:create",
  SESSION_REFLECTION_UPDATE: "sessionReflection:update",
  SESSION_REFLECTION_GET_BY_SESSION: "sessionReflection:getBySession",
  SESSION_REFLECTION_GET: "sessionReflection:get",
  // PDF Sources & Page References (Phase 3 Task 4)
  PDF_SOURCES_LIST: "pdfSources:list",
  PDF_SOURCES_GET: "pdfSources:get",
  PDF_SOURCES_IMPORT: "pdfSources:import",
  PDF_SOURCES_UPDATE: "pdfSources:update",
  PDF_SOURCES_DELETE: "pdfSources:delete",
  PDF_REFERENCES_LIST: "pdfSources:listReferences",
  PDF_REFERENCES_CREATE: "pdfSources:createReference",
  PDF_REFERENCES_DELETE: "pdfSources:deleteReference",
  PDF_SOURCES_OPEN: "pdfSources:openDocument",
  // Question Bank & Deduplication / Ingestion (Phase 3 Tasks 5 & 6)
  QUESTION_BANK_LIST: "questionBank:list",
  QUESTION_BANK_GET: "questionBank:get",
  QUESTION_BANK_CREATE: "questionBank:create",
  QUESTION_BANK_UPDATE: "questionBank:update",
  QUESTION_BANK_DELETE: "questionBank:delete",
  QUESTION_BANK_ARCHIVE: "questionBank:archive",
  QUESTION_BANK_CHECK_DUPLICATE: "questionBank:checkDuplicate",
  QUESTION_BANK_PREVIEW_BULK: "questionBank:previewBulk",
  QUESTION_BANK_COMMIT_BULK: "questionBank:commitBulk",
  QUESTION_BANK_LINK_SOURCES: "questionBank:linkSources",
  QUESTION_BANK_UNLINK_SOURCE: "questionBank:unlinkSource",
  // Exam Engine & AI Builder (Phase 4)
  EXAMS_LIST: "exams:list",
  EXAMS_GET: "exams:get",
  EXAMS_PREVIEW_ASSEMBLY: "exams:previewAssembly",
  EXAMS_CONFIRM_ASSEMBLY: "exams:confirmAssembly",
  EXAMS_UNDO_LAST_MUTATION: "exams:undoLastMutation",
  EXAMS_PREVIEW_AI_CANDIDATES: "exams:previewAiCandidates",
  EXAMS_RENDER_LAYOUT: "exams:renderLayout",
  EXAMS_EXPORT_PDF: "exams:exportPdf",
  EXAMS_PRINT: "exams:print"
}, Ne = {
  N: 16384,
  r: 8,
  p: 1,
  maxmem: 32 * 1024 * 1024,
  keylen: 64,
  saltBytes: 16
};
function Si(r, e, t, s) {
  return new Promise((n, i) => {
    b.scrypt(r, e, t, s, (a, o) => {
      a ? i(a) : n(o);
    });
  });
}
class dp {
  /**
   * Hashes a 4-digit numeric PIN using Node.js crypto.scrypt with a unique 16-byte salt.
   * Throws if the PIN does not conform to the 4-digit PIN schema.
   */
  async hashPin(e) {
    ss.parse(e);
    const t = b.randomBytes(Ne.saltBytes).toString("hex");
    return {
      pinHash: (await Si(e, t, Ne.keylen, {
        N: Ne.N,
        r: Ne.r,
        p: Ne.p,
        maxmem: Ne.maxmem
      })).toString("hex"),
      salt: t
    };
  }
  /**
   * Synchronous hash helper for transactions where async is not desired.
   */
  hashPinSync(e) {
    ss.parse(e);
    const t = b.randomBytes(Ne.saltBytes).toString("hex");
    return {
      pinHash: b.scryptSync(e, t, Ne.keylen, {
        N: Ne.N,
        r: Ne.r,
        p: Ne.p,
        maxmem: Ne.maxmem
      }).toString("hex"),
      salt: t
    };
  }
  /**
   * Verifies a candidate PIN against a stored pinHash and salt in constant time.
   */
  async verifyPin(e, t, s) {
    if (!ss.safeParse(e).success)
      return !1;
    try {
      const i = await Si(e, s, Ne.keylen, {
        N: Ne.N,
        r: Ne.r,
        p: Ne.p,
        maxmem: Ne.maxmem
      }), a = Buffer.from(t, "hex");
      return i.length !== a.length ? !1 : b.timingSafeEqual(i, a);
    } catch {
      return !1;
    }
  }
  /**
   * Synchronous verify helper.
   */
  verifyPinSync(e, t, s) {
    if (!ss.safeParse(e).success)
      return !1;
    try {
      const i = b.scryptSync(e, s, Ne.keylen, {
        N: Ne.N,
        r: Ne.r,
        p: Ne.p,
        maxmem: Ne.maxmem
      }), a = Buffer.from(t, "hex");
      return i.length !== a.length ? !1 : b.timingSafeEqual(i, a);
    } catch {
      return !1;
    }
  }
}
const ku = [
  {
    code: "STUDENTS_READ",
    nameAr: "عرض بيانات الطلاب",
    descriptionAr: "السماح بالاطلاع على قوائم وملفات الطلاب وبيانات التواصل",
    category: "الطلاب"
  },
  {
    code: "STUDENTS_WRITE",
    nameAr: "إدارة وتعديل بيانات الطلاب",
    descriptionAr: "السماح بإضافة وتعديل بيانات الطلاب وملاحظاتهم",
    category: "الطلاب"
  },
  {
    code: "GROUPS_READ",
    nameAr: "عرض المجموعات والمواعيد",
    descriptionAr: "السماح بالاطلاع على المجموعات وقوائم الملتحقين وجداول الحصص",
    category: "المجموعات"
  },
  {
    code: "GROUPS_WRITE",
    nameAr: "إدارة المجموعات والاشتراكات",
    descriptionAr: "السماح بإنشاء المجموعات وتعديلها وإلحاق الطلاب وإنهاء اشتراكاتهم",
    category: "المجموعات"
  },
  {
    code: "SESSIONS_MANAGE",
    nameAr: "إدارة وجدولة الحصص",
    descriptionAr: "السماح بتوليد الحصص وتعديل مواعيدها وإلغائها وإعادة جدولتها",
    category: "الحصص"
  },
  {
    code: "ATTENDANCE_WRITE",
    nameAr: "تسجيل الحضور والغياب",
    descriptionAr: "السماح برصد حضور الطلاب عبر مسح الباركود أو التسجيل اليدوي",
    category: "الحضور"
  },
  {
    code: "PAYMENTS_READ",
    nameAr: "عرض السجلات المالية",
    descriptionAr: "السماح بالاطلاع على سجلات المصاريف الشهرية ودفعات الحصص",
    category: "المالية"
  },
  {
    code: "PAYMENTS_WRITE",
    nameAr: "تسجيل المدفوعات والتحصيل",
    descriptionAr: "السماح بتحصيل الاشتراكات وإصدار إيصالات الدفع وتعديل مبالغ الاستثناءات",
    category: "المالية"
  },
  {
    code: "REPORTS_READ",
    nameAr: "عرض التقارير والإحصاءات",
    descriptionAr: "السماح بالاطلاع على كشوفات الحضور والأداء والتقارير التحليلية",
    category: "التقارير"
  },
  {
    code: "SETTINGS_WRITE",
    nameAr: "تعديل إعدادات النظام",
    descriptionAr: "السماح بتعديل الإعدادات العامة للنظام والمظهر وتفضيلات الطباعة",
    category: "الإعدادات"
  },
  {
    code: "USERS_MANAGE",
    nameAr: "إدارة حسابات المساعدين",
    descriptionAr: "السماح بإنشاء حسابات المساعدين وتعيين صلاحياتهم وتعيين حالاتهم",
    category: "الحسابات"
  },
  {
    code: "BACKUP_MANAGE",
    nameAr: "إدارة النسخ الاحتياطي",
    descriptionAr: "السماح بإنشاء نسخ احتياطية واستعادتها وتعيين مسارات الحفظ",
    category: "النسخ الاحتياطي"
  }
], zt = ku.map((r) => r.code);
function cp(r) {
  (r ?? Jt().db).insert(Mr).values(ku).onConflictDoNothing().run();
}
function zu(r, e, t) {
  return r === "OWNER" ? !0 : r === "ASSISTANT" ? e.includes(t) : !1;
}
function te(r, e, t) {
  if (!zu(r, e, t)) {
    const s = new Error(`PERMISSION_DENIED: Required permission '${t}'`);
    throw s.code = "PERMISSION_DENIED", s;
  }
}
class fe extends Error {
  constructor(e, t, s) {
    super(t), this.code = e, this.retryAfterSeconds = s, this.name = "AuthError";
  }
}
class up {
  now() {
    return /* @__PURE__ */ new Date();
  }
}
const At = {
  MAX_FAILED_ATTEMPTS: 5,
  COOLDOWN_SECONDS: 30,
  SESSION_DURATION_HOURS: 8
};
class lp {
  constructor(e, t = new dp(), s = new up()) {
    h(this, "userRepo");
    h(this, "auditRepo");
    this.db = e, this.pinService = t, this.clock = s, this.userRepo = new kt(this.db), this.auditRepo = new Te(this.db);
  }
  get client() {
    return this.db ?? Jt().db;
  }
  /**
   * Redacts sensitive cryptographic artifacts from audit snapshots.
   */
  safeUserSnapshot(e) {
    const t = { ...e };
    return delete t.pinHash, delete t.salt, t;
  }
  /**
   * Converts a database UserRow into a safe, transportable UserDto.
   */
  toUserDto(e) {
    const t = e.role === "OWNER" ? zt : this.userRepo.getUserPermissions(e.id);
    return {
      id: e.id,
      fullName: e.fullName,
      username: e.username,
      role: e.role,
      status: e.status,
      failedAttempts: e.failedAttempts,
      lockedUntil: e.lockedUntil,
      permissions: t,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  /**
   * Initializes the singular Teacher/Owner account for Tibyan.
   * Fails if an Owner already exists.
   */
  async bootstrapOwner(e) {
    if (this.userRepo.listAll().find((l) => l.role === "OWNER"))
      throw new fe("OWNER_ALREADY_EXISTS", "Teacher Owner account already exists");
    const n = e.username.trim().toLowerCase();
    if (this.userRepo.findByUsername(n))
      throw new fe("USERNAME_ALREADY_EXISTS", "Username is already taken");
    const { pinHash: a, salt: o } = await this.pinService.hashPin(e.pin), d = b.randomUUID(), u = this.clock.now().toISOString();
    return this.client.transaction((l) => {
      const p = new kt(l), S = new Te(l), N = p.create({
        id: d,
        fullName: e.fullName.trim(),
        username: n,
        pinHash: a,
        salt: o,
        role: "OWNER",
        status: "ACTIVE",
        failedAttempts: 0,
        lockedUntil: null,
        createdAt: u,
        updatedAt: u
      });
      return S.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: d,
        actorNameSnapshot: N.fullName,
        action: "OWNER_BOOTSTRAPPED",
        entityType: "USER",
        entityId: d,
        beforeJson: null,
        afterJson: JSON.stringify(this.safeUserSnapshot(N)),
        metadataJson: JSON.stringify({ role: "OWNER", bootstrapTime: u }),
        createdAt: u
      }), this.toUserDto(N);
    });
  }
  /**
   * Authenticates a user using their 4-digit PIN, enforcing brute-force cooldown rules.
   */
  async loginWithPin(e) {
    Kc.parse(e);
    let t = this.userRepo.findById(e.userId);
    if (!t)
      throw new fe("USER_NOT_FOUND", "User not found");
    if (t.status !== "ACTIVE")
      throw new fe("USER_INACTIVE", "User account is inactive");
    const s = this.clock.now().getTime(), n = this.clock.now().toISOString();
    if (t.lockedUntil) {
      const d = new Date(t.lockedUntil).getTime();
      if (d > s) {
        const u = Math.ceil((d - s) / 1e3);
        throw new fe(
          "ACCOUNT_LOCKED",
          `Account is locked due to too many failed attempts. Try again in ${u} seconds.`,
          u
        );
      } else
        this.userRepo.update(t.id, {
          lockedUntil: null,
          failedAttempts: 0,
          updatedAt: n
        }), t = this.userRepo.findById(t.id);
    }
    if (await this.pinService.verifyPin(e.pin, t.pinHash, t.salt))
      return this.client.transaction((d) => {
        const u = new kt(d), l = new Te(d);
        u.update(t.id, {
          failedAttempts: 0,
          lockedUntil: null,
          updatedAt: n
        }), l.insert({
          id: b.randomUUID(),
          actorType: "USER",
          actorUserId: t.id,
          actorNameSnapshot: t.fullName,
          action: "AUTH_LOGIN_SUCCESS",
          entityType: "USER",
          entityId: t.id,
          beforeJson: null,
          afterJson: null,
          metadataJson: JSON.stringify({ loginTime: n }),
          createdAt: n
        });
        const p = t.role === "OWNER" ? zt : u.getUserPermissions(t.id), S = new Date(
          this.clock.now().getTime() + At.SESSION_DURATION_HOURS * 3600 * 1e3
        ).toISOString();
        return {
          userId: t.id,
          fullName: t.fullName,
          username: t.username,
          role: t.role,
          permissions: p,
          tokenExpiresAt: S
        };
      });
    const a = (t.failedAttempts || 0) + 1;
    if (a < At.MAX_FAILED_ATTEMPTS)
      throw this.client.transaction((d) => {
        const u = new kt(d), l = new Te(d);
        u.update(t.id, {
          failedAttempts: a,
          updatedAt: n
        }), l.insert({
          id: b.randomUUID(),
          actorType: "USER",
          actorUserId: t.id,
          actorNameSnapshot: t.fullName,
          action: "AUTH_LOGIN_FAILED",
          entityType: "USER",
          entityId: t.id,
          beforeJson: null,
          afterJson: null,
          metadataJson: JSON.stringify({
            failedAttempts: a,
            remainingAttempts: At.MAX_FAILED_ATTEMPTS - a
          }),
          createdAt: n
        });
      }), new fe("INVALID_PIN", "Invalid PIN provided");
    const o = new Date(
      this.clock.now().getTime() + At.COOLDOWN_SECONDS * 1e3
    ).toISOString();
    throw this.client.transaction((d) => {
      const u = new kt(d), l = new Te(d);
      u.update(t.id, {
        failedAttempts: At.MAX_FAILED_ATTEMPTS,
        lockedUntil: o,
        updatedAt: n
      }), l.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.id,
        actorNameSnapshot: t.fullName,
        action: "AUTH_BRUTE_FORCE_COOLDOWN",
        entityType: "USER",
        entityId: t.id,
        beforeJson: null,
        afterJson: null,
        metadataJson: JSON.stringify({
          failedAttempts: At.MAX_FAILED_ATTEMPTS,
          lockedUntil: o,
          cooldownSeconds: At.COOLDOWN_SECONDS
        }),
        createdAt: n
      });
    }), new fe(
      "ACCOUNT_LOCKED",
      `Account locked due to ${At.MAX_FAILED_ATTEMPTS} consecutive failed attempts. Try again in ${At.COOLDOWN_SECONDS} seconds.`,
      At.COOLDOWN_SECONDS
    );
  }
  /**
   * Creates a new Assistant user with assigned permissions.
   */
  async createAssistant(e, t) {
    jc.parse(e);
    const s = this.userRepo.findById(t);
    if (!s)
      throw new fe("USER_NOT_FOUND", "Actor user not found");
    const n = s.role === "OWNER" ? zt : this.userRepo.getUserPermissions(s.id);
    if (te(s.role, n, "USERS_MANAGE"), e.role === "OWNER")
      throw new fe("INVALID_OPERATION", "Cannot create additional Owner accounts");
    if (s.role !== "OWNER" && e.permissions && e.permissions.length > 0) {
      const p = e.permissions.filter((S) => !n.includes(S));
      if (p.length > 0)
        throw new fe(
          "PERMISSION_DENIED",
          `Cannot grant permissions that the actor does not possess: ${p.join(", ")}`
        );
    }
    const i = e.username.trim().toLowerCase();
    if (this.userRepo.findByUsername(i))
      throw new fe("USERNAME_ALREADY_EXISTS", "Username already exists");
    const { pinHash: o, salt: d } = await this.pinService.hashPin(e.pin), u = b.randomUUID(), l = this.clock.now().toISOString();
    return this.client.transaction((p) => {
      const S = new kt(p), N = new Te(p), y = S.create({
        id: u,
        fullName: e.fullName.trim(),
        username: i,
        pinHash: o,
        salt: d,
        role: "ASSISTANT",
        status: "ACTIVE",
        failedAttempts: 0,
        lockedUntil: null,
        createdAt: l,
        updatedAt: l
      });
      return e.permissions && e.permissions.length > 0 && S.assignPermissions(u, e.permissions), N.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: s.id,
        actorNameSnapshot: s.fullName,
        action: "ASSISTANT_CREATED",
        entityType: "USER",
        entityId: u,
        beforeJson: null,
        afterJson: JSON.stringify(this.safeUserSnapshot(y)),
        metadataJson: JSON.stringify({
          role: "ASSISTANT",
          grantedPermissions: e.permissions
        }),
        createdAt: l
      }), this.toUserDto(y);
    });
  }
  /**
   * Updates granted permissions for an Assistant user.
   */
  async setAssistantPermissions(e, t) {
    Xc.parse(e);
    const s = this.userRepo.findById(t);
    if (!s)
      throw new fe("USER_NOT_FOUND", "Actor user not found");
    const n = s.role === "OWNER" ? zt : this.userRepo.getUserPermissions(s.id);
    te(s.role, n, "USERS_MANAGE");
    const i = this.userRepo.findById(e.userId);
    if (!i)
      throw new fe("USER_NOT_FOUND", "Target user not found");
    if (i.role === "OWNER")
      throw new fe("INVALID_OPERATION", "Owner permissions cannot be altered");
    if (s.role !== "OWNER" && s.id === i.id)
      throw new fe("INVALID_OPERATION", "Cannot modify your own permissions");
    if (s.role !== "OWNER" && e.permissions && e.permissions.length > 0) {
      const d = e.permissions.filter((u) => !n.includes(u));
      if (d.length > 0)
        throw new fe(
          "PERMISSION_DENIED",
          `Cannot grant permissions that the actor does not possess: ${d.join(", ")}`
        );
    }
    const a = this.clock.now().toISOString(), o = this.userRepo.getUserPermissions(i.id);
    return this.client.transaction((d) => {
      const u = new kt(d), l = new Te(d);
      return u.removePermissions(i.id, zt), e.permissions.length > 0 && u.assignPermissions(i.id, e.permissions), l.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: s.id,
        actorNameSnapshot: s.fullName,
        action: "USER_PERMISSIONS_CHANGED",
        entityType: "USER",
        entityId: i.id,
        beforeJson: JSON.stringify({ permissions: o }),
        afterJson: JSON.stringify({ permissions: e.permissions }),
        metadataJson: JSON.stringify({ updatedBy: s.id }),
        createdAt: a
      }), this.toUserDto(i);
    });
  }
  /**
   * Updates user status (ACTIVE or INACTIVE).
   * Rejects attempts to deactivate the sole Owner.
   */
  async setUserStatus(e, t) {
    Zc.parse(e);
    const s = this.userRepo.findById(t);
    if (!s)
      throw new fe("USER_NOT_FOUND", "Actor user not found");
    const n = s.role === "OWNER" ? zt : this.userRepo.getUserPermissions(s.id);
    te(s.role, n, "USERS_MANAGE");
    const i = this.userRepo.findById(e.userId);
    if (!i)
      throw new fe("USER_NOT_FOUND", "Target user not found");
    if (i.role === "OWNER")
      throw new fe("INVALID_OPERATION", "The sole Owner account status cannot be altered");
    const a = this.clock.now().toISOString();
    return this.client.transaction((o) => {
      const d = new kt(o), u = new Te(o), l = d.update(i.id, {
        status: e.status,
        updatedAt: a
      });
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: s.id,
        actorNameSnapshot: s.fullName,
        action: "USER_STATUS_CHANGED",
        entityType: "USER",
        entityId: i.id,
        beforeJson: JSON.stringify(this.safeUserSnapshot(i)),
        afterJson: JSON.stringify(this.safeUserSnapshot(l)),
        metadataJson: JSON.stringify({ oldStatus: i.status, newStatus: e.status }),
        createdAt: a
      }), this.toUserDto(l);
    });
  }
  /**
   * Resets the 4-digit PIN for a user without leaking the PIN or hashes into audit logs.
   */
  async resetUserPin(e, t) {
    Wc.parse(e);
    const s = this.userRepo.findById(t);
    if (!s)
      throw new fe("USER_NOT_FOUND", "Actor user not found");
    if (s.id !== e.userId) {
      const d = s.role === "OWNER" ? zt : this.userRepo.getUserPermissions(s.id);
      te(s.role, d, "USERS_MANAGE");
    }
    const n = this.userRepo.findById(e.userId);
    if (!n)
      throw new fe("USER_NOT_FOUND", "Target user not found");
    if (n.role === "OWNER" && s.id !== n.id)
      throw new fe("PERMISSION_DENIED", "Assistants cannot reset the Owner PIN");
    const { pinHash: i, salt: a } = await this.pinService.hashPin(e.newPin), o = this.clock.now().toISOString();
    return this.client.transaction((d) => {
      const u = new kt(d), l = new Te(d), p = u.update(n.id, {
        pinHash: i,
        salt: a,
        failedAttempts: 0,
        lockedUntil: null,
        updatedAt: o
      });
      return l.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: s.id,
        actorNameSnapshot: s.fullName,
        action: "USER_PIN_RESET",
        entityType: "USER",
        entityId: n.id,
        beforeJson: null,
        afterJson: null,
        metadataJson: JSON.stringify({ pinChanged: !0, resetTime: o }),
        createdAt: o
      }), this.toUserDto(p);
    });
  }
  /**
   * Returns safe active users for the login selector.
   */
  listLoginUsers() {
    return this.userRepo.listAll().filter((e) => e.status === "ACTIVE").map((e) => ({
      id: e.id,
      fullName: e.fullName,
      username: e.username,
      role: e.role
    }));
  }
  /**
   * Returns all users (both ACTIVE and INACTIVE) for the management UI with status and permissions.
   * Authoritatively protected: requires USERS_MANAGE on actor.
   * Strips credential security fields (pinHash, salt, failedAttempts, lockedUntil).
   */
  listManagementUsers(e) {
    const t = this.userRepo.findById(e);
    if (!t)
      throw new fe("USER_NOT_FOUND", "Actor user not found");
    const s = t.role === "OWNER" ? zt : this.userRepo.getUserPermissions(t.id);
    return te(t.role, s, "USERS_MANAGE"), this.userRepo.listAll().map((n) => {
      const i = n.role === "OWNER" ? zt : this.userRepo.getUserPermissions(n.id);
      return {
        id: n.id,
        fullName: n.fullName,
        username: n.username,
        role: n.role,
        status: n.status,
        permissions: i,
        createdAt: n.createdAt,
        updatedAt: n.updatedAt
      };
    });
  }
  /**
   * Retrieves a single user by ID.
   */
  getUserById(e) {
    const t = this.userRepo.findById(e);
    return t ? this.toUserDto(t) : null;
  }
}
class Et extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "PhotoError";
  }
}
const gi = 10 * 1024 * 1024;
class Bu {
  constructor(e) {
    h(this, "mediaBaseDir");
    h(this, "studentsDir");
    this.mediaBaseDir = x.resolve(e), this.studentsDir = x.join(this.mediaBaseDir, "students"), this.ensureDirectoryExists(this.studentsDir);
  }
  ensureDirectoryExists(e) {
    z.existsSync(e) || z.mkdirSync(e, { recursive: !0 });
  }
  /**
   * Detects image format based on magic bytes.
   * Returns 'jpg', 'png', 'webp', or null if unsupported.
   */
  detectImageType(e) {
    return e.length < 12 ? null : e[0] === 255 && e[1] === 216 && e[2] === 255 ? "jpg" : e[0] === 137 && e[1] === 80 && e[2] === 78 && e[3] === 71 && e[4] === 13 && e[5] === 10 && e[6] === 26 && e[7] === 10 ? "png" : e[0] === 82 && // R
    e[1] === 73 && // I
    e[2] === 70 && // F
    e[3] === 70 && // F
    e[8] === 87 && // W
    e[9] === 69 && // E
    e[10] === 66 && // B
    e[11] === 80 ? "webp" : null;
  }
  /**
   * Copies an external image into Tibyan-managed student media storage.
   * Enforces file existence, size limits, content magic-bytes verification,
   * non-user-controlled destination naming, and path traversal rejection.
   */
  async saveStudentPhoto(e, t) {
    if (!e || typeof e != "string" || e.trim().length === 0 || /[\/\\]|\.\./.test(e))
      throw new Et("INVALID_INPUT", "Invalid student ID or path traversal attempt");
    if (!t || typeof t != "string" || t.trim().length === 0)
      throw new Et("INVALID_INPUT", "Source photo path cannot be empty");
    const s = x.resolve(t);
    let n;
    try {
      n = await z.promises.stat(s);
    } catch {
      throw new Et("INVALID_PHOTO", `Source photo file not found or inaccessible: ${t}`);
    }
    if (!n.isFile())
      throw new Et("INVALID_PHOTO", "Source photo path is not a regular file");
    if (n.size > gi)
      throw new Et(
        "PHOTO_TOO_LARGE",
        `Photo size (${n.size} bytes) exceeds maximum allowed limit (${gi} bytes)`
      );
    let i;
    try {
      const N = await z.promises.open(s, "r");
      i = Buffer.alloc(16), await N.read(i, 0, 16, 0), await N.close();
    } catch (N) {
      throw new Et("INVALID_PHOTO", `Failed to read photo header: ${N.message}`);
    }
    const a = this.detectImageType(i);
    if (!a)
      throw new Et(
        "INVALID_PHOTO",
        "Unsupported or corrupted image format. Only JPEG, PNG, and WebP are allowed."
      );
    const o = e.replace(/[^a-zA-Z0-9_-]/g, ""), d = b.randomUUID(), u = `${o}-${d}.${a}`, l = x.join(this.studentsDir, u), p = x.resolve(l);
    if (!p.startsWith(x.resolve(this.studentsDir)))
      throw new Et("INVALID_PHOTO", "Path traversal attempt detected in photo destination");
    try {
      this.ensureDirectoryExists(this.studentsDir), await z.promises.copyFile(s, p);
    } catch (N) {
      throw new Et("PHOTO_COPY_FAILED", `Failed to copy photo into managed storage: ${N.message}`);
    }
    return {
      relativePath: x.join("students", u).replace(/\\/g, "/"),
      fullPath: p
    };
  }
  /**
   * Safely deletes a previously managed student photo.
   * Strictly prevents deletion of files outside the managed students directory.
   */
  async deleteManagedPhoto(e) {
    if (!e) return;
    const t = x.resolve(this.mediaBaseDir, e), s = x.resolve(this.studentsDir);
    if (!t.startsWith(s))
      throw new Et(
        "INVALID_INPUT",
        "Cannot delete file outside of managed student media storage"
      );
    try {
      z.existsSync(t) && await z.promises.unlink(t);
    } catch {
    }
  }
  /**
   * Resolves a relative managed photo path to an absolute filesystem path.
   */
  resolveFullPath(e) {
    const t = x.resolve(this.mediaBaseDir, e), s = x.resolve(this.studentsDir);
    if (!t.startsWith(s))
      throw new Et(
        "INVALID_INPUT",
        "Cannot resolve path outside of managed student media storage"
      );
    return t;
  }
}
class tt extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "StudentError";
  }
}
class hp {
  constructor(e, t = new Bu("./media")) {
    h(this, "studentRepo");
    h(this, "auditRepo");
    this.db = e, this.photoService = t, this.studentRepo = new Ct(this.db), this.auditRepo = new me(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  toStudentDto(e) {
    return {
      id: e.id,
      studentCode: e.studentCode,
      fullName: e.fullName,
      photoPath: e.photoPath,
      educationSystem: e.educationSystem,
      gradeLevel: e.gradeLevel,
      languageTrack: e.languageTrack,
      guardianPhone: e.guardianPhone,
      status: e.status,
      qrToken: e.qrToken,
      barcodeValue: e.barcodeValue,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  toStudentNoteDto(e) {
    return {
      id: e.id,
      studentId: e.studentId,
      authorUserId: e.authorUserId,
      authorNameSnapshot: e.authorNameSnapshot,
      noteText: e.noteText,
      tag: e.tag,
      createdAt: e.createdAt
    };
  }
  parseSchema(e, t) {
    try {
      return e.parse(t);
    } catch (s) {
      throw new tt("INVALID_INPUT", s.message || "Invalid input");
    }
  }
  checkPermission(e, t) {
    try {
      te(e.role, e.permissions ?? [], t);
    } catch (s) {
      throw new tt("PERMISSION_DENIED", s.message || `Permission denied: ${t}`);
    }
  }
  isStudentCodeCollisionError(e) {
    if (!e || typeof e != "object") return !1;
    const t = e, s = t.code, n = typeof t.message == "string" ? t.message : "";
    return (s === "SQLITE_CONSTRAINT_UNIQUE" || s === "SQLITE_CONSTRAINT") && (n.includes("students.student_code") || n.includes("student_code") || n.includes("students.barcode_value") || n.includes("barcode_value"));
  }
  /**
   * Generates a unique, human-friendly student code with collision resistance.
   */
  generateUniqueStudentCode(e, t = 0) {
    const s = e.list().length + 1 + t;
    for (let n = 0; n < 20; n++) {
      const a = `TB-${(s + n).toString().padStart(4, "0")}`;
      if (!e.findByCode(a))
        return a;
    }
    for (let n = 0; n < 25; n++) {
      const a = `TB-${Math.floor(1e3 + Math.random() * 9e3)}`;
      if (!e.findByCode(a))
        return a;
    }
    throw new tt("STUDENT_CODE_CONFLICT", "Unable to allocate a unique student code");
  }
  /**
   * Creates a new student and generates immutable/unique identifiers (studentCode, qrToken, barcodeValue).
   */
  async createStudent(e, t) {
    const s = this.parseSchema(tm, e);
    this.checkPermission(t, "STUDENTS_WRITE");
    const n = b.randomUUID();
    let i = null;
    if (s.photoPath)
      try {
        i = (await this.photoService.saveStudentPhoto(n, s.photoPath)).relativePath;
      } catch (u) {
        throw new tt(u.code || "INVALID_PHOTO", u.message);
      }
    const a = (/* @__PURE__ */ new Date()).toISOString(), o = 5;
    let d = null;
    try {
      for (let u = 0; u < o; u++)
        try {
          const l = this.client.transaction((p) => {
            const S = new Ct(p), N = new me(p), y = this.generateUniqueStudentCode(S, u), I = b.randomBytes(16).toString("hex"), L = y, w = S.create({
              id: n,
              studentCode: y,
              fullName: s.fullName.trim(),
              photoPath: i,
              educationSystem: s.educationSystem,
              gradeLevel: s.gradeLevel,
              languageTrack: s.languageTrack,
              guardianPhone: s.guardianPhone,
              status: "ACTIVE",
              qrToken: I,
              barcodeValue: L,
              createdAt: a,
              updatedAt: a
            });
            return s.initialNote && s.initialNote.trim().length > 0 && S.addNote({
              id: b.randomUUID(),
              studentId: n,
              authorUserId: t.userId,
              authorNameSnapshot: t.fullName,
              noteText: s.initialNote.trim(),
              tag: "GENERAL",
              createdAt: a
            }), N.insert({
              id: b.randomUUID(),
              actorType: "USER",
              actorUserId: t.userId,
              actorNameSnapshot: t.fullName,
              action: "STUDENT_CREATED",
              entityType: "STUDENT",
              entityId: n,
              beforeJson: null,
              afterJson: JSON.stringify(this.toStudentDto(w)),
              metadataJson: JSON.stringify({
                studentCode: y,
                educationSystem: w.educationSystem,
                gradeLevel: w.gradeLevel,
                languageTrack: w.languageTrack
              }),
              createdAt: a
            }), w;
          });
          return this.toStudentDto(l);
        } catch (l) {
          if (this.isStudentCodeCollisionError(l)) {
            d = l;
            continue;
          }
          throw l;
        }
      throw new tt(
        "STUDENT_CODE_CONFLICT",
        `Exhausted collision retry budget for studentCode: ${(d == null ? void 0 : d.message) || "repeated constraint violations"}`
      );
    } catch (u) {
      throw i && await this.photoService.deleteManagedPhoto(i), u;
    }
  }
  /**
   * Updates student details, photo, or status.
   */
  async updateStudent(e, t) {
    const s = this.parseSchema(nm, e);
    this.checkPermission(t, "STUDENTS_WRITE");
    const n = this.studentRepo.findById(s.studentId);
    if (!n)
      throw new tt("STUDENT_NOT_FOUND", `Student not found: ${s.studentId}`);
    if (s.status && s.status !== "ACTIVE" && s.status !== "INACTIVE")
      throw new tt("INVALID_STUDENT_STATUS_TRANSITION", `Unsupported student status: ${s.status}`);
    let i = null, a = n.photoPath;
    if (s.photoPath !== void 0) {
      if (s.photoPath === null)
        a = null;
      else if (s.photoPath !== n.photoPath)
        try {
          i = (await this.photoService.saveStudentPhoto(n.id, s.photoPath)).relativePath, a = i;
        } catch (u) {
          throw new tt(u.code || "INVALID_PHOTO", u.message);
        }
    }
    const o = (/* @__PURE__ */ new Date()).toISOString(), d = a !== n.photoPath ? n.photoPath : null;
    try {
      const u = this.client.transaction((l) => {
        const p = new Ct(l), S = new me(l), N = {
          updatedAt: o
        };
        s.fullName !== void 0 && (N.fullName = s.fullName.trim()), s.educationSystem !== void 0 && (N.educationSystem = s.educationSystem), s.gradeLevel !== void 0 && (N.gradeLevel = s.gradeLevel), s.languageTrack !== void 0 && (N.languageTrack = s.languageTrack), s.guardianPhone !== void 0 && (N.guardianPhone = s.guardianPhone), s.status !== void 0 && (N.status = s.status), s.photoPath !== void 0 && (N.photoPath = a);
        const y = p.update(n.id, N), I = Object.keys(N).filter((P) => P !== "updatedAt"), L = I.length === 1 && I[0] === "photoPath", w = L ? "STUDENT_PHOTO_CHANGED" : "STUDENT_UPDATED";
        return S.insert({
          id: b.randomUUID(),
          actorType: "USER",
          actorUserId: t.userId,
          actorNameSnapshot: t.fullName,
          action: w,
          entityType: "STUDENT",
          entityId: n.id,
          beforeJson: JSON.stringify(this.toStudentDto(n)),
          afterJson: JSON.stringify(this.toStudentDto(y)),
          metadataJson: JSON.stringify(
            L ? { oldPhotoPath: n.photoPath, newPhotoPath: a } : { updatedFields: I }
          ),
          createdAt: o
        }), y;
      });
      return d && await this.photoService.deleteManagedPhoto(d), this.toStudentDto(u);
    } catch (u) {
      throw i && await this.photoService.deleteManagedPhoto(i), u;
    }
  }
  /**
   * Retrieves a student by ID.
   */
  async getStudentById(e, t) {
    this.checkPermission(t, "STUDENTS_READ");
    const s = this.studentRepo.findById(e);
    if (!s)
      throw new tt("STUDENT_NOT_FOUND", `Student not found: ${e}`);
    return this.toStudentDto(s);
  }
  /**
   * Searches and filters students.
   */
  async searchStudents(e, t) {
    const s = this.parseSchema(tu, e);
    return this.checkPermission(t, "STUDENTS_READ"), this.studentRepo.list({
      searchQuery: s.searchQuery,
      status: s.status,
      gradeLevel: s.gradeLevel,
      educationSystem: s.educationSystem,
      languageTrack: s.languageTrack
    }).map((i) => this.toStudentDto(i));
  }
  /**
   * Sets student status (soft-state transition: ACTIVE <-> INACTIVE).
   */
  async setStudentStatus(e, t, s) {
    if (this.checkPermission(s, "STUDENTS_WRITE"), t !== "ACTIVE" && t !== "INACTIVE")
      throw new tt("INVALID_STUDENT_STATUS_TRANSITION", `Unsupported student status: ${t}`);
    const n = this.studentRepo.findById(e);
    if (!n)
      throw new tt("STUDENT_NOT_FOUND", `Student not found: ${e}`);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new Ct(o), u = new me(o), l = d.update(e, {
        status: t,
        updatedAt: i
      });
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: s.userId,
        actorNameSnapshot: s.fullName,
        action: "STUDENT_STATUS_CHANGED",
        entityType: "STUDENT",
        entityId: e,
        beforeJson: JSON.stringify(this.toStudentDto(n)),
        afterJson: JSON.stringify(this.toStudentDto(l)),
        metadataJson: JSON.stringify({
          oldStatus: n.status,
          newStatus: t
        }),
        createdAt: i
      }), l;
    });
    return this.toStudentDto(a);
  }
  /**
   * Adds an academic or behavioral note to a student.
   */
  async addStudentNote(e, t) {
    const s = this.parseSchema(eu, e);
    if (this.checkPermission(t, "STUDENTS_WRITE"), !this.studentRepo.findById(s.studentId))
      throw new tt("STUDENT_NOT_FOUND", `Student not found: ${s.studentId}`);
    const i = b.randomUUID(), a = (/* @__PURE__ */ new Date()).toISOString(), o = this.client.transaction((d) => {
      const u = new Ct(d), l = new me(d), p = u.addNote({
        id: i,
        studentId: s.studentId,
        authorUserId: t.userId,
        authorNameSnapshot: t.fullName,
        noteText: s.noteText.trim(),
        tag: s.tag,
        createdAt: a
      });
      return l.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "STUDENT_NOTE_ADDED",
        entityType: "STUDENT",
        entityId: s.studentId,
        beforeJson: null,
        afterJson: JSON.stringify(this.toStudentNoteDto(p)),
        metadataJson: JSON.stringify({
          noteId: i,
          tag: s.tag
        }),
        createdAt: a
      }), p;
    });
    return this.toStudentNoteDto(o);
  }
  /**
   * Lists cumulative notes for a student.
   */
  async listStudentNotes(e, t) {
    if (this.checkPermission(t, "STUDENTS_READ"), !this.studentRepo.findById(e))
      throw new tt("STUDENT_NOT_FOUND", `Student not found: ${e}`);
    return this.studentRepo.getNotes(e).map((i) => this.toStudentNoteDto(i));
  }
  /**
   * Sets or clears a student's photo using managed photo storage.
   */
  async setStudentPhoto(e, t, s) {
    return this.updateStudent({ studentId: e, photoPath: t }, s);
  }
}
function _i(r, e) {
  const t = e.paymentTypeOverride !== null && e.paymentTypeOverride !== void 0, s = e.paymentAmountOverride !== null && e.paymentAmountOverride !== void 0;
  return {
    paymentType: t ? e.paymentTypeOverride : r.defaultPaymentType,
    amount: s ? e.paymentAmountOverride : r.defaultPaymentAmount,
    isOverridden: t || s
  };
}
class wt extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "GroupError";
  }
}
class mp {
  constructor(e, t = new Mn(), s) {
    h(this, "groupRepo");
    h(this, "enrollmentRepo");
    h(this, "sessionRepo");
    h(this, "auditRepo");
    this.db = e, this.dateProvider = t, this.onScheduleChanged = s, this.groupRepo = new mt(this.db), this.enrollmentRepo = new Ut(this.db), this.sessionRepo = new ht(this.db), this.auditRepo = new me(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  parseSchema(e, t) {
    try {
      return e.parse(t);
    } catch (s) {
      throw new wt("INVALID_INPUT", s.message || "Validation error");
    }
  }
  checkPermission(e, t) {
    try {
      te(e.role, e.permissions ?? [], t);
    } catch (s) {
      throw new wt("PERMISSION_DENIED", s.message || `Permission denied: ${t}`);
    }
  }
  validateSlots(e) {
    const t = /* @__PURE__ */ new Set();
    for (const s of e) {
      if ((s.durationMinutes ?? 120) <= 0)
        throw new wt("INVALID_SCHEDULE", "Duration must be greater than 0 minutes");
      const i = `${s.weekday}_${s.startTime}`;
      if (t.has(i))
        throw new wt(
          "DUPLICATE_SCHEDULE_SLOT",
          `Duplicate schedule slot for weekday ${s.weekday} at ${s.startTime}`
        );
      t.add(i);
    }
  }
  toScheduleSlotDto(e) {
    return {
      id: e.id,
      groupId: e.groupId,
      weekday: e.weekday,
      startTime: e.startTime,
      durationMinutes: e.durationMinutes,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  toGroupDto(e, t, s) {
    const n = t ?? this.groupRepo.getSchedules(e.id), i = s !== void 0 ? s : this.enrollmentRepo.listByGroup(e.id, !0).length;
    return {
      id: e.id,
      name: e.name,
      educationSystem: e.educationSystem,
      gradeLevel: e.gradeLevel,
      languageTrack: e.languageTrack,
      focusMathBranch: e.focusMathBranch,
      defaultPaymentType: e.defaultPaymentType,
      defaultPaymentAmount: e.defaultPaymentAmount,
      status: e.status,
      schedules: n.map((a) => this.toScheduleSlotDto(a)),
      enrolledCount: i,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  /**
   * Creates a new Group with optional recurring weekly schedules.
   */
  async createGroup(e, t) {
    const s = this.parseSchema(nu, e);
    this.checkPermission(t, "GROUPS_WRITE"), s.schedules && s.schedules.length > 0 && this.validateSlots(s.schedules);
    const n = b.randomUUID(), i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new mt(o), u = new me(o), l = d.create({
        id: n,
        name: s.name.trim(),
        educationSystem: s.educationSystem,
        gradeLevel: s.gradeLevel,
        languageTrack: s.languageTrack,
        focusMathBranch: s.focusMathBranch,
        defaultPaymentType: s.defaultPaymentType,
        defaultPaymentAmount: s.defaultPaymentAmount,
        status: "ACTIVE",
        createdAt: i,
        updatedAt: i
      }), p = [];
      if (s.schedules && s.schedules.length > 0)
        for (const S of s.schedules) {
          const N = d.addSchedule({
            id: b.randomUUID(),
            groupId: n,
            weekday: S.weekday,
            startTime: S.startTime.trim(),
            durationMinutes: S.durationMinutes,
            createdAt: i,
            updatedAt: i
          });
          p.push(N);
        }
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "GROUP_CREATED",
        entityType: "GROUP",
        entityId: n,
        beforeJson: null,
        afterJson: JSON.stringify(this.toGroupDto(l, p, 0)),
        metadataJson: JSON.stringify({
          name: l.name,
          educationSystem: l.educationSystem,
          gradeLevel: l.gradeLevel,
          defaultPaymentType: l.defaultPaymentType,
          defaultPaymentAmount: l.defaultPaymentAmount,
          scheduleCount: p.length
        }),
        createdAt: i
      }), { groupRow: l, insertedSchedules: p };
    });
    return this.onScheduleChanged && a.insertedSchedules.length > 0 && await this.onScheduleChanged(n, t), this.toGroupDto(a.groupRow, a.insertedSchedules, 0);
  }
  /**
   * Updates an existing group's metadata or default payment terms.
   */
  async updateGroup(e, t) {
    const s = this.parseSchema(ru, e);
    this.checkPermission(t, "GROUPS_WRITE");
    const n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new wt("GROUP_NOT_FOUND", `Group not found: ${s.groupId}`);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new mt(o), u = new me(o), l = {
        updatedAt: i
      };
      s.name !== void 0 && (l.name = s.name.trim()), s.educationSystem !== void 0 && (l.educationSystem = s.educationSystem), s.gradeLevel !== void 0 && (l.gradeLevel = s.gradeLevel), s.languageTrack !== void 0 && (l.languageTrack = s.languageTrack), s.focusMathBranch !== void 0 && (l.focusMathBranch = s.focusMathBranch), s.defaultPaymentType !== void 0 && (l.defaultPaymentType = s.defaultPaymentType), s.defaultPaymentAmount !== void 0 && (l.defaultPaymentAmount = s.defaultPaymentAmount), s.status !== void 0 && (l.status = s.status);
      const p = d.update(n.id, l), S = Object.keys(l).filter((I) => I !== "updatedAt"), y = S.length === 1 && l.status === "ARCHIVED" ? "GROUP_ARCHIVED" : "GROUP_UPDATED";
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: y,
        entityType: "GROUP",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toGroupDto(n)),
        afterJson: JSON.stringify(this.toGroupDto(p)),
        metadataJson: JSON.stringify({ updatedFields: S }),
        createdAt: i
      }), p;
    });
    return this.toGroupDto(a);
  }
  /**
   * Soft-archives a group. Does not physically delete rows or historical sessions.
   */
  async archiveGroup(e, t) {
    return this.updateGroup({ groupId: e, status: "ARCHIVED" }, t);
  }
  /**
   * Retrieves a group by ID.
   */
  async getGroupById(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.groupRepo.findById(e);
    if (!s)
      throw new wt("GROUP_NOT_FOUND", `Group not found: ${e}`);
    return this.toGroupDto(s);
  }
  /**
   * Lists and filters groups.
   */
  async listGroups(e, t) {
    return this.checkPermission(t, "GROUPS_READ"), this.groupRepo.list({
      status: e.status,
      gradeLevel: e.gradeLevel,
      educationSystem: e.educationSystem,
      languageTrack: e.languageTrack
    }).map((n) => this.toGroupDto(n));
  }
  /**
   * Replaces a group's recurring weekly schedules.
   * Prunes only future untouched SCHEDULED sessions and materializes the new slots.
   */
  async setWeeklySchedule(e, t) {
    const s = this.parseSchema(iu, e);
    this.checkPermission(t, "GROUPS_WRITE");
    const n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new wt("GROUP_NOT_FOUND", `Group not found: ${s.groupId}`);
    if (n.status === "ARCHIVED")
      throw new wt("GROUP_ARCHIVED", "Cannot modify weekly schedule for an archived group");
    this.validateSlots(s.slots);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.dateProvider.today(), o = this.dateProvider.nowTime(), d = this.client.transaction((u) => {
      const l = new mt(u), p = new ht(u), S = new me(u), N = p.deleteUntouchedFutureScheduledSessions(
        n.id,
        a,
        o
      );
      l.deleteSchedulesByGroup(n.id);
      const y = [];
      for (const I of s.slots) {
        const L = l.addSchedule({
          id: I.id ?? b.randomUUID(),
          groupId: n.id,
          weekday: I.weekday,
          startTime: I.startTime.trim(),
          durationMinutes: I.durationMinutes,
          createdAt: i,
          updatedAt: i
        });
        y.push(L);
      }
      return S.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "GROUP_SCHEDULE_CHANGED",
        entityType: "GROUP",
        entityId: n.id,
        beforeJson: null,
        afterJson: JSON.stringify(y.map((I) => this.toScheduleSlotDto(I))),
        metadataJson: JSON.stringify({
          slotCount: y.length,
          purgedUntouchedFutureSessions: N
        }),
        createdAt: i
      }), y;
    });
    return this.onScheduleChanged && await this.onScheduleChanged(n.id, t), d.map((u) => this.toScheduleSlotDto(u));
  }
  /**
   * Lists weekly schedule slots for a group.
   */
  async listWeeklySchedule(e, t) {
    if (this.checkPermission(t, "GROUPS_READ"), !this.groupRepo.findById(e))
      throw new wt("GROUP_NOT_FOUND", `Group not found: ${e}`);
    return this.groupRepo.getSchedules(e).map((i) => this.toScheduleSlotDto(i));
  }
}
class ke extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "EnrollmentError";
  }
}
class pp {
  constructor(e) {
    h(this, "groupRepo");
    h(this, "studentRepo");
    h(this, "enrollmentRepo");
    h(this, "auditRepo");
    this.db = e, this.groupRepo = new mt(this.db), this.studentRepo = new Ct(this.db), this.enrollmentRepo = new Ut(this.db), this.auditRepo = new me(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  parseSchema(e, t) {
    try {
      return e.parse(t);
    } catch (s) {
      throw new ke("INVALID_INPUT", s.message || "Validation error");
    }
  }
  checkPermission(e, t) {
    try {
      te(e.role, e.permissions ?? [], t);
    } catch (s) {
      throw new ke(
        "PERMISSION_DENIED",
        s.message || `Permission denied: ${t}`
      );
    }
  }
  toEnrollmentDto(e, t, s, n) {
    const i = this.groupRepo.findById(e.groupId);
    let a;
    return i && (a = _i(
      {
        defaultPaymentType: i.defaultPaymentType,
        defaultPaymentAmount: i.defaultPaymentAmount
      },
      {
        paymentTypeOverride: e.paymentTypeOverride,
        paymentAmountOverride: e.paymentAmountOverride
      }
    )), {
      id: e.id,
      groupId: e.groupId,
      groupName: t ?? (i == null ? void 0 : i.name),
      studentId: e.studentId,
      studentName: s,
      studentCode: n,
      enrolledAt: e.enrolledAt,
      leftAt: e.leftAt,
      status: e.status,
      paymentTypeOverride: e.paymentTypeOverride,
      paymentAmountOverride: e.paymentAmountOverride,
      effectivePaymentType: a == null ? void 0 : a.paymentType,
      effectivePaymentAmount: a == null ? void 0 : a.amount,
      isPaymentOverridden: a == null ? void 0 : a.isOverridden,
      createdAt: e.createdAt
    };
  }
  /**
   * Enrolls a student into a group after strict validation of compatibility, active status,
   * and absence of duplicate active enrollments.
   */
  async enrollStudent(e, t) {
    const s = this.parseSchema(au, e);
    this.checkPermission(t, "GROUPS_WRITE");
    const n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new ke("GROUP_NOT_FOUND", `Group not found: ${s.groupId}`);
    if (n.status === "ARCHIVED")
      throw new ke("GROUP_ARCHIVED", "Cannot enroll into an archived group");
    const i = this.studentRepo.findById(s.studentId);
    if (!i)
      throw new ke("STUDENT_NOT_FOUND", `Student not found: ${s.studentId}`);
    if (i.status === "INACTIVE")
      throw new ke("STUDENT_INACTIVE", "Cannot enroll an inactive student");
    if (i.educationSystem !== n.educationSystem)
      throw new ke(
        "STUDENT_GROUP_MISMATCH",
        `Education system mismatch: student is ${i.educationSystem}, group is ${n.educationSystem}`
      );
    if (i.gradeLevel !== n.gradeLevel)
      throw new ke(
        "STUDENT_GROUP_MISMATCH",
        `Grade level mismatch: student is ${i.gradeLevel}, group is ${n.gradeLevel}`
      );
    if (i.languageTrack !== n.languageTrack)
      throw new ke(
        "STUDENT_GROUP_MISMATCH",
        `Language track mismatch: student is ${i.languageTrack}, group is ${n.languageTrack}`
      );
    const a = this.enrollmentRepo.findActiveEnrollment(
      s.groupId,
      s.studentId
    );
    if (a)
      throw new ke(
        "ENROLLMENT_ALREADY_ACTIVE",
        `Student is already actively enrolled in this group (enrollment ID: ${a.id})`
      );
    const o = b.randomUUID(), d = (/* @__PURE__ */ new Date()).toISOString(), u = this.client.transaction((l) => {
      const p = new Ut(l), S = new me(l), N = p.create({
        id: o,
        groupId: s.groupId,
        studentId: s.studentId,
        enrolledAt: d,
        leftAt: null,
        status: "ACTIVE",
        paymentTypeOverride: s.paymentTypeOverride ?? null,
        paymentAmountOverride: s.paymentAmountOverride ?? null,
        createdAt: d
      }), y = this.toEnrollmentDto(
        N,
        n.name,
        i.fullName,
        i.studentCode
      );
      return S.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "STUDENT_ENROLLED",
        entityType: "ENROLLMENT",
        entityId: o,
        beforeJson: null,
        afterJson: JSON.stringify(y),
        metadataJson: JSON.stringify({
          groupId: s.groupId,
          groupName: n.name,
          studentId: s.studentId,
          studentName: i.fullName,
          studentCode: i.studentCode,
          paymentTypeOverride: s.paymentTypeOverride,
          paymentAmountOverride: s.paymentAmountOverride
        }),
        createdAt: d
      }), N;
    });
    return this.toEnrollmentDto(u, n.name, i.fullName, i.studentCode);
  }
  /**
   * Re-enrolls a student into a group. Creates a new ACTIVE record and preserves previous ENDED rows.
   */
  async reEnrollStudent(e, t) {
    return this.enrollStudent(e, t);
  }
  /**
   * Ends an active enrollment, recording the departure timestamp and preserving the history row.
   */
  async endEnrollment(e, t) {
    const s = this.parseSchema(du, e);
    this.checkPermission(t, "GROUPS_WRITE");
    const n = this.enrollmentRepo.findById(s.enrollmentId);
    if (!n)
      throw new ke(
        "ENROLLMENT_NOT_FOUND",
        `Enrollment not found: ${s.enrollmentId}`
      );
    if (n.status === "ENDED")
      return this.toEnrollmentDto(n);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new Ut(o), u = new me(o);
      d.endEnrollment(n.id, i);
      const l = d.findById(n.id);
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "ENROLLMENT_ENDED",
        entityType: "ENROLLMENT",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toEnrollmentDto(n)),
        afterJson: JSON.stringify(this.toEnrollmentDto(l)),
        metadataJson: JSON.stringify({
          reason: s.reason ?? null,
          leftAt: i
        }),
        createdAt: i
      }), l;
    });
    return this.toEnrollmentDto(a);
  }
  /**
   * Updates payment overrides on an existing enrollment row.
   */
  async updateEnrollmentPaymentTerms(e, t) {
    const s = this.parseSchema(ou, e);
    this.checkPermission(t, "GROUPS_WRITE");
    const n = this.enrollmentRepo.findById(s.enrollmentId);
    if (!n)
      throw new ke(
        "ENROLLMENT_NOT_FOUND",
        `Enrollment not found: ${s.enrollmentId}`
      );
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new Ut(o), u = new me(o), l = d.updatePaymentOverrides(
        n.id,
        s.paymentTypeOverride,
        s.paymentAmountOverride
      );
      return u.insert({
        id: b.randomUUID(),
        actorType: "USER",
        actorUserId: t.userId,
        actorNameSnapshot: t.fullName,
        action: "ENROLLMENT_PAYMENT_CHANGED",
        entityType: "ENROLLMENT",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toEnrollmentDto(n)),
        afterJson: JSON.stringify(this.toEnrollmentDto(l)),
        metadataJson: JSON.stringify({
          paymentTypeOverride: s.paymentTypeOverride,
          paymentAmountOverride: s.paymentAmountOverride
        }),
        createdAt: i
      }), l;
    });
    return this.toEnrollmentDto(a);
  }
  /**
   * Calculates the current effective payment terms for an enrollment.
   */
  async getEffectivePaymentTerms(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.enrollmentRepo.findById(e);
    if (!s)
      throw new ke("ENROLLMENT_NOT_FOUND", `Enrollment not found: ${e}`);
    const n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new ke("GROUP_NOT_FOUND", `Group not found: ${s.groupId}`);
    return _i(
      {
        defaultPaymentType: n.defaultPaymentType,
        defaultPaymentAmount: n.defaultPaymentAmount
      },
      {
        paymentTypeOverride: s.paymentTypeOverride,
        paymentAmountOverride: s.paymentAmountOverride
      }
    );
  }
  /**
   * Lists enrollments for a specific group.
   */
  async listGroupEnrollments(e, t = !1, s) {
    this.checkPermission(s, "GROUPS_READ");
    const n = this.groupRepo.findById(e);
    if (!n)
      throw new ke("GROUP_NOT_FOUND", `Group not found: ${e}`);
    return this.enrollmentRepo.listByGroup(e, t).map((a) => {
      const o = this.studentRepo.findById(a.studentId);
      return this.toEnrollmentDto(a, n.name, o == null ? void 0 : o.fullName, o == null ? void 0 : o.studentCode);
    });
  }
  /**
   * Lists enrollments for a specific student across all groups.
   */
  async listStudentEnrollments(e, t = !1, s) {
    this.checkPermission(s, "GROUPS_READ");
    const n = this.studentRepo.findById(e);
    if (!n)
      throw new ke("STUDENT_NOT_FOUND", `Student not found: ${e}`);
    return this.enrollmentRepo.listByStudent(e, t).map((a) => {
      const o = this.groupRepo.findById(a.groupId);
      return this.toEnrollmentDto(a, o == null ? void 0 : o.name, n.fullName, n.studentCode);
    });
  }
}
class ut extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "SessionError";
  }
}
function Me(r) {
  return r.actorType === "SYSTEM";
}
function fp(r, e) {
  return `${r}_${e}`;
}
function Ep(r) {
  if (!r) return !1;
  const e = String(r.message || ""), t = String(r.code || "");
  return (t === "SQLITE_CONSTRAINT_UNIQUE" || t === "SQLITE_CONSTRAINT") && e.includes("sessions.occurrence_key");
}
function Sp(r, e = 28) {
  const t = r.split("-").map(Number), s = t[0] ?? 2026, n = t[1] ?? 1, i = t[2] ?? 1, a = [];
  for (let o = 0; o < e; o++) {
    const d = new Date(Date.UTC(s, n - 1, i + o, 12, 0, 0)), u = d.getUTCFullYear(), l = String(d.getUTCMonth() + 1).padStart(2, "0"), p = String(d.getUTCDate()).padStart(2, "0");
    a.push({
      dateStr: `${u}-${l}-${p}`,
      weekday: d.getUTCDay()
      // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    });
  }
  return a;
}
class Mu {
  constructor(e, t = new Mn()) {
    h(this, "sessionRepo");
    h(this, "groupRepo");
    h(this, "enrollmentRepo");
    h(this, "auditRepo");
    this.db = e, this.dateProvider = t, this.sessionRepo = new ht(this.db), this.groupRepo = new mt(this.db), this.enrollmentRepo = new Ut(this.db), this.auditRepo = new me(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  parseSchema(e, t) {
    try {
      return e.parse(t);
    } catch (s) {
      throw new ut("INVALID_INPUT", s.message || "Validation error");
    }
  }
  checkPermission(e, t) {
    if (!Me(e))
      try {
        te(e.role, e.permissions ?? [], t);
      } catch (s) {
        throw new ut(
          "PERMISSION_DENIED",
          s.message || `Permission denied: ${t}`
        );
      }
  }
  toSessionDto(e, t) {
    const s = t ?? this.groupRepo.findById(e.groupId), n = this.enrollmentRepo.listByGroup(e.groupId, !0).length;
    return {
      id: e.id,
      groupId: e.groupId,
      groupName: (s == null ? void 0 : s.name) ?? "مجموعة غير معروفة",
      scheduleId: e.scheduleId,
      educationSystem: s == null ? void 0 : s.educationSystem,
      gradeLevel: s == null ? void 0 : s.gradeLevel,
      languageTrack: s == null ? void 0 : s.languageTrack,
      occurrenceKey: e.occurrenceKey,
      scheduledDate: e.scheduledDate,
      scheduledStartTime: e.scheduledStartTime,
      effectiveDate: e.effectiveDate,
      effectiveStartTime: e.effectiveStartTime,
      durationMinutes: e.durationMinutes,
      status: e.status,
      rescheduleReason: e.rescheduleReason,
      rescheduledAt: e.rescheduledAt,
      cancellationReason: e.cancellationReason ?? null,
      notes: e.notes,
      studentCount: n,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  /**
   * Materializes sessions over an exact 28-calendar-day rolling horizon (today through today + 27 days).
   * Deterministic and idempotent: skips any occurrenceKey that already exists in any status.
   * Concurrency-safe: handles concurrent INSERT-time collisions gracefully without swallowing unrelated errors.
   */
  async materializeRollingHorizon(e = {}, t) {
    var S, N;
    this.checkPermission(t, "SESSIONS_MANAGE");
    const s = e.horizonDays ?? 28, n = this.dateProvider.today(), i = Sp(n, s), a = ((S = i[0]) == null ? void 0 : S.dateStr) ?? n, o = ((N = i[i.length - 1]) == null ? void 0 : N.dateStr) ?? n;
    let d = [];
    if (e.groupId) {
      const y = this.groupRepo.findById(e.groupId);
      if (!y)
        throw new ut("GROUP_NOT_FOUND", `Group not found: ${e.groupId}`);
      if (y.status === "ARCHIVED")
        return { startDate: a, endDate: o, createdCount: 0, existingCount: 0 };
      d = [y];
    } else
      d = this.groupRepo.list({ status: "ACTIVE" });
    const u = (/* @__PURE__ */ new Date()).toISOString();
    let l = 0, p = 0;
    return this.client.transaction((y) => {
      const I = new ht(y), L = new mt(y), w = new me(y);
      for (const P of d) {
        const O = L.getSchedules(P.id);
        if (O.length !== 0) {
          for (const k of O)
            for (const { dateStr: B, weekday: ue } of i)
              if (k.weekday === ue) {
                const M = fp(k.id, B);
                if (I.findByOccurrenceKey(M)) {
                  p++;
                  continue;
                }
                try {
                  I.create({
                    id: b.randomUUID(),
                    groupId: P.id,
                    scheduleId: k.id,
                    occurrenceKey: M,
                    scheduledDate: B,
                    scheduledStartTime: k.startTime,
                    effectiveDate: B,
                    effectiveStartTime: k.startTime,
                    durationMinutes: k.durationMinutes,
                    status: "SCHEDULED",
                    rescheduleReason: null,
                    rescheduledAt: null,
                    cancellationReason: null,
                    notes: null,
                    createdAt: u,
                    updatedAt: u
                  }), l++;
                } catch (Se) {
                  if (Ep(Se)) {
                    p++;
                    continue;
                  }
                  throw Se;
                }
              }
        }
      }
      if (l > 0) {
        const P = Me(t);
        w.insert({
          id: b.randomUUID(),
          actorType: P ? "SYSTEM" : "USER",
          actorUserId: P ? null : t.userId,
          actorNameSnapshot: t.fullName,
          action: "SESSION_HORIZON_MATERIALIZED",
          entityType: "SESSION",
          entityId: e.groupId ?? "ALL_GROUPS",
          beforeJson: null,
          afterJson: JSON.stringify({ createdCount: l, existingCount: p, startDate: a, endDate: o }),
          metadataJson: JSON.stringify({
            startDate: a,
            endDate: o,
            createdCount: l,
            existingCount: p,
            groupsProcessed: d.length
          }),
          createdAt: u
        });
      }
    }), {
      startDate: a,
      endDate: o,
      createdCount: l,
      existingCount: p
    };
  }
  /**
   * Reschedules a single session to a new effective date and start time.
   * Keeps occurrenceKey, scheduledDate, and scheduledStartTime immutable.
   */
  async rescheduleSession(e, t) {
    const s = this.parseSchema(cu, e);
    this.checkPermission(t, "SESSIONS_MANAGE");
    const n = this.sessionRepo.findById(s.sessionId);
    if (!n)
      throw new ut("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (n.status === "COMPLETED" || n.status === "CANCELLED_BY_TEACHER")
      throw new ut(
        "SESSION_NOT_RESCHEDULABLE",
        `Cannot reschedule a session with status ${n.status}`
      );
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new ht(o), u = new me(o), l = d.update(n.id, {
        effectiveDate: s.newEffectiveDate,
        effectiveStartTime: s.newEffectiveStartTime,
        status: "RESCHEDULED",
        rescheduledAt: i,
        rescheduleReason: s.reason,
        updatedAt: i
      }), p = Me(t);
      return u.insert({
        id: b.randomUUID(),
        actorType: p ? "SYSTEM" : "USER",
        actorUserId: p ? null : t.userId,
        actorNameSnapshot: t.fullName,
        action: "SESSION_RESCHEDULED",
        entityType: "SESSION",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toSessionDto(n)),
        afterJson: JSON.stringify(this.toSessionDto(l)),
        metadataJson: JSON.stringify({
          newEffectiveDate: s.newEffectiveDate,
          newEffectiveStartTime: s.newEffectiveStartTime,
          reason: s.reason
        }),
        createdAt: i
      }), l;
    });
    return this.toSessionDto(a);
  }
  /**
   * Cancels a session (setting status = CANCELLED_BY_TEACHER).
   * Stores cancellation reason in the dedicated cancellationReason column.
   * Leaves general notes semantically untouched.
   * Preserves occurrenceKey and scheduled/effective times.
   */
  async cancelSession(e, t) {
    const s = this.parseSchema(uu, e);
    this.checkPermission(t, "SESSIONS_MANAGE");
    const n = this.sessionRepo.findById(s.sessionId);
    if (!n)
      throw new ut("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (n.status === "COMPLETED")
      throw new ut("SESSION_NOT_CANCELLABLE", "Cannot cancel a completed session");
    if (n.status === "CANCELLED_BY_TEACHER")
      return this.toSessionDto(n);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = this.client.transaction((o) => {
      const d = new ht(o), u = new me(o), l = d.update(n.id, {
        status: "CANCELLED_BY_TEACHER",
        cancellationReason: s.reason,
        // notes remain completely untouched and independent
        updatedAt: i
      }), p = Me(t);
      return u.insert({
        id: b.randomUUID(),
        actorType: p ? "SYSTEM" : "USER",
        actorUserId: p ? null : t.userId,
        actorNameSnapshot: t.fullName,
        action: "SESSION_CANCELLED",
        entityType: "SESSION",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toSessionDto(n)),
        afterJson: JSON.stringify(this.toSessionDto(l)),
        metadataJson: JSON.stringify({
          cancellationReason: s.reason
        }),
        createdAt: i
      }), l;
    });
    return this.toSessionDto(a);
  }
  /**
   * Completes a session (setting status = COMPLETED).
   * Updates notes if provided.
   * Atomically records ABSENT attendance records for all unmarked eligible enrolled students.
   * Atomically writes academic audit entries for session completion and each auto-absence record.
   */
  async completeSession(e, t) {
    const s = this.parseSchema(fu, e);
    this.checkPermission(t, "SESSIONS_MANAGE");
    const n = this.sessionRepo.findById(s.sessionId);
    if (!n)
      throw new ut("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (n.status === "CANCELLED_BY_TEACHER")
      throw new ut("SESSION_NOT_COMPLETABLE", "Cannot complete a cancelled session");
    if (n.status === "COMPLETED")
      return this.toSessionDto(n);
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = Me(t), o = a ? null : t.userId, d = this.client.transaction((u) => {
      const l = new ht(u), p = new me(u), S = new Ut(u), N = new nn(u), y = {
        status: "COMPLETED",
        updatedAt: i
      };
      s.notes !== void 0 && (y.notes = s.notes);
      const I = l.update(n.id, y);
      p.insert({
        id: b.randomUUID(),
        actorType: a ? "SYSTEM" : "USER",
        actorUserId: o,
        actorNameSnapshot: t.fullName,
        action: "SESSION_COMPLETED",
        entityType: "SESSION",
        entityId: n.id,
        beforeJson: JSON.stringify(this.toSessionDto(n)),
        afterJson: JSON.stringify(this.toSessionDto(I)),
        metadataJson: JSON.stringify({
          notes: s.notes ?? null
        }),
        createdAt: i
      });
      const L = S.listByGroup(n.groupId).filter((O) => !(O.enrolledAt.slice(0, 10) > n.effectiveDate || O.leftAt && O.leftAt.slice(0, 10) < n.effectiveDate)), w = N.listBySessionId(n.id), P = new Set(w.map((O) => O.studentId));
      for (const O of L)
        if (!P.has(O.studentId)) {
          const k = b.randomUUID(), B = N.upsert({
            id: k,
            sessionId: n.id,
            studentId: O.studentId,
            status: "ABSENT",
            arrivalTime: null,
            notes: "غياب تلقائي عند اكتمال الحصة",
            recordedByUserId: o,
            recordedAt: i,
            updatedAt: i
          });
          p.insert({
            id: b.randomUUID(),
            actorType: a ? "SYSTEM" : "USER",
            actorUserId: o,
            actorNameSnapshot: t.fullName,
            action: "ATTENDANCE_RECORDED",
            entityType: "ATTENDANCE",
            entityId: B.id,
            beforeJson: null,
            afterJson: JSON.stringify({
              id: B.id,
              sessionId: B.sessionId,
              studentId: B.studentId,
              status: B.status,
              arrivalTime: B.arrivalTime,
              notes: B.notes,
              recordedByUserId: B.recordedByUserId,
              recordedAt: B.recordedAt,
              updatedAt: B.updatedAt
            }),
            metadataJson: JSON.stringify({
              autoAbsenceOnCompletion: !0,
              sessionId: n.id,
              studentId: O.studentId
            }),
            createdAt: i
          });
        }
      return I;
    });
    return this.toSessionDto(d);
  }
  /**
   * Retrieves a single session by its unique ID.
   */
  async getSessionById(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.sessionRepo.findById(e);
    if (!s)
      throw new ut("SESSION_NOT_FOUND", `Session not found: ${e}`);
    return this.toSessionDto(s);
  }
  /**
   * Lists sessions within a date range (effectiveDate between startDate and endDate inclusive).
   */
  async listSessionsForDateRange(e, t) {
    const s = this.parseSchema(lu, e);
    return this.checkPermission(t, "GROUPS_READ"), this.sessionRepo.listByDateRange(
      s.startDate,
      s.endDate,
      s.groupId
    ).map((i) => this.toSessionDto(i));
  }
  /**
   * Regenerates future sessions for a group after schedule changes:
   * Prunes strictly future untouched SCHEDULED sessions and materializes the new slots across the 28-day horizon.
   */
  async regenerateFutureSessionsAfterScheduleChange(e, t) {
    this.checkPermission(t, "SESSIONS_MANAGE");
    const s = this.groupRepo.findById(e);
    if (!s)
      throw new ut("GROUP_NOT_FOUND", `Group not found: ${e}`);
    const n = this.dateProvider.today(), i = this.dateProvider.nowTime(), a = this.sessionRepo.deleteUntouchedFutureScheduledSessions(
      s.id,
      n,
      i
    ), o = await this.materializeRollingHorizon({ groupId: e }, t);
    return {
      removedCount: a,
      createdCount: o.createdCount
    };
  }
}
class Ye extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "BackupError";
  }
}
async function js(r) {
  return new Promise((e, t) => {
    const s = b.createHash("sha256"), n = z.createReadStream(r);
    n.on("data", (i) => s.update(i)), n.on("end", () => e(s.digest("hex"))), n.on("error", (i) => t(i));
  });
}
function Xs(r) {
  var t;
  let e = null;
  try {
    e = Ds(r);
    const s = e.pragma("integrity_check");
    if (!s || s.length === 0 || ((t = s[0]) == null ? void 0 : t.integrity_check) !== "ok") {
      const n = s && s[0] ? s[0].integrity_check : "Corrupted or unreadable database";
      throw new Error(n);
    }
  } catch (s) {
    throw s instanceof Ye ? s : new Ye(
      "BACKUP_INTEGRITY_FAILED",
      `PRAGMA integrity_check failed for ${x.basename(r)}: ${s.message}`
    );
  } finally {
    if (e)
      try {
        e.close();
      } catch {
      }
  }
}
class gp {
  constructor(e) {
    h(this, "appDataDir");
    h(this, "systemDbPath");
    h(this, "academicYearsDbDir");
    h(this, "mediaRootDir");
    h(this, "backupRootDir");
    h(this, "weeklyRetentionCount");
    h(this, "weeklyIntervalDays");
    h(this, "dateProvider");
    h(this, "systemDb");
    h(this, "systemDrizzle");
    h(this, "academicYearRepo");
    h(this, "backupRecordRepo");
    h(this, "systemAuditRepo");
    h(this, "getAcademicYearDbPath");
    h(this, "getAcademicYearMediaDir");
    h(this, "isRunning", !1);
    this.appDataDir = x.resolve(e.appDataDir), this.systemDbPath = x.resolve(
      e.systemDbPath ?? x.join(this.appDataDir, "data", "system", "tibyan-system.sqlite")
    ), this.academicYearsDbDir = x.resolve(
      e.academicYearsDbDir ?? x.join(this.appDataDir, "data", "academic-years")
    ), this.mediaRootDir = x.resolve(
      e.mediaRootDir ?? x.join(this.appDataDir, "media")
    ), this.backupRootDir = x.resolve(
      e.backupRootDir ?? x.join(this.appDataDir, "backups")
    ), this.weeklyRetentionCount = e.weeklyRetentionCount ?? 4, this.weeklyIntervalDays = e.weeklyIntervalDays ?? 7, this.dateProvider = e.dateProvider ?? new Mn(), this.systemDb = e.systemDb, this.systemDrizzle = e.systemDrizzle, this.academicYearRepo = e.academicYearRepo ?? new bc(), this.backupRecordRepo = e.backupRecordRepo ?? new gr(), this.systemAuditRepo = e.systemAuditRepo ?? new Te(), this.getAcademicYearDbPath = e.getAcademicYearDbPath ?? ((t) => x.join(this.academicYearsDbDir, t.dbFilename)), this.getAcademicYearMediaDir = e.getAcademicYearMediaDir ?? ((t) => x.join(this.mediaRootDir, t.name)), z.mkdirSync(x.join(this.backupRootDir, "weekly"), { recursive: !0 }), z.mkdirSync(x.join(this.backupRootDir, "archive"), { recursive: !0 }), z.mkdirSync(x.join(this.backupRootDir, "staging"), { recursive: !0 });
  }
  /**
   * Returns current status of local backups.
   */
  getBackupStatus() {
    const e = this.backupRecordRepo.listRecent(10), t = e[0] ?? null;
    return {
      lastBackupAt: t ? t.backupDate : null,
      lastBackupStatus: t ? t.status : null,
      totalBackupsCount: e.length,
      latestBackupSizeBytes: t ? t.sizeBytes : null,
      isBackupRunning: this.isRunning
    };
  }
  /**
   * Determines if a weekly backup is due based on the configured weekly interval (7 days).
   * - Only confirmed SUCCESS weekly or manual backups satisfy the interval.
   * - FAILED records NEVER suppress a due weekly backup.
   * - ARCHIVAL records NEVER suppress a due weekly backup.
   * - A successful manual backup resets the 7-day interval because it creates an identical full multi-year generation.
   */
  isWeeklyBackupDue() {
    const e = this.backupRecordRepo.listRecent(50), t = x.resolve(x.join(this.backupRootDir, "archive")), s = e.find((o) => o.status !== "SUCCESS" || x.resolve(o.backupPath).startsWith(t) || o.backupPath.includes("/archive/") || o.backupPath.includes("\\archive\\") ? !1 : z.existsSync(o.backupPath));
    if (!s)
      return !0;
    const n = new Date(s.backupDate || s.createdAt).getTime(), i = this.dateProvider.nowDate ? this.dateProvider.nowDate().getTime() : Date.now(), a = this.weeklyIntervalDays * 24 * 60 * 60 * 1e3;
    return i - n >= a;
  }
  /**
   * Executes a scheduled or automated weekly backup.
   * If initiated by a USER actor, requires BACKUP_MANAGE permission.
   * Automatic SYSTEM weekly backups (actor undefined/null) require no human permission.
   */
  async createWeeklyBackup(e) {
    return e && te(e.role, e.permissions ?? [], "BACKUP_MANAGE"), this.executeBackupGeneration({ backupType: "WEEKLY", actor: e });
  }
  /**
   * Executes an explicit manual backup using the identical verified multi-year engine.
   * Requires BACKUP_MANAGE permission.
   */
  async createManualBackup(e) {
    return te(e.role, e.permissions ?? [], "BACKUP_MANAGE"), this.executeBackupGeneration({ backupType: "MANUAL", actor: e });
  }
  /**
   * Creates a dedicated archival backup for a specific academic year before or during archiving.
   * If initiated by a USER, requires BACKUP_MANAGE permission.
   * Archival backups are placed in the separate 'archive' root and are never pruned by weekly retention.
   */
  async createAcademicYearArchiveBackup(e, t) {
    if (t && te(t.role, t.permissions ?? [], "BACKUP_MANAGE"), this.isRunning)
      throw new Ye("BACKUP_ALREADY_RUNNING", "A backup operation is already in progress");
    this.isRunning = !0;
    const s = b.randomUUID(), n = this.dateProvider.nowIso ? this.dateProvider.nowIso() : (/* @__PURE__ */ new Date()).toISOString(), i = x.join(this.backupRootDir, "staging", `staging_${s}`);
    let a = null;
    try {
      const o = this.academicYearRepo.findById(e) ?? this.academicYearRepo.findByName(e);
      if (!o)
        throw new Ye(
          "ACADEMIC_YEAR_NOT_FOUND",
          `Academic year not found for id/name: ${e}`
        );
      this.validateSafeName(o.name), z.mkdirSync(i, { recursive: !0 });
      const d = x.join(i, "system"), u = x.join(i, "academic-years"), l = x.join(i, "media", o.name);
      z.mkdirSync(d, { recursive: !0 }), z.mkdirSync(u, { recursive: !0 });
      const p = x.join(d, "tibyan-system.sqlite");
      await this.backupSystemDatabase(p), Xs(p);
      const S = z.statSync(p).size, N = await js(p), y = this.getAcademicYearDbPath(o), I = x.join(u, o.dbFilename);
      await this.backupAcademicDatabase(o, y, I), Xs(I);
      const L = z.statSync(I).size, w = await js(I), P = this.getAcademicYearMediaDir(o), O = await this.copyManagedMediaSafely(P, l), k = S + L + (z.existsSync(l) ? this.computeDirSize(l) : 0), B = {
        version: 1,
        createdAt: n,
        backupType: "ARCHIVAL",
        systemDatabase: {
          relativePath: "system/tibyan-system.sqlite",
          sizeBytes: S,
          checksumSha256: N
        },
        academicYears: [
          {
            id: o.id,
            name: o.name,
            dbFilename: o.dbFilename,
            databaseRelativePath: `academic-years/${o.dbFilename}`,
            databaseSizeBytes: L,
            databaseChecksumSha256: w,
            mediaRelativePath: O > 0 ? `media/${o.name}` : null,
            mediaFilesCount: O
          }
        ],
        totalSizeBytes: k
      };
      z.writeFileSync(
        x.join(i, "manifest.json"),
        JSON.stringify(B, null, 2),
        "utf8"
      );
      const ue = n.replace(/[:.]/g, "-"), M = `archive_${o.name}_${ue}_${s.slice(0, 8)}`, K = x.join(this.backupRootDir, "archive", M);
      if (z.existsSync(K))
        throw new Ye(
          "BACKUP_FAILED",
          `Target archival backup directory already exists: ${K}`
        );
      return z.renameSync(i, K), a = K, this.commitSuccess(
        {
          id: s,
          backupPath: K,
          backupDate: n,
          status: "SUCCESS",
          sizeBytes: k,
          academicYearsIncludedJson: JSON.stringify([o.name]),
          createdAt: n
        },
        {
          action: "ACADEMIC_YEAR_ARCHIVE_BACKUP_CREATED",
          entityId: s,
          metadata: {
            academicYearId: o.id,
            academicYearName: o.name,
            backupPath: K,
            sizeBytes: k
          }
        },
        t
      );
    } catch (o) {
      if (z.existsSync(i))
        try {
          z.rmSync(i, { recursive: !0, force: !0 });
        } catch {
        }
      if (a && z.existsSync(a))
        try {
          z.rmSync(a, { recursive: !0, force: !0 });
        } catch {
        }
      this.logAudit(
        "BACKUP_FAILED",
        s,
        { backupType: "ARCHIVAL", academicYearId: e, error: o.message },
        t
      );
      try {
        this.backupRecordRepo.create({
          id: s,
          backupPath: i,
          backupDate: n,
          status: "FAILED",
          sizeBytes: 0,
          academicYearsIncludedJson: JSON.stringify([e]),
          createdAt: n
        });
      } catch {
      }
      throw o;
    } finally {
      this.isRunning = !1;
    }
  }
  /**
   * Applies rolling weekly retention policy:
   * - Authoritative success definition: Requires BOTH a published directory with manifest.json
   *   AND a matching SUCCESS record in system backup_records.
   * - Directories in weekly/ lacking a SUCCESS backup record are orphans; they are safely quarantined/removed
   *   and NEVER counted toward the 4 known-good generations.
   * - Retains exactly the newest 4 confirmed successful generations.
   * - Archival backups are placed in 'archive/' and are strictly excluded from weekly retention.
   */
  applyWeeklyRetention() {
    const e = x.join(this.backupRootDir, "weekly");
    if (!z.existsSync(e)) return [];
    const t = this.backupRecordRepo.listRecent(100), s = /* @__PURE__ */ new Map();
    for (const d of t)
      d.status === "SUCCESS" && s.set(x.resolve(d.backupPath), d);
    const n = z.readdirSync(e, { withFileTypes: !0 }), i = [], a = [];
    for (const d of n)
      if (d.isDirectory()) {
        const u = x.resolve(x.join(e, d.name)), l = x.join(u, "manifest.json"), p = s.get(u);
        if (z.existsSync(l) && p) {
          const S = z.statSync(u);
          i.push({ fullPath: u, mtimeMs: S.mtimeMs });
        } else
          a.push(u);
      }
    const o = [];
    for (const d of a)
      try {
        z.rmSync(d, { recursive: !0, force: !0 }), o.push(d);
      } catch {
      }
    if (i.sort((d, u) => u.mtimeMs - d.mtimeMs), i.length > this.weeklyRetentionCount) {
      const d = i.slice(this.weeklyRetentionCount);
      for (const u of d)
        try {
          z.rmSync(u.fullPath, { recursive: !0, force: !0 }), o.push(u.fullPath);
        } catch {
        }
    }
    return o;
  }
  /**
   * Internal execution engine for weekly and manual generations.
   */
  async executeBackupGeneration(e) {
    if (this.isRunning)
      throw new Ye("BACKUP_ALREADY_RUNNING", "A backup operation is already in progress");
    this.isRunning = !0;
    const t = b.randomUUID(), s = this.dateProvider.nowIso ? this.dateProvider.nowIso() : (/* @__PURE__ */ new Date()).toISOString(), n = x.join(this.backupRootDir, "staging", `staging_${t}`);
    let i = null;
    try {
      z.mkdirSync(n, { recursive: !0 });
      const a = x.join(n, "system"), o = x.join(n, "academic-years"), d = x.join(n, "media");
      z.mkdirSync(a, { recursive: !0 }), z.mkdirSync(o, { recursive: !0 }), z.mkdirSync(d, { recursive: !0 });
      const u = x.join(a, "tibyan-system.sqlite");
      await this.backupSystemDatabase(u), Xs(u);
      const l = z.statSync(u).size, p = await js(u), S = this.academicYearRepo.listAll(), N = [], y = [];
      for (const B of S) {
        this.validateSafeName(B.name), y.push(B.name);
        const ue = this.getAcademicYearDbPath(B), M = x.join(o, B.dbFilename);
        await this.backupAcademicDatabase(B, ue, M), Xs(M);
        const K = z.statSync(M).size, Se = await js(M), Tt = this.getAcademicYearMediaDir(B), qe = x.join(d, B.name), He = await this.copyManagedMediaSafely(Tt, qe);
        N.push({
          id: B.id,
          name: B.name,
          dbFilename: B.dbFilename,
          databaseRelativePath: `academic-years/${B.dbFilename}`,
          databaseSizeBytes: K,
          databaseChecksumSha256: Se,
          mediaRelativePath: He > 0 ? `media/${B.name}` : null,
          mediaFilesCount: He
        });
      }
      const I = this.computeDirSize(n), L = {
        version: 1,
        createdAt: s,
        backupType: e.backupType,
        systemDatabase: {
          relativePath: "system/tibyan-system.sqlite",
          sizeBytes: l,
          checksumSha256: p
        },
        academicYears: N,
        totalSizeBytes: I
      };
      z.writeFileSync(
        x.join(n, "manifest.json"),
        JSON.stringify(L, null, 2),
        "utf8"
      );
      const P = `generation_${s.replace(/[:.]/g, "-")}_${t.slice(0, 8)}`, O = x.join(this.backupRootDir, "weekly", P);
      if (z.existsSync(O))
        throw new Ye(
          "BACKUP_FAILED",
          `Target weekly backup directory already exists: ${O}`
        );
      z.renameSync(n, O), i = O;
      const k = this.commitSuccess(
        {
          id: t,
          backupPath: O,
          backupDate: s,
          status: "SUCCESS",
          sizeBytes: I,
          academicYearsIncludedJson: JSON.stringify(y),
          createdAt: s
        },
        {
          action: "BACKUP_COMPLETED",
          entityId: t,
          metadata: {
            backupType: e.backupType,
            backupPath: O,
            sizeBytes: I,
            academicYearsCount: N.length
          }
        },
        e.actor
      );
      return this.applyWeeklyRetention(), k;
    } catch (a) {
      if (z.existsSync(n))
        try {
          z.rmSync(n, { recursive: !0, force: !0 });
        } catch {
        }
      if (i && z.existsSync(i))
        try {
          z.rmSync(i, { recursive: !0, force: !0 });
        } catch {
        }
      this.logAudit(
        "BACKUP_FAILED",
        t,
        { backupType: e.backupType, error: a.message },
        e.actor
      );
      try {
        this.backupRecordRepo.create({
          id: t,
          backupPath: n,
          backupDate: s,
          status: "FAILED",
          sizeBytes: 0,
          academicYearsIncludedJson: JSON.stringify([]),
          createdAt: s
        });
      } catch {
      }
      throw a;
    } finally {
      this.isRunning = !1;
    }
  }
  /**
   * Commits the SUCCESS backup_record and system_audit_log entry in ONE system SQLite transaction.
   */
  commitSuccess(e, t, s) {
    const n = this.dateProvider.nowIso ? this.dateProvider.nowIso() : (/* @__PURE__ */ new Date()).toISOString(), i = s ? "USER" : "SYSTEM", a = s ? s.userId : null, o = s ? s.fullName : "Automated Backup Engine", d = (l) => {
      const p = new gr(l), S = new Te(l), N = p.create(e);
      return S.insert({
        id: b.randomUUID(),
        actorType: i,
        actorUserId: a,
        actorNameSnapshot: o,
        action: t.action,
        entityType: "BACKUP",
        entityId: t.entityId,
        beforeJson: null,
        afterJson: null,
        metadataJson: t.metadata ? JSON.stringify(t.metadata) : null,
        createdAt: n
      }), N;
    };
    let u;
    return this.systemDrizzle ? u = this.systemDrizzle.transaction((l) => d(l)) : di() ? u = Jt().db.transaction((l) => d(l)) : this.systemDb && this.systemDb.open ? this.systemDb.transaction(() => {
      u = this.backupRecordRepo.create(e), this.systemAuditRepo && this.systemAuditRepo.insert({
        id: b.randomUUID(),
        actorType: i,
        actorUserId: a,
        actorNameSnapshot: o,
        action: t.action,
        entityType: "BACKUP",
        entityId: t.entityId,
        beforeJson: null,
        afterJson: null,
        metadataJson: t.metadata ? JSON.stringify(t.metadata) : null,
        createdAt: n
      });
    })() : (u = this.backupRecordRepo.create(e), this.systemAuditRepo && this.systemAuditRepo.insert({
      id: b.randomUUID(),
      actorType: i,
      actorUserId: a,
      actorNameSnapshot: o,
      action: t.action,
      entityType: "BACKUP",
      entityId: t.entityId,
      beforeJson: null,
      afterJson: null,
      metadataJson: t.metadata ? JSON.stringify(t.metadata) : null,
      createdAt: n
    })), {
      id: u.id,
      backupPath: u.backupPath,
      backupDate: u.backupDate,
      status: u.status,
      sizeBytes: u.sizeBytes,
      academicYearsIncluded: JSON.parse(u.academicYearsIncludedJson),
      createdAt: u.createdAt
    };
  }
  /**
   * Backs up system database via better-sqlite3 native backup API.
   */
  async backupSystemDatabase(e) {
    if (z.mkdirSync(x.dirname(e), { recursive: !0 }), this.systemDb && this.systemDb.open) {
      await this.systemDb.backup(e);
      return;
    }
    if (di()) {
      const s = Jt();
      if (s.raw.open) {
        await s.raw.backup(e);
        return;
      }
    }
    if (!z.existsSync(this.systemDbPath))
      throw new Ye(
        "BACKUP_SOURCE_MISSING",
        `System database source not found: ${this.systemDbPath}`
      );
    const t = Ds(this.systemDbPath);
    try {
      await t.backup(e);
    } catch (s) {
      throw new Ye(
        "BACKUP_FAILED",
        `System database SQLite backup failed: ${s.message}`
      );
    } finally {
      try {
        t.close();
      } catch {
      }
    }
  }
  /**
   * Backs up an academic database via better-sqlite3 native backup API.
   */
  async backupAcademicDatabase(e, t, s) {
    if (z.mkdirSync(x.dirname(s), { recursive: !0 }), ah()) {
      const i = Fe();
      if (i.academicYearName === e.name && i.raw.open) {
        await i.raw.backup(s);
        return;
      }
    }
    if (!z.existsSync(t))
      throw new Ye(
        "BACKUP_SOURCE_MISSING",
        `Academic database source not found for year '${e.name}': ${t}`
      );
    const n = Ds(t);
    try {
      await n.backup(s);
    } catch (i) {
      throw new Ye(
        "BACKUP_FAILED",
        `Academic database SQLite backup failed for year '${e.name}': ${i.message}`
      );
    } finally {
      try {
        n.close();
      } catch {
      }
    }
  }
  /**
   * Copies managed media for an academic year, strictly preventing symbolic link escapes.
   */
  async copyManagedMediaSafely(e, t) {
    const s = x.resolve(e), n = x.resolve(this.backupRootDir);
    if (s.startsWith(n) || n.startsWith(s))
      throw new Ye(
        "INVALID_BACKUP_PATH",
        "Source media directory cannot reside inside the backup directory"
      );
    if (!z.existsSync(e))
      return 0;
    let i = 0;
    const a = async (o, d) => {
      const u = await z.promises.readdir(o, { withFileTypes: !0 });
      for (const l of u) {
        const p = x.join(o, l.name), S = x.join(d, l.name);
        (await z.promises.lstat(p)).isSymbolicLink() && !(await z.promises.realpath(p)).startsWith(s) || (l.isDirectory() ? (await z.promises.mkdir(S, { recursive: !0 }), await a(p, S)) : l.isFile() && (await z.promises.mkdir(x.dirname(S), { recursive: !0 }), await z.promises.copyFile(p, S), i++));
      }
    };
    try {
      return await z.promises.mkdir(t, { recursive: !0 }), await a(s, t), i;
    } catch (o) {
      throw o instanceof Ye ? o : new Ye(
        "BACKUP_MEDIA_COPY_FAILED",
        `Failed to copy managed media from ${e}: ${o.message}`
      );
    }
  }
  /**
   * Validates that an academic year name does not contain path traversal characters.
   */
  validateSafeName(e) {
    if (!e || /[\/\\]|\.\./.test(e))
      throw new Ye(
        "INVALID_BACKUP_PATH",
        `Invalid academic year name containing illegal path traversal characters: ${e}`
      );
  }
  /**
   * Recursively computes the total size in bytes of a directory.
   */
  computeDirSize(e) {
    let t = 0;
    const s = (n) => {
      if (!z.existsSync(n)) return;
      const i = z.readdirSync(n, { withFileTypes: !0 });
      for (const a of i) {
        const o = x.join(n, a.name);
        a.isDirectory() ? s(o) : a.isFile() && (t += z.statSync(o).size);
      }
    };
    return s(e), t;
  }
  /**
   * Logs system audit events without exposing sensitive metadata.
   */
  logAudit(e, t, s, n) {
    if (!this.systemAuditRepo) return;
    const i = this.dateProvider.nowIso ? this.dateProvider.nowIso() : (/* @__PURE__ */ new Date()).toISOString(), a = n ? "USER" : "SYSTEM", o = n ? n.userId : null, d = n ? n.fullName : "Automated Backup Engine";
    try {
      this.systemAuditRepo.insert({
        id: b.randomUUID(),
        actorType: a,
        actorUserId: o,
        actorNameSnapshot: d,
        action: e,
        entityType: "BACKUP",
        entityId: t,
        beforeJson: null,
        afterJson: null,
        metadataJson: s ? JSON.stringify(s) : null,
        createdAt: i
      });
    } catch {
    }
  }
}
class Fu extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "DashboardError";
  }
}
const _p = {
  0: "الأحد",
  1: "الإثنين",
  2: "الثلاثاء",
  3: "الأربعاء",
  4: "الخميس",
  5: "الجمعة",
  6: "السبت"
};
function Np(r) {
  const e = r.split("-").map(Number), t = e[0], s = e[1], n = e[2], a = new Date(Date.UTC(t, s - 1, n, 12, 0, 0)).getUTCDay();
  return _p[a] ?? "";
}
class Ip {
  constructor(e, t) {
    h(this, "sessionRepo");
    h(this, "groupRepo");
    h(this, "enrollmentRepo");
    h(this, "studentRepo");
    h(this, "dateProvider");
    this.db = e, this.dateProvider = (t == null ? void 0 : t.dateProvider) ?? new Mn(), this.sessionRepo = (t == null ? void 0 : t.sessionRepo) ?? new ht(this.db), this.groupRepo = (t == null ? void 0 : t.groupRepo) ?? new mt(this.db), this.enrollmentRepo = (t == null ? void 0 : t.enrollmentRepo) ?? new Ut(this.db), this.studentRepo = (t == null ? void 0 : t.studentRepo) ?? new Ct(this.db);
  }
  /**
   * Aggregates the Today Dashboard for the current date or an explicitly requested calendar date.
   *
   * @param requestedDate Optional calendar date formatted as YYYY-MM-DD. Defaults to dateProvider.today().
   */
  async getTodayDashboard(e) {
    const t = e ?? this.dateProvider.today();
    if (!Vc(t))
      throw new Fu("INVALID_DATE", `Invalid calendar date: ${t}`);
    const s = Np(t), n = this.sessionRepo.listByEffectiveDate(t), i = Array.from(new Set(n.map((O) => O.groupId))), a = this.groupRepo.findByIds(i), o = new Map(a.map((O) => [O.id, O])), d = this.enrollmentRepo.countActiveByGroupIds(i), u = n.map((O) => {
      const k = o.get(O.groupId);
      if (!k)
        throw new Error(`Group not found for session: ${O.id} (group: ${O.groupId})`);
      const B = O.rescheduledAt !== null || O.scheduledDate !== O.effectiveDate || O.scheduledStartTime !== O.effectiveStartTime, ue = d.get(O.groupId) ?? 0;
      return {
        sessionId: O.id,
        groupId: O.groupId,
        groupName: k.name,
        educationSystem: k.educationSystem,
        gradeLevel: k.gradeLevel,
        languageTrack: k.languageTrack,
        effectiveStartTime: O.effectiveStartTime,
        durationMinutes: O.durationMinutes,
        status: O.status,
        isRescheduled: B,
        originalScheduledDate: O.scheduledDate,
        originalScheduledTime: O.scheduledStartTime,
        enrolledCount: ue
      };
    });
    u.sort((O, k) => O.effectiveStartTime !== k.effectiveStartTime ? O.effectiveStartTime.localeCompare(k.effectiveStartTime) : O.groupName !== k.groupName ? O.groupName.localeCompare(k.groupName) : O.groupId !== k.groupId ? O.groupId.localeCompare(k.groupId) : O.sessionId.localeCompare(k.sessionId));
    const l = u.filter((O) => O.status !== "CANCELLED_BY_TEACHER").reduce((O, k) => O + k.enrolledCount, 0), p = this.groupRepo.countActive(), S = this.enrollmentRepo.countDistinctActiveEnrolledStudents(), N = this.studentRepo.listFollowUpNotesWithActiveStudents(), y = /* @__PURE__ */ new Set(), I = [];
    for (const O of N)
      y.has(O.student.id) || (y.add(O.student.id), I.push({
        studentId: O.student.id,
        studentName: O.student.fullName,
        studentCode: O.student.studentCode,
        gradeLevel: O.student.gradeLevel,
        tag: O.note.tag,
        latestNote: O.note.noteText,
        createdAt: O.note.createdAt
      }));
    const L = I.map((O) => O.studentId), w = this.enrollmentRepo.getActiveGroupsForStudents(L), P = I.map((O) => {
      const k = w.get(O.studentId), B = k && k.length > 0 ? k[0].groupName : "";
      return {
        studentId: O.studentId,
        studentName: O.studentName,
        studentCode: O.studentCode,
        gradeLevel: O.gradeLevel,
        groupName: B,
        tag: O.tag,
        latestNote: O.latestNote,
        createdAt: O.createdAt
      };
    });
    return {
      currentDate: t,
      weekdayArabic: s,
      classes: u,
      totalStudentsExpectedToday: l,
      activeGroupsCount: p,
      totalEnrolledStudents: S,
      needsAttention: P
    };
  }
  /**
   * Alias for getTodayDashboard with an explicit calendar date.
   */
  async getDashboardForDate(e) {
    return this.getTodayDashboard(e);
  }
}
class Ge extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "AttendanceError";
  }
}
class yp {
  constructor(e) {
    h(this, "attendanceRepo");
    h(this, "sessionRepo");
    h(this, "groupRepo");
    h(this, "enrollmentRepo");
    h(this, "studentRepo");
    h(this, "auditRepo");
    h(this, "followUpRepo");
    h(this, "sessionService");
    this.db = e, this.attendanceRepo = new nn(this.db), this.followUpRepo = new ci(this.db), this.sessionRepo = new ht(this.db), this.groupRepo = new mt(this.db), this.enrollmentRepo = new Ut(this.db), this.studentRepo = new Ct(this.db), this.auditRepo = new me(this.db), this.sessionService = new Mu(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  checkPermission(e, t) {
    if (!Me(e))
      try {
        te(e.role, e.permissions ?? [], t);
      } catch (s) {
        throw new Ge(
          "PERMISSION_DENIED",
          s.message || `Permission denied: ${t}`
        );
      }
  }
  isStudentEnrolledOnDate(e, t) {
    return !(e.enrolledAt.slice(0, 10) > t || e.leftAt && e.leftAt.slice(0, 10) < t);
  }
  toSafePhotoUrl(e) {
    if (!e) return null;
    const t = e.trim().replace(/\\/g, "/");
    if (t.startsWith("/") || /^[a-zA-Z]:/.test(t) || t.startsWith("//") || t.includes("..") || t.toLowerCase().includes("appdata"))
      throw new Ge("INVALID_PHOTO_PATH", "Dangerous or absolute photoPath detected");
    return `tibyan-media://${t.startsWith("tibyan-media://") ? t.replace(/^tibyan-media:\/\//, "") : t}`;
  }
  /**
   * Retrieves the full roster for a session, including active enrolled students as of
   * session.effectiveDate, any recorded attendance entries, and an aggregate summary count.
   * Roster data is minimized (no financial or guardian phone data exposed).
   */
  async getSessionRoster(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = await this.sessionService.getSessionById(e, t), n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new Ge("SESSION_NOT_FOUND", `Group not found for session: ${e}`);
    const i = this.enrollmentRepo.listByGroup(s.groupId).filter((y) => this.isStudentEnrolledOnDate(y, s.effectiveDate)), a = this.attendanceRepo.listBySessionId(e), o = /* @__PURE__ */ new Map();
    for (const y of a)
      o.set(y.studentId, y);
    const d = [];
    let u = 0, l = 0, p = 0, S = 0, N = 0;
    for (const y of i) {
      const I = this.studentRepo.findById(y.studentId);
      if (!I) continue;
      const L = o.get(I.id);
      let w = null;
      L ? (w = this.toAttendanceRecordDto(L), L.status === "PRESENT" ? u++ : L.status === "ABSENT" ? l++ : L.status === "LATE" ? p++ : L.status === "EXCUSED" && S++) : N++, d.push({
        studentId: I.id,
        studentCode: I.studentCode,
        studentName: I.fullName,
        photoUrl: this.toSafePhotoUrl(I.photoPath),
        enrollmentId: y.id,
        attendanceRecord: w
      });
    }
    return d.sort((y, I) => y.studentName.localeCompare(I.studentName, "ar")), {
      session: s,
      groupName: n.name,
      roster: d,
      summary: {
        totalStudents: d.length,
        present: u,
        absent: l,
        late: p,
        excused: S,
        unmarked: N
      }
    };
  }
  /**
   * Records or updates attendance for a single student in a session.
   * Validates temporal enrollment and rejects cancelled sessions.
   * Atomically logs mutation to academic audit log.
   */
  async recordAttendance(e, t) {
    this.checkPermission(t, "ATTENDANCE_WRITE");
    const s = mu.parse(e), n = this.sessionRepo.findById(s.sessionId);
    if (!n)
      throw new Ge("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (n.status === "CANCELLED_BY_TEACHER")
      throw new Ge("SESSION_CANCELLED", "Cannot record attendance for a cancelled session");
    if (!this.studentRepo.findById(s.studentId))
      throw new Ge("STUDENT_NOT_FOUND", `Student not found: ${s.studentId}`);
    if (this.enrollmentRepo.listByGroup(n.groupId).filter((N) => N.studentId === s.studentId && this.isStudentEnrolledOnDate(N, n.effectiveDate)).length === 0)
      throw new Ge(
        "STUDENT_NOT_ENROLLED",
        `Student is not enrolled in this group on session date ${n.effectiveDate}`
      );
    let o = null;
    if (s.status === "LATE") {
      if (!s.arrivalTime)
        throw new Ge("INVALID_ARRIVAL_TIME", "Arrival time is required for LATE status");
      o = s.arrivalTime;
    } else if (s.status === "PRESENT")
      o = s.arrivalTime ?? null;
    else {
      if (s.arrivalTime != null)
        throw new Ge("INVALID_ARRIVAL_TIME", "Arrival time must be null for ABSENT or EXCUSED");
      o = null;
    }
    const d = this.attendanceRepo.findBySessionAndStudent(
      s.sessionId,
      s.studentId
    ), u = (/* @__PURE__ */ new Date()).toISOString(), l = Me(t), p = l ? null : t.userId, S = this.client.transaction((N) => {
      const y = new nn(N), I = new me(N), L = d ? d.id : b.randomUUID(), w = y.upsert({
        id: L,
        sessionId: s.sessionId,
        studentId: s.studentId,
        status: s.status,
        arrivalTime: o,
        notes: s.notes ?? null,
        recordedByUserId: p,
        recordedAt: d ? d.recordedAt : u,
        updatedAt: u
      });
      return I.insert({
        id: b.randomUUID(),
        actorType: l ? "SYSTEM" : "USER",
        actorUserId: p,
        actorNameSnapshot: t.fullName,
        action: d ? "ATTENDANCE_UPDATED" : "ATTENDANCE_RECORDED",
        entityType: "ATTENDANCE",
        entityId: w.id,
        beforeJson: d ? JSON.stringify(this.toAttendanceRecordDto(d)) : null,
        afterJson: JSON.stringify(this.toAttendanceRecordDto(w)),
        metadataJson: JSON.stringify({
          sessionId: s.sessionId,
          studentId: s.studentId,
          status: s.status,
          arrivalTime: o
        }),
        createdAt: u
      }), w;
    });
    return this.toAttendanceRecordDto(S);
  }
  /**
   * Atomically records/updates attendance for multiple students in a session.
   * Rejects duplicate students and validates temporal enrollment.
   */
  async batchRecordAttendance(e, t) {
    this.checkPermission(t, "ATTENDANCE_WRITE");
    const s = pu.parse(e), n = this.sessionRepo.findById(s.sessionId);
    if (!n)
      throw new Ge("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (n.status === "CANCELLED_BY_TEACHER")
      throw new Ge("SESSION_CANCELLED", "Cannot record attendance for a cancelled session");
    const i = this.enrollmentRepo.listByGroup(n.groupId).filter((p) => this.isStudentEnrolledOnDate(p, n.effectiveDate)), a = new Set(i.map((p) => p.studentId));
    for (const p of s.records)
      if (!a.has(p.studentId))
        throw new Ge(
          "STUDENT_NOT_ENROLLED",
          `Student ${p.studentId} is not enrolled on session date ${n.effectiveDate}`
        );
    const o = (/* @__PURE__ */ new Date()).toISOString(), d = Me(t), u = d ? null : t.userId;
    return this.client.transaction((p) => {
      const S = new nn(p), N = new me(p), y = [];
      for (const I of s.records) {
        if (!this.studentRepo.findById(I.studentId))
          throw new Ge("STUDENT_NOT_FOUND", `Student not found: ${I.studentId}`);
        let w = null;
        if (I.status === "LATE") {
          if (!I.arrivalTime)
            throw new Ge("INVALID_ARRIVAL_TIME", "Arrival time is required for LATE status");
          w = I.arrivalTime;
        } else if (I.status === "PRESENT")
          w = I.arrivalTime ?? null;
        else {
          if (I.arrivalTime != null)
            throw new Ge("INVALID_ARRIVAL_TIME", "Arrival time must be null for ABSENT or EXCUSED");
          w = null;
        }
        const P = S.findBySessionAndStudent(
          s.sessionId,
          I.studentId
        ), O = P ? P.id : b.randomUUID(), k = S.upsert({
          id: O,
          sessionId: s.sessionId,
          studentId: I.studentId,
          status: I.status,
          arrivalTime: w,
          notes: I.notes ?? null,
          recordedByUserId: u,
          recordedAt: P ? P.recordedAt : o,
          updatedAt: o
        });
        N.insert({
          id: b.randomUUID(),
          actorType: d ? "SYSTEM" : "USER",
          actorUserId: u,
          actorNameSnapshot: t.fullName,
          action: P ? "ATTENDANCE_UPDATED" : "ATTENDANCE_RECORDED",
          entityType: "ATTENDANCE",
          entityId: k.id,
          beforeJson: P ? JSON.stringify(this.toAttendanceRecordDto(P)) : null,
          afterJson: JSON.stringify(this.toAttendanceRecordDto(k)),
          metadataJson: JSON.stringify({
            sessionId: s.sessionId,
            studentId: I.studentId,
            status: I.status,
            arrivalTime: w
          }),
          createdAt: o
        }), y.push(k);
      }
      return y;
    }).map((p) => this.toAttendanceRecordDto(p));
  }
  /**
   * Completes a session delegating authoritatively to SessionService.
   */
  async completeSession(e, t) {
    return this.sessionService.completeSession(e, t);
  }
  /**
   * Compiles End-of-Day Follow-Up items for absent and late students on a given date,
   * generating polite Arabic WhatsApp notification drafts without hardcoded subjects.
   * Cancelled teacher sessions are strictly excluded.
   */
  async getEndOfDayFollowUp(e, t) {
    this.checkPermission(t, "GROUPS_READ"), Hs.parse(e);
    const s = this.attendanceRepo.listByDateWithDetails(e), n = this.sessionRepo.listByEffectiveDate(e).filter((l) => l.status !== "CANCELLED_BY_TEACHER"), i = new Set(n.map((l) => l.id)), a = s.filter((l) => i.has(l.sessionId)), o = [];
    let d = 0, u = 0;
    for (const l of a)
      if (l.status === "ABSENT")
        d++, o.push({
          attendanceRecordId: l.id,
          studentId: l.studentId,
          studentName: l.studentName,
          guardianPhone: l.guardianPhone,
          sessionId: l.sessionId,
          groupName: l.groupName,
          status: "ABSENT",
          sessionDate: l.sessionDate,
          sessionStartTime: l.sessionStartTime,
          whatsappMessage: `السلام عليكم ورحمة الله وبركاته، ولي أمر الطالب/ة ${l.studentName}. نود إحاطتكم بعلم أن الطالب/ة غاب/ت عن حضور حصة اليوم (${l.sessionDate}) لمجموعة ${l.groupName}. يرجى المتابعة لتعويض ما فاته.`,
          contactStatus: l.contactStatus,
          contactedAt: l.contactedAt,
          contactedByUserId: l.contactedByUserId,
          contactNote: l.contactNote
        });
      else if (l.status === "LATE") {
        u++;
        const p = l.arrivalTime ? ` (حضر في تمام الساعة ${l.arrivalTime})` : "";
        o.push({
          attendanceRecordId: l.id,
          studentId: l.studentId,
          studentName: l.studentName,
          guardianPhone: l.guardianPhone,
          sessionId: l.sessionId,
          groupName: l.groupName,
          status: "LATE",
          sessionDate: l.sessionDate,
          sessionStartTime: l.sessionStartTime,
          whatsappMessage: `السلام عليكم ورحمة الله وبركاته، ولي أمر الطالب/ة ${l.studentName}. نود إحاطتكم بعلم أن الطالب/ة تأخر/ت عن موعد بدء الحصة لمجموعة ${l.groupName} اليوم (${l.sessionDate})${p}. نرجو الحرص على الحضور في الموعد المحدد.`,
          contactStatus: l.contactStatus,
          contactedAt: l.contactedAt,
          contactedByUserId: l.contactedByUserId,
          contactNote: l.contactNote
        });
      }
    return {
      date: e,
      totalSessions: n.length,
      totalAbsent: d,
      totalLate: u,
      followUps: o
    };
  }
  /**
   * Authoritatively updates parent follow-up contact status and notes for an absent/late student.
   * Atomically records audit trail in academic_audit_log.
   */
  async updateFollowUpStatus(e, t) {
    this.checkPermission(t, "ATTENDANCE_WRITE");
    const s = Eu.parse(e);
    if (!this.attendanceRepo.findById(s.attendanceRecordId))
      throw new Ge(
        "ATTENDANCE_RECORD_NOT_FOUND",
        `Attendance record not found: ${s.attendanceRecordId}`
      );
    const i = (/* @__PURE__ */ new Date()).toISOString(), a = Me(t), o = a ? null : t.userId, d = this.client.transaction((u) => {
      const l = new ci(u), p = new me(u), S = l.findByAttendanceRecordId(s.attendanceRecordId), N = S ? S.id : b.randomUUID(), y = s.contactStatus === "UNCONTACTED" ? null : (S == null ? void 0 : S.contactedAt) ?? i, I = s.contactStatus === "UNCONTACTED" ? null : (S == null ? void 0 : S.contactedByUserId) ?? o, L = l.upsert({
        id: N,
        attendanceRecordId: s.attendanceRecordId,
        contactStatus: s.contactStatus,
        note: s.note ?? null,
        contactedAt: y,
        contactedByUserId: I,
        createdAt: S ? S.createdAt : i,
        updatedAt: i
      });
      return p.insert({
        id: b.randomUUID(),
        actorType: a ? "SYSTEM" : "USER",
        actorUserId: o,
        actorNameSnapshot: t.fullName,
        action: "FOLLOW_UP_STATUS_UPDATED",
        entityType: "ATTENDANCE_FOLLOW_UP",
        entityId: L.id,
        beforeJson: S ? JSON.stringify(this.toAttendanceFollowUpDto(S)) : null,
        afterJson: JSON.stringify(this.toAttendanceFollowUpDto(L)),
        metadataJson: JSON.stringify({
          attendanceRecordId: s.attendanceRecordId,
          contactStatus: s.contactStatus
        }),
        createdAt: i
      }), L;
    });
    return this.toAttendanceFollowUpDto(d);
  }
  toAttendanceFollowUpDto(e) {
    return {
      id: e.id,
      attendanceRecordId: e.attendanceRecordId,
      contactStatus: e.contactStatus,
      note: e.note,
      contactedAt: e.contactedAt,
      contactedByUserId: e.contactedByUserId,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  toAttendanceRecordDto(e) {
    return {
      id: e.id,
      sessionId: e.sessionId,
      studentId: e.studentId,
      status: e.status,
      arrivalTime: e.arrivalTime,
      notes: e.notes,
      recordedByUserId: e.recordedByUserId,
      recordedAt: e.recordedAt,
      updatedAt: e.updatedAt
    };
  }
}
class _t extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "FinanceError";
  }
}
function Ni(r) {
  return Math.round(r * 100);
}
function Zs(r) {
  return `${(r / 100).toLocaleString("ar-EG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ج.م`;
}
class $u {
  constructor(e) {
    h(this, "paymentRepo");
    h(this, "invoiceRepo");
    h(this, "discountRepo");
    h(this, "studentRepo");
    h(this, "groupRepo");
    h(this, "enrollmentRepo");
    h(this, "sessionRepo");
    h(this, "auditRepo");
    this.db = e, this.paymentRepo = new kc(this.db), this.invoiceRepo = new uh(this.db), this.discountRepo = new lh(this.db), this.studentRepo = new Ct(this.db), this.groupRepo = new mt(this.db), this.enrollmentRepo = new Ut(this.db), this.sessionRepo = new ht(this.db), this.auditRepo = new me(this.db);
  }
  get client() {
    return this.db ?? Fe().db;
  }
  requireActorPermissions(e, t) {
    Me(e) || te(e.role, e.permissions ?? [], t);
  }
  // --- Sequential Identifier Generators ---
  generateReceiptNumber() {
    const e = (/* @__PURE__ */ new Date()).getFullYear();
    let t = this.paymentRepo.countAll() + 1, s = `REC-${e}-${t.toString().padStart(4, "0")}`;
    for (; this.paymentRepo.findByReceiptNumber(s); )
      t++, s = `REC-${e}-${t.toString().padStart(4, "0")}`;
    return s;
  }
  generateInvoiceNumber() {
    const e = (/* @__PURE__ */ new Date()).getFullYear();
    let t = this.invoiceRepo.countAll() + 1, s = `INV-${e}-${t.toString().padStart(4, "0")}`;
    for (; this.invoiceRepo.findByInvoiceNumber(s); )
      t++, s = `INV-${e}-${t.toString().padStart(4, "0")}`;
    return s;
  }
  // --- Payments ---
  async recordPayment(e, t) {
    this.requireActorPermissions(t, "PAYMENTS_WRITE");
    const s = gm.parse(e), n = this.studentRepo.findById(s.studentId);
    if (!n)
      throw new _t("STUDENT_NOT_FOUND", `الطالب بالمعرف ${s.studentId} غير موجود`);
    let i;
    if (s.groupId) {
      const S = this.groupRepo.findById(s.groupId);
      if (!S)
        throw new _t("GROUP_NOT_FOUND", `المجموعة بالمعرف ${s.groupId} غير موجودة`);
      i = S.name;
    }
    const a = (/* @__PURE__ */ new Date()).toISOString(), o = b.randomUUID(), d = this.generateReceiptNumber(), u = Me(t) ? null : t.userId, l = t.fullName, p = this.paymentRepo.insert({
      id: o,
      receiptNumber: d,
      studentId: n.id,
      groupId: s.groupId ?? null,
      amountCents: s.amountCents,
      paymentMethod: s.paymentMethod,
      paymentDate: s.paymentDate,
      periodMonth: s.periodMonth ?? null,
      notes: s.notes ?? null,
      recordedByUserId: u ?? "SYSTEM",
      createdAt: a,
      updatedAt: a
    });
    return this.auditRepo.insert({
      id: b.randomUUID(),
      actorType: Me(t) ? "SYSTEM" : "USER",
      actorUserId: u,
      actorNameSnapshot: l,
      action: "PAYMENT_RECORDED",
      entityType: "PAYMENT",
      entityId: o,
      beforeJson: null,
      afterJson: JSON.stringify(p),
      metadataJson: JSON.stringify({
        receiptNumber: d,
        studentId: n.id,
        amountCents: s.amountCents,
        paymentMethod: s.paymentMethod
      }),
      createdAt: a
    }), {
      id: p.id,
      receiptNumber: p.receiptNumber,
      studentId: p.studentId,
      studentName: n.fullName,
      studentCode: n.studentCode,
      groupId: p.groupId,
      groupName: i,
      amountCents: p.amountCents,
      paymentMethod: p.paymentMethod,
      paymentDate: p.paymentDate,
      periodMonth: p.periodMonth,
      notes: p.notes,
      recordedByUserId: p.recordedByUserId,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt
    };
  }
  async listStudentPayments(e) {
    const t = this.studentRepo.findById(e);
    if (!t)
      throw new _t("STUDENT_NOT_FOUND", "الطالب غير موجود");
    return this.paymentRepo.listByStudent(e).map((n) => {
      let i;
      if (n.groupId) {
        const a = this.groupRepo.findById(n.groupId);
        i = a == null ? void 0 : a.name;
      }
      return {
        id: n.id,
        receiptNumber: n.receiptNumber,
        studentId: n.studentId,
        studentName: t.fullName,
        studentCode: t.studentCode,
        groupId: n.groupId,
        groupName: i,
        amountCents: n.amountCents,
        paymentMethod: n.paymentMethod,
        paymentDate: n.paymentDate,
        periodMonth: n.periodMonth,
        notes: n.notes,
        recordedByUserId: n.recordedByUserId,
        createdAt: n.createdAt,
        updatedAt: n.updatedAt
      };
    });
  }
  // --- Discounts ---
  async applyDiscount(e, t) {
    this.requireActorPermissions(t, "PAYMENTS_WRITE");
    const s = _m.parse(e), n = this.studentRepo.findById(s.studentId);
    if (!n)
      throw new _t("STUDENT_NOT_FOUND", "الطالب غير موجود");
    let i;
    if (s.groupId) {
      const p = this.groupRepo.findById(s.groupId);
      if (!p)
        throw new _t("GROUP_NOT_FOUND", "المجموعة غير موجودة");
      i = p.name;
    }
    const a = (/* @__PURE__ */ new Date()).toISOString(), o = b.randomUUID(), d = Me(t) ? null : t.userId, u = t.fullName, l = this.discountRepo.insert({
      id: o,
      studentId: n.id,
      groupId: s.groupId ?? null,
      discountType: s.discountType,
      discountValue: s.discountValue,
      reason: s.reason,
      status: "ACTIVE",
      appliedByUserId: d,
      createdAt: a,
      updatedAt: a
    });
    return this.auditRepo.insert({
      id: b.randomUUID(),
      actorType: Me(t) ? "SYSTEM" : "USER",
      actorUserId: d,
      actorNameSnapshot: u,
      action: "DISCOUNT_APPLIED",
      entityType: "STUDENT_DISCOUNT",
      entityId: o,
      beforeJson: null,
      afterJson: JSON.stringify(l),
      metadataJson: JSON.stringify({
        studentId: n.id,
        discountType: s.discountType,
        discountValue: s.discountValue
      }),
      createdAt: a
    }), {
      id: l.id,
      studentId: l.studentId,
      groupId: l.groupId,
      groupName: i,
      discountType: l.discountType,
      discountValue: l.discountValue,
      reason: l.reason,
      status: l.status,
      appliedByUserId: l.appliedByUserId,
      createdAt: l.createdAt,
      updatedAt: l.updatedAt
    };
  }
  async listDiscounts(e) {
    return this.discountRepo.listAllByStudent(e).map((s) => {
      let n;
      if (s.groupId) {
        const i = this.groupRepo.findById(s.groupId);
        n = i == null ? void 0 : i.name;
      }
      return {
        id: s.id,
        studentId: s.studentId,
        groupId: s.groupId,
        groupName: n,
        discountType: s.discountType,
        discountValue: s.discountValue,
        reason: s.reason,
        status: s.status,
        appliedByUserId: s.appliedByUserId,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt
      };
    });
  }
  // --- Financial Summary & Balance Calculations ---
  async getStudentFinancialSummary(e) {
    var w;
    const t = this.studentRepo.findById(e);
    if (!t)
      throw new _t("STUDENT_NOT_FOUND", "الطالب غير موجود");
    const s = this.enrollmentRepo.listByStudent(e), n = this.paymentRepo.listByStudent(e), i = this.discountRepo.listActiveByStudent(e);
    let a = 0;
    const o = [], d = /* @__PURE__ */ new Date(), u = d.getFullYear(), l = d.getMonth();
    for (const P of s) {
      if (P.status !== "ACTIVE" && !P.leftAt) continue;
      const O = this.groupRepo.findById(P.groupId);
      if (!O) continue;
      const k = P.paymentTypeOverride ?? O.defaultPaymentType, B = P.paymentAmountOverride !== null && P.paymentAmountOverride !== void 0 ? Ni(P.paymentAmountOverride) : Ni(O.defaultPaymentAmount);
      let ue = 0, M = 0, K = 0;
      if (k === "MONTHLY") {
        const qe = new Date(P.enrolledAt), He = qe.getFullYear(), be = qe.getMonth();
        M = (u - He) * 12 + (l - be) + 1, M < 1 && (M = 1), ue = B * M;
      } else
        K = this.sessionRepo.listByGroup(O.id).filter(
          (be) => be.status === "COMPLETED" || be.effectiveDate <= d.toISOString().slice(0, 10)
        ).length, ue = B * K;
      const Se = n.filter((qe) => qe.groupId === O.id).reduce((qe, He) => qe + He.amountCents, 0), Tt = Math.max(0, ue - Se);
      o.push({
        groupId: O.id,
        groupName: O.name,
        paymentType: k,
        rateCents: B,
        enrolledAt: P.enrolledAt,
        sessionsCount: k === "PER_SESSION" ? K : void 0,
        monthsCount: k === "MONTHLY" ? M : void 0,
        totalChargeCents: ue,
        totalPaidCents: Se,
        balanceCents: Tt
      }), a += ue;
    }
    let p = 0;
    for (const P of i)
      if (P.discountType === "PERCENTAGE") {
        const O = P.groupId ? ((w = o.find((B) => B.groupId === P.groupId)) == null ? void 0 : w.totalChargeCents) ?? 0 : a, k = Math.round(O * P.discountValue / 100);
        p += k;
      } else
        p += P.discountValue;
    p = Math.min(p, a);
    const S = Math.max(0, a - p), N = n.reduce((P, O) => P + O.amountCents, 0), y = Math.max(0, S - N);
    let I = "UNPAID";
    S === 0 || y === 0 ? I = "PAID" : N > 0 ? I = "PARTIALLY_PAID" : I = "UNPAID";
    const L = n.slice(0, 10).map((P) => ({
      id: P.id,
      receiptNumber: P.receiptNumber,
      studentId: P.studentId,
      studentName: t.fullName,
      studentCode: t.studentCode,
      groupId: P.groupId,
      amountCents: P.amountCents,
      paymentMethod: P.paymentMethod,
      paymentDate: P.paymentDate,
      periodMonth: P.periodMonth,
      notes: P.notes,
      recordedByUserId: P.recordedByUserId,
      createdAt: P.createdAt,
      updatedAt: P.updatedAt
    }));
    return {
      studentId: t.id,
      studentName: t.fullName,
      studentCode: t.studentCode,
      guardianPhone: t.guardianPhone,
      gradeLevel: t.gradeLevel,
      totalChargesCents: a,
      totalDiscountsCents: p,
      netPayableCents: S,
      totalPaidCents: N,
      remainingBalanceCents: y,
      status: I,
      subscriptions: o,
      recentPayments: L
    };
  }
  async listAllSummaries(e) {
    const t = this.studentRepo.list({
      searchQuery: e == null ? void 0 : e.search,
      status: "ACTIVE"
    }), s = [];
    for (const n of t) {
      const i = await this.getStudentFinancialSummary(n.id);
      e != null && e.groupId && !i.subscriptions.some((o) => o.groupId === e.groupId) || e != null && e.status && i.status !== e.status || s.push(i);
    }
    return s;
  }
  async getOverallFinanceKpi() {
    const e = await this.listAllSummaries();
    let t = 0, s = 0, n = 0, i = 0, a = 0, o = 0;
    for (const d of e)
      t += d.totalChargesCents, s += d.totalPaidCents, n += d.remainingBalanceCents, i += d.totalDiscountsCents, d.status === "PAID" ? a++ : o++;
    return {
      totalChargesCents: t,
      totalCollectedCents: s,
      totalOutstandingCents: n,
      totalDiscountsCents: i,
      activeStudentsCount: e.length,
      paidStudentsCount: a,
      unpaidStudentsCount: o
    };
  }
  // --- Invoicing ---
  async createInvoice(e, t) {
    this.requireActorPermissions(t, "PAYMENTS_WRITE");
    const s = Im.parse(e), n = this.studentRepo.findById(s.studentId);
    if (!n)
      throw new _t("STUDENT_NOT_FOUND", "الطالب غير موجود");
    let i;
    if (s.groupId) {
      const B = this.groupRepo.findById(s.groupId);
      i = B == null ? void 0 : B.name;
    }
    let a = 0;
    const o = s.items.map((B) => {
      const ue = B.quantity * B.unitPriceCents;
      return a += ue, {
        id: b.randomUUID(),
        invoiceId: "",
        // Set by repository
        description: B.description,
        itemType: B.itemType,
        quantity: B.quantity,
        unitPriceCents: B.unitPriceCents,
        amountCents: ue,
        sessionId: B.sessionId ?? null
      };
    }), d = Math.min(s.discountCents ?? 0, a), u = Math.max(0, a - d), l = this.paymentRepo.totalPaidByStudent(n.id, s.groupId ?? void 0), p = Math.min(l, u), S = Math.max(0, u - p), N = S === 0 ? "PAID" : p > 0 ? "PARTIALLY_PAID" : "UNPAID", y = (/* @__PURE__ */ new Date()).toISOString(), I = b.randomUUID(), L = this.generateInvoiceNumber(), { invoice: w, items: P } = this.invoiceRepo.insert(
      {
        id: I,
        invoiceNumber: L,
        studentId: n.id,
        groupId: s.groupId ?? null,
        issueDate: s.issueDate,
        dueDate: s.dueDate ?? null,
        periodMonth: s.periodMonth ?? null,
        subtotalCents: a,
        discountCents: d,
        totalCents: u,
        paidCents: p,
        remainingCents: S,
        status: N,
        notes: s.notes ?? null,
        createdAt: y,
        updatedAt: y
      },
      o
    ), O = Me(t) ? null : t.userId, k = t.fullName;
    return this.auditRepo.insert({
      id: b.randomUUID(),
      actorType: Me(t) ? "SYSTEM" : "USER",
      actorUserId: O,
      actorNameSnapshot: k,
      action: "INVOICE_CREATED",
      entityType: "INVOICE",
      entityId: I,
      beforeJson: null,
      afterJson: JSON.stringify(w),
      metadataJson: JSON.stringify({
        invoiceNumber: L,
        studentId: n.id,
        totalCents: u
      }),
      createdAt: y
    }), {
      id: w.id,
      invoiceNumber: w.invoiceNumber,
      studentId: w.studentId,
      studentName: n.fullName,
      studentCode: n.studentCode,
      groupId: w.groupId,
      groupName: i,
      issueDate: w.issueDate,
      dueDate: w.dueDate,
      periodMonth: w.periodMonth,
      subtotalCents: w.subtotalCents,
      discountCents: w.discountCents,
      totalCents: w.totalCents,
      paidCents: w.paidCents,
      remainingCents: w.remainingCents,
      status: w.status,
      notes: w.notes,
      items: P.map((B) => ({
        id: B.id,
        invoiceId: B.invoiceId,
        description: B.description,
        itemType: B.itemType,
        quantity: B.quantity,
        unitPriceCents: B.unitPriceCents,
        amountCents: B.amountCents,
        sessionId: B.sessionId
      })),
      createdAt: w.createdAt,
      updatedAt: w.updatedAt
    };
  }
  async getInvoice(e) {
    const t = this.invoiceRepo.findById(e);
    if (!t)
      throw new _t("INVOICE_NOT_FOUND", "الفاتورة غير موجودة");
    const { invoice: s, items: n } = t, i = this.studentRepo.findById(s.studentId);
    let a;
    if (s.groupId) {
      const o = this.groupRepo.findById(s.groupId);
      a = o == null ? void 0 : o.name;
    }
    return {
      id: s.id,
      invoiceNumber: s.invoiceNumber,
      studentId: s.studentId,
      studentName: i == null ? void 0 : i.fullName,
      studentCode: i == null ? void 0 : i.studentCode,
      groupId: s.groupId,
      groupName: a,
      issueDate: s.issueDate,
      dueDate: s.dueDate,
      periodMonth: s.periodMonth,
      subtotalCents: s.subtotalCents,
      discountCents: s.discountCents,
      totalCents: s.totalCents,
      paidCents: s.paidCents,
      remainingCents: s.remainingCents,
      status: s.status,
      notes: s.notes,
      items: n.map((o) => ({
        id: o.id,
        invoiceId: o.invoiceId,
        description: o.description,
        itemType: o.itemType,
        quantity: o.quantity,
        unitPriceCents: o.unitPriceCents,
        amountCents: o.amountCents,
        sessionId: o.sessionId
      })),
      createdAt: s.createdAt,
      updatedAt: s.updatedAt
    };
  }
  async listStudentInvoices(e) {
    const t = this.studentRepo.findById(e);
    return this.invoiceRepo.listByStudent(e).map(({ invoice: n, items: i }) => {
      let a;
      if (n.groupId) {
        const o = this.groupRepo.findById(n.groupId);
        a = o == null ? void 0 : o.name;
      }
      return {
        id: n.id,
        invoiceNumber: n.invoiceNumber,
        studentId: n.studentId,
        studentName: t == null ? void 0 : t.fullName,
        studentCode: t == null ? void 0 : t.studentCode,
        groupId: n.groupId,
        groupName: a,
        issueDate: n.issueDate,
        dueDate: n.dueDate,
        periodMonth: n.periodMonth,
        subtotalCents: n.subtotalCents,
        discountCents: n.discountCents,
        totalCents: n.totalCents,
        paidCents: n.paidCents,
        remainingCents: n.remainingCents,
        status: n.status,
        notes: n.notes,
        items: i.map((o) => ({
          id: o.id,
          invoiceId: o.invoiceId,
          description: o.description,
          itemType: o.itemType,
          quantity: o.quantity,
          unitPriceCents: o.unitPriceCents,
          amountCents: o.amountCents,
          sessionId: o.sessionId
        })),
        createdAt: n.createdAt,
        updatedAt: n.updatedAt
      };
    });
  }
}
const Tp = {
  PREP_1: "الصف الأول الإعدادي",
  PREP_2: "الصف الثاني الإعدادي",
  PREP_3: "الصف الثالث الإعدادي",
  SEC_1: "الصف الأول الثانوي",
  SEC_2: "الصف الثاني الثانوي",
  SEC_3: "الصف الثالث الثانوي"
}, Ap = {
  CASH: "نقدي",
  VODAFONE_CASH: "فودافون كاش",
  INSTAPAY: "إنستاباي",
  BANK_TRANSFER: "تحويل بنكي",
  OTHER: "أخرى"
};
class qu {
  constructor(e) {
    h(this, "paymentRepo");
    h(this, "studentRepo");
    h(this, "groupRepo");
    h(this, "financeService");
    this.db = e, this.paymentRepo = new kc(this.db), this.studentRepo = new Ct(this.db), this.groupRepo = new mt(this.db), this.financeService = new $u(this.db);
  }
  requireActorPermissions(e) {
    Me(e) || te(e.role, e.permissions ?? [], "PAYMENTS_READ");
  }
  /**
   * Authoritative loader for thermal receipt data.
   * Loads persisted payment record, student details, group info, and remaining balance.
   * Never mutates the database; safe for idempotent receipt printing and reprinting.
   */
  async getThermalReceiptData(e, t) {
    this.requireActorPermissions(t);
    const s = this.paymentRepo.findById(e);
    if (!s)
      throw new _t("PAYMENT_NOT_FOUND", `سجل الدفعة بالمعرف ${e} غير موجود`);
    const n = this.studentRepo.findById(s.studentId);
    if (!n)
      throw new _t("STUDENT_NOT_FOUND", "الطالب المرتبط بالدفعة غير موجود");
    let i;
    if (s.groupId) {
      const N = this.groupRepo.findById(s.groupId);
      N && (i = N.name);
    }
    let a, o;
    try {
      const N = await this.financeService.getStudentFinancialSummary(n.id);
      a = N.remainingBalanceCents, o = Zs(N.remainingBalanceCents);
    } catch {
    }
    const d = n.gradeLevel, u = Tp[d] || d, l = Ap[s.paymentMethod] || s.paymentMethod, p = t.fullName || "أ. زياد محمد", S = t.fullName || "المسؤول";
    return {
      paymentId: s.id,
      receiptNumber: s.receiptNumber,
      studentId: n.id,
      studentName: n.fullName,
      studentCode: n.studentCode,
      gradeLevel: n.gradeLevel,
      gradeLevelNameAr: u,
      groupName: i,
      amountCents: s.amountCents,
      amountFormatted: Zs(s.amountCents),
      paymentMethod: s.paymentMethod,
      paymentMethodNameAr: l,
      paymentDate: s.paymentDate,
      periodMonth: s.periodMonth,
      remainingBalanceCents: a,
      remainingBalanceFormatted: o,
      teacherName: p,
      operatorName: S,
      notes: s.notes,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      isTestReceipt: !1
    };
  }
  /**
   * Generates a non-financial test receipt for printer testing.
   * Completely decoupled from persistence, zero DB side effects.
   */
  generateTestReceiptData(e = "80mm", t) {
    const s = b.randomUUID(), n = /* @__PURE__ */ new Date(), i = n.toISOString().slice(0, 10);
    return {
      paymentId: s,
      receiptNumber: "TEST-0000",
      studentId: s,
      studentName: "طالب تجريبي — فحص الطابعة",
      studentCode: "TB-TEST",
      gradeLevel: "PREP_1",
      gradeLevelNameAr: "الصف الأول الإعدادي",
      groupName: `مجموعة الرياضيات (${e})`,
      amountCents: 15e3,
      amountFormatted: Zs(15e3),
      paymentMethod: "CASH",
      paymentMethodNameAr: "نقدي",
      paymentDate: i,
      periodMonth: i.slice(0, 7),
      remainingBalanceCents: 0,
      remainingBalanceFormatted: Zs(0),
      teacherName: t || "أ. زياد محمد (مدرس الرياضيات)",
      operatorName: "المشرف",
      notes: `إيصال اختبار للتأكد من جودة خطوط وأبعاد ورق ${e}`,
      issuedAt: n.toISOString(),
      isTestReceipt: !0
    };
  }
}
const Rp = {
  " ": [0, 0, 0, 0, 0],
  "-": [8, 8, 8, 8, 8],
  ":": [0, 54, 54, 0, 0],
  ".": [0, 96, 96, 0, 0],
  ",": [0, 64, 96, 0, 0],
  "/": [32, 16, 8, 4, 2],
  "#": [20, 127, 20, 127, 20],
  "*": [20, 8, 62, 8, 20],
  "=": [20, 20, 20, 20, 20],
  "+": [8, 8, 62, 8, 8],
  0: [62, 81, 73, 69, 62],
  1: [0, 66, 127, 64, 0],
  2: [66, 97, 81, 73, 70],
  3: [33, 65, 69, 75, 49],
  4: [24, 20, 18, 127, 16],
  5: [39, 69, 69, 69, 57],
  6: [60, 74, 73, 73, 48],
  7: [1, 113, 9, 5, 3],
  8: [54, 73, 73, 73, 54],
  9: [6, 73, 73, 41, 30],
  A: [126, 17, 17, 17, 126],
  B: [127, 73, 73, 73, 54],
  C: [62, 65, 65, 65, 34],
  D: [127, 65, 65, 34, 28],
  E: [127, 73, 73, 73, 65],
  F: [127, 9, 9, 9, 1],
  G: [62, 65, 73, 73, 122],
  H: [127, 8, 8, 8, 127],
  I: [0, 65, 127, 65, 0],
  J: [32, 64, 65, 63, 1],
  K: [127, 8, 20, 34, 65],
  L: [127, 64, 64, 64, 64],
  M: [127, 2, 12, 2, 127],
  N: [127, 4, 8, 16, 127],
  O: [62, 65, 65, 65, 62],
  P: [127, 9, 9, 9, 6],
  Q: [62, 65, 81, 33, 94],
  R: [127, 9, 25, 41, 70],
  S: [70, 73, 73, 73, 49],
  T: [1, 1, 127, 1, 1],
  U: [63, 64, 64, 64, 63],
  V: [31, 32, 64, 32, 31],
  W: [127, 32, 24, 32, 127],
  X: [99, 20, 8, 20, 99],
  Y: [7, 8, 112, 8, 7],
  Z: [97, 81, 73, 69, 67]
};
class Dp {
  constructor(e, t) {
    h(this, "widthDots");
    h(this, "heightDots");
    h(this, "bytesPerRow");
    h(this, "buffer");
    this.widthDots = e, this.heightDots = t, this.bytesPerRow = Math.ceil(e / 8), this.buffer = Buffer.alloc(this.bytesPerRow * t, 0);
  }
  setPixel(e, t, s = 1) {
    if (e < 0 || e >= this.widthDots || t < 0 || t >= this.heightDots) return;
    const n = t * this.bytesPerRow + Math.floor(e / 8), i = 7 - e % 8;
    s === 1 ? this.buffer[n] |= 1 << i : this.buffer[n] &= ~(1 << i);
  }
  drawHLine(e, t = 0, s = this.widthDots - 1, n = 1) {
    for (let i = 0; i < n; i++) {
      const a = e + i;
      if (a >= this.heightDots) break;
      for (let o = t; o <= s; o++)
        this.setPixel(o, a, 1);
    }
  }
  drawDashedLine(e, t = 0, s = this.widthDots - 1, n = 6, i = 4) {
    let a = !0, o = 0;
    for (let d = t; d <= s; d++)
      a && (this.setPixel(d, e, 1), this.setPixel(d, e + 1, 1)), o++, a && o >= n ? (a = !1, o = 0) : !a && o >= i && (a = !0, o = 0);
  }
  drawRect(e, t, s, n, i = !1, a = 2) {
    if (i)
      for (let o = t; o < t + n; o++)
        for (let d = e; d < e + s; d++)
          this.setPixel(d, o, 1);
    else {
      for (let o = 0; o < a; o++)
        this.drawHLine(t + o, e, e + s - 1), this.drawHLine(t + n - 1 - o, e, e + s - 1);
      for (let o = t; o < t + n; o++)
        for (let d = 0; d < a; d++)
          this.setPixel(e + d, o, 1), this.setPixel(e + s - 1 - d, o, 1);
    }
  }
  drawAsciiText(e, t, s, n = 1) {
    const i = e.toUpperCase();
    let a = t;
    for (let o = 0; o < i.length; o++) {
      const d = i[o], u = Rp[d] ?? [0, 0, 0, 0, 0];
      for (let l = 0; l < 5; l++) {
        const p = u[l] ?? 0;
        for (let S = 0; S < 7; S++)
          if ((p & 1 << S) !== 0)
            for (let N = 0; N < n; N++)
              for (let y = 0; y < n; y++)
                this.setPixel(a + l * n + N, s + S * n + y, 1);
      }
      a += 6 * n;
    }
  }
  drawCenterAsciiText(e, t, s = 1) {
    const n = e.length * 6 * s, i = Math.max(0, Math.floor((this.widthDots - n) / 2));
    this.drawAsciiText(e, i, t, s);
  }
  drawBarcode(e, t, s, n, i = 2) {
    let a = t;
    this.drawRect(a, s, i * 2, n, !0), a += i * 3;
    for (let o = 0; o < e.length; o++) {
      const d = e.charCodeAt(o);
      for (let u = 0; u < 6; u++)
        (d >> u & 1) === 1 && this.drawRect(a, s, i, n, !0), a += i + 1;
      a += i;
    }
    this.drawRect(a, s, i * 2, n, !0);
  }
}
class ls {
  constructor() {
    h(this, "buffer", []);
    this.init();
  }
  /**
   * Reset / Initialize printer (ESC @)
   */
  init() {
    return this.buffer.push(27, 64), this;
  }
  /**
   * Text alignment (ESC a n: 0=Left, 1=Center, 2=Right)
   */
  setAlign(e) {
    const t = e === "center" ? 1 : e === "right" ? 2 : 0;
    return this.buffer.push(27, 97, t), this;
  }
  /**
   * Bold font on/off (ESC E n)
   */
  setBold(e) {
    return this.buffer.push(27, 69, e ? 1 : 0), this;
  }
  /**
   * Underline mode on/off (ESC - n)
   */
  setUnderline(e) {
    return this.buffer.push(27, 45, e ? 1 : 0), this;
  }
  /**
   * Character size multiplier (GS ! n)
   */
  setTextSize(e = 1, t = 1) {
    const s = Math.min(Math.max(e, 1), 8) - 1, n = Math.min(Math.max(t, 1), 8) - 1, i = s << 4 | n;
    return this.buffer.push(29, 33, i), this;
  }
  /**
   * Print and feed n lines (ESC d n)
   */
  feed(e = 1) {
    return e <= 0 ? this : (this.buffer.push(27, 100, Math.min(e, 255)), this);
  }
  /**
   * Paper cut command (GS V m n)
   */
  cut(e = "partial") {
    const t = e === "full" ? 65 : 66;
    return this.buffer.push(29, 86, t, 0), this;
  }
  /**
   * Append raw text encoded as UTF-8 bytes
   */
  text(e) {
    const t = Buffer.from(e, "utf-8");
    for (let s = 0; s < t.length; s++)
      this.buffer.push(t[s]);
    return this;
  }
  /**
   * Append text with line feed (0x0A)
   */
  line(e = "") {
    return e && this.text(e), this.buffer.push(10), this;
  }
  /**
   * Horizontal divider line
   */
  horizontalRule(e = "-", t = 32) {
    const s = e.repeat(t);
    return this.line(s);
  }
  /**
   * Aligned two-column row (Left/Right)
   */
  twoColumnLine(e, t, s = 32) {
    const n = Math.max(1, s - (e.length + t.length)), i = e + " ".repeat(n) + t;
    return this.line(i);
  }
  /**
   * GS v 0 Raster Bit Image
   * Prints monochrome 1-bit bitmap data
   * @param widthDots Image width in dots (must be divisible by 8 or padded)
   * @param heightDots Image height in dots
   * @param bitData Array of 1-bit monochrome data (1 = black, 0 = white)
   */
  rasterBitImage(e, t, s) {
    const n = Math.ceil(e / 8), i = n % 256, a = Math.floor(n / 256), o = t % 256, d = Math.floor(t / 256);
    this.buffer.push(29, 118, 48, 0, i, a, o, d);
    for (let u = 0; u < s.length; u++)
      this.buffer.push(s[u]);
    return this;
  }
  /**
   * Append raw byte array
   */
  raw(e) {
    for (let t = 0; t < e.length; t++)
      this.buffer.push(e[t]);
    return this;
  }
  /**
   * Compile buffer into Node Buffer
   */
  build() {
    return Buffer.from(this.buffer);
  }
  /**
   * Compile buffer into Base64 string
   */
  buildBase64() {
    return this.build().toString("base64");
  }
  /**
   * Builds complete deterministic full 1-bit monochrome raster data representing
   * the authoritative receipt layout for thermal printing.
   */
  static createDeterministicReceiptRaster(e, t = "80mm") {
    const s = t === "58mm", n = s ? 384 : 576, i = 560, a = new Dp(n, i);
    a.drawHLine(4, 20, n - 21, 2), a.drawDashedLine(12, 10, n - 11);
    const o = s ? 120 : 160, d = Math.floor((n - o) / 2);
    a.drawRect(d, 22, o, 36, !1, 2), a.drawCenterAsciiText("T I B Y A N", 32, 2), a.drawCenterAsciiText("TEACHER OS - THERMAL RECEIPT", 70, 1), a.drawCenterAsciiText(e.isTestReceipt ? "*** TEST RECEIPT ***" : "OFFICIAL PAYMENT RECEIPT", 84, 1), a.drawDashedLine(100, 10, n - 11), a.drawAsciiText(`RECEIPT: ${e.receiptNumber}`, 20, 114, 2), a.drawAsciiText(`DATE: ${e.paymentDate}`, 20, 136, 1), e.issuedAt && a.drawAsciiText(`TIME: ${e.issuedAt.slice(11, 19)}`, s ? 200 : 340, 136, 1), a.drawHLine(152, 10, n - 11, 1), a.drawAsciiText(`STUDENT: ${e.studentCode}`, 20, 166, 2), a.drawAsciiText(`NAME: ${e.studentName}`, 20, 190, 1), e.groupName && a.drawAsciiText(`GROUP: ${e.groupName}`, 20, 206, 1), e.gradeLevelNameAr && a.drawAsciiText(`GRADE: ${e.gradeLevelNameAr}`, 20, 222, 1), e.periodMonth && a.drawAsciiText(`PERIOD: ${e.periodMonth}`, 20, 238, 1), a.drawAsciiText(`METHOD: ${e.paymentMethodNameAr || e.paymentMethod}`, 20, 254, 1), a.drawDashedLine(274, 10, n - 11);
    const u = s ? 340 : 500, l = Math.floor((n - u) / 2);
    a.drawRect(l, 290, u, 64, !1, 3), a.drawCenterAsciiText("AMOUNT PAID", 300, 1);
    const p = `${e.amountFormatted} (${(e.amountCents / 100).toFixed(2)} EGP)`;
    a.drawCenterAsciiText(p, 320, 2), e.remainingBalanceFormatted !== void 0 && a.drawCenterAsciiText(`REMAINING BALANCE: ${e.remainingBalanceFormatted}`, 366, 1), e.notes && a.drawAsciiText(`NOTES: ${e.notes}`, 20, 384, 1), a.drawHLine(402, 10, n - 11, 1);
    const N = Math.floor((n - (s ? 260 : 360)) / 2);
    return a.drawBarcode(e.receiptNumber, N, 416, 40, s ? 2 : 3), a.drawCenterAsciiText(e.receiptNumber, 462, 1), a.drawDashedLine(482, 10, n - 11), a.drawCenterAsciiText("THANK YOU - TIBYAN EDUCATION", 496, 1), a.drawCenterAsciiText(e.teacherName, 512, 1), a.drawHLine(532, 20, n - 21, 2), {
      widthDots: n,
      heightDots: i,
      bitData: a.buffer,
      rasterByteCount: a.buffer.length,
      paperWidth: t
    };
  }
  /**
   * Build complete ESC/POS payload containing a full raster receipt (GS v 0).
   * Ensures Arabic shaping, custom typography, and complex layouts are printed
   * as pure monochrome bit images rather than relying on printer Arabic code pages.
   */
  static buildRasterReceipt(e) {
    const t = new ls();
    return t.setAlign("center"), t.rasterBitImage(e.widthDots, e.heightDots, e.bitData), t.feed(e.feedLines ?? 3), (e.autoCut ?? !0) && t.cut("partial"), t.build();
  }
  /**
   * Build complete formatted ESC/POS receipt for standard thermal printers.
   * Defaults to pure 1-bit monochrome raster (GS v 0) to ensure Arabic quality,
   * deterministic rendering, and independence from printer code pages.
   */
  static buildReceipt(e, t) {
    const n = (t == null ? void 0 : t.paperWidth) === "58mm" ? "58mm" : "80mm", i = (t == null ? void 0 : t.autoCut) ?? !0, a = ls.createDeterministicReceiptRaster(e, n);
    return ls.buildRasterReceipt({
      widthDots: a.widthDots,
      heightDots: a.heightDots,
      bitData: a.bitData,
      autoCut: i,
      feedLines: 3
    });
  }
}
class G extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "CurriculumError";
  }
}
class Op {
  constructor(e, t) {
    h(this, "catalogRepo");
    h(this, "nodeRepo");
    h(this, "groupCurriculumRepo");
    h(this, "groupRepo");
    h(this, "sessionRepo");
    this.systemDb = e, this.academicDb = t, this.catalogRepo = new ys(e), this.nodeRepo = new es(e), this.groupCurriculumRepo = new Kn(t), this.groupRepo = new mt(t), this.sessionRepo = new ht(t);
  }
  checkPermission(e, t) {
    var s;
    if (t) {
      if (!e || !e.userId || !((s = e.fullName) != null && s.trim()) || !e.role)
        throw new G(
          "PERMISSION_DENIED",
          "PERMISSION_DENIED: Complete authenticated actor (userId, fullName, role) is required"
        );
      try {
        te(e.role, e.permissions ?? [], t);
      } catch {
        throw new G(
          "PERMISSION_DENIED",
          `PERMISSION_DENIED: Actor does not have required permission '${t}'`
        );
      }
    }
  }
  getActorSnapshot(e) {
    var s, n;
    const t = ((s = e == null ? void 0 : e.fullName) == null ? void 0 : s.trim()) || ((n = e == null ? void 0 : e.nameSnapshot) == null ? void 0 : n.trim());
    if (!t || !(e != null && e.userId))
      throw new G(
        "PERMISSION_DENIED",
        "PERMISSION_DENIED: Complete authenticated actor is required for audit snapshot"
      );
    return t;
  }
  // ==========================================
  // 1. Catalog Management (System DB)
  // ==========================================
  listCatalogs(e, t) {
    return this.checkPermission(t, "GROUPS_READ"), this.catalogRepo.list(e).map((n) => this.mapCatalogRow(n));
  }
  getCatalog(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.catalogRepo.findById(e);
    if (!s)
      throw new G("CATALOG_NOT_FOUND", `Curriculum catalog '${e}' not found`);
    return this.mapCatalogRow(s);
  }
  createCatalog(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = gu.parse(e), n = this.catalogRepo.getNextVersion(
      s.educationSystem,
      s.gradeLevel,
      s.languageTrack,
      s.mathBranch
    ), i = (/* @__PURE__ */ new Date()).toISOString(), a = b.randomUUID();
    return this.systemDb.transaction((o) => {
      const d = new ys(o), u = new Te(o), l = d.create({
        id: a,
        code: s.code,
        title: s.title,
        description: s.description ?? null,
        educationSystem: s.educationSystem,
        gradeLevel: s.gradeLevel,
        languageTrack: s.languageTrack,
        mathBranch: s.mathBranch ?? null,
        version: n,
        status: "DRAFT",
        publishedAt: null,
        createdAt: i,
        updatedAt: i
      });
      return u.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "CURRICULUM_CATALOG_CREATED",
        entityType: "CURRICULUM_CATALOG",
        entityId: l.id,
        beforeJson: null,
        afterJson: JSON.stringify(l),
        metadataJson: null,
        createdAt: i
      }), this.mapCatalogRow(l);
    });
  }
  updateCatalog(e, t, s) {
    this.checkPermission(s, "GROUPS_WRITE");
    const n = _u.parse(t), i = this.catalogRepo.findById(e);
    if (!i)
      throw new G("CATALOG_NOT_FOUND", `Curriculum catalog '${e}' not found`);
    if (i.status !== "DRAFT")
      throw new G(
        "IMMUTABLE_CATALOG",
        `Catalog '${e}' is in status '${i.status}' and cannot be edited. Revise catalog to version N+1 instead.`
      );
    const a = (/* @__PURE__ */ new Date()).toISOString();
    return this.systemDb.transaction((o) => {
      const d = new ys(o), u = new Te(o), l = d.update(e, {
        ...n.title !== void 0 ? { title: n.title } : {},
        ...n.description !== void 0 ? { description: n.description } : {},
        updatedAt: a
      });
      if (!l)
        throw new G("CATALOG_NOT_FOUND", `Catalog '${e}' could not be updated`);
      return u.insert({
        id: b.randomUUID(),
        actorType: s != null && s.userId ? "USER" : "SYSTEM",
        actorUserId: (s == null ? void 0 : s.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(s),
        action: "CURRICULUM_CATALOG_UPDATED",
        entityType: "CURRICULUM_CATALOG",
        entityId: e,
        beforeJson: JSON.stringify(i),
        afterJson: JSON.stringify(l),
        metadataJson: null,
        createdAt: a
      }), this.mapCatalogRow(l);
    });
  }
  publishCatalog(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = this.catalogRepo.findById(e);
    if (!s)
      throw new G("CATALOG_NOT_FOUND", `Curriculum catalog '${e}' not found`);
    if (s.status === "PUBLISHED")
      return this.mapCatalogRow(s);
    if (s.status !== "DRAFT")
      throw new G(
        "INVALID_STATUS_TRANSITION",
        `Cannot publish a catalog in '${s.status}' status`
      );
    const n = this.nodeRepo.findByCatalogId(e);
    this.validateCatalogTreeCompleteness(e, n);
    const i = (/* @__PURE__ */ new Date()).toISOString();
    return this.systemDb.transaction((a) => {
      const o = new ys(a), d = new Te(a), u = o.update(e, {
        status: "PUBLISHED",
        publishedAt: i,
        updatedAt: i
      });
      if (!u)
        throw new G("CATALOG_NOT_FOUND", `Catalog '${e}' could not be updated`);
      return d.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "CURRICULUM_CATALOG_PUBLISHED",
        entityType: "CURRICULUM_CATALOG",
        entityId: e,
        beforeJson: JSON.stringify(s),
        afterJson: JSON.stringify(u),
        metadataJson: null,
        createdAt: i
      }), this.mapCatalogRow(u);
    });
  }
  reviseCatalog(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = this.catalogRepo.findById(e);
    if (!s)
      throw new G("CATALOG_NOT_FOUND", `Curriculum catalog '${e}' not found`);
    if (s.status !== "PUBLISHED")
      throw new G(
        "INVALID_STATUS_TRANSITION",
        `Only PUBLISHED catalogs can be revised into a new version. Catalog '${e}' is in '${s.status}' status.`
      );
    const n = this.catalogRepo.getNextVersion(
      s.educationSystem,
      s.gradeLevel,
      s.languageTrack,
      s.mathBranch
    ), i = (/* @__PURE__ */ new Date()).toISOString(), a = b.randomUUID(), o = this.nodeRepo.findByCatalogId(e);
    return this.systemDb.transaction((d) => {
      const u = new ys(d), l = new es(d), p = new Te(d), S = u.create({
        id: a,
        code: `${s.code}-v${n}`,
        title: s.title,
        description: s.description,
        educationSystem: s.educationSystem,
        gradeLevel: s.gradeLevel,
        languageTrack: s.languageTrack,
        mathBranch: s.mathBranch,
        version: n,
        status: "DRAFT",
        publishedAt: null,
        createdAt: i,
        updatedAt: i
      }), N = /* @__PURE__ */ new Map();
      for (const y of o)
        N.set(y.id, b.randomUUID());
      for (const y of o) {
        const I = N.get(y.id), L = y.parentId ? N.get(y.parentId) ?? null : null;
        l.create({
          id: I,
          catalogId: a,
          parentId: L,
          tier: y.tier,
          titleAr: y.titleAr,
          titleEn: y.titleEn ?? null,
          code: y.code,
          description: y.description ?? null,
          metadataJson: y.metadataJson ?? null,
          orderIndex: y.orderIndex,
          createdAt: i,
          updatedAt: i
        });
      }
      return p.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "CURRICULUM_CATALOG_REVISED",
        entityType: "CURRICULUM_CATALOG",
        entityId: a,
        beforeJson: JSON.stringify({ sourceCatalogId: e, sourceVersion: s.version }),
        afterJson: JSON.stringify(S),
        metadataJson: JSON.stringify({ clonedNodesCount: o.length }),
        createdAt: i
      }), this.mapCatalogRow(S);
    });
  }
  // ==========================================
  // 2. Node Management (System DB)
  // ==========================================
  createNode(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = Nu.parse(e), n = this.catalogRepo.findById(s.catalogId);
    if (!n)
      throw new G(
        "CATALOG_NOT_FOUND",
        `Curriculum catalog '${s.catalogId}' not found`
      );
    if (n.status !== "DRAFT")
      throw new G(
        "IMMUTABLE_CATALOG",
        "Cannot add nodes to a published or archived catalog. Revise catalog to version N+1 instead."
      );
    if (s.tier === "UNIT" && s.parentId)
      throw new G(
        "INVALID_PARENT_TIER",
        "UNIT tier nodes cannot have a parent (they must be root)"
      );
    let i = null;
    if (s.parentId && (i = this.nodeRepo.findById(s.parentId), !i || i.catalogId !== s.catalogId))
      throw new G(
        "PARENT_NODE_NOT_FOUND",
        `Parent node '${s.parentId}' not found in catalog '${s.catalogId}'`
      );
    this.validateParent(s.tier, i);
    const a = this.nodeRepo.findByCatalogId(s.catalogId).filter((l) => (l.parentId ?? null) === (s.parentId ?? null));
    if (s.orderIndex !== void 0 && a.find((p) => p.orderIndex === s.orderIndex))
      throw new G(
        "INVALID_INPUT",
        `Reorder collision: position '${s.orderIndex}' would be occupied by multiple sibling nodes`
      );
    const o = s.orderIndex ?? this.nodeRepo.getNextOrderIndex(s.catalogId, s.parentId ?? null), d = (/* @__PURE__ */ new Date()).toISOString(), u = b.randomUUID();
    return this.systemDb.transaction((l) => {
      const p = new es(l), S = new Te(l), N = p.create({
        id: u,
        catalogId: s.catalogId,
        parentId: s.parentId ?? null,
        tier: s.tier,
        titleAr: s.titleAr,
        titleEn: s.titleEn ?? null,
        code: s.code,
        description: s.description ?? null,
        metadataJson: s.metadataJson ?? null,
        orderIndex: o,
        createdAt: d,
        updatedAt: d
      });
      return S.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "CURRICULUM_NODE_CREATED",
        entityType: "CURRICULUM_NODE",
        entityId: N.id,
        beforeJson: null,
        afterJson: JSON.stringify(N),
        metadataJson: null,
        createdAt: d
      }), this.mapNodeRow(N);
    });
  }
  updateNode(e, t, s) {
    this.checkPermission(s, "GROUPS_WRITE");
    const n = Iu.parse(t), i = this.nodeRepo.findById(e);
    if (!i)
      throw new G("NODE_NOT_FOUND", `Curriculum node '${e}' not found`);
    const a = this.catalogRepo.findById(i.catalogId);
    if (!a || a.status !== "DRAFT")
      throw new G(
        "IMMUTABLE_CATALOG",
        "Cannot update nodes of a published or archived catalog. Revise catalog to version N+1 instead."
      );
    if (n.orderIndex !== void 0 && n.orderIndex !== i.orderIndex && this.nodeRepo.findByCatalogId(i.catalogId).filter((l) => (l.parentId ?? null) === (i.parentId ?? null) && l.id !== e).find((l) => l.orderIndex === n.orderIndex))
      throw new G(
        "INVALID_INPUT",
        `Reorder collision: position '${n.orderIndex}' would be occupied by multiple sibling nodes`
      );
    const o = (/* @__PURE__ */ new Date()).toISOString();
    return this.systemDb.transaction((d) => {
      const u = new es(d), l = new Te(d), p = u.update(e, {
        ...n.titleAr !== void 0 ? { titleAr: n.titleAr } : {},
        ...n.titleEn !== void 0 ? { titleEn: n.titleEn } : {},
        ...n.code !== void 0 ? { code: n.code } : {},
        ...n.description !== void 0 ? { description: n.description } : {},
        ...n.metadataJson !== void 0 ? { metadataJson: n.metadataJson } : {},
        ...n.orderIndex !== void 0 ? { orderIndex: n.orderIndex } : {},
        updatedAt: o
      });
      if (!p)
        throw new G("NODE_NOT_FOUND", `Node '${e}' could not be updated`);
      return l.insert({
        id: b.randomUUID(),
        actorType: s != null && s.userId ? "USER" : "SYSTEM",
        actorUserId: (s == null ? void 0 : s.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(s),
        action: "CURRICULUM_NODE_UPDATED",
        entityType: "CURRICULUM_NODE",
        entityId: e,
        beforeJson: JSON.stringify(i),
        afterJson: JSON.stringify(p),
        metadataJson: null,
        createdAt: o
      }), this.mapNodeRow(p);
    });
  }
  deleteNode(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = this.nodeRepo.findById(e);
    if (!s)
      throw new G("NODE_NOT_FOUND", `Curriculum node '${e}' not found`);
    const n = this.catalogRepo.findById(s.catalogId);
    if (!n || n.status !== "DRAFT")
      throw new G(
        "IMMUTABLE_CATALOG",
        "Cannot delete nodes of a published or archived catalog. Revise catalog to version N+1 instead."
      );
    const i = this.nodeRepo.findByCatalogId(s.catalogId), a = this.collectDescendantIds(e, i), o = [e, ...a], d = (/* @__PURE__ */ new Date()).toISOString();
    return this.systemDb.transaction((u) => {
      const l = new es(u), p = new Te(u), S = l.deleteBatch(o);
      return p.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "CURRICULUM_NODE_DELETED",
        entityType: "CURRICULUM_NODE",
        entityId: e,
        beforeJson: JSON.stringify({ targetNode: s, deletedDescendantIds: a }),
        afterJson: null,
        metadataJson: JSON.stringify({ deletedTotal: S }),
        createdAt: d
      }), S;
    });
  }
  reorderNodes(e, t, s) {
    let n, i;
    typeof e == "string" ? (n = Or.parse({
      catalogId: e,
      items: t
    }), i = s) : (n = Or.parse(e), i = t), this.checkPermission(i, "GROUPS_WRITE");
    const a = this.catalogRepo.findById(n.catalogId);
    if (!a || a.status !== "DRAFT")
      throw new G(
        "IMMUTABLE_CATALOG",
        "Cannot reorder nodes of a published or archived catalog."
      );
    const o = /* @__PURE__ */ new Set();
    for (const I of n.items) {
      if (o.has(I.orderIndex))
        throw new G(
          "INVALID_INPUT",
          `Duplicate orderIndex '${I.orderIndex}' in reorder batch`
        );
      o.add(I.orderIndex);
    }
    const d = this.nodeRepo.findByCatalogId(n.catalogId), u = new Map(d.map((I) => [I.id, I]));
    let l;
    for (const I of n.items) {
      const L = u.get(I.id);
      if (!L)
        throw new G(
          "NODE_NOT_FOUND",
          `One or more nodes do not belong to catalog '${n.catalogId}'`
        );
      const w = L.parentId ?? null;
      if (l === void 0)
        l = w;
      else if (l !== w)
        throw new G(
          "INVALID_INPUT",
          "All nodes in a reorder batch must belong to the same parent node"
        );
    }
    const p = d.filter((I) => (I.parentId ?? null) === l), S = /* @__PURE__ */ new Map();
    for (const I of p)
      S.set(I.id, I.orderIndex);
    for (const I of n.items)
      S.set(I.id, I.orderIndex);
    const N = /* @__PURE__ */ new Set();
    for (const [, I] of S.entries()) {
      if (N.has(I))
        throw new G(
          "INVALID_INPUT",
          `Reorder collision: position '${I}' would be occupied by multiple sibling nodes`
        );
      N.add(I);
    }
    const y = (/* @__PURE__ */ new Date()).toISOString();
    this.systemDb.transaction((I) => {
      const L = new es(I), w = new Te(I);
      L.reorder(n.catalogId, n.items), w.insert({
        id: b.randomUUID(),
        actorType: i != null && i.userId ? "USER" : "SYSTEM",
        actorUserId: (i == null ? void 0 : i.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(i),
        action: "CURRICULUM_NODES_REORDERED",
        entityType: "CURRICULUM_CATALOG",
        entityId: n.catalogId,
        beforeJson: null,
        afterJson: JSON.stringify(n.items),
        metadataJson: null,
        createdAt: y
      });
    });
  }
  getTree(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.nodeRepo.findByCatalogId(e);
    return this.buildTree(s);
  }
  // ==========================================
  // 3. Group Assignment & Pacing (Cross-DB)
  // ==========================================
  assignGroupCatalog(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = yu.parse(e), n = this.groupRepo.findById(s.groupId);
    if (!n)
      throw new G("GROUP_NOT_FOUND", `Group '${s.groupId}' not found`);
    const i = this.catalogRepo.findById(s.catalogId);
    if (!i)
      throw new G("CATALOG_NOT_FOUND", `Curriculum catalog '${s.catalogId}' not found`);
    if (i.status !== "PUBLISHED")
      throw new G(
        "INVALID_STATUS_TRANSITION",
        "Cannot assign an unready draft catalog to an active group"
      );
    const a = n.focusMathBranch ?? null, o = i.mathBranch ?? null;
    if (n.educationSystem !== i.educationSystem || n.gradeLevel !== i.gradeLevel || n.languageTrack !== i.languageTrack || a !== o)
      throw new G(
        "SCOPE_MISMATCH",
        `Group scope (${n.educationSystem}/${n.gradeLevel}/${n.languageTrack}/${a}) does not match catalog scope (${i.educationSystem}/${i.gradeLevel}/${i.languageTrack}/${o}) (math branch mismatch)`
      );
    const d = this.groupCurriculumRepo.getAssignment(s.groupId), u = d && d.catalogId !== s.catalogId, l = this.groupCurriculumRepo.countByGroup(s.groupId);
    if (u && l > 0 && s.resetProgress !== !0)
      throw new G(
        "REASSIGNMENT_REQUIRES_RESET_CONFIRMATION",
        "REASSIGNMENT_REQUIRES_RESET_CONFIRMATION: Group already has recorded curriculum progress. Reassigning catalog requires explicit resetProgress: true to confirm progress reset."
      );
    const p = (/* @__PURE__ */ new Date()).toISOString();
    return this.academicDb.transaction((S) => {
      const N = new Kn(S), y = new me(S);
      u && s.resetProgress === !0 && N.resetProgressForGroup(s.groupId);
      const I = N.assignCatalog({
        id: d ? d.id : b.randomUUID(),
        groupId: s.groupId,
        catalogId: s.catalogId,
        catalogVersion: i.version,
        assignedAt: p,
        assignedByUserId: (t == null ? void 0 : t.userId) ?? null,
        assignedByNameSnapshot: this.getActorSnapshot(t),
        notes: s.notes ?? null,
        createdAt: d ? d.createdAt : p,
        updatedAt: p
      }), L = u && s.resetProgress === !0 ? "GROUP_CURRICULUM_REASSIGNED_WITH_RESET" : "GROUP_CURRICULUM_ASSIGNED";
      return y.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: L,
        entityType: "GROUP_CURRICULUM_ASSIGNMENT",
        entityId: I.id,
        beforeJson: d ? JSON.stringify(d) : null,
        afterJson: JSON.stringify(I),
        metadataJson: JSON.stringify({ resetPreviousProgress: u && s.resetProgress === !0 }),
        createdAt: p
      }), this.mapAssignmentRow(I);
    });
  }
  updateGroupNodeProgress(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = Tu.parse(e), n = this.groupCurriculumRepo.getAssignment(s.groupId);
    if (!n)
      throw new G(
        "INVALID_INPUT",
        `Group '${s.groupId}' has no assigned curriculum catalog`
      );
    const i = this.nodeRepo.findById(s.nodeId);
    if (!i || i.catalogId !== n.catalogId)
      throw new G(
        "NODE_NOT_FOUND",
        `Curriculum node '${s.nodeId}' does not belong to group's assigned catalog`
      );
    if (i.tier !== "SKILL")
      throw new G(
        "INVALID_NODE_TIER",
        `Progress tracking is only supported for SKILL tier nodes (node '${i.id}' is '${i.tier}')`
      );
    const a = (/* @__PURE__ */ new Date()).toISOString(), o = this.groupCurriculumRepo.getNodeProgress(s.groupId, s.nodeId);
    return this.academicDb.transaction((d) => {
      const u = new Kn(d), l = new me(d), p = u.upsertProgress({
        id: o ? o.id : b.randomUUID(),
        groupId: s.groupId,
        catalogId: n.catalogId,
        nodeId: s.nodeId,
        status: s.status,
        completedAt: s.status === "COMPLETED" ? a : null,
        updatedByUserId: (t == null ? void 0 : t.userId) ?? null,
        updatedByNameSnapshot: this.getActorSnapshot(t),
        notes: s.notes ?? (o == null ? void 0 : o.notes) ?? null,
        createdAt: o ? o.createdAt : a,
        updatedAt: a
      });
      return l.insert({
        id: b.randomUUID(),
        actorType: t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: this.getActorSnapshot(t),
        action: "GROUP_CURRICULUM_PROGRESS_UPDATED",
        entityType: "GROUP_CURRICULUM_PROGRESS",
        entityId: p.id,
        beforeJson: o ? JSON.stringify(o) : null,
        afterJson: JSON.stringify(p),
        metadataJson: null,
        createdAt: a
      }), this.mapProgressRow(p);
    });
  }
  getGroupOverview(e, t) {
    var ue;
    this.checkPermission(t, "GROUPS_READ");
    const s = this.groupCurriculumRepo.getAssignment(e);
    if (!s)
      return {
        assignment: null,
        catalog: null,
        totalSkills: 0,
        completedSkills: 0,
        inProgressSkills: 0,
        remainingSkills: 0,
        completionPercentage: 0,
        projection: {
          status: "INSUFFICIENT_DATA",
          messageAr: "لم يتم تعيين منهج دراسي لهذه المجموعة بعد",
          completedSessionsCount: 0,
          skillsPerWeekRate: null,
          projectedCompletionDate: null
        }
      };
    const n = this.catalogRepo.findById(s.catalogId);
    if (!n || n.status !== "PUBLISHED")
      throw new G(
        "CATALOG_INTEGRITY_ERROR",
        `CATALOG_INTEGRITY_ERROR: Assigned catalog '${s.catalogId}' is missing or not in PUBLISHED status`
      );
    const i = this.mapCatalogRow(n), a = this.nodeRepo.findByCatalogId(s.catalogId), o = a.filter((M) => M.tier === "SKILL"), d = o.length > 0 ? o : a.filter((M) => M.tier === "LESSON"), u = d.length, l = this.groupCurriculumRepo.getProgressByGroup(e), p = new Map(l.map((M) => [M.nodeId, M.status]));
    let S = 0, N = 0;
    for (const M of d) {
      const K = p.get(M.id);
      K === "COMPLETED" ? S++ : K === "IN_PROGRESS" && N++;
    }
    const y = Math.max(0, u - S), I = u > 0 ? Math.round(S / u * 1e3) / 10 : 0, L = this.sessionRepo.listByGroup(e).filter((M) => M.status === "COMPLETED"), w = L.length;
    let P = "INSUFFICIENT_DATA", O = "بيانات الحصص والتقدم غير كافية لحساب التوقع بدقة (يلزم حصتان مكتملتان ومهارة مكتملة واحدة على الأقل)", k = null, B = null;
    if (u > 0 && y === 0)
      P = "COMPLETED", O = "تم إكمال جميع مهارات المنهج بنجاح", B = ((ue = L[L.length - 1]) == null ? void 0 : ue.effectiveDate) ?? null;
    else if (w >= 2 && S > 0) {
      const M = [...L].sort((vs, Cs) => vs.effectiveDate.localeCompare(Cs.effectiveDate)), K = M[0], Se = M[M.length - 1], Tt = new Date(K.effectiveDate), qe = new Date(Se.effectiveDate), He = Math.max(0, qe.getTime() - Tt.getTime()), dt = Math.max(7, Math.round(He / (1e3 * 60 * 60 * 24))) / 7, Kt = S / dt;
      if (k = Math.round(Kt * 10) / 10, Kt <= 0)
        P = "UNREALISTIC_PACING", O = "معدل الإنجاز الحالي غير كافٍ لتقدير موعد الانتهاء";
      else {
        const vs = y / Kt, Cs = qe.getTime() + vs * 7 * 24 * 60 * 60 * 1e3;
        B = new Date(Cs).toISOString().split("T")[0] ?? null, P = "INSUFFICIENT_DATA", O = `يسير المنهج بمعدل تقديري ${k} مهارة/أسبوع (موعد الانتهاء التقديري: ${B})؛ لم يُحدد تاريخ مستهدف للمنهج`;
      }
    }
    return {
      assignment: this.mapAssignmentRow(s),
      catalog: i,
      totalSkills: u,
      completedSkills: S,
      inProgressSkills: N,
      remainingSkills: y,
      completionPercentage: I,
      projection: {
        status: P,
        messageAr: O,
        completedSessionsCount: w,
        skillsPerWeekRate: k,
        projectedCompletionDate: B
      }
    };
  }
  getGroupProgressMap(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.groupCurriculumRepo.getProgressByGroup(e), n = {};
    for (const i of s)
      n[i.nodeId] = i.status;
    return n;
  }
  // ==========================================
  // Private Helpers
  // ==========================================
  validateParent(e, t) {
    if (e === "UNIT") {
      if (t !== null)
        throw new G(
          "INVALID_PARENT_TIER",
          "UNIT tier nodes cannot have a parent (they must be root)"
        );
      return;
    }
    if (!t)
      throw new G(
        "PARENT_NODE_NOT_FOUND",
        `Nodes of tier '${e}' must specify a parent node`
      );
    if (e === "LESSON" && t.tier !== "UNIT")
      throw new G(
        "INVALID_PARENT_TIER",
        `LESSON parent must be a UNIT (received '${t.tier}')`
      );
    if (e === "CONCEPT" && t.tier !== "LESSON")
      throw new G(
        "INVALID_PARENT_TIER",
        `CONCEPT parent must be a LESSON (received '${t.tier}')`
      );
    if (e === "SKILL" && t.tier !== "CONCEPT")
      throw new G(
        "INVALID_PARENT_TIER",
        `SKILL parent must be a CONCEPT (received '${t.tier}')`
      );
  }
  validateCatalogTreeCompleteness(e, t) {
    if (t.length === 0)
      throw new G(
        "EMPTY_CATALOG",
        "Cannot publish an empty catalog without any curriculum nodes"
      );
    const s = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
    for (const o of t) {
      s.set(o.id, o);
      const d = o.parentId ?? "__ROOT__";
      n.has(d) || n.set(d, []), n.get(d).push(o);
    }
    for (const o of t)
      if (o.parentId !== null && !s.has(o.parentId))
        throw new G(
          "INCOMPLETE_CATALOG",
          `Node '${o.titleAr}' (${o.id}) references a non-existent parent '${o.parentId}'`
        );
    const i = n.get("__ROOT__") ?? [];
    if (i.length === 0)
      throw new G(
        "INCOMPLETE_CATALOG",
        "Catalog must contain at least one root UNIT module before publishing"
      );
    for (const o of i)
      if (o.tier !== "UNIT")
        throw new G(
          "INCOMPLETE_CATALOG",
          `Root node '${o.titleAr}' (${o.id}) has invalid tier '${o.tier}'. All root nodes must be UNIT tier.`
        );
    const a = /* @__PURE__ */ new Set();
    for (const o of i) {
      if (a.has(o.id))
        throw new G(
          "INCOMPLETE_CATALOG",
          `Duplicate root node '${o.id}' encountered`
        );
      a.add(o.id);
      const d = n.get(o.id) ?? [];
      if (d.length === 0)
        throw new G(
          "INCOMPLETE_CATALOG",
          `Unit '${o.titleAr}' (${o.code}) has no LESSON modules`
        );
      for (const u of d) {
        if (u.tier !== "LESSON")
          throw new G(
            "INCOMPLETE_CATALOG",
            `Child of Unit '${o.titleAr}' must be LESSON tier, got '${u.tier}'`
          );
        if (a.has(u.id))
          throw new G(
            "INCOMPLETE_CATALOG",
            `Cyclic or duplicate reachability detected at lesson '${u.id}'`
          );
        a.add(u.id);
        const l = n.get(u.id) ?? [];
        if (l.length === 0)
          throw new G(
            "INCOMPLETE_CATALOG",
            `Lesson '${u.titleAr}' (${u.code}) has no CONCEPT items`
          );
        for (const p of l) {
          if (p.tier !== "CONCEPT")
            throw new G(
              "INCOMPLETE_CATALOG",
              `Child of Lesson '${u.titleAr}' must be CONCEPT tier, got '${p.tier}'`
            );
          if (a.has(p.id))
            throw new G(
              "INCOMPLETE_CATALOG",
              `Cyclic or duplicate reachability detected at concept '${p.id}'`
            );
          a.add(p.id);
          const S = n.get(p.id) ?? [];
          if (S.length === 0)
            throw new G(
              "INCOMPLETE_CATALOG",
              `Concept '${p.titleAr}' (${p.code}) has no measurable SKILL items`
            );
          for (const N of S) {
            if (N.tier !== "SKILL")
              throw new G(
                "INCOMPLETE_CATALOG",
                `Child of Concept '${p.titleAr}' must be SKILL tier, got '${N.tier}'`
              );
            if (a.has(N.id))
              throw new G(
                "INCOMPLETE_CATALOG",
                `Cyclic or duplicate reachability detected at skill '${N.id}'`
              );
            if (a.add(N.id), (n.get(N.id) ?? []).length > 0)
              throw new G(
                "INCOMPLETE_CATALOG",
                `Skill '${N.titleAr}' (${N.id}) cannot have child nodes (leaf tier)`
              );
          }
        }
      }
    }
    if (a.size !== t.length)
      throw new G(
        "INCOMPLETE_CATALOG",
        `Catalog contains ${t.length - a.size} disconnected or orphaned node(s) not reachable from root UNITs`
      );
  }
  collectDescendantIds(e, t) {
    const s = /* @__PURE__ */ new Map();
    for (const a of t)
      if (a.parentId) {
        const o = s.get(a.parentId) ?? [];
        o.push(a.id), s.set(a.parentId, o);
      }
    const n = [], i = [e];
    for (; i.length > 0; ) {
      const a = i.shift(), o = s.get(a) ?? [];
      for (const d of o)
        n.push(d), i.push(d);
    }
    return n;
  }
  buildTree(e) {
    const t = /* @__PURE__ */ new Map(), s = [], n = [...e].sort((i, a) => i.orderIndex - a.orderIndex);
    for (const i of n)
      t.set(i.id, {
        ...this.mapNodeRow(i),
        children: []
      });
    for (const i of n) {
      const a = t.get(i.id);
      if (!i.parentId)
        s.push(a);
      else {
        const o = t.get(i.parentId);
        o ? o.children.push(a) : s.push(a);
      }
    }
    return s;
  }
  mapCatalogRow(e) {
    return {
      id: e.id,
      code: e.code,
      title: e.title,
      description: e.description,
      educationSystem: e.educationSystem,
      gradeLevel: e.gradeLevel,
      languageTrack: e.languageTrack,
      mathBranch: e.mathBranch,
      version: e.version,
      status: e.status,
      publishedAt: e.publishedAt,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  mapNodeRow(e) {
    return {
      id: e.id,
      catalogId: e.catalogId,
      parentId: e.parentId,
      tier: e.tier,
      titleAr: e.titleAr,
      titleEn: e.titleEn ?? null,
      code: e.code,
      description: e.description,
      metadataJson: e.metadataJson ?? null,
      orderIndex: e.orderIndex,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  mapAssignmentRow(e) {
    return {
      id: e.id,
      groupId: e.groupId,
      catalogId: e.catalogId,
      catalogVersion: e.catalogVersion,
      assignedAt: e.assignedAt,
      assignedByUserId: e.assignedByUserId,
      assignedByNameSnapshot: e.assignedByNameSnapshot,
      notes: e.notes,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  mapProgressRow(e) {
    return {
      id: e.id,
      groupId: e.groupId,
      catalogId: e.catalogId,
      nodeId: e.nodeId,
      status: e.status,
      completedAt: e.completedAt,
      updatedByUserId: e.updatedByUserId,
      updatedByNameSnapshot: e.updatedByNameSnapshot,
      notes: e.notes,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
}
const wp = [
  "\\write",
  "\\newwrite",
  "\\openout",
  "\\openin",
  "\\closeout",
  "\\closein",
  "\\read",
  "\\input",
  "\\include",
  "\\endinput",
  "\\catcode",
  "\\csname",
  "\\endcsname",
  "\\def",
  "\\gdef",
  "\\edef",
  "\\xdef",
  "\\let",
  "\\futurelet",
  "\\immediate",
  "\\special",
  "\\escapechar",
  "\\url",
  "\\href",
  "\\loop",
  "\\repeat",
  "\\every",
  "\\outer"
];
function vp(r) {
  if (!r || typeof r != "string" || r.trim().length === 0)
    return {
      valid: !1,
      error: "LaTeX expression cannot be empty",
      errorAr: "المعادلة الرياضية لا يمكن أن تكون فارغة"
    };
  const e = r.trim();
  for (const o of wp) {
    const d = o.replace(/\\/g, "\\\\");
    if (new RegExp(`${d}(?![a-zA-Z])`, "i").test(e))
      return {
        valid: !1,
        error: `Unsafe TeX command rejected: ${o}`,
        errorAr: `تم رفض أمر TeX غير آمن: ${o}`
      };
  }
  const t = [];
  let s = !1;
  for (let o = 0; o < e.length; o++) {
    const d = e[o];
    if (s) {
      s = !1;
      continue;
    }
    if (d === "\\") {
      s = !0;
      continue;
    }
    if (d === "{" || d === "[" || d === "(")
      t.push({ char: d, index: o });
    else if (d === "}" || d === "]" || d === ")") {
      if (t.length === 0)
        return {
          valid: !1,
          error: `Unmatched closing delimiter '${d}' at position ${o + 1}`,
          errorAr: `قوس إغلاق غير متطابق '${d}' عند الموضع ${o + 1}`
        };
      const u = t.pop();
      if ({ "}": "{", "]": "[", ")": "(" }[d] !== u.char)
        return {
          valid: !1,
          error: `Mismatched delimiters: expected closing for '${u.char}' but found '${d}' at position ${o + 1}`,
          errorAr: `عدم تطابق في الأقواس: متوقع إغلاق '${u.char}' ولكن وُجد '${d}' عند الموضع ${o + 1}`
        };
    }
  }
  if (t.length > 0) {
    const o = t[t.length - 1];
    return {
      valid: !1,
      error: `Unclosed delimiter '${o.char}' at position ${o.index + 1}`,
      errorAr: `قوس غير مغلق '${o.char}' عند الموضع ${o.index + 1}`
    };
  }
  const n = [], i = /\\(begin|end)\{([a-zA-Z0-9*]+)\}/g;
  let a;
  for (; (a = i.exec(e)) !== null; ) {
    const o = a[1], d = a[2], u = a.index;
    if (o === "begin")
      n.push({ name: d, index: u });
    else if (o === "end") {
      if (n.length === 0)
        return {
          valid: !1,
          error: `Unmatched '\\end{${d}}' at position ${u + 1}`,
          errorAr: `بيئة إغلاق غير متطابقة '\\end{${d}}' عند الموضع ${u + 1}`
        };
      const l = n.pop();
      if (l.name !== d)
        return {
          valid: !1,
          error: `Mismatched environment: expected '\\end{${l.name}}' but found '\\end{${d}}' at position ${u + 1}`,
          errorAr: `عدم تطابق في البيئة الرياضية: متوقع '\\end{${l.name}}' ولكن وُجد '\\end{${d}}'`
        };
    }
  }
  if (n.length > 0) {
    const o = n[n.length - 1];
    return {
      valid: !1,
      error: `Unclosed environment '\\begin{${o.name}}' at position ${o.index + 1}`,
      errorAr: `بيئة رياضية غير مغلقة '\\begin{${o.name}}'`
    };
  }
  return { valid: !0 };
}
class Zn extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "ContentSanitizationError";
  }
}
class Hu {
  constructor(e) {
    h(this, "mediaValidator");
    this.mediaValidator = e;
  }
  /**
   * Sanitizes plain text by stripping HTML tags, scripts, and null bytes.
   */
  sanitizeText(e) {
    if (!e || typeof e != "string") return "";
    let t = e.replace(/\0/g, "");
    return t = t.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ""), t = t.replace(/<[^>]+>/g, ""), t;
  }
  /**
   * Validates and sanitizes an entire MathRichContent document.
   */
  sanitizeDocument(e) {
    const t = _e.parse(e), s = [];
    for (const n of t.blocks)
      s.push(this.sanitizeBlock(n));
    return {
      version: 1,
      blocks: s
    };
  }
  /**
   * Validates and sanitizes a single RichContentBlock.
   */
  sanitizeBlock(e) {
    switch (e.type) {
      case "text": {
        const t = this.sanitizeText(e.content);
        return {
          ...e,
          content: t
        };
      }
      case "math": {
        const t = vp(e.latex);
        if (!t.valid)
          throw new Zn(
            "INVALID_LATEX",
            t.error ?? "Invalid or unsafe LaTeX expression"
          );
        return {
          ...e,
          altTextAr: e.altTextAr ? this.sanitizeText(e.altTextAr) : e.altTextAr
        };
      }
      case "image": {
        if (this.mediaValidator)
          this.mediaValidator.validateMediaId(e.mediaId);
        else if (/[\0\\]|\.\.|\%2e\%2e/i.test(e.mediaId))
          throw new Zn(
            "INVALID_MEDIA_ID",
            "Path traversal or illegal characters detected in image mediaId"
          );
        return {
          ...e,
          caption: e.caption ? this.sanitizeText(e.caption) : e.caption,
          altText: e.altText ? this.sanitizeText(e.altText) : e.altText
        };
      }
      case "geometry": {
        if (e.svgPayload) {
          const t = e.svgPayload;
          if (/<script\b/i.test(t) || /\bon[a-z]+\s*=/i.test(t) || /javascript:/i.test(t) || /<object\b/i.test(t) || /<embed\b/i.test(t) || /<iframe\b/i.test(t))
            throw new Zn(
              "UNSAFE_SVG_PAYLOAD",
              "Executable script, external object, or event handler detected in SVG payload"
            );
        }
        return {
          ...e,
          title: e.title ? this.sanitizeText(e.title) : e.title
        };
      }
    }
  }
}
class Ws extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "LessonPlannerError";
  }
}
class Cp {
  constructor(e, t) {
    h(this, "nodeRepo");
    h(this, "lessonPlanRepo");
    h(this, "sanitizer");
    this.academicDb = t, this.nodeRepo = new es(e), this.lessonPlanRepo = new rn(t), this.sanitizer = new Hu();
  }
  checkPermission(e, t = "GROUPS_READ") {
    if (e && e.role)
      try {
        te(e.role, e.permissions ?? [], t);
      } catch {
        throw new Ws("PERMISSION_DENIED", `Permission '${t}' is required.`);
      }
  }
  sanitizeSections(e) {
    return {
      objectives: e.objectives.map((t) => this.sanitizer.sanitizeText(t)),
      priorReview: this.sanitizer.sanitizeDocument(e.priorReview),
      explanation: this.sanitizer.sanitizeDocument(e.explanation),
      examples: this.sanitizer.sanitizeDocument(e.examples),
      inClassQuestions: this.sanitizer.sanitizeDocument(e.inClassQuestions),
      commonMistakes: this.sanitizer.sanitizeDocument(e.commonMistakes),
      homework: this.sanitizer.sanitizeDocument(e.homework),
      timingBreakdown: e.timingBreakdown.map((t) => ({
        ...t,
        label: this.sanitizer.sanitizeText(t.label)
      })),
      notes: e.notes ? this.sanitizer.sanitizeText(e.notes) : null
    };
  }
  createLessonPlan(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = Au.parse(e), n = this.nodeRepo.findById(s.curriculumNodeId);
    if (!n)
      throw new Ws(
        "CURRICULUM_NODE_NOT_FOUND",
        `Curriculum node not found: ${s.curriculumNodeId}`
      );
    const i = this.sanitizeSections(s.sections), a = (/* @__PURE__ */ new Date()).toISOString(), o = b.randomUUID(), d = this.academicDb.transaction((u) => {
      const l = new rn(u), p = new me(u), S = l.create({
        id: o,
        curriculumNodeId: s.curriculumNodeId,
        title: s.title.trim(),
        targetDurationMinutes: s.targetDurationMinutes,
        status: s.status,
        version: 1,
        sectionsJson: JSON.stringify(i),
        createdAt: a,
        updatedAt: a
      });
      return p.insert({
        id: b.randomUUID(),
        actorType: (t == null ? void 0 : t.role) === "ASSISTANT" || t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: (t == null ? void 0 : t.nameSnapshot) ?? (t == null ? void 0 : t.fullName) ?? "System",
        action: "LESSON_PLAN_CREATED",
        entityType: "LESSON_PLAN",
        entityId: o,
        beforeJson: null,
        afterJson: JSON.stringify(S),
        metadataJson: JSON.stringify({
          curriculumNodeId: s.curriculumNodeId,
          targetDurationMinutes: s.targetDurationMinutes,
          nodeTitle: n.titleAr
        }),
        createdAt: a
      }), S;
    });
    return this.mapToDto(d, i);
  }
  updateLessonPlan(e, t, s) {
    this.checkPermission(s, "GROUPS_WRITE");
    const n = Ru.parse(t), i = this.lessonPlanRepo.findById(e);
    if (!i)
      throw new Ws("LESSON_PLAN_NOT_FOUND", `Lesson plan not found: ${e}`);
    let a;
    n.sections && (a = this.sanitizeSections(n.sections));
    const o = (/* @__PURE__ */ new Date()).toISOString(), d = i.version + 1, u = this.academicDb.transaction((l) => {
      const p = new rn(l), S = new me(l), N = p.update(e, {
        ...n.title ? { title: n.title.trim() } : {},
        ...n.targetDurationMinutes ? { targetDurationMinutes: n.targetDurationMinutes } : {},
        ...n.status ? { status: n.status } : {},
        ...a ? { sectionsJson: JSON.stringify(a) } : {},
        version: d,
        updatedAt: o
      });
      return S.insert({
        id: b.randomUUID(),
        actorType: (s == null ? void 0 : s.role) === "ASSISTANT" || s != null && s.userId ? "USER" : "SYSTEM",
        actorUserId: (s == null ? void 0 : s.userId) ?? null,
        actorNameSnapshot: (s == null ? void 0 : s.nameSnapshot) ?? (s == null ? void 0 : s.fullName) ?? "System",
        action: "LESSON_PLAN_UPDATED",
        entityType: "LESSON_PLAN",
        entityId: e,
        beforeJson: JSON.stringify(i),
        afterJson: JSON.stringify(N),
        metadataJson: JSON.stringify({
          previousVersion: i.version,
          newVersion: d
        }),
        createdAt: o
      }), N;
    });
    return this.mapToDto(u, a);
  }
  getLessonPlanById(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.lessonPlanRepo.findById(e);
    if (!s)
      throw new Ws("LESSON_PLAN_NOT_FOUND", `Lesson plan not found: ${e}`);
    return this.mapToDto(s);
  }
  listLessonPlansByNode(e, t) {
    return this.checkPermission(t, "GROUPS_READ"), this.lessonPlanRepo.findByCurriculumNodeId(e).map((n) => this.mapToDto(n));
  }
  listLessonPlans(e, t) {
    return this.checkPermission(t, "GROUPS_READ"), this.lessonPlanRepo.list(e).map((n) => this.mapToDto(n));
  }
  archiveLessonPlan(e, t) {
    return this.checkPermission(t, "GROUPS_WRITE"), this.updateLessonPlan(e, { status: "ARCHIVED" }, t);
  }
  mapToDto(e, t) {
    const s = t ?? JSON.parse(e.sectionsJson);
    return {
      id: e.id,
      curriculumNodeId: e.curriculumNodeId,
      title: e.title,
      targetDurationMinutes: e.targetDurationMinutes,
      status: e.status,
      version: e.version,
      sections: s,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
}
class Ns extends Error {
  constructor(e, t) {
    super(t), this.code = e, this.name = "SessionReflectionError";
  }
}
class Up {
  constructor(e) {
    h(this, "sessionRepo");
    h(this, "reflectionRepo");
    h(this, "lessonPlanRepo");
    this.academicDb = e, this.sessionRepo = new ht(e), this.reflectionRepo = new jn(e), this.lessonPlanRepo = new rn(e);
  }
  checkPermission(e, t = "GROUPS_READ") {
    if (e && e.role)
      try {
        te(e.role, e.permissions ?? [], t);
      } catch {
        throw new Ns("PERMISSION_DENIED", `Permission '${t}' is required.`);
      }
  }
  createReflection(e, t) {
    this.checkPermission(t, "GROUPS_WRITE");
    const s = Du.parse(e);
    if (!this.sessionRepo.findById(s.sessionId))
      throw new Ns("SESSION_NOT_FOUND", `Session not found: ${s.sessionId}`);
    if (this.reflectionRepo.findBySessionId(s.sessionId))
      throw new Ns(
        "DUPLICATE_SESSION_REFLECTION",
        `A reflection already exists for session: ${s.sessionId}`
      );
    let a = null, o = null;
    if (s.lessonPlanId) {
      const p = this.lessonPlanRepo.findById(s.lessonPlanId);
      if (!p)
        throw new Ns(
          "LESSON_PLAN_NOT_FOUND",
          `Lesson plan not found: ${s.lessonPlanId}`
        );
      o = {
        planId: p.id,
        curriculumNodeId: p.curriculumNodeId,
        title: p.title,
        targetDurationMinutes: p.targetDurationMinutes,
        version: p.version,
        sections: JSON.parse(p.sectionsJson),
        snapshottedAt: (/* @__PURE__ */ new Date()).toISOString()
      }, a = JSON.stringify(o);
    }
    const d = (/* @__PURE__ */ new Date()).toISOString(), u = b.randomUUID(), l = this.academicDb.transaction((p) => {
      var I, L, w;
      const S = new jn(p), N = new me(p), y = S.create({
        id: u,
        sessionId: s.sessionId,
        lessonPlanId: s.lessonPlanId ?? null,
        lessonPlanSnapshotJson: a,
        completionStatus: s.completionStatus,
        uncompletedItems: ((I = s.uncompletedItems) == null ? void 0 : I.trim()) || null,
        topicsNeedingReview: ((L = s.topicsNeedingReview) == null ? void 0 : L.trim()) || null,
        quickNotes: ((w = s.quickNotes) == null ? void 0 : w.trim()) || null,
        createdAt: d,
        updatedAt: d
      });
      return N.insert({
        id: b.randomUUID(),
        actorType: (t == null ? void 0 : t.role) === "ASSISTANT" || t != null && t.userId ? "USER" : "SYSTEM",
        actorUserId: (t == null ? void 0 : t.userId) ?? null,
        actorNameSnapshot: (t == null ? void 0 : t.nameSnapshot) ?? (t == null ? void 0 : t.fullName) ?? "System",
        action: "SESSION_REFLECTION_CREATED",
        entityType: "SESSION_REFLECTION",
        entityId: u,
        beforeJson: null,
        afterJson: JSON.stringify(y),
        metadataJson: JSON.stringify({
          sessionId: s.sessionId,
          completionStatus: s.completionStatus,
          lessonPlanId: s.lessonPlanId ?? null
        }),
        createdAt: d
      }), y;
    });
    return this.mapToDto(l, o);
  }
  updateReflection(e, t, s) {
    this.checkPermission(s, "GROUPS_WRITE");
    const n = Ou.parse(t), i = this.reflectionRepo.findById(e);
    if (!i)
      throw new Ns("REFLECTION_NOT_FOUND", `Reflection not found: ${e}`);
    const a = (/* @__PURE__ */ new Date()).toISOString(), o = this.academicDb.transaction((d) => {
      var S, N, y;
      const u = new jn(d), l = new me(d), p = u.update(e, {
        ...n.completionStatus ? { completionStatus: n.completionStatus } : {},
        ...n.uncompletedItems !== void 0 ? { uncompletedItems: ((S = n.uncompletedItems) == null ? void 0 : S.trim()) || null } : {},
        ...n.topicsNeedingReview !== void 0 ? { topicsNeedingReview: ((N = n.topicsNeedingReview) == null ? void 0 : N.trim()) || null } : {},
        ...n.quickNotes !== void 0 ? { quickNotes: ((y = n.quickNotes) == null ? void 0 : y.trim()) || null } : {},
        updatedAt: a
      });
      return l.insert({
        id: b.randomUUID(),
        actorType: (s == null ? void 0 : s.role) === "ASSISTANT" || s != null && s.userId ? "USER" : "SYSTEM",
        actorUserId: (s == null ? void 0 : s.userId) ?? null,
        actorNameSnapshot: (s == null ? void 0 : s.nameSnapshot) ?? (s == null ? void 0 : s.fullName) ?? "System",
        action: "SESSION_REFLECTION_UPDATED",
        entityType: "SESSION_REFLECTION",
        entityId: e,
        beforeJson: JSON.stringify(i),
        afterJson: JSON.stringify(p),
        metadataJson: JSON.stringify({
          sessionId: i.sessionId
        }),
        createdAt: a
      }), p;
    });
    return this.mapToDto(o);
  }
  getReflectionBySessionId(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.reflectionRepo.findBySessionId(e);
    return s ? this.mapToDto(s) : null;
  }
  getReflectionById(e, t) {
    this.checkPermission(t, "GROUPS_READ");
    const s = this.reflectionRepo.findById(e);
    if (!s)
      throw new Ns("REFLECTION_NOT_FOUND", `Reflection not found: ${e}`);
    return this.mapToDto(s);
  }
  mapToDto(e, t) {
    let s = t ?? null;
    return !s && e.lessonPlanSnapshotJson && (s = JSON.parse(e.lessonPlanSnapshotJson)), {
      id: e.id,
      sessionId: e.sessionId,
      lessonPlanId: e.lessonPlanId,
      lessonPlanSnapshot: s,
      completionStatus: e.completionStatus,
      uncompletedItems: e.uncompletedItems,
      topicsNeedingReview: e.topicsNeedingReview,
      quickNotes: e.quickNotes,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
}
class Ii {
  /**
   * Validates that the file exists, is a valid PDF, and calculates its metadata.
   */
  static scanFile(e) {
    if (!Ft.existsSync(e))
      throw new Error(`ملف PDF غير موجود في المسار المحدد: ${e}`);
    if (!Ft.statSync(e).isFile())
      throw new Error(`المسار المحدد ليس ملفاً صالحاً: ${e}`);
    const s = Ft.readFileSync(e);
    return this.scanBuffer(s, st.basename(e));
  }
  /**
   * Scans a PDF buffer for magic bytes, SHA-256 hash, and page count.
   */
  static scanBuffer(e, t) {
    if (e.length < 5 || e.toString("utf-8", 0, 5) !== "%PDF-")
      throw new Error("الملف المحدد ليس ملف PDF صالح (غياب الترويسة القياسية %PDF-)");
    const s = ge.createHash("sha256").update(e).digest("hex"), n = this.extractPageCount(e);
    return {
      fileName: this.sanitizeFileName(t),
      fileSizeBytes: e.length,
      sha256Hash: s,
      pageCount: n
    };
  }
  /**
   * Deterministically extracts page count from the PDF binary structure.
   */
  static extractPageCount(e) {
    const t = e.toString("binary"), s = /\/Type\s*\/Pages\b[^>]*\/Count\s+(\d+)/g;
    let n, i = 0;
    for (; (n = s.exec(t)) !== null; ) {
      const d = parseInt(n[1], 10);
      !isNaN(d) && d > i && (i = d);
    }
    if (i > 0)
      return i;
    const a = /\/Type\s*\/Page\b(?!\s*s)/g;
    let o = 0;
    for (; a.exec(t) !== null; )
      o++;
    return o > 0 ? o : 1;
  }
  /**
   * Sanitizes filename to prevent directory traversal and illegal characters.
   */
  static sanitizeFileName(e) {
    return st.basename(e).replace(/[^a-zA-Z0-9_\u0600-\u06FF.-]/g, "_");
  }
  /**
   * Prevents directory traversal by verifying resolved path remains within baseDir.
   */
  static assertWithinBase(e, t) {
    const s = st.resolve(t);
    if (!st.resolve(e).startsWith(s))
      throw new Error("محاولة وصول غير مصرح بها خارج المجلد المخصص للمصادر (Directory Traversal Detected)");
  }
}
class xp {
  constructor(e, t) {
    h(this, "sourceDocRepo");
    h(this, "sourceRefRepo");
    h(this, "catalogRepo");
    h(this, "auditRepo");
    h(this, "storageDir");
    this.sourceDocRepo = new ch(e), this.sourceRefRepo = new Lc(e), this.catalogRepo = new ys(e), this.auditRepo = new Te(e), this.storageDir = st.resolve(t), Ft.existsSync(this.storageDir) || Ft.mkdirSync(this.storageDir, { recursive: !0 });
  }
  importSource(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = wu.parse(e), n = Ii.scanFile(s.sourceFilePath);
    if (s.curriculumCatalogId && !this.catalogRepo.findById(s.curriculumCatalogId))
      throw new Error(`فهرس المنهج المحدد غير موجود: ${s.curriculumCatalogId}`);
    const i = this.sourceDocRepo.findByHash(n.sha256Hash);
    if (i)
      return this.mapDocToDto(i);
    const a = `${n.sha256Hash}.pdf`, o = st.join(this.storageDir, a);
    Ii.assertWithinBase(o, this.storageDir), Ft.existsSync(o) || Ft.copyFileSync(s.sourceFilePath, o);
    const d = ge.randomUUID(), u = (/* @__PURE__ */ new Date()).toISOString(), l = this.sourceDocRepo.create({
      id: d,
      title: s.title,
      author: s.author ?? null,
      publisher: s.publisher ?? null,
      editionYear: s.editionYear ?? null,
      curriculumCatalogId: s.curriculumCatalogId ?? null,
      filePath: st.relative(this.storageDir, o),
      fileName: n.fileName,
      fileSizeBytes: n.fileSizeBytes,
      sha256Hash: n.sha256Hash,
      pageCount: n.pageCount,
      status: "INDEXED",
      metadataJson: null,
      createdAt: u,
      updatedAt: u
    });
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "IMPORT_SOURCE_DOCUMENT",
      entityType: "SOURCE_DOCUMENT",
      entityId: d,
      afterJson: JSON.stringify(l),
      createdAt: u
    }), this.mapDocToDto(l);
  }
  getSource(e) {
    const t = this.sourceDocRepo.findById(e);
    if (!t)
      throw new Error(`وثيقة المصدر غير موجودة: ${e}`);
    return this.mapDocToDto(t);
  }
  listSources(e) {
    return this.sourceDocRepo.list(e).map((s) => this.mapDocToDto(s));
  }
  updateSource(e, t, s) {
    te(s.role, s.permissions ?? [], "GROUPS_WRITE");
    const n = vu.parse(t), i = this.sourceDocRepo.findById(e);
    if (!i)
      throw new Error(`وثيقة المصدر غير موجودة: ${e}`);
    if (n.curriculumCatalogId && !this.catalogRepo.findById(n.curriculumCatalogId))
      throw new Error(`فهرس المنهج المحدد غير موجود: ${n.curriculumCatalogId}`);
    const a = this.sourceDocRepo.update(e, {
      title: n.title ?? i.title,
      author: n.author !== void 0 ? n.author : i.author,
      publisher: n.publisher !== void 0 ? n.publisher : i.publisher,
      editionYear: n.editionYear !== void 0 ? n.editionYear : i.editionYear,
      curriculumCatalogId: n.curriculumCatalogId !== void 0 ? n.curriculumCatalogId : i.curriculumCatalogId
    }), o = (/* @__PURE__ */ new Date()).toISOString();
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: s.userId ? "USER" : "SYSTEM",
      actorUserId: s.userId ?? null,
      actorNameSnapshot: s.fullName,
      action: "UPDATE_SOURCE_DOCUMENT",
      entityType: "SOURCE_DOCUMENT",
      entityId: e,
      beforeJson: JSON.stringify(i),
      afterJson: JSON.stringify(a),
      createdAt: o
    }), this.mapDocToDto(a);
  }
  deleteSource(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = this.sourceDocRepo.findById(e);
    if (!s)
      throw new Error(`وثيقة المصدر غير موجودة: ${e}`);
    this.sourceDocRepo.delete(e);
    const n = st.join(this.storageDir, s.filePath);
    try {
      Ft.existsSync(n) && Ft.unlinkSync(n);
    } catch {
    }
    const i = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "DELETE_SOURCE_DOCUMENT",
      entityType: "SOURCE_DOCUMENT",
      entityId: e,
      beforeJson: JSON.stringify(s),
      createdAt: i
    });
  }
  // --- Page References ---
  createReference(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = Cu.parse(e), n = this.sourceDocRepo.findById(s.sourceDocumentId);
    if (!n)
      throw new Error(`وثيقة المصدر غير موجودة: ${s.sourceDocumentId}`);
    if (s.startPage > n.pageCount || s.endPage > n.pageCount)
      throw new Error(
        `نطاق الصفحات المطلوب (${s.startPage}-${s.endPage}) يتجاوز إجمالي صفحات المصدر (${n.pageCount})`
      );
    const i = ge.randomUUID(), a = (/* @__PURE__ */ new Date()).toISOString(), o = this.sourceRefRepo.create({
      id: i,
      sourceDocumentId: s.sourceDocumentId,
      startPage: s.startPage,
      endPage: s.endPage,
      referenceLabel: s.referenceLabel,
      notes: s.notes ?? null,
      createdAt: a,
      updatedAt: a
    });
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "CREATE_SOURCE_REFERENCE",
      entityType: "SOURCE_REFERENCE",
      entityId: i,
      afterJson: JSON.stringify(o),
      createdAt: a
    }), this.mapRefToDto(o);
  }
  listReferences(e) {
    return (e ? this.sourceRefRepo.listBySourceDocument(e) : this.sourceRefRepo.findAll()).map((s) => this.mapRefToDto(s));
  }
  updateReference(e, t, s) {
    te(s.role, s.permissions ?? [], "GROUPS_WRITE");
    const n = Vm.parse(t), i = this.sourceRefRepo.findById(e);
    if (!i)
      throw new Error(`مرجع الصفحة غير موجود: ${e}`);
    const a = n.startPage ?? i.startPage, o = n.endPage ?? i.endPage;
    if (o < a)
      throw new Error("رقم صفحة النهاية يجب أن يكون أكبر من أو يساوي رقم صفحة البداية");
    const d = this.sourceRefRepo.update(e, {
      startPage: a,
      endPage: o,
      referenceLabel: n.referenceLabel ?? i.referenceLabel,
      notes: n.notes !== void 0 ? n.notes : i.notes
    }), u = (/* @__PURE__ */ new Date()).toISOString();
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: s.userId ? "USER" : "SYSTEM",
      actorUserId: s.userId ?? null,
      actorNameSnapshot: s.fullName,
      action: "UPDATE_SOURCE_REFERENCE",
      entityType: "SOURCE_REFERENCE",
      entityId: e,
      beforeJson: JSON.stringify(i),
      afterJson: JSON.stringify(d),
      createdAt: u
    }), this.mapRefToDto(d);
  }
  deleteReference(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = this.sourceRefRepo.findById(e);
    if (!s)
      throw new Error(`مرجع الصفحة غير موجود: ${e}`);
    this.sourceRefRepo.delete(e);
    const n = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "DELETE_SOURCE_REFERENCE",
      entityType: "SOURCE_REFERENCE",
      entityId: e,
      beforeJson: JSON.stringify(s),
      createdAt: n
    });
  }
  resolveAbsolutePath(e) {
    return st.resolve(this.storageDir, e);
  }
  mapDocToDto(e) {
    return {
      id: e.id,
      title: e.title,
      author: e.author,
      publisher: e.publisher,
      editionYear: e.editionYear,
      curriculumCatalogId: e.curriculumCatalogId,
      filePath: e.filePath,
      fileName: e.fileName,
      fileSizeBytes: e.fileSizeBytes,
      sha256Hash: e.sha256Hash,
      pageCount: e.pageCount,
      status: e.status,
      metadata: e.metadataJson ? JSON.parse(e.metadataJson) : void 0,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
  mapRefToDto(e) {
    return {
      id: e.id,
      sourceDocumentId: e.sourceDocumentId,
      startPage: e.startPage,
      endPage: e.endPage,
      referenceLabel: e.referenceLabel,
      notes: e.notes,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
}
class ns {
  constructor(e) {
    this.questionRepo = e;
  }
  /**
   * Normalizes Arabic text by removing diacritics, unifying letter shapes, and stripping punctuation.
   */
  static normalizeText(e) {
    return e ? e.replace(/[\u064B-\u065F\u0670]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").toLowerCase().replace(/[^\w\s\u0600-\u06FF=+\-*/^()]/g, " ").replace(/\s+/g, " ").trim() : "";
  }
  /**
   * Normalizes LaTeX mathematical expressions by stripping non-semantic spaces.
   */
  static normalizeLatex(e) {
    return e ? e.trim().replace(/\s*\{\s*/g, "{").replace(/\s*\}\s*/g, "}").replace(/\s*=\s*/g, "=").replace(/\s*\+\s*/g, "+").replace(/\s*-\s*/g, "-").replace(/\s*\*\s*/g, "*").replace(/\s*\\cdot\s*/g, "\\cdot").replace(/\s+/g, " ") : "";
  }
  /**
   * Generates a deterministic content fingerprint (SHA-256) from a MathRichContent document.
   */
  static generateFingerprint(e) {
    const t = [];
    for (const n of e.blocks)
      if (n.type === "text") {
        const i = this.normalizeText(n.content);
        i && t.push(i);
      } else if (n.type === "math") {
        const i = this.normalizeLatex(n.latex);
        i && t.push(`math:${i}`);
      }
    const s = t.join("||");
    return ge.createHash("sha256").update(s).digest("hex");
  }
  /**
   * Checks whether a given question body is a duplicate of an existing question.
   */
  checkDuplicate(e, t = []) {
    const s = ns.generateFingerprint(e), i = this.questionRepo.findByFingerprint(s).find((a) => a.status !== "ARCHIVED");
    if (i)
      return {
        isDuplicate: !0,
        matchLevel: "EXACT",
        existingQuestionId: i.id,
        existingQuestionCode: i.code,
        reasonAr: `تطابق تام ومؤكد مع المسألة المسجلة كود (${i.code})`
      };
    if (t.length > 0) {
      const a = this.extractTokens(e);
      for (const o of t) {
        const d = this.questionRepo.list({
          curriculumNodeId: o,
          status: "ACTIVE"
        });
        for (const u of d)
          try {
            const l = JSON.parse(u.bodyJson), p = this.extractTokens(l), S = this.calculateJaccardSimilarity(a, p);
            if (S >= 0.8)
              return {
                isDuplicate: !0,
                matchLevel: "CANDIDATE",
                existingQuestionId: u.id,
                existingQuestionCode: u.code,
                reasonAr: `تشابه كبير (${Math.round(S * 100)}%) في صياغة المسألة مع (${u.code}) لنفس المهارة التعليمية`
              };
          } catch {
          }
      }
    }
    return {
      isDuplicate: !1,
      matchLevel: "NONE",
      reasonAr: "لا يوجد تطابق مسبق في بنك الأسئلة"
    };
  }
  /**
   * Previews a batch of question records for bulk ingestion review.
   */
  previewBulk(e) {
    const t = [], s = /* @__PURE__ */ new Map();
    for (const n of e) {
      const i = [];
      (!n.body || !n.body.blocks || n.body.blocks.length === 0) && i.push("نص المسألة فارغ تماماً"), (!n.curriculumNodeIds || n.curriculumNodeIds.length === 0) && i.push("المسألة غير مربوطة بأي مهارة أو درس في المنهج");
      const a = ns.generateFingerprint(n.body);
      s.has(a) ? i.push(`تكرار تام مع مسألة أخرى داخل نفس دفعة الاستيراد (رقم ${s.get(a)})`) : s.set(a, n.tempId);
      const o = this.checkDuplicate(n.body, n.curriculumNodeIds);
      let d = "VALID", u = "CREATE_NEW";
      o.matchLevel === "EXACT" ? (d = "DUPLICATE_EXACT", u = n.sourceReferenceIds && n.sourceReferenceIds.length > 0 ? "LINK_SOURCE" : "DISMISS") : o.matchLevel === "CANDIDATE" ? (d = "DUPLICATE_CANDIDATE", u = "CREATE_NEW") : i.length > 0 ? (d = "WARNING", u = "CREATE_NEW") : (!n.sourceReferenceIds || n.sourceReferenceIds.length === 0) && (d = "WARNING", i.push("المسألة لا تتضمن مرجع كتاب أو صفحة")), t.push({
        tempId: n.tempId,
        item: n,
        status: d,
        validationErrors: i,
        duplicateMatch: o.isDuplicate ? o : void 0,
        suggestedAction: u
      });
    }
    return t;
  }
  extractTokens(e) {
    const t = /* @__PURE__ */ new Set();
    for (const s of e.blocks)
      s.type === "text" ? ns.normalizeText(s.content).split(" ").filter((i) => i.length > 2).forEach((i) => t.add(i)) : s.type === "math" && t.add(ns.normalizeLatex(s.latex));
    return t;
  }
  calculateJaccardSimilarity(e, t) {
    if (e.size === 0 || t.size === 0) return 0;
    let s = 0;
    for (const i of e)
      t.has(i) && s++;
    const n = e.size + t.size - s;
    return n === 0 ? 0 : s / n;
  }
}
class bp {
  constructor(e) {
    h(this, "questionRepo");
    h(this, "nodeRepo");
    h(this, "sourceRefRepo");
    h(this, "auditRepo");
    h(this, "sanitizer");
    h(this, "duplicateDetector");
    this.questionRepo = new Pc(e), this.nodeRepo = new es(e), this.sourceRefRepo = new Lc(e), this.auditRepo = new Te(e), this.sanitizer = new Hu(), this.duplicateDetector = new ns(this.questionRepo);
  }
  createQuestion(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = Uu.parse(e), n = this.sanitizer.sanitizeDocument(s.body), i = s.modelAnswer ? this.sanitizer.sanitizeDocument(s.modelAnswer) : null;
    for (const p of s.curriculumNodeIds)
      if (!this.nodeRepo.findById(p))
        throw new Error(`عنصر المنهج المحدد غير موجود: ${p}`);
    for (const p of s.sourceReferenceIds)
      if (!this.sourceRefRepo.findById(p))
        throw new Error(`مرجع المصدر المحدد غير موجود: ${p}`);
    const a = ns.generateFingerprint(n), o = this.questionRepo.getNextCode(), d = ge.randomUUID(), u = (/* @__PURE__ */ new Date()).toISOString(), l = this.questionRepo.create(
      {
        id: d,
        code: o,
        bodyJson: JSON.stringify(n),
        modelAnswerJson: i ? JSON.stringify(i) : null,
        questionType: s.questionType,
        difficulty: s.difficulty,
        defaultMarks: s.defaultMarks,
        languageTrack: s.languageTrack,
        status: s.status,
        contentFingerprint: a,
        metadataJson: null,
        createdAt: u,
        updatedAt: u
      },
      s.curriculumNodeIds,
      s.sourceReferenceIds
    );
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "CREATE_QUESTION",
      entityType: "QUESTION",
      entityId: d,
      afterJson: JSON.stringify(l),
      createdAt: u
    }), this.getQuestion(d);
  }
  getQuestion(e) {
    const t = this.questionRepo.findById(e);
    if (!t)
      throw new Error(`المسألة غير موجودة في بنك الأسئلة: ${e}`);
    const s = this.questionRepo.getCurriculumTagIds(e), n = this.questionRepo.getSourceReferences(e);
    return this.mapToDto(t, s, n);
  }
  listQuestions(e) {
    const t = e ? bu.parse(e) : void 0;
    return this.questionRepo.list(t).map((n) => {
      const i = this.questionRepo.getCurriculumTagIds(n.id), a = this.questionRepo.getSourceReferences(n.id);
      return this.mapToDto(n, i, a);
    });
  }
  updateQuestion(e, t, s) {
    te(s.role, s.permissions ?? [], "GROUPS_WRITE");
    const n = xu.parse(t), i = this.questionRepo.findById(e);
    if (!i)
      throw new Error(`المسألة غير موجودة في بنك الأسئلة: ${e}`);
    let a, o;
    n.body && (a = this.sanitizer.sanitizeDocument(n.body), o = ns.generateFingerprint(a));
    let d;
    if (n.modelAnswer !== void 0 && (d = n.modelAnswer ? this.sanitizer.sanitizeDocument(n.modelAnswer) : null), n.curriculumNodeIds) {
      for (const l of n.curriculumNodeIds)
        if (!this.nodeRepo.findById(l)) throw new Error(`عنصر المنهج المحدد غير موجود: ${l}`);
    }
    if (n.sourceReferenceIds) {
      for (const l of n.sourceReferenceIds)
        if (!this.sourceRefRepo.findById(l)) throw new Error(`مرجع المصدر المحدد غير موجود: ${l}`);
    }
    this.questionRepo.update(
      e,
      {
        bodyJson: a ? JSON.stringify(a) : void 0,
        modelAnswerJson: d !== void 0 ? d ? JSON.stringify(d) : null : void 0,
        questionType: n.questionType,
        difficulty: n.difficulty,
        defaultMarks: n.defaultMarks,
        languageTrack: n.languageTrack,
        status: n.status,
        contentFingerprint: o
      },
      n.curriculumNodeIds,
      n.sourceReferenceIds
    );
    const u = (/* @__PURE__ */ new Date()).toISOString();
    return this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: s.userId ? "USER" : "SYSTEM",
      actorUserId: s.userId ?? null,
      actorNameSnapshot: s.fullName,
      action: "UPDATE_QUESTION",
      entityType: "QUESTION",
      entityId: e,
      beforeJson: JSON.stringify(i),
      createdAt: u
    }), this.getQuestion(e);
  }
  archiveQuestion(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = this.questionRepo.findById(e);
    if (!s)
      throw new Error(`المسألة غير موجودة: ${e}`);
    this.questionRepo.archive(e);
    const n = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "ARCHIVE_QUESTION",
      entityType: "QUESTION",
      entityId: e,
      beforeJson: JSON.stringify(s),
      createdAt: n
    });
  }
  deleteQuestion(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = this.questionRepo.findById(e);
    if (!s)
      throw new Error(`المسألة غير موجودة: ${e}`);
    this.questionRepo.delete(e);
    const n = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "DELETE_QUESTION",
      entityType: "QUESTION",
      entityId: e,
      beforeJson: JSON.stringify(s),
      createdAt: n
    });
  }
  linkSources(e, t, s) {
    if (te(s.role, s.permissions ?? [], "GROUPS_WRITE"), !this.questionRepo.findById(e))
      throw new Error(`المسألة غير موجودة: ${e}`);
    for (const a of t)
      this.questionRepo.linkSourceReference(e, a);
    const i = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: s.userId ? "USER" : "SYSTEM",
      actorUserId: s.userId ?? null,
      actorNameSnapshot: s.fullName,
      action: "LINK_SOURCES_TO_QUESTION",
      entityType: "QUESTION",
      entityId: e,
      afterJson: JSON.stringify({ linkedSourceIds: t }),
      createdAt: i
    });
  }
  unlinkSource(e, t, s) {
    te(s.role, s.permissions ?? [], "GROUPS_WRITE"), this.questionRepo.unlinkSourceReference(e, t);
    const n = (/* @__PURE__ */ new Date()).toISOString();
    this.auditRepo.insert({
      id: ge.randomUUID(),
      actorType: s.userId ? "USER" : "SYSTEM",
      actorUserId: s.userId ?? null,
      actorNameSnapshot: s.fullName,
      action: "UNLINK_SOURCE_FROM_QUESTION",
      entityType: "QUESTION",
      entityId: e,
      afterJson: JSON.stringify({ unlinkedSourceId: t }),
      createdAt: n
    });
  }
  checkDuplicate(e, t = []) {
    return this.duplicateDetector.checkDuplicate(e, t);
  }
  previewBulk(e) {
    const t = e.map((s) => Zr.parse(s));
    return this.duplicateDetector.previewBulk(t);
  }
  commitBulk(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = Lu.parse(e);
    let n = 0, i = 0, a = 0;
    for (const o of s.actions) {
      if (o.action === "DISMISS") {
        a++;
        continue;
      }
      if (o.action === "LINK_SOURCE") {
        if (!o.targetQuestionId)
          throw new Error("يجب تحديد المسألة المستهدفة لربط المصدر البديل بها");
        for (const d of o.item.sourceReferenceIds)
          this.questionRepo.addSourceReference(
            o.targetQuestionId,
            d,
            "تم الربط عبر الاستيراد المجمع"
          );
        i++;
        continue;
      }
      o.action === "CREATE_NEW" && (this.createQuestion(
        {
          body: o.item.body,
          modelAnswer: o.item.modelAnswer,
          questionType: o.item.questionType,
          difficulty: o.item.difficulty,
          defaultMarks: o.item.defaultMarks,
          languageTrack: o.item.languageTrack,
          status: "ACTIVE",
          curriculumNodeIds: o.item.curriculumNodeIds,
          sourceReferenceIds: o.item.sourceReferenceIds
        },
        t
      ), n++);
    }
    return { createdCount: n, linkedCount: i, dismissedCount: a };
  }
  mapToDto(e, t, s) {
    return {
      id: e.id,
      code: e.code,
      body: JSON.parse(e.bodyJson),
      modelAnswer: e.modelAnswerJson ? JSON.parse(e.modelAnswerJson) : null,
      questionType: e.questionType,
      difficulty: e.difficulty,
      defaultMarks: e.defaultMarks,
      languageTrack: e.languageTrack,
      status: e.status,
      contentFingerprint: e.contentFingerprint,
      curriculumTags: t,
      sourceReferences: s,
      metadata: e.metadataJson ? JSON.parse(e.metadataJson) : void 0,
      createdAt: e.createdAt,
      updatedAt: e.updatedAt
    };
  }
}
function Gu(r, e) {
  const t = [], s = e.filter(
    (n) => n.curriculumTags.some((i) => r.curriculumNodeIds.includes(i)) && (r.sourceReferenceIds.length === 0 || n.sourceReferenceIds.some((i) => r.sourceReferenceIds.includes(i)))
  );
  s.length < r.totalQuestions && t.push("لا يوجد عدد كافٍ من الأسئلة المطابقة لنطاق المنهج والمصادر المحدد"), s.reduce((n, i) => n + i.defaultMarks, 0) < r.totalMarks && t.push("إجمالي درجات الأسئلة المتاحة لا يحقق الدرجة الكلية المطلوبة");
  for (const [n, i] of Object.entries(r.difficultyDistribution))
    s.filter((a) => a.difficulty === n).length < i && t.push(`لا يوجد عدد كافٍ من أسئلة الصعوبة ${n}`);
  for (const [n, i] of Object.entries(r.questionTypeDistribution))
    s.filter((a) => a.questionType === n).length < i && t.push(`لا يوجد عدد كافٍ من أسئلة النوع ${n}`);
  return { valid: t.length === 0, conflicts: t };
}
function Lp(r, e) {
  const t = Gu(r, e);
  if (!t.valid)
    return { selected: [], conflicts: t.conflicts };
  const s = e.filter(
    (d) => d.curriculumTags.some((u) => r.curriculumNodeIds.includes(u)) && (r.sourceReferenceIds.length === 0 || d.sourceReferenceIds.some((u) => r.sourceReferenceIds.includes(u)))
  ).sort((d, u) => d.id.localeCompare(u.id)), n = [], i = /* @__PURE__ */ new Set(), a = { ...r.difficultyDistribution }, o = { ...r.questionTypeDistribution };
  for (const d of s) {
    if (n.length >= r.totalQuestions) break;
    if (i.has(d.id)) continue;
    const u = a[d.difficulty] ?? 0, l = o[d.questionType] ?? 0;
    u > 0 && l > 0 && (n.push(d), i.add(d.id), a[d.difficulty] = u - 1, o[d.questionType] = l - 1);
  }
  for (const d of s) {
    if (n.length >= r.totalQuestions) break;
    if (i.has(d.id)) continue;
    const u = a[d.difficulty] ?? 0;
    if (u > 0) {
      n.push(d), i.add(d.id), a[d.difficulty] = u - 1;
      const l = o[d.questionType] ?? 0;
      l > 0 && (o[d.questionType] = l - 1);
    }
  }
  for (const d of s) {
    if (n.length >= r.totalQuestions) break;
    i.has(d.id) || (n.push(d), i.add(d.id));
  }
  return { selected: n, conflicts: [] };
}
function Pp(r, e) {
  if (!Number.isInteger(e) || e < 1 || e > 4) throw new Error("عدد النماذج غير صالح");
  if (new Set(r.map((n) => n.id)).size !== r.length) throw new Error("لا يمكن تكرار مواضع الأسئلة");
  const t = ["A", "B", "C", "D"], s = r.reduce((n, i) => n + i.marks, 0);
  if (!r.every((n) => Number.isInteger(n.marks) && n.marks > 0)) throw new Error("درجات الأسئلة غير صالحة");
  return t.slice(0, e).map((n, i) => {
    const a = r.length === 0 ? [] : [...r.slice(i % r.length), ...r.slice(0, i % r.length)];
    return { label: n, placementIds: a.map((o) => o.id), totalMarks: s, answerKey: a.map((o) => ({ placementId: o.id, answer: o.answer })) };
  });
}
const kp = `.katex{font:normal 1.21em KaTeX_Main,Times New Roman,serif;line-height:1.2;position:relative;text-indent:0;text-rendering:auto}.katex *{-ms-high-contrast-adjust:none!important;border-color:currentColor}.katex .katex-version:after{content:"0.18.7"}.katex .katex-mathml{border:0;-webkit-clip-path:inset(50%);clip-path:inset(50%);height:1px;overflow:hidden;padding:0;position:absolute;width:1px}.katex .katex-html>.katex-newline{display:block}.katex .katex-base{position:relative;white-space:nowrap;width:-webkit-min-content;width:-moz-min-content;width:min-content}.katex .katex-base,.katex .katex-strut{display:inline-block}.katex .textbf{font-weight:700}.katex .textit{font-style:italic}.katex .textrm{font-family:KaTeX_Main}.katex .textsf{font-family:KaTeX_SansSerif}.katex .texttt{font-family:KaTeX_Typewriter}.katex .mathnormal{font-family:KaTeX_Math;font-style:italic}.katex .mathit{font-family:KaTeX_Main;font-style:italic}.katex .mathrm{font-style:normal}.katex .mathbf{font-family:KaTeX_Main;font-weight:700}.katex .boldsymbol{font-family:KaTeX_Math;font-style:italic;font-weight:700}.katex .amsrm,.katex .mathbb,.katex .textbb{font-family:KaTeX_AMS}.katex .mathcal{font-family:KaTeX_Caligraphic}.katex .mathfrak,.katex .textfrak{font-family:KaTeX_Fraktur}.katex .mathboldfrak,.katex .textboldfrak{font-family:KaTeX_Fraktur;font-weight:700}.katex .mathtt{font-family:KaTeX_Typewriter}.katex .mathscr,.katex .textscr{font-family:KaTeX_Script}.katex .mathsf,.katex .textsf{font-family:KaTeX_SansSerif}.katex .mathboldsf,.katex .textboldsf{font-family:KaTeX_SansSerif;font-weight:700}.katex .mathitsf,.katex .mathsfit,.katex .textitsf{font-family:KaTeX_SansSerif;font-style:italic}.katex .mainrm{font-family:KaTeX_Main;font-style:normal}.katex .vlist-t{border-collapse:collapse;display:inline-table;table-layout:fixed}.katex .vlist-r{display:table-row}.katex .vlist{display:table-cell;position:relative;vertical-align:bottom}.katex .vlist>span{display:block;height:0;position:relative}.katex .vlist>span>span{display:inline-block}.katex .vlist>span>.pstrut{overflow:hidden;width:0}.katex .vlist-t2{margin-right:-2px}.katex .vlist-s{display:table-cell;font-size:1px;min-width:2px;vertical-align:bottom;width:2px}.katex .katex-vbox{align-items:baseline;display:inline-flex;flex-direction:column}.katex .katex-thinbox{display:inline-flex;flex-direction:row;max-width:0;width:0}.katex .msupsub{text-align:left}.katex .mfrac>span>span{text-align:center}.katex .mfrac .frac-line{border-bottom-style:solid;display:inline-block;width:100%}.katex .katex-hdashline,.katex .katex-hline,.katex .katex-overline .overline-line,.katex .katex-rule,.katex .katex-underline .underline-line,.katex .mfrac .frac-line{min-height:1px}.katex .mspace{display:inline-block}.katex .katex-smash{display:inline;line-height:0}.katex .clap,.katex .llap,.katex .rlap{position:relative;width:0}.katex .clap>.katex-inner,.katex .llap>.katex-inner,.katex .rlap>.katex-inner{position:absolute}.katex .clap>.katex-fix,.katex .llap>.katex-fix,.katex .rlap>.katex-fix{display:inline-block}.katex .llap>.katex-inner{right:0}.katex .clap>.katex-inner,.katex .rlap>.katex-inner{left:0}.katex .clap>.katex-inner>span{margin-left:-50%;margin-right:50%}.katex .katex-rule{border:0 solid;display:inline-block;position:relative}.katex .katex-hline,.katex .katex-overline .overline-line,.katex .katex-underline .underline-line{border-bottom-style:solid;display:inline-block;width:100%}.katex .katex-hdashline{border-bottom-style:dashed;display:inline-block;width:100%}.katex .sqrt>.katex-root{margin-left:.2777777778em;margin-right:-.5555555556em}.katex .fontsize-ensurer.reset-size1.size1,.katex .katex-sizing.reset-size1.size1{font-size:1em}.katex .fontsize-ensurer.reset-size1.size2,.katex .katex-sizing.reset-size1.size2{font-size:1.2em}.katex .fontsize-ensurer.reset-size1.size3,.katex .katex-sizing.reset-size1.size3{font-size:1.4em}.katex .fontsize-ensurer.reset-size1.size4,.katex .katex-sizing.reset-size1.size4{font-size:1.6em}.katex .fontsize-ensurer.reset-size1.size5,.katex .katex-sizing.reset-size1.size5{font-size:1.8em}.katex .fontsize-ensurer.reset-size1.size6,.katex .katex-sizing.reset-size1.size6{font-size:2em}.katex .fontsize-ensurer.reset-size1.size7,.katex .katex-sizing.reset-size1.size7{font-size:2.4em}.katex .fontsize-ensurer.reset-size1.size8,.katex .katex-sizing.reset-size1.size8{font-size:2.88em}.katex .fontsize-ensurer.reset-size1.size9,.katex .katex-sizing.reset-size1.size9{font-size:3.456em}.katex .fontsize-ensurer.reset-size1.size10,.katex .katex-sizing.reset-size1.size10{font-size:4.148em}.katex .fontsize-ensurer.reset-size1.size11,.katex .katex-sizing.reset-size1.size11{font-size:4.976em}.katex .fontsize-ensurer.reset-size2.size1,.katex .katex-sizing.reset-size2.size1{font-size:.8333333333em}.katex .fontsize-ensurer.reset-size2.size2,.katex .katex-sizing.reset-size2.size2{font-size:1em}.katex .fontsize-ensurer.reset-size2.size3,.katex .katex-sizing.reset-size2.size3{font-size:1.1666666667em}.katex .fontsize-ensurer.reset-size2.size4,.katex .katex-sizing.reset-size2.size4{font-size:1.3333333333em}.katex .fontsize-ensurer.reset-size2.size5,.katex .katex-sizing.reset-size2.size5{font-size:1.5em}.katex .fontsize-ensurer.reset-size2.size6,.katex .katex-sizing.reset-size2.size6{font-size:1.6666666667em}.katex .fontsize-ensurer.reset-size2.size7,.katex .katex-sizing.reset-size2.size7{font-size:2em}.katex .fontsize-ensurer.reset-size2.size8,.katex .katex-sizing.reset-size2.size8{font-size:2.4em}.katex .fontsize-ensurer.reset-size2.size9,.katex .katex-sizing.reset-size2.size9{font-size:2.88em}.katex .fontsize-ensurer.reset-size2.size10,.katex .katex-sizing.reset-size2.size10{font-size:3.4566666667em}.katex .fontsize-ensurer.reset-size2.size11,.katex .katex-sizing.reset-size2.size11{font-size:4.1466666667em}.katex .fontsize-ensurer.reset-size3.size1,.katex .katex-sizing.reset-size3.size1{font-size:.7142857143em}.katex .fontsize-ensurer.reset-size3.size2,.katex .katex-sizing.reset-size3.size2{font-size:.8571428571em}.katex .fontsize-ensurer.reset-size3.size3,.katex .katex-sizing.reset-size3.size3{font-size:1em}.katex .fontsize-ensurer.reset-size3.size4,.katex .katex-sizing.reset-size3.size4{font-size:1.1428571429em}.katex .fontsize-ensurer.reset-size3.size5,.katex .katex-sizing.reset-size3.size5{font-size:1.2857142857em}.katex .fontsize-ensurer.reset-size3.size6,.katex .katex-sizing.reset-size3.size6{font-size:1.4285714286em}.katex .fontsize-ensurer.reset-size3.size7,.katex .katex-sizing.reset-size3.size7{font-size:1.7142857143em}.katex .fontsize-ensurer.reset-size3.size8,.katex .katex-sizing.reset-size3.size8{font-size:2.0571428571em}.katex .fontsize-ensurer.reset-size3.size9,.katex .katex-sizing.reset-size3.size9{font-size:2.4685714286em}.katex .fontsize-ensurer.reset-size3.size10,.katex .katex-sizing.reset-size3.size10{font-size:2.9628571429em}.katex .fontsize-ensurer.reset-size3.size11,.katex .katex-sizing.reset-size3.size11{font-size:3.5542857143em}.katex .fontsize-ensurer.reset-size4.size1,.katex .katex-sizing.reset-size4.size1{font-size:.625em}.katex .fontsize-ensurer.reset-size4.size2,.katex .katex-sizing.reset-size4.size2{font-size:.75em}.katex .fontsize-ensurer.reset-size4.size3,.katex .katex-sizing.reset-size4.size3{font-size:.875em}.katex .fontsize-ensurer.reset-size4.size4,.katex .katex-sizing.reset-size4.size4{font-size:1em}.katex .fontsize-ensurer.reset-size4.size5,.katex .katex-sizing.reset-size4.size5{font-size:1.125em}.katex .fontsize-ensurer.reset-size4.size6,.katex .katex-sizing.reset-size4.size6{font-size:1.25em}.katex .fontsize-ensurer.reset-size4.size7,.katex .katex-sizing.reset-size4.size7{font-size:1.5em}.katex .fontsize-ensurer.reset-size4.size8,.katex .katex-sizing.reset-size4.size8{font-size:1.8em}.katex .fontsize-ensurer.reset-size4.size9,.katex .katex-sizing.reset-size4.size9{font-size:2.16em}.katex .fontsize-ensurer.reset-size4.size10,.katex .katex-sizing.reset-size4.size10{font-size:2.5925em}.katex .fontsize-ensurer.reset-size4.size11,.katex .katex-sizing.reset-size4.size11{font-size:3.11em}.katex .fontsize-ensurer.reset-size5.size1,.katex .katex-sizing.reset-size5.size1{font-size:.5555555556em}.katex .fontsize-ensurer.reset-size5.size2,.katex .katex-sizing.reset-size5.size2{font-size:.6666666667em}.katex .fontsize-ensurer.reset-size5.size3,.katex .katex-sizing.reset-size5.size3{font-size:.7777777778em}.katex .fontsize-ensurer.reset-size5.size4,.katex .katex-sizing.reset-size5.size4{font-size:.8888888889em}.katex .fontsize-ensurer.reset-size5.size5,.katex .katex-sizing.reset-size5.size5{font-size:1em}.katex .fontsize-ensurer.reset-size5.size6,.katex .katex-sizing.reset-size5.size6{font-size:1.1111111111em}.katex .fontsize-ensurer.reset-size5.size7,.katex .katex-sizing.reset-size5.size7{font-size:1.3333333333em}.katex .fontsize-ensurer.reset-size5.size8,.katex .katex-sizing.reset-size5.size8{font-size:1.6em}.katex .fontsize-ensurer.reset-size5.size9,.katex .katex-sizing.reset-size5.size9{font-size:1.92em}.katex .fontsize-ensurer.reset-size5.size10,.katex .katex-sizing.reset-size5.size10{font-size:2.3044444444em}.katex .fontsize-ensurer.reset-size5.size11,.katex .katex-sizing.reset-size5.size11{font-size:2.7644444444em}.katex .fontsize-ensurer.reset-size6.size1,.katex .katex-sizing.reset-size6.size1{font-size:.5em}.katex .fontsize-ensurer.reset-size6.size2,.katex .katex-sizing.reset-size6.size2{font-size:.6em}.katex .fontsize-ensurer.reset-size6.size3,.katex .katex-sizing.reset-size6.size3{font-size:.7em}.katex .fontsize-ensurer.reset-size6.size4,.katex .katex-sizing.reset-size6.size4{font-size:.8em}.katex .fontsize-ensurer.reset-size6.size5,.katex .katex-sizing.reset-size6.size5{font-size:.9em}.katex .fontsize-ensurer.reset-size6.size6,.katex .katex-sizing.reset-size6.size6{font-size:1em}.katex .fontsize-ensurer.reset-size6.size7,.katex .katex-sizing.reset-size6.size7{font-size:1.2em}.katex .fontsize-ensurer.reset-size6.size8,.katex .katex-sizing.reset-size6.size8{font-size:1.44em}.katex .fontsize-ensurer.reset-size6.size9,.katex .katex-sizing.reset-size6.size9{font-size:1.728em}.katex .fontsize-ensurer.reset-size6.size10,.katex .katex-sizing.reset-size6.size10{font-size:2.074em}.katex .fontsize-ensurer.reset-size6.size11,.katex .katex-sizing.reset-size6.size11{font-size:2.488em}.katex .fontsize-ensurer.reset-size7.size1,.katex .katex-sizing.reset-size7.size1{font-size:.4166666667em}.katex .fontsize-ensurer.reset-size7.size2,.katex .katex-sizing.reset-size7.size2{font-size:.5em}.katex .fontsize-ensurer.reset-size7.size3,.katex .katex-sizing.reset-size7.size3{font-size:.5833333333em}.katex .fontsize-ensurer.reset-size7.size4,.katex .katex-sizing.reset-size7.size4{font-size:.6666666667em}.katex .fontsize-ensurer.reset-size7.size5,.katex .katex-sizing.reset-size7.size5{font-size:.75em}.katex .fontsize-ensurer.reset-size7.size6,.katex .katex-sizing.reset-size7.size6{font-size:.8333333333em}.katex .fontsize-ensurer.reset-size7.size7,.katex .katex-sizing.reset-size7.size7{font-size:1em}.katex .fontsize-ensurer.reset-size7.size8,.katex .katex-sizing.reset-size7.size8{font-size:1.2em}.katex .fontsize-ensurer.reset-size7.size9,.katex .katex-sizing.reset-size7.size9{font-size:1.44em}.katex .fontsize-ensurer.reset-size7.size10,.katex .katex-sizing.reset-size7.size10{font-size:1.7283333333em}.katex .fontsize-ensurer.reset-size7.size11,.katex .katex-sizing.reset-size7.size11{font-size:2.0733333333em}.katex .fontsize-ensurer.reset-size8.size1,.katex .katex-sizing.reset-size8.size1{font-size:.3472222222em}.katex .fontsize-ensurer.reset-size8.size2,.katex .katex-sizing.reset-size8.size2{font-size:.4166666667em}.katex .fontsize-ensurer.reset-size8.size3,.katex .katex-sizing.reset-size8.size3{font-size:.4861111111em}.katex .fontsize-ensurer.reset-size8.size4,.katex .katex-sizing.reset-size8.size4{font-size:.5555555556em}.katex .fontsize-ensurer.reset-size8.size5,.katex .katex-sizing.reset-size8.size5{font-size:.625em}.katex .fontsize-ensurer.reset-size8.size6,.katex .katex-sizing.reset-size8.size6{font-size:.6944444444em}.katex .fontsize-ensurer.reset-size8.size7,.katex .katex-sizing.reset-size8.size7{font-size:.8333333333em}.katex .fontsize-ensurer.reset-size8.size8,.katex .katex-sizing.reset-size8.size8{font-size:1em}.katex .fontsize-ensurer.reset-size8.size9,.katex .katex-sizing.reset-size8.size9{font-size:1.2em}.katex .fontsize-ensurer.reset-size8.size10,.katex .katex-sizing.reset-size8.size10{font-size:1.4402777778em}.katex .fontsize-ensurer.reset-size8.size11,.katex .katex-sizing.reset-size8.size11{font-size:1.7277777778em}.katex .fontsize-ensurer.reset-size9.size1,.katex .katex-sizing.reset-size9.size1{font-size:.2893518519em}.katex .fontsize-ensurer.reset-size9.size2,.katex .katex-sizing.reset-size9.size2{font-size:.3472222222em}.katex .fontsize-ensurer.reset-size9.size3,.katex .katex-sizing.reset-size9.size3{font-size:.4050925926em}.katex .fontsize-ensurer.reset-size9.size4,.katex .katex-sizing.reset-size9.size4{font-size:.462962963em}.katex .fontsize-ensurer.reset-size9.size5,.katex .katex-sizing.reset-size9.size5{font-size:.5208333333em}.katex .fontsize-ensurer.reset-size9.size6,.katex .katex-sizing.reset-size9.size6{font-size:.5787037037em}.katex .fontsize-ensurer.reset-size9.size7,.katex .katex-sizing.reset-size9.size7{font-size:.6944444444em}.katex .fontsize-ensurer.reset-size9.size8,.katex .katex-sizing.reset-size9.size8{font-size:.8333333333em}.katex .fontsize-ensurer.reset-size9.size9,.katex .katex-sizing.reset-size9.size9{font-size:1em}.katex .fontsize-ensurer.reset-size9.size10,.katex .katex-sizing.reset-size9.size10{font-size:1.2002314815em}.katex .fontsize-ensurer.reset-size9.size11,.katex .katex-sizing.reset-size9.size11{font-size:1.4398148148em}.katex .fontsize-ensurer.reset-size10.size1,.katex .katex-sizing.reset-size10.size1{font-size:.2410800386em}.katex .fontsize-ensurer.reset-size10.size2,.katex .katex-sizing.reset-size10.size2{font-size:.2892960463em}.katex .fontsize-ensurer.reset-size10.size3,.katex .katex-sizing.reset-size10.size3{font-size:.337512054em}.katex .fontsize-ensurer.reset-size10.size4,.katex .katex-sizing.reset-size10.size4{font-size:.3857280617em}.katex .fontsize-ensurer.reset-size10.size5,.katex .katex-sizing.reset-size10.size5{font-size:.4339440694em}.katex .fontsize-ensurer.reset-size10.size6,.katex .katex-sizing.reset-size10.size6{font-size:.4821600771em}.katex .fontsize-ensurer.reset-size10.size7,.katex .katex-sizing.reset-size10.size7{font-size:.5785920926em}.katex .fontsize-ensurer.reset-size10.size8,.katex .katex-sizing.reset-size10.size8{font-size:.6943105111em}.katex .fontsize-ensurer.reset-size10.size9,.katex .katex-sizing.reset-size10.size9{font-size:.8331726133em}.katex .fontsize-ensurer.reset-size10.size10,.katex .katex-sizing.reset-size10.size10{font-size:1em}.katex .fontsize-ensurer.reset-size10.size11,.katex .katex-sizing.reset-size10.size11{font-size:1.1996142719em}.katex .fontsize-ensurer.reset-size11.size1,.katex .katex-sizing.reset-size11.size1{font-size:.2009646302em}.katex .fontsize-ensurer.reset-size11.size2,.katex .katex-sizing.reset-size11.size2{font-size:.2411575563em}.katex .fontsize-ensurer.reset-size11.size3,.katex .katex-sizing.reset-size11.size3{font-size:.2813504823em}.katex .fontsize-ensurer.reset-size11.size4,.katex .katex-sizing.reset-size11.size4{font-size:.3215434084em}.katex .fontsize-ensurer.reset-size11.size5,.katex .katex-sizing.reset-size11.size5{font-size:.3617363344em}.katex .fontsize-ensurer.reset-size11.size6,.katex .katex-sizing.reset-size11.size6{font-size:.4019292605em}.katex .fontsize-ensurer.reset-size11.size7,.katex .katex-sizing.reset-size11.size7{font-size:.4823151125em}.katex .fontsize-ensurer.reset-size11.size8,.katex .katex-sizing.reset-size11.size8{font-size:.578778135em}.katex .fontsize-ensurer.reset-size11.size9,.katex .katex-sizing.reset-size11.size9{font-size:.6945337621em}.katex .fontsize-ensurer.reset-size11.size10,.katex .katex-sizing.reset-size11.size10{font-size:.8336012862em}.katex .fontsize-ensurer.reset-size11.size11,.katex .katex-sizing.reset-size11.size11{font-size:1em}.katex .delimsizing.size1{font-family:KaTeX_Size1}.katex .delimsizing.size2{font-family:KaTeX_Size2}.katex .delimsizing.size3{font-family:KaTeX_Size3}.katex .delimsizing.size4{font-family:KaTeX_Size4}.katex .delimsizing.mult .delim-size1>span{font-family:KaTeX_Size1}.katex .delimsizing.mult .delim-size4>span{font-family:KaTeX_Size4}.katex .nulldelimiter{display:inline-block;width:.12em}.katex .delimcenter,.katex .op-symbol{position:relative}.katex .op-symbol.small-op{font-family:KaTeX_Size1}.katex .op-symbol.large-op{font-family:KaTeX_Size2}.katex .katex-accent>.vlist-t,.katex .op-limits>.vlist-t{text-align:center}.katex .katex-accent .accent-body{position:relative}.katex .katex-accent .accent-body:not(.accent-full){width:0}.katex .katex-overlay{display:block}.katex .mtable .vertical-separator{display:inline-block;min-width:1px}.katex .mtable .arraycolsep{display:inline-block}.katex .mtable .col-align-c>.vlist-t{text-align:center}.katex .mtable .col-align-l>.vlist-t{text-align:left}.katex .mtable .col-align-r>.vlist-t{text-align:right}.katex .svg-align{text-align:left}.katex svg{fill:currentColor;stroke:currentColor;display:block;height:inherit;position:absolute;width:100%}.katex svg path{stroke:none}.katex svg{fill-rule:nonzero;fill-opacity:1;stroke-width:1;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1}.katex img{border-style:none;max-height:none;max-width:none;min-height:0;min-width:0}.katex .katex-stretchy{display:block;overflow:hidden;position:relative;width:100%}.katex .katex-stretchy:after,.katex .katex-stretchy:before{content:""}.katex .hide-tail{overflow:hidden;position:relative;width:100%}.katex .halfarrow-left{left:0;overflow:hidden;position:absolute;width:50.2%}.katex .halfarrow-right{overflow:hidden;position:absolute;right:0;width:50.2%}.katex .brace-left{left:0;overflow:hidden;position:absolute;width:25.1%}.katex .brace-center{left:25%;overflow:hidden;position:absolute;width:50%}.katex .brace-right{overflow:hidden;position:absolute;right:0;width:25.1%}.katex .x-arrow-pad{padding:0 .5em}.katex .cd-arrow-pad{padding:0 .55556em 0 .27778em}.katex .mover,.katex .munder,.katex .x-arrow{text-align:center}.katex .boxpad{padding:0 .3em}.katex .fbox,.katex .fcolorbox{border:.04em solid;box-sizing:border-box}.katex .cancel-pad{padding:0 .2em}.katex .cancel-lap{margin-left:-.2em;margin-right:-.2em}.katex .katex-sout{border-bottom-style:solid;border-bottom-width:.08em}.katex .angl{border-right:.049em solid;border-top:.049em solid;box-sizing:border-box;margin-right:.03889em}.katex .anglpad{padding:0 .03889em}.katex .reflectbox{display:inline-block;transform:scaleX(-1)}.katex .eqn-num:before{content:"(" counter(katexEqnNo) ")";counter-increment:katexEqnNo}.katex .mml-eqn-num:before{content:"(" counter(mmlEqnNo) ")";counter-increment:mmlEqnNo}.katex .mtr-glue{width:50%}.katex .cd-vert-arrow{display:inline-block;position:relative}.katex .cd-label-left{display:inline-block;position:absolute;right:calc(50% + .3em);text-align:left}.katex .cd-label-right{display:inline-block;left:calc(50% + .3em);position:absolute;text-align:right}.katex-display{display:block;margin:1em 0;text-align:center}.katex-display>.katex{display:block;text-align:center;white-space:nowrap}.katex-display>.katex>.katex-html{display:block;position:relative}.katex-display>.katex>.katex-html>.katex-tag{position:absolute;right:0}.katex-display.leqno>.katex>.katex-html>.katex-tag{left:0;right:auto}.katex-display.fleqn>.katex{padding-left:2em;text-align:left}body{counter-reset:katexEqnNo mmlEqnNo}
`, Yu = (r) => /<script\b|\bon[a-z]+\s*=|javascript:|https?:\/\/(?!www\.w3\.org\/)/i.test(r), Wn = (r) => {
  if (Yu(r)) throw new Error("محتوى الطباعة غير آمن");
  return r.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}, yi = (r) => {
  if (Yu(r)) throw new Error("محتوى الطباعة غير آمن");
  return r;
};
class zp {
  render(e, t) {
    if (!Number.isInteger(e.durationMinutes) || e.durationMinutes <= 0 || !Number.isInteger(e.totalMarks) || e.totalMarks <= 0) throw new Error("بيانات الاختبار غير صالحة");
    const s = e.sections.map((n) => `<section class="exam-section"><h2>${Wn(n.title)}</h2><p class="instructions">${Wn(n.instructions)}</p>${n.questions.map((i) => this.question(i, t)).join("")}</section>`).join("");
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>@page{size:A4;margin:15mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#0f172a;line-height:1.65}.exam-header{border-bottom:2px solid #0f766e;margin-bottom:12px}.exam-meta{display:flex;justify-content:space-between;direction:rtl}.exam-section{break-inside: avoid;page-break-inside: avoid;margin:12px 0}.question{break-inside: avoid;page-break-inside: avoid;border:1px solid #cbd5e1;padding:10px;margin:8px 0}.marks{float:left;font-weight:bold}.answer-space{border-bottom:1px dotted #94a3b8;height:1.7em}.answer{background:#ecfdf5;padding:8px}.math{direction:ltr;unicode-bidi:isolate}${kp}</style></head><body><header class="exam-header"><h1>${Wn(e.title)}</h1><div class="exam-meta"><span>الزمن: ${e.durationMinutes} دقيقة</span><span>الدرجة الكلية: ${e.totalMarks}</span></div></header>${s}</body></html>`;
  }
  question(e, t) {
    if (!Number.isInteger(e.number) || e.number < 1 || !Number.isInteger(e.marks) || e.marks <= 0 || e.answerSpaceLines < 0) throw new Error("سؤال غير صالح للطباعة");
    const s = t === "STUDENT" ? "" : e.answerHtml ? `<div class="answer">${yi(e.answerHtml)}</div>` : "", n = t === "ANSWER_KEY" ? "" : Array.from({ length: e.answerSpaceLines }, () => '<div class="answer-space"></div>').join("");
    return `<article class="question"><span class="marks">(${e.marks} درجات)</span><strong>س${e.number}.</strong>${yi(e.bodyHtml)}${n}${s}</article>`;
  }
}
let wr = null;
function Bp(r) {
  wr = r;
}
function Mp(r, e = !1) {
  if (wr)
    try {
      return `<span class="math font-math" dir="ltr" style="direction:ltr;unicode-bidi:isolate;">${wr.renderToString(r, {
        displayMode: e,
        throwOnError: !1,
        strict: !1,
        trust: !1,
        output: "html"
        // Avoid http:// namespace attributes from MathML
      })}</span>`;
    } catch {
    }
  return `<span class="math" dir="ltr">${String(r).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</span>`;
}
class Fp {
  constructor(e, t) {
    h(this, "examRepo");
    h(this, "academicAuditRepo");
    h(this, "questionRepo");
    this.examRepo = new hh(e), this.academicAuditRepo = new me(e), this.questionRepo = new Pc(t);
  }
  /**
   * Deterministically validates blueprint against current Question Bank
   * and previews balanced selection. No AI, no mutations.
   */
  previewAssembly(e) {
    const t = Wr.parse(e), n = this.questionRepo.list({ status: "ACTIVE" }).map((d) => {
      const u = this.questionRepo.getCurriculumTagIds(d.id), l = this.questionRepo.getSourceReferences(d.id);
      return {
        id: d.id,
        questionType: d.questionType,
        difficulty: d.difficulty,
        defaultMarks: d.defaultMarks,
        curriculumTags: u,
        sourceReferenceIds: l.map((p) => p.sourceReferenceId),
        body: JSON.parse(d.bodyJson),
        modelAnswer: d.modelAnswerJson ? JSON.parse(d.modelAnswerJson) : null
      };
    }), i = Gu(t, n);
    if (!i.valid)
      return {
        valid: !1,
        conflicts: i.conflicts,
        selectedQuestions: [],
        totalSelectedMarks: 0,
        totalSelectedQuestions: 0
      };
    const { selected: a } = Lp(t, n), o = a.map((d) => ({
      questionId: d.id,
      marks: d.defaultMarks,
      curriculumNodeIds: d.curriculumTags,
      sourceReferenceIds: d.sourceReferenceIds,
      questionType: d.questionType,
      difficulty: d.difficulty,
      body: d.body,
      modelAnswer: d.modelAnswer
    }));
    return {
      valid: !0,
      conflicts: [],
      selectedQuestions: o,
      totalSelectedMarks: o.reduce((d, u) => d + u.marks, 0),
      totalSelectedQuestions: o.length
    };
  }
  /**
   * Explicit teacher confirmation of an assembled exam.
   * Generates deterministic variants A/B/C/D, creates Academic DB snapshot,
   * writes academic audit log.
   */
  confirmAssembly(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = rp.parse(e), n = ge.randomUUID(), i = ge.randomUUID(), a = (/* @__PURE__ */ new Date()).toISOString(), o = s.placements.map((S, N) => ({
      id: ge.randomUUID(),
      examSectionId: i,
      questionIdSnapshot: S.questionId ?? null,
      provenance: S.provenance,
      contentJson: JSON.stringify(S.body),
      answerJson: S.modelAnswer ? JSON.stringify(S.modelAnswer) : null,
      curriculumNodeIdsJson: JSON.stringify(S.curriculumNodeIds),
      sourceReferenceIdsJson: JSON.stringify(S.sourceReferenceIds),
      marks: S.marks,
      answerSpaceLines: S.answerSpaceLines,
      position: N,
      createdAt: a
    })), d = o.map((S) => ({
      id: S.id,
      marks: S.marks,
      answer: S.answerJson ? JSON.parse(S.answerJson) : null
    })), l = Pp(d, s.blueprint.variantCount).map((S) => ({
      id: ge.randomUUID(),
      examId: n,
      label: S.label,
      questionOrderJson: JSON.stringify(S.placementIds),
      answerKeyJson: JSON.stringify(S.answerKey),
      createdAt: a
    }));
    this.examRepo.create({
      exam: {
        id: n,
        title: s.blueprint.title,
        blueprintJson: JSON.stringify(s.blueprint),
        layoutJson: JSON.stringify({ pageSize: "A4", orientation: "PORTRAIT" }),
        status: "CONFIRMED",
        createdAt: a,
        updatedAt: a
      },
      sections: [
        {
          id: i,
          examId: n,
          title: s.sectionTitle,
          instructionsJson: JSON.stringify([]),
          position: 0,
          createdAt: a
        }
      ],
      questions: o,
      versions: l
    }), this.academicAuditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "CONFIRM_EXAM_ASSEMBLY",
      entityType: "EXAM",
      entityId: n,
      afterJson: JSON.stringify({
        examId: n,
        title: s.blueprint.title,
        questionCount: o.length,
        totalMarks: o.reduce((S, N) => S + N.marks, 0),
        variantCount: l.length
      }),
      createdAt: a
    });
    const p = this.examRepo.findSnapshot(n);
    if (!p)
      throw new Error(`Failed to retrieve confirmed exam snapshot for: ${n}`);
    return this.mapSnapshotToDto(p);
  }
  /**
   * Reverses the latest exam creation if it was the last mutation on this exam.
   */
  undoLastMutation(e, t) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const s = this.academicAuditRepo.findByEntity("EXAM", e);
    if (s.length === 0)
      throw new Error("لا توجد عمليات قابلة للتراجع لهذا الاختبار");
    const n = s[0];
    if (n.action !== "CONFIRM_EXAM_ASSEMBLY")
      throw new Error("آخر عملية على هذا الاختبار غير قابلة للتراجع التلقائي");
    const i = (/* @__PURE__ */ new Date()).toISOString();
    this.examRepo.delete(e), this.academicAuditRepo.insert({
      id: ge.randomUUID(),
      actorType: t.userId ? "USER" : "SYSTEM",
      actorUserId: t.userId ?? null,
      actorNameSnapshot: t.fullName,
      action: "UNDO_CONFIRM_EXAM_ASSEMBLY",
      entityType: "EXAM",
      entityId: e,
      beforeJson: n.afterJson,
      createdAt: i
    });
  }
  getExam(e) {
    const t = this.examRepo.findSnapshot(e);
    return t ? this.mapSnapshotToDto(t) : null;
  }
  listExams() {
    return this.examRepo.list().map((t) => {
      const s = this.examRepo.findSnapshot(t.id);
      return s ? this.mapSnapshotToDto(s) : {
        id: t.id,
        title: t.title,
        blueprint: JSON.parse(t.blueprintJson),
        status: t.status,
        sections: [],
        placements: [],
        versions: [],
        createdAt: t.createdAt,
        updatedAt: t.updatedAt
      };
    });
  }
  mapSnapshotToDto(e) {
    return {
      id: e.exam.id,
      title: e.exam.title,
      blueprint: JSON.parse(e.exam.blueprintJson),
      status: e.exam.status,
      sections: e.sections.map((t) => ({
        id: t.id,
        examId: t.examId,
        title: t.title,
        instructionsJson: t.instructionsJson,
        position: t.position,
        createdAt: t.createdAt
      })),
      placements: e.questions.map((t) => ({
        id: t.id,
        examSectionId: t.examSectionId,
        questionId: t.questionIdSnapshot ?? void 0,
        provenance: t.provenance,
        body: JSON.parse(t.contentJson),
        modelAnswer: t.answerJson ? JSON.parse(t.answerJson) : null,
        marks: t.marks,
        answerSpaceLines: t.answerSpaceLines,
        curriculumNodeIds: JSON.parse(t.curriculumNodeIdsJson),
        sourceReferenceIds: JSON.parse(t.sourceReferenceIdsJson),
        position: t.position
      })),
      versions: e.versions.map((t) => ({
        id: t.id,
        examId: t.examId,
        label: t.label,
        questionOrder: JSON.parse(t.questionOrderJson),
        answerKey: JSON.parse(t.answerKeyJson),
        createdAt: t.createdAt
      })),
      createdAt: e.exam.createdAt,
      updatedAt: e.exam.updatedAt
    };
  }
  /**
   * Renders professional A4 printable HTML for student, teacher, or answer key.
   * Supports deterministic version ordering A/B/C/D if versionLabel is requested.
   */
  renderPrintableHtml(e, t, s) {
    const n = this.examRepo.findSnapshot(e);
    if (!n)
      throw new Error(`الاختبار غير موجود: ${e}`);
    const i = this.mapSnapshotToDto(n), a = new zp(), o = (p) => {
      if (p.type === "text") {
        const S = String(p.content ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        return `<span class="text-block" dir="${p.direction ?? "auto"}">${S}</span>`;
      }
      if (p.type === "math") {
        const S = String(p.latex ?? ""), N = p.displayMode === "block";
        return Mp(S, N);
      }
      return p.type === "geometry" && p.svgPayload ? `<div class="geometry-container">${p.svgPayload}</div>` : "";
    }, d = (p) => !p || !Array.isArray(p.blocks) ? "" : p.blocks.map(o).join(" ");
    let u = i.placements;
    if (s) {
      const p = i.versions.find((S) => S.label === s);
      if (p) {
        const S = new Map(i.placements.map((y) => [y.id, y])), N = p.questionOrder.map((y) => S.get(y)).filter((y) => !!y);
        N.length > 0 && (u = N);
      }
    }
    const l = {
      title: `${i.title}${s ? ` - نموذج (${s})` : ""}`,
      durationMinutes: i.blueprint.durationMinutes,
      totalMarks: i.blueprint.totalMarks,
      sections: i.sections.map((p) => ({
        title: p.title,
        instructions: "أجب عن جميع الأسئلة الآتية:",
        questions: u.filter((S) => !S.examSectionId || S.examSectionId === p.id).map((S, N) => ({
          number: N + 1,
          marks: S.marks,
          bodyHtml: d(S.body),
          answerHtml: S.modelAnswer ? d(S.modelAnswer) : null,
          answerSpaceLines: S.answerSpaceLines
        }))
      }))
    };
    return a.render(l, t);
  }
}
function $p(r) {
  if (!r || typeof r != "object" || !Array.isArray(r.candidates)) throw new Error();
  const e = r.candidates;
  if (e.length > 100) throw new Error();
  return { candidates: e.map((t) => ep.parse(t)) };
}
class qp {
  constructor(e = fetch, t = {}) {
    h(this, "timeoutMs");
    h(this, "retryDelayMs");
    this.fetchImpl = e, this.timeoutMs = t.timeoutMs ?? 15e3, this.retryDelayMs = t.retryDelayMs ?? 100;
  }
  async preview(e) {
    var d, u, l, p, S, N, y;
    const t = new AbortController();
    let s = !1;
    const n = () => t.abort();
    (d = e.signal) == null || d.addEventListener("abort", n, { once: !0 });
    const i = setTimeout(() => {
      s = !0, t.abort();
    }, this.timeoutMs), a = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(e.model)}:generateContent`, o = { method: "POST", signal: t.signal, headers: { "Content-Type": "application/json", "x-goog-api-key": e.apiKey }, body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: e.prompt }] }], generationConfig: { responseMimeType: "application/json" } }) };
    try {
      let I;
      for (let P = 0; P < 3; P++) {
        try {
          I = await this.fetchImpl(a, o);
        } catch {
          if (t.signal.aborted) throw new Error(s ? "انتهت مهلة الاتصال بخدمة الذكاء الاصطناعي" : "تم إلغاء طلب الذكاء الاصطناعي");
          if (P < 2) {
            await this.delay();
            continue;
          }
          throw new Error("تعذر الاتصال بخدمة الذكاء الاصطناعي");
        }
        if (I.ok || P === 2 || I.status < 500) break;
        await this.delay();
      }
      if (!(I != null && I.ok)) throw new Error("تعذر الاتصال بخدمة الذكاء الاصطناعي");
      const L = await I.json(), w = ((N = (S = (p = (l = (u = L == null ? void 0 : L.candidates) == null ? void 0 : u[0]) == null ? void 0 : l.content) == null ? void 0 : p.parts) == null ? void 0 : S[0]) == null ? void 0 : N.text) ?? L;
      try {
        return $p(typeof w == "string" ? JSON.parse(w) : w);
      } catch {
        throw new Error("استجابة الذكاء الاصطناعي غير صالحة");
      }
    } finally {
      clearTimeout(i), (y = e.signal) == null || y.removeEventListener("abort", n);
    }
  }
  async delay() {
    this.retryDelayMs > 0 && await new Promise((e) => setTimeout(e, this.retryDelayMs));
  }
}
const us = class us {
  constructor(e, t) {
    this.store = e, this.cipher = t;
  }
  save(e) {
    if (!e.trim() || !this.cipher.isEncryptionAvailable()) throw new Error("تعذر تأمين مفتاح الذكاء الاصطناعي");
    this.store.set(us.key, this.cipher.encryptString(e));
  }
  get() {
    const e = this.store.get(us.key);
    return e ? this.cipher.decryptString(e) : null;
  }
  status() {
    return { configured: !!this.store.get(us.key) };
  }
  clear() {
    this.store.set(us.key, "");
  }
};
h(us, "key", "ai.gemini.credential");
let vr = us;
class Hp {
  constructor(e, t = {}) {
    h(this, "provider");
    h(this, "model");
    this.credentialService = e, this.provider = t.provider ?? new qp(), this.model = t.model ?? "gemini-flash-latest";
  }
  /**
   * Generates candidate questions using Gemini.
   * Strips all internal IDs before generating prompt.
   * Provider enforces strict structured output conforming to AiExamCandidateSchema.
   */
  async previewCandidates(e, t, s) {
    te(t.role, t.permissions ?? [], "GROUPS_WRITE");
    const n = ip.parse(e), i = this.credentialService.get();
    if (!i)
      throw new Error("لم يتم تهيئة مفتاح خدمة الذكاء الاصطناعي في إعدادات النظام");
    const a = this.buildPrompt(n);
    return this.provider.preview({
      apiKey: i,
      model: this.model,
      prompt: a,
      signal: s
    });
  }
  buildPrompt(e) {
    return [
      "أنت خبير تربوي في إعداد مسائل واختبارات الرياضيات للمناهج المصرية باللغة العربية.",
      `المطلوب: توليد ${e.count} مسائل اختبارية مطابقة للمواصفات التالية بدقة متناهية:`,
      `- الموضوع أو المعيار: ${e.topicOrStandard}`,
      `- المرحلة والصف الدراسي: ${e.gradeLevel}`,
      `- المسار اللغوي: ${e.languageTrack}`,
      `- نوع المسألة: ${e.questionType}`,
      `- مستوى الصعوبة: ${e.difficulty}`,
      `- الدرجة المخصصة لكل مسألة: ${e.marks}`,
      "",
      "تعليمات التنسيق الفني:",
      "1. يجب أن تكون الاستجابة حصراً بصيغة JSON مطابقة تماماً للمخطط التالي:",
      "{",
      '  "candidates": [',
      "    {",
      '      "body": {',
      '        "version": 1,',
      '        "blocks": [',
      '          { "id": "b1", "type": "text", "content": "نص المسألة بالعربية", "direction": "rtl" },',
      '          { "id": "b2", "type": "math", "latex": "x^2 + 5x + 6 = 0", "displayMode": "block" }',
      "        ]",
      "      },",
      '      "modelAnswer": {',
      '        "version": 1,',
      '        "blocks": [',
      '          { "id": "a1", "type": "text", "content": "خطوات الحل النموذجي", "direction": "rtl" }',
      "        ]",
      "      },",
      `      "questionType": "${e.questionType}",`,
      `      "difficulty": "${e.difficulty}",`,
      `      "marks": ${e.marks}`,
      "    }",
      "  ]",
      "}",
      "2. لا تُضف أي معرّفات قواعد بيانات (UUIDs) أو حقول خارج المخطط المذكور.",
      "3. اجعل الصياغة الرياضية سليمة ومكتوبة بصيغة LaTeX القياسية للكتل الرياضية."
    ].join(`
`);
  }
}
let jt = null;
function Gp() {
  if (jt) return jt;
  const r = st.dirname(el(import.meta.url)), e = [
    // From electron/ → packages/design-system/ (workspace layout)
    st.resolve(r, "../../../packages/design-system/package.json"),
    // From apps/desktop/electron/ → packages/design-system/
    st.resolve(r, "../../packages/design-system/package.json"),
    // From dist-electron/ → node_modules/@tibyan/design-system/
    st.resolve(r, "../node_modules/@tibyan/design-system/package.json")
  ];
  for (const t of e)
    try {
      if (jt = ti(t)("katex"), jt) return jt;
    } catch {
    }
  try {
    if (jt = ti(st.join(process.cwd(), "package.json"))("katex"), jt) return jt;
  } catch {
  }
  return null;
}
function Yp(r, e = !1) {
  var u;
  const t = r ?? process.env.TIBYAN_APP_DATA_DIR ?? ((u = It) != null && u.getPath ? It.getPath("userData") : x.resolve("./app-data")), s = x.resolve(t), n = x.join(s, "data", "system"), i = e ? ":memory:" : x.join(n, "tibyan-system.sqlite"), a = x.join(s, "data", "academic-years"), o = x.join(s, "media"), d = x.join(s, "backups");
  return {
    appDataDir: s,
    systemDbDir: n,
    systemDbPath: i,
    academicYearsDbDir: a,
    mediaRootDir: o,
    backupRootDir: d
  };
}
class Jp {
  constructor(e = {}) {
    h(this, "paths");
    h(this, "inMemory");
    // Authoritative MAIN session
    h(this, "_currentSession", null);
    // System-level persistence & services
    h(this, "systemDb");
    h(this, "academicYearRepo");
    h(this, "backupRecordRepo");
    h(this, "systemAuditRepo");
    h(this, "globalSettingsRepo");
    h(this, "geminiCredentialService");
    h(this, "authService");
    h(this, "backupService");
    // Academic-year scoped persistence & services
    h(this, "activeAcademicYear", null);
    h(this, "academicDb", null);
    h(this, "studentService", null);
    h(this, "groupService", null);
    h(this, "enrollmentService", null);
    h(this, "sessionService", null);
    h(this, "dashboardService", null);
    h(this, "attendanceService", null);
    h(this, "financeService", null);
    h(this, "thermalReceiptService", null);
    h(this, "curriculumService", null);
    h(this, "lessonPlannerService", null);
    h(this, "sessionReflectionService", null);
    h(this, "pdfSourceService");
    h(this, "questionBankService");
    h(this, "aiExamService");
    h(this, "examService", null);
    this.inMemory = e.inMemory ?? !1, this.paths = Yp(e.customAppDataDir, this.inMemory);
  }
  /**
   * Initializes application storage, system database, and discovers active academic year.
   */
  initialize() {
    this.inMemory || (z.mkdirSync(this.paths.systemDbDir, { recursive: !0 }), z.mkdirSync(this.paths.academicYearsDbDir, { recursive: !0 }), z.mkdirSync(this.paths.mediaRootDir, { recursive: !0 }), z.mkdirSync(this.paths.backupRootDir, { recursive: !0 })), this.systemDb = rh({
      filePath: this.paths.systemDbPath,
      autoMigrate: !0
    }), cp(this.systemDb.db), this.academicYearRepo = new bc(this.systemDb.db), this.backupRecordRepo = new gr(this.systemDb.db), this.systemAuditRepo = new Te(this.systemDb.db), this.globalSettingsRepo = new dh(this.systemDb.db), this.geminiCredentialService = new vr(
      {
        get: (s) => this.globalSettingsRepo.get(s) ?? void 0,
        set: (s, n) => this.globalSettingsRepo.set(s, n)
      },
      {
        isEncryptionAvailable: () => Yn.isEncryptionAvailable(),
        encryptString: (s) => Yn.encryptString(s).toString("base64"),
        decryptString: (s) => Yn.decryptString(Buffer.from(s, "base64"))
      }
    ), this.authService = new lp(this.systemDb.db), this.backupService = new gp({
      appDataDir: this.paths.appDataDir,
      systemDbPath: this.paths.systemDbPath,
      academicYearsDbDir: this.paths.academicYearsDbDir,
      mediaRootDir: this.paths.mediaRootDir,
      backupRootDir: this.paths.backupRootDir,
      systemDb: this.systemDb.raw,
      systemDrizzle: this.systemDb.db,
      academicYearRepo: this.academicYearRepo,
      systemAuditRepo: this.systemAuditRepo
    });
    const e = x.join(this.paths.appDataDir, "sources");
    this.pdfSourceService = new xp(this.systemDb.db, e), this.questionBankService = new bp(this.systemDb.db), this.aiExamService = new Hp(this.geminiCredentialService);
    try {
      Bp(Gp());
    } catch {
    }
    const t = this.academicYearRepo.findActive();
    t && this.mountAcademicYear(t);
  }
  /**
   * Mounts the specified academic-year database and initializes its services.
   */
  mountAcademicYear(e) {
    if (this.academicDb && this.unmountAcademicYear(), !e.dbFilename || typeof e.dbFilename != "string")
      throw new Error("INVALID_ACADEMIC_YEAR_FILENAME: Missing dbFilename in academic year registry.");
    const t = x.normalize(e.dbFilename);
    if (x.isAbsolute(t) || t.includes("..") || x.basename(t) !== t)
      throw new Error(`SECURITY_ERROR: Invalid academic year dbFilename traversal detected: ${e.dbFilename}`);
    const s = x.resolve(this.paths.academicYearsDbDir), n = this.inMemory ? ":memory:" : x.resolve(s, t);
    if (!this.inMemory && !n.startsWith(s))
      throw new Error(`SECURITY_ERROR: Academic year database path escaped canonical root: ${n}`);
    this.academicDb = ih(e.name, {
      filePath: n,
      autoMigrate: !0
    }), this.activeAcademicYear = e;
    const i = this.inMemory ? x.join(this.paths.mediaRootDir, e.name) : x.join(this.paths.mediaRootDir, e.name);
    this.inMemory || z.mkdirSync(i, { recursive: !0 });
    const a = new Bu(i);
    this.studentService = new hp(this.academicDb.db, a), this.groupService = new mp(this.academicDb.db), this.enrollmentService = new pp(this.academicDb.db), this.sessionService = new Mu(this.academicDb.db), this.dashboardService = new Ip(this.academicDb.db), this.attendanceService = new yp(this.academicDb.db), this.financeService = new $u(this.academicDb.db), this.thermalReceiptService = new qu(this.academicDb.db), this.curriculumService = new Op(this.systemDb.db, this.academicDb.db), this.lessonPlannerService = new Cp(this.systemDb.db, this.academicDb.db), this.sessionReflectionService = new Up(this.academicDb.db), this.examService = new Fp(this.academicDb.db, this.systemDb.db);
  }
  /**
   * Unmounts the current academic year database and teardowns scoped services.
   */
  unmountAcademicYear() {
    this.studentService = null, this.groupService = null, this.enrollmentService = null, this.sessionService = null, this.dashboardService = null, this.attendanceService = null, this.financeService = null, this.thermalReceiptService = null, this.curriculumService = null, this.lessonPlannerService = null, this.sessionReflectionService = null, this.examService = null, $r(), this.academicDb = null, this.activeAcademicYear = null;
  }
  /**
   * Returns authoritative session context for current user.
   */
  get currentSession() {
    return this._currentSession;
  }
  /**
   * Sets the authoritative session context upon successful authentication.
   */
  setSession(e) {
    this._currentSession = e;
  }
  /**
   * Clears authoritative session on logout.
   */
  clearSession() {
    this._currentSession = null;
  }
  /**
   * Retrieves authenticated actor context from authoritative MAIN session.
   * Throws AuthError if session is not active.
   */
  requireAuthenticatedActor() {
    if (!this._currentSession)
      throw new fe("PERMISSION_DENIED", "Authentication required. No active session.");
    return {
      userId: this._currentSession.userId,
      fullName: this._currentSession.fullName,
      role: this._currentSession.role,
      permissions: this._currentSession.permissions
    };
  }
  /**
   * Requires an active academic year to be mounted. Throws error if not mounted.
   */
  requireActiveAcademicYear() {
    if (!this.activeAcademicYear || !this.academicDb)
      throw new Error("NO_ACTIVE_ACADEMIC_YEAR: No academic year is currently active.");
  }
  /**
   * Cleanly closes all database connections and resets state.
   */
  close() {
    this.clearSession(), this.unmountAcademicYear(), Fr(), oh();
  }
}
function Vp(r) {
  if (r instanceof bt) {
    const e = r.issues.map((t) => ({
      path: t.path.join("."),
      message: t.message
    }));
    return Ue(
      "VALIDATION_ERROR",
      "Input validation failed. Please verify submitted data.",
      e
    );
  }
  if (r instanceof fe) {
    const e = r.retryAfterSeconds !== void 0 ? { retryAfterSeconds: r.retryAfterSeconds } : void 0;
    return Ue(r.code, r.message, e);
  }
  if (r instanceof tt || r instanceof wt || r instanceof ke || r instanceof ut || r instanceof Fu || r instanceof Ye || r instanceof _t)
    return Ue(r.code, r.message);
  if (r instanceof Error) {
    if (r.code === "PERMISSION_DENIED" || r.message.includes("PERMISSION_DENIED"))
      return Ue("PERMISSION_DENIED", r.message);
    if (r.message.includes("NO_ACTIVE_ACADEMIC_YEAR"))
      return Ue("NO_ACTIVE_ACADEMIC_YEAR", "No active academic year is currently loaded.");
    if (r.message.includes("INVALID_PHOTO_TOKEN"))
      return Ue("INVALID_PHOTO_TOKEN", r.message);
    if (r.message.includes("PHOTO_TOKEN_EXPIRED"))
      return Ue("PHOTO_TOKEN_EXPIRED", r.message);
    if (r.message.includes("NOT_FOUND") || r.message.includes("not found"))
      return Ue("NOT_FOUND", "The requested resource was not found.");
    if (r.message.includes("DATABASE_FILE_COLLISION"))
      return Ue("DATABASE_FILE_COLLISION", "An academic year database file already exists on disk.");
    if (r.message.includes("already exists") || r.message.includes("already registered"))
      return Ue("ACADEMIC_YEAR_ALREADY_EXISTS", r.message);
    if (r.message.includes("SECURITY_ERROR"))
      return Ue("SECURITY_ERROR", "A security restriction prevented this operation.");
  }
  return Ue("INTERNAL_ERROR", "An unexpected internal error occurred. Please try again.");
}
async function R(r) {
  try {
    const e = await r();
    return Wh(e);
  } catch (e) {
    return Vp(e);
  }
}
function Qp(r, e) {
  f.handle(E.AUTH_LIST_USERS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => r.authService.listLoginUsers());
  }), f.handle(E.AUTH_LIST_MANAGEMENT_USERS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const s = r.requireAuthenticatedActor();
      return r.authService.listManagementUsers(s.userId);
    });
  }), f.handle(E.AUTH_LOGIN_PIN, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = Kc.parse(s), i = await r.authService.loginWithPin(n);
      return r.setSession(i), i;
    });
  }), f.handle(E.AUTH_LOGOUT, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      r.clearSession();
    });
  }), f.handle(E.AUTH_GET_SESSION, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => r.currentSession);
  }), f.handle(E.AUTH_BOOTSTRAP_OWNER, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = em.parse(s);
      return r.authService.bootstrapOwner(n);
    });
  }), f.handle(E.AUTH_CREATE_USER, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = jc.parse(s);
      return r.authService.createAssistant(i, n.userId);
    });
  }), f.handle(E.AUTH_UPDATE_PERMISSIONS, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Xc.parse(s);
      await r.authService.setAssistantPermissions(i, n.userId);
    });
  }), f.handle(E.AUTH_CHANGE_STATUS, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Zc.parse(s);
      await r.authService.setUserStatus(i, n.userId);
    });
  }), f.handle(E.AUTH_RESET_PIN, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Wc.parse(s);
      await r.authService.resetUserPin(i, n.userId);
    });
  });
}
function Kp() {
  f.removeHandler(E.AUTH_LIST_USERS), f.removeHandler(E.AUTH_LIST_MANAGEMENT_USERS), f.removeHandler(E.AUTH_LOGIN_PIN), f.removeHandler(E.AUTH_LOGOUT), f.removeHandler(E.AUTH_GET_SESSION), f.removeHandler(E.AUTH_BOOTSTRAP_OWNER), f.removeHandler(E.AUTH_CREATE_USER), f.removeHandler(E.AUTH_UPDATE_PERMISSIONS), f.removeHandler(E.AUTH_CHANGE_STATUS), f.removeHandler(E.AUTH_RESET_PIN);
}
const Gs = /* @__PURE__ */ new Map();
function Ju() {
  const r = Date.now();
  for (const [e, t] of Gs.entries())
    t.expiresAt <= r && Gs.delete(e);
}
function Ti(r, e, t) {
  const s = Gs.get(r);
  if (!s)
    throw new Error("INVALID_PHOTO_TOKEN: Token not found or already consumed");
  if (Gs.delete(r), s.expiresAt <= Date.now())
    throw new Error("PHOTO_TOKEN_EXPIRED: Photo selection token has expired");
  if (s.userId !== e)
    throw new Error("INVALID_PHOTO_TOKEN: Token was selected by a different user session");
  if (s.academicYearId !== t)
    throw new Error("INVALID_PHOTO_TOKEN: Token was selected for a different academic year");
  return Ju(), s.sourcePath;
}
function jp(r) {
  return r.length < 12 ? null : r[0] === 255 && r[1] === 216 && r[2] === 255 ? "jpg" : r[0] === 137 && r[1] === 80 && r[2] === 78 && r[3] === 71 && r[4] === 13 && r[5] === 10 && r[6] === 26 && r[7] === 10 ? "png" : r[0] === 82 && r[1] === 73 && r[2] === 70 && r[3] === 70 && r[8] === 87 && r[9] === 69 && r[10] === 66 && r[11] === 80 ? "webp" : null;
}
function en(r) {
  return {
    ...r,
    photoUrl: r.photoPath ? `tibyan-media://${r.photoPath}` : void 0
  };
}
function Xp(r, e) {
  f.handle(E.STUDENTS_LIST, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = s ? tu.parse(s) : {};
      return (await r.studentService.searchStudents(i, n)).map(en);
    });
  }), f.handle(E.STUDENTS_GET_BY_ID, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid student ID").parse(s), a = await r.studentService.getStudentById(i, n);
      return en(a);
    });
  }), f.handle(E.STUDENTS_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = r.activeAcademicYear.id, a = sm.parse(s);
      let o = null;
      typeof a.photoToken == "string" && (o = Ti(a.photoToken, n.userId, i));
      const d = {
        fullName: a.fullName,
        educationSystem: a.educationSystem,
        gradeLevel: a.gradeLevel,
        languageTrack: a.languageTrack,
        guardianPhone: a.guardianPhone,
        photoPath: o,
        initialNote: a.initialNote
      }, u = await r.studentService.createStudent(
        d,
        n
      );
      return en(u);
    });
  }), f.handle(E.STUDENTS_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = r.activeAcademicYear.id, a = rm.parse(s);
      let o;
      a.photoToken === null ? o = null : typeof a.photoToken == "string" ? o = Ti(a.photoToken, n.userId, i) : o = void 0;
      const d = {
        studentId: a.studentId,
        fullName: a.fullName,
        educationSystem: a.educationSystem,
        gradeLevel: a.gradeLevel,
        languageTrack: a.languageTrack,
        guardianPhone: a.guardianPhone,
        photoPath: o,
        status: a.status
      }, u = await r.studentService.updateStudent(
        d,
        n
      );
      return en(u);
    });
  }), f.handle(E.STUDENTS_ADD_NOTE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = eu.parse(s);
      return r.studentService.addStudentNote(i, n);
    });
  }), f.handle(E.STUDENTS_LIST_NOTES, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid student ID").parse(s);
      return r.studentService.listStudentNotes(i, n);
    });
  }), f.handle(E.STUDENTS_CHOOSE_PHOTO_DIALOG, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const s = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const n = r.activeAcademicYear.id, i = e ? await an.showOpenDialog(e, {
        title: "اختر صورة الطالب",
        properties: ["openFile"],
        filters: [{ name: "Images", extensions: ["jpg", "jpeg", "png", "webp"] }]
      }) : { canceled: !0, filePaths: [] };
      if (i.canceled || i.filePaths.length === 0)
        return null;
      const a = x.resolve(i.filePaths[0]);
      Ju();
      const o = await z.promises.stat(a);
      if (!o.isFile())
        throw new Error("INVALID_PHOTO: Not a regular file");
      if (o.size > 10 * 1024 * 1024)
        throw new Error("PHOTO_TOO_LARGE: Photo exceeds maximum allowed size (10 MB)");
      const d = await z.promises.open(a, "r"), u = Buffer.alloc(16);
      await d.read(u, 0, 16, 0), await d.close();
      const l = jp(u);
      if (!l)
        throw new Error("INVALID_PHOTO: Unsupported or corrupted image format. Only JPEG, PNG, and WebP are allowed.");
      const p = await z.promises.readFile(a), N = `data:${l === "jpg" ? "image/jpeg" : l === "png" ? "image/png" : "image/webp"};base64,${p.toString("base64")}`, y = b.randomUUID();
      return Gs.set(y, {
        sourcePath: a,
        userId: s.userId,
        academicYearId: n,
        expiresAt: Date.now() + 600 * 1e3
      }), { photoToken: y, previewUrl: N };
    });
  }), f.handle(E.STUDENTS_PRINT_CARDS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      if (r.requireAuthenticatedActor(), !e)
        throw new Error("WINDOW_NOT_FOUND: Main window is not available for printing");
      e.webContents.print({
        silent: !1,
        printBackground: !0
      });
    });
  }), f.handle(
    E.STUDENTS_EXPORT_CARDS_PDF,
    async (t, s) => {
      if (!A(t, e))
        throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => {
        if (r.requireAuthenticatedActor(), !e)
          throw new Error("WINDOW_NOT_FOUND: Main window is not available for PDF export");
        const n = await e.webContents.printToPDF({
          pageSize: "A4",
          printBackground: !0,
          margins: { top: 0, bottom: 0, left: 0, right: 0 }
        });
        let i = s == null ? void 0 : s.targetPath;
        if (!i) {
          const a = (s == null ? void 0 : s.defaultFilename) || "بطاقات_الطلاب.pdf", o = await an.showSaveDialog(e, {
            title: "حفظ بطاقات الطلاب بصيغة PDF",
            defaultPath: a,
            filters: [{ name: "PDF Documents", extensions: ["pdf"] }]
          });
          if (o.canceled || !o.filePath)
            return { canceled: !0, filePath: "" };
          i = o.filePath;
        }
        return await z.promises.writeFile(i, n), { canceled: !1, filePath: i };
      });
    }
  );
}
function Zp() {
  f.removeHandler(E.STUDENTS_LIST), f.removeHandler(E.STUDENTS_GET_BY_ID), f.removeHandler(E.STUDENTS_CREATE), f.removeHandler(E.STUDENTS_UPDATE), f.removeHandler(E.STUDENTS_ADD_NOTE), f.removeHandler(E.STUDENTS_LIST_NOTES), f.removeHandler(E.STUDENTS_CHOOSE_PHOTO_DIALOG), f.removeHandler(E.STUDENTS_PRINT_CARDS), f.removeHandler(E.STUDENTS_EXPORT_CARDS_PDF);
}
function Wp(r, e) {
  f.handle(E.GROUPS_LIST, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const s = r.requireAuthenticatedActor();
      return r.requireActiveAcademicYear(), r.groupService.listGroups({}, s);
    });
  }), f.handle(E.GROUPS_GET_BY_ID, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid group ID").parse(s);
      return r.groupService.getGroupById(i, n);
    });
  }), f.handle(E.GROUPS_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = nu.parse(s);
      return r.groupService.createGroup(i, n);
    });
  }), f.handle(E.GROUPS_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = ru.parse(s);
      return r.groupService.updateGroup(i, n);
    });
  }), f.handle(E.GROUPS_SET_SCHEDULE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = iu.parse(s);
      return await r.groupService.setWeeklySchedule(i, n), r.groupService.getGroupById(i.groupId, n);
    });
  }), f.handle(E.ENROLLMENTS_LIST_BY_GROUP, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid group ID").parse(s);
      return r.enrollmentService.listGroupEnrollments(i, !1, n);
    });
  }), f.handle(E.ENROLLMENTS_ENROLL, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = au.parse(s);
      return r.enrollmentService.enrollStudent(i, n);
    });
  }), f.handle(E.ENROLLMENTS_UPDATE_PAYMENT, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = ou.parse(s);
      return r.enrollmentService.updateEnrollmentPaymentTerms(i, n);
    });
  }), f.handle(E.ENROLLMENTS_END, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = du.parse(s);
      await r.enrollmentService.endEnrollment(i, n);
    });
  });
}
function ef() {
  f.removeHandler(E.GROUPS_LIST), f.removeHandler(E.GROUPS_GET_BY_ID), f.removeHandler(E.GROUPS_CREATE), f.removeHandler(E.GROUPS_UPDATE), f.removeHandler(E.GROUPS_SET_SCHEDULE), f.removeHandler(E.ENROLLMENTS_LIST_BY_GROUP), f.removeHandler(E.ENROLLMENTS_ENROLL), f.removeHandler(E.ENROLLMENTS_UPDATE_PAYMENT), f.removeHandler(E.ENROLLMENTS_END);
}
function tf(r, e) {
  f.handle(E.SESSIONS_MATERIALIZE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      return r.requireActiveAcademicYear(), Bh().or(Fh()).parse(s), r.sessionService.materializeRollingHorizon({}, n);
    });
  }), f.handle(E.SESSIONS_LIST_BY_RANGE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = lu.parse(s);
      return r.sessionService.listSessionsForDateRange(i, n);
    });
  }), f.handle(E.SESSIONS_RESCHEDULE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = cu.parse(s);
      return r.sessionService.rescheduleSession(i, n);
    });
  }), f.handle(E.SESSIONS_CANCEL, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = uu.parse(s);
      return r.sessionService.cancelSession(i, n);
    });
  }), f.handle(E.SESSIONS_COMPLETE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = fu.parse(s);
      return r.sessionService.completeSession(i, n);
    });
  });
}
function sf() {
  f.removeHandler(E.SESSIONS_MATERIALIZE), f.removeHandler(E.SESSIONS_LIST_BY_RANGE), f.removeHandler(E.SESSIONS_RESCHEDULE), f.removeHandler(E.SESSIONS_CANCEL), f.removeHandler(E.SESSIONS_COMPLETE);
}
function nf(r, e) {
  f.handle(E.DASHBOARD_GET_TODAY, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => (r.requireAuthenticatedActor(), r.requireActiveAcademicYear(), r.dashboardService.getTodayDashboard()));
  });
}
function rf() {
  f.removeHandler(E.DASHBOARD_GET_TODAY);
}
function Ai(r) {
  let e = [];
  if (Array.isArray(r.academicYearsIncluded))
    e = r.academicYearsIncluded;
  else if (r.academicYearsIncludedJson)
    try {
      e = JSON.parse(r.academicYearsIncludedJson);
    } catch {
      e = [];
    }
  return {
    id: r.id,
    backupDate: r.backupDate,
    status: r.status,
    sizeBytes: r.sizeBytes,
    academicYearsIncluded: e,
    createdAt: r.createdAt
  };
}
function af(r, e) {
  f.handle(E.BACKUP_TRIGGER, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      s && dm.parse(s);
      const i = await r.backupService.createManualBackup(n);
      return Ai(i);
    });
  }), f.handle(E.BACKUP_GET_STATUS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => (r.requireAuthenticatedActor(), r.backupService.getBackupStatus()));
  }), f.handle(E.BACKUP_LIST_RECORDS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => (r.requireAuthenticatedActor(), r.backupRecordRepo.listRecent(50).map(Ai)));
  });
}
function of() {
  f.removeHandler(E.BACKUP_TRIGGER), f.removeHandler(E.BACKUP_GET_STATUS), f.removeHandler(E.BACKUP_LIST_RECORDS);
}
let Ri = "system";
function Di(r) {
  return {
    id: r.id,
    name: r.name,
    dbFilename: r.dbFilename,
    isActive: r.isActive,
    isArchived: r.isArchived,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt
  };
}
function df(r, e) {
  f.handle(E.SYSTEM_GET_INFO, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      var s;
      return {
        nameEn: "Tibyan",
        nameAr: "تِبيان",
        version: "1.0.0",
        isPackaged: ((s = It) == null ? void 0 : s.isPackaged) ?? !1,
        platform: process.platform,
        appDataDir: r.paths.appDataDir
      };
    });
  }), f.handle(E.SYSTEM_GET_SETTINGS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      var s, n;
      return {
        theme: Ri,
        activeAcademicYearId: ((s = r.activeAcademicYear) == null ? void 0 : s.id) ?? null,
        activeAcademicYearName: ((n = r.activeAcademicYear) == null ? void 0 : n.name) ?? null
      };
    });
  }), f.handle(E.SYSTEM_GET_SETUP_STATE, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      var a;
      const n = (r.academicYearRepo ? r.authService.userRepo.listAll() : []).some((o) => o.role === "OWNER"), i = r.activeAcademicYear !== null;
      return {
        isSetupComplete: n && i,
        hasOwner: n,
        hasActiveAcademicYear: i,
        activeAcademicYearName: ((a = r.activeAcademicYear) == null ? void 0 : a.name) ?? null
      };
    });
  }), f.handle(E.SYSTEM_UPDATE_THEME, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      Ri = lm.parse(s).theme;
    });
  }), f.handle(E.SYSTEM_LIST_ACADEMIC_YEARS, async (t) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => r.academicYearRepo.listAll().map(Di));
  }), f.handle(E.SYSTEM_CREATE_ACADEMIC_YEAR, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      if (r.currentSession) {
        const w = r.requireAuthenticatedActor();
        te(w.role, w.permissions ?? [], "SETTINGS_WRITE");
      }
      const n = cm.parse(s);
      if (r.academicYearRepo.findByName(n.name))
        throw new Error(`Academic year ${n.name} already exists.`);
      const a = b.randomUUID(), o = (/* @__PURE__ */ new Date()).toISOString(), d = `tibyan-${n.name}.sqlite`, u = r.academicYearRepo.listAll();
      if (u.find((w) => w.dbFilename === d))
        throw new Error(`Academic year database ${d} is already registered.`);
      const p = x.normalize(d);
      if (x.isAbsolute(p) || p.includes("..") || x.basename(p) !== p)
        throw new Error(`SECURITY_ERROR: Invalid academic year dbFilename traversal detected: ${d}`);
      const S = x.resolve(r.paths.academicYearsDbDir), N = r.inMemory ? ":memory:" : x.resolve(S, p);
      if (!r.inMemory && !N.startsWith(S))
        throw new Error(`SECURITY_ERROR: Academic year database path escaped canonical root: ${N}`);
      if (!r.inMemory && z.existsSync(N))
        throw new Error(`DATABASE_FILE_COLLISION: File already exists on disk: ${d}`);
      let y = !1;
      if (!r.inMemory) {
        let w = null;
        try {
          w = Ds(N), y = !0, vc(w);
        } catch (P) {
          if (w != null && w.open && w.close(), y && z.existsSync(N))
            try {
              z.unlinkSync(N);
            } catch {
            }
          throw P;
        } finally {
          w != null && w.open && w.close();
        }
      }
      const I = u.length === 0;
      let L;
      try {
        L = r.academicYearRepo.create({
          id: a,
          name: n.name,
          dbFilename: d,
          isActive: I,
          isArchived: !1,
          createdAt: o,
          updatedAt: o
        });
      } catch (w) {
        if (!r.inMemory && y && z.existsSync(N))
          try {
            z.unlinkSync(N);
          } catch {
          }
        throw w;
      }
      if (I)
        try {
          r.mountAcademicYear(L);
        } catch (w) {
          throw w;
        }
      return Di(L);
    });
  }), f.handle(E.SYSTEM_SWITCH_ACADEMIC_YEAR, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      const n = r.requireAuthenticatedActor();
      te(n.role, n.permissions ?? [], "SETTINGS_WRITE");
      const i = um.parse(s), a = r.academicYearRepo.findById(i.academicYearId);
      if (!a)
        throw new Error("ACADEMIC_YEAR_NOT_FOUND: The requested academic year was not found.");
      r.academicYearRepo.setActiveYear(a.id);
      const o = r.academicYearRepo.findById(a.id);
      r.mountAcademicYear(o);
    });
  }), f.handle(E.SYSTEM_OPEN_WHATSAPP, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = hm.parse(s), a = `https://wa.me/${`20${n.phone.slice(1)}`}?text=${encodeURIComponent(n.message)}`;
      if (!rl(a))
        throw new Error("INVALID_WHATSAPP_URL: URL failed strict security validation.");
      await Od.openExternal(a);
    });
  });
}
function cf() {
  f.removeHandler(E.SYSTEM_GET_INFO), f.removeHandler(E.SYSTEM_GET_SETTINGS), f.removeHandler(E.SYSTEM_GET_SETUP_STATE), f.removeHandler(E.SYSTEM_UPDATE_THEME), f.removeHandler(E.SYSTEM_LIST_ACADEMIC_YEARS), f.removeHandler(E.SYSTEM_CREATE_ACADEMIC_YEAR), f.removeHandler(E.SYSTEM_SWITCH_ACADEMIC_YEAR), f.removeHandler(E.SYSTEM_OPEN_WHATSAPP);
}
function uf(r, e) {
  f.handle(E.ATTENDANCE_GET_ROSTER, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid session ID format").parse(s);
      return r.attendanceService.getSessionRoster(i, n);
    });
  }), f.handle(E.ATTENDANCE_RECORD, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = mu.parse(s);
      return r.attendanceService.recordAttendance(i, n);
    });
  }), f.handle(E.ATTENDANCE_BATCH_RECORD, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = pu.parse(s);
      return r.attendanceService.batchRecordAttendance(i, n);
    });
  }), f.handle(E.ATTENDANCE_GET_END_OF_DAY, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Hs.parse(s);
      return r.attendanceService.getEndOfDayFollowUp(i, n);
    });
  }), f.handle(E.ATTENDANCE_UPDATE_FOLLOW_UP_STATUS, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Eu.parse(s);
      return r.attendanceService.updateFollowUpStatus(i, n);
    });
  });
}
function lf() {
  f.removeHandler(E.ATTENDANCE_GET_ROSTER), f.removeHandler(E.ATTENDANCE_RECORD), f.removeHandler(E.ATTENDANCE_BATCH_RECORD), f.removeHandler(E.ATTENDANCE_GET_END_OF_DAY), f.removeHandler(E.ATTENDANCE_UPDATE_FOLLOW_UP_STATUS);
}
function hf(r, e) {
  function t() {
    if (r.requireActiveAcademicYear(), !r.financeService)
      throw new Error("SERVICE_UNAVAILABLE: Finance service is not initialized");
    return r.financeService;
  }
  f.handle(E.FINANCE_RECORD_PAYMENT, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return t().recordPayment(n, i);
    });
  }), f.handle(E.FINANCE_LIST_STUDENT_PAYMENTS, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().listStudentPayments(n)));
  }), f.handle(E.FINANCE_GET_STUDENT_SUMMARY, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().getStudentFinancialSummary(n)));
  }), f.handle(
    E.FINANCE_LIST_ALL_SUMMARIES,
    async (s, n) => {
      if (!A(s, e))
        throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => (r.requireAuthenticatedActor(), t().listAllSummaries(n)));
    }
  ), f.handle(E.FINANCE_GET_OVERALL_KPI, async (s) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().getOverallFinanceKpi()));
  }), f.handle(E.FINANCE_APPLY_DISCOUNT, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return t().applyDiscount(n, i);
    });
  }), f.handle(E.FINANCE_LIST_DISCOUNTS, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().listDiscounts(n)));
  }), f.handle(E.FINANCE_CREATE_INVOICE, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return t().createInvoice(n, i);
    });
  }), f.handle(E.FINANCE_GET_INVOICE, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().getInvoice(n)));
  }), f.handle(E.FINANCE_LIST_INVOICES, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const i = t();
      return n ? i.listStudentInvoices(n) : i.invoiceRepo.listAll().map(({ invoice: a, items: o }) => ({
        id: a.id,
        invoiceNumber: a.invoiceNumber,
        studentId: a.studentId,
        groupId: a.groupId,
        issueDate: a.issueDate,
        dueDate: a.dueDate,
        periodMonth: a.periodMonth,
        subtotalCents: a.subtotalCents,
        discountCents: a.discountCents,
        totalCents: a.totalCents,
        paidCents: a.paidCents,
        remainingCents: a.remainingCents,
        status: a.status,
        notes: a.notes,
        items: o.map((d) => ({
          id: d.id,
          invoiceId: d.invoiceId,
          description: d.description,
          itemType: d.itemType,
          quantity: d.quantity,
          unitPriceCents: d.unitPriceCents,
          amountCents: d.amountCents,
          sessionId: d.sessionId
        })),
        createdAt: a.createdAt,
        updatedAt: a.updatedAt
      }));
    });
  }), f.handle(E.FINANCE_PRINT_INVOICE, async (s) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      if (r.requireAuthenticatedActor(), !e)
        throw new Error("WINDOW_NOT_FOUND: Main window is not available for printing");
      return e.webContents.print({
        silent: !1,
        printBackground: !0
      }), { printed: !0 };
    });
  }), f.handle(
    E.FINANCE_EXPORT_INVOICE_PDF,
    async (s, n) => {
      if (!A(s, e))
        throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => {
        if (r.requireAuthenticatedActor(), !e)
          throw new Error("WINDOW_NOT_FOUND: Main window is not available for PDF export");
        const i = await e.webContents.printToPDF({
          pageSize: "A4",
          printBackground: !0,
          margins: { top: 0, bottom: 0, left: 0, right: 0 }
        });
        let a = n == null ? void 0 : n.targetPath;
        if (!a) {
          const o = (n == null ? void 0 : n.defaultFilename) || "فاتورة_طالب.pdf", d = await an.showSaveDialog(e, {
            title: "حفظ الفاتورة بصيغة PDF",
            defaultPath: o,
            filters: [{ name: "PDF Documents", extensions: ["pdf"] }]
          });
          if (d.canceled || !d.filePath)
            return { canceled: !0, filePath: "" };
          a = d.filePath;
        }
        return await z.promises.writeFile(a, i), { canceled: !1, filePath: a };
      });
    }
  );
}
function mf() {
  f.removeHandler(E.FINANCE_RECORD_PAYMENT), f.removeHandler(E.FINANCE_LIST_STUDENT_PAYMENTS), f.removeHandler(E.FINANCE_GET_STUDENT_SUMMARY), f.removeHandler(E.FINANCE_LIST_ALL_SUMMARIES), f.removeHandler(E.FINANCE_GET_OVERALL_KPI), f.removeHandler(E.FINANCE_CREATE_INVOICE), f.removeHandler(E.FINANCE_GET_INVOICE), f.removeHandler(E.FINANCE_LIST_INVOICES), f.removeHandler(E.FINANCE_APPLY_DISCOUNT), f.removeHandler(E.FINANCE_LIST_DISCOUNTS), f.removeHandler(E.FINANCE_PRINT_INVOICE), f.removeHandler(E.FINANCE_EXPORT_INVOICE_PDF);
}
function pf(r, e) {
  function t() {
    if (r.requireActiveAcademicYear(), !r.thermalReceiptService)
      throw new Error("SERVICE_UNAVAILABLE: Thermal receipt service is not initialized");
    return r.thermalReceiptService;
  }
  f.handle(E.THERMAL_LIST_PRINTERS, async (s) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      if (r.requireAuthenticatedActor(), !e || !e.webContents)
        return [];
      try {
        return (await e.webContents.getPrintersAsync()).map((i) => ({
          name: i.name,
          displayName: i.displayName || i.name,
          description: i.description || "",
          status: i.status,
          isDefault: i.isDefault
        }));
      } catch {
        return [];
      }
    });
  }), f.handle(E.THERMAL_GET_RECEIPT_DATA, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return t().getThermalReceiptData(n, i);
    });
  }), f.handle(E.THERMAL_PRINT_RECEIPT, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor(), a = t(), o = Rm.parse(n), d = await a.getThermalReceiptData(o.paymentId, i), u = o.settings, l = (u == null ? void 0 : u.paperWidth) === "58mm";
      if ((u == null ? void 0 : u.printMethod) === "ESCPOS_NETWORK") {
        const S = u.networkHost, N = u.networkPort || 9100;
        if (!S)
          throw new Error("NETWORK_PRINTER_HOST_REQUIRED: IP address or hostname is required for network printing");
        const y = ls.buildReceipt(d, {
          paperWidth: l ? "58mm" : "80mm",
          autoCut: u.autoCut ?? !0
        });
        return await er(S, N, y), { success: !0, message: "تم إرسال الإيصال إلى طابعة الشبكة بنجاح" };
      }
      if (!e)
        throw new Error("WINDOW_NOT_FOUND: Main window is not available for printing");
      const p = {
        silent: !0,
        deviceName: (u == null ? void 0 : u.printerName) || void 0,
        copies: (u == null ? void 0 : u.copies) || 1,
        margins: { marginType: "none" },
        pageSize: {
          width: l ? 58e3 : 8e4,
          // microns (58mm or 80mm)
          height: 2e5
          // content-driven roll
        },
        printBackground: !0
      };
      try {
        e.webContents.print(p, (S, N) => {
          !S && N && console.warn("Thermal print warning:", N);
        });
      } catch (S) {
        throw new Error(`PRINT_FAILED: ${S.message || "Failed to trigger system print"}`);
      }
      return { success: !0, message: "تم إرسال الإيصال إلى طابعة النظام بنجاح" };
    });
  }), f.handle(E.THERMAL_TEST_PRINT, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      var N;
      const i = r.requireAuthenticatedActor(), a = Dm.parse(n || {}), o = a.paperWidth || ((N = a.settings) == null ? void 0 : N.paperWidth) || "80mm";
      let d;
      try {
        d = t();
      } catch {
        d = new qu();
      }
      const u = d.generateTestReceiptData(o, i.fullName), l = a.settings, p = o === "58mm";
      if ((l == null ? void 0 : l.printMethod) === "ESCPOS_NETWORK") {
        const y = l.networkHost, I = l.networkPort || 9100;
        if (!y)
          throw new Error("NETWORK_PRINTER_HOST_REQUIRED: IP address or hostname is required for network printing");
        const L = ls.buildReceipt(u, {
          paperWidth: o,
          autoCut: l.autoCut ?? !0
        });
        return await er(y, I, L), { success: !0, message: "تم إرسال إيصال الاختبار إلى طابعة الشبكة بنجاح" };
      }
      if (!e)
        throw new Error("WINDOW_NOT_FOUND: Main window is not available for printing");
      const S = {
        silent: !0,
        deviceName: (l == null ? void 0 : l.printerName) || void 0,
        copies: 1,
        margins: { marginType: "none" },
        pageSize: {
          width: p ? 58e3 : 8e4,
          height: 18e4
        },
        printBackground: !0
      };
      try {
        e.webContents.print(S, (y, I) => {
          !y && I && console.warn("Test print warning:", I);
        });
      } catch (y) {
        throw new Error(`PRINT_FAILED: ${y.message || "Failed to trigger system test print"}`);
      }
      return { success: !0, message: "تم إرسال إيصال الاختبار بنجاح" };
    });
  }), f.handle(E.THERMAL_GENERATE_ESCPOS, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const i = Om.parse(n), a = ls.buildReceipt(i.receipt, {
        paperWidth: i.paperWidth,
        autoCut: i.autoCut
      });
      return {
        base64: a.toString("base64"),
        byteLength: a.length
      };
    });
  }), f.handle(E.THERMAL_PRINT_ESCPOS_NETWORK, async (s, n) => {
    if (!A(s, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const i = wm.parse(n), a = Buffer.from(i.payloadBase64, "base64");
      return await er(i.host, i.port, a), { success: !0, message: "تم إرسال أمر الطباعة عبر الشبكة بنجاح" };
    });
  });
}
function er(r, e, t, s = 5e3) {
  return new Promise((n, i) => {
    const a = new tl.Socket();
    let o = !1;
    a.setTimeout(s);
    const d = () => {
      a.removeAllListeners(), a.destroy();
    };
    a.on("connect", () => {
      a.write(t, (u) => {
        if (u) {
          o || (o = !0, d(), i(new Error(`PRINTER_WRITE_ERROR: ${u.message}`)));
          return;
        }
        a.end(() => {
          o || (o = !0, d(), n());
        });
      });
    }), a.on("timeout", () => {
      o || (o = !0, d(), i(new Error(`PRINTER_CONNECTION_TIMEOUT: Connection to printer at ${r}:${e} timed out after ${s}ms`)));
    }), a.on("error", (u) => {
      o || (o = !0, d(), i(new Error(`PRINTER_NETWORK_ERROR: Unable to connect to printer at ${r}:${e} (${u.message})`)));
    }), a.connect(e, r);
  });
}
function ff() {
  f.removeHandler(E.THERMAL_LIST_PRINTERS), f.removeHandler(E.THERMAL_GET_RECEIPT_DATA), f.removeHandler(E.THERMAL_PRINT_RECEIPT), f.removeHandler(E.THERMAL_TEST_PRINT), f.removeHandler(E.THERMAL_GENERATE_ESCPOS), f.removeHandler(E.THERMAL_PRINT_ESCPOS_NETWORK);
}
function Ef(r, e) {
  f.handle(E.CURRICULUM_LIST_CATALOGS, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = s ? Cm.parse(s) : void 0;
      return r.curriculumService.listCatalogs(i, n);
    });
  }), f.handle(E.CURRICULUM_GET_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid catalog ID").parse(s);
      return r.curriculumService.getCatalog(i, n);
    });
  }), f.handle(E.CURRICULUM_CREATE_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = gu.parse(s);
      return r.curriculumService.createCatalog(i, n);
    });
  }), f.handle(E.CURRICULUM_UPDATE_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = T({
        id: c().uuid("Invalid catalog ID"),
        input: _u
      }), { id: a, input: o } = i.parse(s);
      return r.curriculumService.updateCatalog(a, o, n);
    });
  }), f.handle(E.CURRICULUM_PUBLISH_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid catalog ID").parse(s);
      return r.curriculumService.publishCatalog(i, n);
    });
  }), f.handle(E.CURRICULUM_REVISE_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid catalog ID").parse(s);
      return r.curriculumService.reviseCatalog(i, n);
    });
  }), f.handle(E.CURRICULUM_GET_TREE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid catalog ID").parse(s);
      return r.curriculumService.getTree(i, n);
    });
  }), f.handle(E.CURRICULUM_CREATE_NODE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Nu.parse(s);
      return r.curriculumService.createNode(i, n);
    });
  }), f.handle(E.CURRICULUM_UPDATE_NODE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = T({
        id: c().uuid("Invalid node ID"),
        input: Iu
      }), { id: a, input: o } = i.parse(s);
      return r.curriculumService.updateNode(a, o, n);
    });
  }), f.handle(E.CURRICULUM_DELETE_NODE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid node ID").parse(s);
      return r.curriculumService.deleteNode(i, n);
    });
  }), f.handle(E.CURRICULUM_REORDER_NODES, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Or.parse(s);
      return r.curriculumService.reorderNodes(i, n);
    });
  }), f.handle(E.CURRICULUM_GET_GROUP_OVERVIEW, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid group ID").parse(s);
      return r.curriculumService.getGroupOverview(i, n);
    });
  }), f.handle(E.CURRICULUM_ASSIGN_GROUP_CATALOG, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = yu.parse(s);
      return r.curriculumService.assignGroupCatalog(i, n);
    });
  }), f.handle(E.CURRICULUM_UPDATE_GROUP_PROGRESS, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Tu.parse(s);
      return r.curriculumService.updateGroupNodeProgress(i, n);
    });
  }), f.handle(E.CURRICULUM_GET_GROUP_PROGRESS_MAP, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid group ID").parse(s);
      return r.curriculumService.getGroupProgressMap(i, n);
    });
  });
}
function Sf() {
  f.removeHandler(E.CURRICULUM_LIST_CATALOGS), f.removeHandler(E.CURRICULUM_GET_CATALOG), f.removeHandler(E.CURRICULUM_CREATE_CATALOG), f.removeHandler(E.CURRICULUM_UPDATE_CATALOG), f.removeHandler(E.CURRICULUM_PUBLISH_CATALOG), f.removeHandler(E.CURRICULUM_REVISE_CATALOG), f.removeHandler(E.CURRICULUM_GET_TREE), f.removeHandler(E.CURRICULUM_CREATE_NODE), f.removeHandler(E.CURRICULUM_UPDATE_NODE), f.removeHandler(E.CURRICULUM_DELETE_NODE), f.removeHandler(E.CURRICULUM_REORDER_NODES), f.removeHandler(E.CURRICULUM_GET_GROUP_OVERVIEW), f.removeHandler(E.CURRICULUM_ASSIGN_GROUP_CATALOG), f.removeHandler(E.CURRICULUM_UPDATE_GROUP_PROGRESS), f.removeHandler(E.CURRICULUM_GET_GROUP_PROGRESS_MAP);
}
function gf(r, e) {
  f.handle(E.LESSON_PLAN_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Au.parse(s);
      return r.lessonPlannerService.createLessonPlan(i, n);
    });
  }), f.handle(E.LESSON_PLAN_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const { id: i, input: a } = T({
        id: c().uuid("Invalid lesson plan ID"),
        input: Ru
      }).parse(s);
      return r.lessonPlannerService.updateLessonPlan(i, a, n);
    });
  }), f.handle(E.LESSON_PLAN_GET, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid lesson plan ID").parse(s);
      return r.lessonPlannerService.getLessonPlanById(i, n);
    });
  }), f.handle(E.LESSON_PLAN_LIST_BY_NODE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().min(1).parse(s);
      return r.lessonPlannerService.listLessonPlansByNode(i, n);
    });
  }), f.handle(E.LESSON_PLAN_LIST, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = s ? Ym.parse(s) : void 0;
      return r.lessonPlannerService.listLessonPlans(i, n);
    });
  }), f.handle(E.LESSON_PLAN_ARCHIVE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid lesson plan ID").parse(s);
      return r.lessonPlannerService.archiveLessonPlan(i, n);
    });
  }), f.handle(E.SESSION_REFLECTION_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = Du.parse(s);
      return r.sessionReflectionService.createReflection(i, n);
    });
  }), f.handle(E.SESSION_REFLECTION_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const { id: i, input: a } = T({
        id: c().uuid("Invalid session reflection ID"),
        input: Ou
      }).parse(s);
      return r.sessionReflectionService.updateReflection(i, a, n);
    });
  }), f.handle(E.SESSION_REFLECTION_GET_BY_SESSION, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().min(1).parse(s);
      return r.sessionReflectionService.getReflectionBySessionId(i, n);
    });
  }), f.handle(E.SESSION_REFLECTION_GET, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor();
      r.requireActiveAcademicYear();
      const i = c().uuid("Invalid session reflection ID").parse(s);
      return r.sessionReflectionService.getReflectionById(i, n);
    });
  });
}
function _f() {
  f.removeHandler(E.LESSON_PLAN_CREATE), f.removeHandler(E.LESSON_PLAN_UPDATE), f.removeHandler(E.LESSON_PLAN_GET), f.removeHandler(E.LESSON_PLAN_LIST_BY_NODE), f.removeHandler(E.LESSON_PLAN_LIST), f.removeHandler(E.LESSON_PLAN_ARCHIVE), f.removeHandler(E.SESSION_REFLECTION_CREATE), f.removeHandler(E.SESSION_REFLECTION_UPDATE), f.removeHandler(E.SESSION_REFLECTION_GET_BY_SESSION), f.removeHandler(E.SESSION_REFLECTION_GET);
}
function Nf(r, e) {
  f.handle(E.PDF_SOURCES_LIST, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = c().uuid().optional().parse(s);
      return r.pdfSourceService.listSources(n);
    });
  }), f.handle(E.PDF_SOURCES_GET, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = c().uuid().parse(s);
      return r.pdfSourceService.getSource(n);
    });
  }), f.handle(E.PDF_SOURCES_IMPORT, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = wu.parse(s);
      return r.pdfSourceService.importSource(i, n);
    });
  }), f.handle(E.PDF_SOURCES_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), { id: i, input: a } = T({
        id: c().uuid(),
        input: vu.omit({ id: !0 })
      }).parse(s);
      return r.pdfSourceService.updateSource(i, { id: i, ...a }, n);
    });
  }), f.handle(E.PDF_SOURCES_DELETE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = c().uuid().parse(s);
      r.pdfSourceService.deleteSource(i, n);
    });
  }), f.handle(E.PDF_REFERENCES_LIST, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = c().uuid().optional().parse(s);
      return r.pdfSourceService.listReferences(n);
    });
  }), f.handle(E.PDF_REFERENCES_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Cu.parse(s);
      return r.pdfSourceService.createReference(i, n);
    });
  }), f.handle(E.PDF_REFERENCES_DELETE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = c().uuid().parse(s);
      r.pdfSourceService.deleteReference(i, n);
    });
  }), f.handle(E.PDF_SOURCES_OPEN, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const { id: n } = T({
        id: c().uuid(),
        page: D().int().positive().optional()
      }).parse(s), i = await r.pdfSourceService.getSource(n), a = r.pdfSourceService.resolveAbsolutePath(i.filePath);
      await Od.openPath(a);
    });
  });
}
function If() {
  f.removeHandler(E.PDF_SOURCES_LIST), f.removeHandler(E.PDF_SOURCES_GET), f.removeHandler(E.PDF_SOURCES_IMPORT), f.removeHandler(E.PDF_SOURCES_UPDATE), f.removeHandler(E.PDF_SOURCES_DELETE), f.removeHandler(E.PDF_REFERENCES_LIST), f.removeHandler(E.PDF_REFERENCES_CREATE), f.removeHandler(E.PDF_REFERENCES_DELETE);
}
function yf(r, e) {
  f.handle(E.QUESTION_BANK_LIST, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = s ? bu.parse(s) : void 0;
      return r.questionBankService.listQuestions(n);
    });
  }), f.handle(E.QUESTION_BANK_GET, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = c().uuid().parse(s);
      return r.questionBankService.getQuestion(n);
    });
  }), f.handle(E.QUESTION_BANK_CREATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Uu.parse(s);
      return r.questionBankService.createQuestion(i, n);
    });
  }), f.handle(E.QUESTION_BANK_UPDATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), { id: i, input: a } = T({
        id: c().uuid(),
        input: xu.omit({ id: !0 })
      }).parse(s);
      return r.questionBankService.updateQuestion(i, { id: i, ...a }, n);
    });
  }), f.handle(E.QUESTION_BANK_ARCHIVE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = c().uuid().parse(s);
      r.questionBankService.archiveQuestion(i, n);
    });
  }), f.handle(E.QUESTION_BANK_CHECK_DUPLICATE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const { body: n, curriculumNodeIds: i } = T({
        body: Mh(),
        curriculumNodeIds: J(c().uuid()).default([])
      }).parse(s);
      return r.questionBankService.checkDuplicate(n, i);
    });
  }), f.handle(E.QUESTION_BANK_PREVIEW_BULK, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      r.requireAuthenticatedActor();
      const n = J(Ys()).parse(s);
      return r.questionBankService.previewBulk(n);
    });
  }), f.handle(E.QUESTION_BANK_COMMIT_BULK, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = Lu.parse(s);
      return r.questionBankService.commitBulk(i, n);
    });
  }), f.handle(E.QUESTION_BANK_DELETE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), i = c().uuid().parse(s);
      r.questionBankService.deleteQuestion(i, n);
    });
  }), f.handle(E.QUESTION_BANK_LINK_SOURCES, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), { questionId: i, sourceReferenceIds: a } = T({
        questionId: c().uuid(),
        sourceReferenceIds: J(c().uuid())
      }).parse(s);
      return r.questionBankService.linkSources(i, a, n);
    });
  }), f.handle(E.QUESTION_BANK_UNLINK_SOURCE, async (t, s) => {
    if (!A(t, e))
      throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const n = r.requireAuthenticatedActor(), { questionId: i, sourceReferenceId: a } = T({
        questionId: c().uuid(),
        sourceReferenceId: c().uuid()
      }).parse(s);
      return r.questionBankService.unlinkSource(i, a, n);
    });
  });
}
function Tf() {
  f.removeHandler(E.QUESTION_BANK_LIST), f.removeHandler(E.QUESTION_BANK_GET), f.removeHandler(E.QUESTION_BANK_CREATE), f.removeHandler(E.QUESTION_BANK_UPDATE), f.removeHandler(E.QUESTION_BANK_DELETE), f.removeHandler(E.QUESTION_BANK_ARCHIVE), f.removeHandler(E.QUESTION_BANK_CHECK_DUPLICATE), f.removeHandler(E.QUESTION_BANK_PREVIEW_BULK), f.removeHandler(E.QUESTION_BANK_COMMIT_BULK), f.removeHandler(E.QUESTION_BANK_LINK_SOURCES), f.removeHandler(E.QUESTION_BANK_UNLINK_SOURCE);
}
function Af(r, e) {
  f.handle(E.GEMINI_GET_STATUS, async (t) => {
    if (!A(t, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => op.parse(r.geminiCredentialService.status()));
  }), f.handle(E.GEMINI_SET_CREDENTIAL, async (t, s) => {
    if (!A(t, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      const n = r.requireAuthenticatedActor();
      te(n.role, n.permissions ?? [], "SETTINGS_WRITE"), r.geminiCredentialService.save(ap.parse(s).apiKey);
    });
  }), f.handle(E.GEMINI_DELETE_CREDENTIAL, async (t) => {
    if (!A(t, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(() => {
      const s = r.requireAuthenticatedActor();
      te(s.role, s.permissions ?? [], "SETTINGS_WRITE"), r.geminiCredentialService.clear();
    });
  });
}
function Rf() {
  f.removeHandler(E.GEMINI_GET_STATUS), f.removeHandler(E.GEMINI_SET_CREDENTIAL), f.removeHandler(E.GEMINI_DELETE_CREDENTIAL);
}
function Df(r, e) {
  function t() {
    if (r.requireActiveAcademicYear(), !r.examService)
      throw new Error("SERVICE_UNAVAILABLE: Exam service is not initialized");
    return r.examService;
  }
  f.handle(E.EXAMS_LIST, async (s) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().listExams()));
  }), f.handle(E.EXAMS_GET, async (s, n) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().getExam(n)));
  }), f.handle(E.EXAMS_PREVIEW_ASSEMBLY, async (s, n) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => (r.requireAuthenticatedActor(), t().previewAssembly(n)));
  }), f.handle(E.EXAMS_CONFIRM_ASSEMBLY, async (s, n) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return t().confirmAssembly(n, i);
    });
  }), f.handle(E.EXAMS_UNDO_LAST_MUTATION, async (s, n) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      t().undoLastMutation(n, i);
    });
  }), f.handle(E.EXAMS_PREVIEW_AI_CANDIDATES, async (s, n) => {
    if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
    return R(async () => {
      const i = r.requireAuthenticatedActor();
      return r.aiExamService.previewCandidates(n, i);
    });
  }), f.handle(
    E.EXAMS_RENDER_LAYOUT,
    async (s, n) => {
      if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => (r.requireAuthenticatedActor(), t().renderPrintableHtml(n.examId, n.kind, n.versionLabel)));
    }
  ), f.handle(
    E.EXAMS_PRINT,
    async (s, n) => {
      if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => {
        if (r.requireAuthenticatedActor(), !e) throw new Error("WINDOW_NOT_FOUND: Main window is not available for printing");
        return t().renderPrintableHtml(n.examId, n.kind, n.versionLabel), await e.webContents.print({
          silent: !1,
          printBackground: !0
        }), { success: !0 };
      });
    }
  ), f.handle(
    E.EXAMS_EXPORT_PDF,
    async (s, n) => {
      if (!A(s, e)) throw new Error("UNAUTHORIZED_IPC_SENDER");
      return R(async () => {
        if (r.requireAuthenticatedActor(), !e) throw new Error("WINDOW_NOT_FOUND: Main window is not available for PDF export");
        const i = await e.webContents.printToPDF({
          pageSize: "A4",
          printBackground: !0,
          margins: { top: 0, bottom: 0, left: 0, right: 0 }
        });
        let a = n == null ? void 0 : n.targetPath;
        if (!a) {
          const o = (n == null ? void 0 : n.defaultFilename) || `اختبار_${n.examId.slice(0, 8)}.pdf`, d = await an.showSaveDialog(e, {
            title: "تصدير الاختبار كملف PDF",
            defaultPath: o,
            filters: [{ name: "PDF Documents", extensions: ["pdf"] }]
          });
          if (d.canceled || !d.filePath)
            return { canceled: !0, filePath: "" };
          a = d.filePath;
        }
        return await z.promises.writeFile(a, i), { canceled: !1, filePath: a };
      });
    }
  );
}
function Of() {
  f.removeHandler(E.EXAMS_LIST), f.removeHandler(E.EXAMS_GET), f.removeHandler(E.EXAMS_PREVIEW_ASSEMBLY), f.removeHandler(E.EXAMS_CONFIRM_ASSEMBLY), f.removeHandler(E.EXAMS_UNDO_LAST_MUTATION), f.removeHandler(E.EXAMS_PREVIEW_AI_CANDIDATES), f.removeHandler(E.EXAMS_RENDER_LAYOUT), f.removeHandler(E.EXAMS_PRINT), f.removeHandler(E.EXAMS_EXPORT_PDF);
}
function wf(r, e) {
  Vu(), Qp(r, e), Xp(r, e), Wp(r, e), tf(r, e), uf(r, e), hf(r, e), pf(r, e), Ef(r, e), gf(r, e), Nf(r, e), yf(r, e), nf(r, e), af(r, e), df(r, e), Af(r, e), Df(r, e);
}
function Vu() {
  Kp(), Zp(), ef(), sf(), lf(), mf(), ff(), Sf(), _f(), If(), Tf(), rf(), of(), cf(), Rf(), Of();
}
async function vf(r, e) {
  try {
    if (!e.currentSession)
      return new Response("Unauthorized", { status: 401 });
    if (!zu(e.currentSession.role, e.currentSession.permissions, "STUDENTS_READ"))
      return new Response("Forbidden", { status: 403 });
    if (!e.studentService)
      return new Response("Service Unavailable", { status: 503 });
    const t = r.url;
    if (typeof t != "string" || t.includes("..") || t.includes("\\") || /%2e/i.test(t) || /%5c/i.test(t) || /%2f/i.test(t))
      return new Response("Forbidden", { status: 403 });
    let s;
    try {
      s = new URL(r.url);
    } catch {
      return new Response("Bad Request", { status: 400 });
    }
    if (s.protocol !== "tibyan-media:")
      return new Response("Bad Request", { status: 400 });
    const n = (s.host ? `${s.host}${s.pathname}` : s.pathname).replace(/^\/+/, ""), i = decodeURIComponent(n);
    if (i.includes("..") || i.includes("\\") || i.includes("\0") || x.isAbsolute(i))
      return new Response("Forbidden", { status: 403 });
    if (!i.startsWith("students/"))
      return new Response("Forbidden", { status: 403 });
    const a = e.studentService.photoService.resolveFullPath(i), o = x.resolve(a);
    if (e.activeAcademicYear) {
      const S = x.resolve(
        e.paths.mediaRootDir,
        e.activeAcademicYear.name,
        "students"
      );
      if (!o.startsWith(S))
        return new Response("Forbidden", { status: 403 });
    }
    if (!z.existsSync(o))
      return new Response("Not Found", { status: 404 });
    const d = await z.promises.stat(o);
    if (!d.isFile())
      return new Response("Bad Request", { status: 400 });
    const u = x.extname(o).toLowerCase();
    let l;
    if (u === ".jpg" || u === ".jpeg")
      l = "image/jpeg";
    else if (u === ".png")
      l = "image/png";
    else if (u === ".webp")
      l = "image/webp";
    else
      return new Response("Unsupported Media Type", { status: 415 });
    const p = await z.promises.readFile(o);
    return new Response(p, {
      status: 200,
      headers: {
        "Content-Type": l,
        "Content-Length": String(d.size),
        "Cache-Control": "public, max-age=3600"
      }
    });
  } catch {
    return new Response("Forbidden", { status: 403 });
  }
}
function Cf(r) {
  wd.handle("tibyan-media", (e) => vf(e, r));
}
wd.registerSchemesAsPrivileged([
  {
    scheme: "tibyan-media",
    privileges: {
      standard: !0,
      secure: !0,
      supportFetchAPI: !0,
      corsEnabled: !0,
      stream: !0
    }
  }
]);
const Qu = Zu(import.meta.url), Ps = x.dirname(Qu);
globalThis.__filename = Qu;
globalThis.__dirname = Ps;
const Ku = It.requestSingleInstanceLock();
Ku || It.quit();
let Je = null;
const Dn = new Jp();
async function Oi() {
  const r = z.existsSync(x.join(Ps, "preload.cjs")) ? x.join(Ps, "preload.cjs") : x.join(Ps, "preload.js");
  Je = new vd({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 700,
    title: "تِبيان — نظام إدارة المعلم",
    backgroundColor: "#0B3D3D",
    autoHideMenuBar: !0,
    webPreferences: {
      ...sl,
      preload: r
    }
  }), Je.setMenuBarVisibility(!1), Je.removeMenu();
  const e = process.env.VITE_DEV_SERVER_URL;
  return nl(Je, { allowedDevOrigin: e }), il(Je.webContents.session, Je), wf(Dn, Je), e ? await Je.loadURL(e) : await Je.loadFile(x.join(Ps, "../dist/index.html")), Je.on("closed", () => {
    Je = null;
  }), Je;
}
It.on("second-instance", () => {
  Je && (Je.isMinimized() && Je.restore(), Je.focus());
});
It.on("window-all-closed", () => {
  process.platform !== "darwin" && It.quit();
});
It.on("before-quit", () => {
  Vu(), Dn.close();
});
Ku && It.whenReady().then(async () => {
  Wu.setApplicationMenu(null), Dn.initialize(), Cf(Dn), await Oi(), It.on("activate", async () => {
    vd.getAllWindows().length === 0 && await Oi();
  });
});
export {
  Dn as runtime
};
