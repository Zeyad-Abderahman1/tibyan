import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  dialect: 'sqlite',
  schema: './src/schema/academic.schema.ts',
  out: './src/migrations/academic',
});
